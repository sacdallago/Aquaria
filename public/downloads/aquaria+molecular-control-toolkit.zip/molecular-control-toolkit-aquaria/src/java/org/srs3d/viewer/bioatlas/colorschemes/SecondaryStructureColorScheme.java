/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.colorschemes;

import java.util.Collection;
import java.util.Map;
import java.util.Vector;

import javax.media.j3d.Appearance;
import javax.vecmath.Color3f;

import org.srs3d.viewer.bioatlas.objects.Coil;
import org.srs3d.viewer.bioatlas.objects.Helix;
import org.srs3d.viewer.bioatlas.objects.NucleicChain;
import org.srs3d.viewer.bioatlas.objects.Strand;
import org.srs3d.viewer.bioatlas.objects.Subchain;
import org.srs3d.viewer.bioatlas.objects.Turn;
import org.srs3d.viewer.j3d.AbstractColorScheme;
import org.srs3d.viewer.j3d.AppearanceHelper;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.objects.ObjectManager;

/**
 * The <code>SecondaryStructureColorScheme</code> represents a standard color sheme.
 *
 * @author Karsten Klein
 *
 * @created March 20, 2001
 */
public class SecondaryStructureColorScheme extends AbstractColorScheme {
    private Color3f helixColor = new Color3f(1.0f, 0.1f, 0.1f);
    private Color3f strandColor = new Color3f(0.1f, 0.7f, 0.1f);
    private Color3f coilColor = new Color3f(0.8f, 0.8f, 0.8f);
    private Color3f turnColor = new Color3f(0.9f, 0.6f, 0.1f);
    private Color3f naColor = new Color3f(0.3f, 0.3f, 1.0f);
    private Color3f subchainColor = new Color3f(0.6f, 0.9f, 0.0f);

    /**
     * Constructor description.
     *
     * @param contextData Parameter description.
     */
    public SecondaryStructureColorScheme(ContextData contextData) {
        super(contextData);
    }

    /**
     * Description of the Method
     *
     * @param object Description of Parameter
     * @param appearance Description of parameter.
     */
    public boolean modify(AbstractObject object, Appearance appearance) {
        Collection collection = new Vector();
        getContextData().getObjectManager().getAssociations(object, collection);
        collection.add(object);
        ObjectManager.extract(collection, Subchain.class);
        if (!collection.isEmpty()) {
            Color3f color = null;
            Subchain subchain = (Subchain) collection.iterator().next();
            switch (subchain.getCode()) {

                case Coil.CODE:
                    color = coilColor;
                    break;

                case Helix.CODE:
                    color = helixColor;
                    break;

                case Strand.CODE:
                    color = strandColor;
                    break;

                case NucleicChain.CODE:
                    color = naColor;
                    break;

                case Turn.CODE:
                    color = turnColor;
                    break;

                default:
                    color = subchainColor;
                    break;
            }
            Color3f newColor = new Color3f(color);
            newColor.scale(getColorScale());
            AppearanceHelper.modifyAppearance(appearance, newColor);
            AppearanceHelper.enableVertexColors(appearance, false);
            return true;
        }
        return false;
    }

    /**
     * Method description.
     *
     * @param map Parameter description.
     *
     * @return Return description.
     */
    public Map getInformation(Map map) {
        map = super.getInformation(map);
        Color3f color;
        color = new Color3f(helixColor);
        color.scale(getLegendColorScale());
        map.put("helix", color);
        color = new Color3f(strandColor);
        color.scale(getLegendColorScale());
        map.put("strand", color);
        color = new Color3f(turnColor);
        color.scale(getLegendColorScale());
        map.put("turn", color);
        color = new Color3f(coilColor);
        color.scale(getLegendColorScale());
        map.put("coil", color);
        color = new Color3f(naColor);
        color.scale(getLegendColorScale());
        map.put("DNA/RNA", color);
        Vector vector = new Vector();
        vector.add("helix");
        vector.add("strand");
        vector.add("turn");
        vector.add("coil");
        vector.add("DNA/RNA");
        map.put("ORDER", vector);
        map.put("NAME", "Secondary Structure");
        return map;
    }
}
