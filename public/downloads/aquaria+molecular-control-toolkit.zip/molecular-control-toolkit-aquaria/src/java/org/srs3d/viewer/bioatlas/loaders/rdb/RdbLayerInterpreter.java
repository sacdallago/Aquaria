/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.loaders.rdb;

import java.util.Map;

import javax.vecmath.Vector3f;

import org.srs3d.viewer.bioatlas.objects.Layer;
import org.srs3d.viewer.objects.ObjectContainer;

/**
 * The RdbLayerInterpreter class.
 *
 * @author Karsten Klein
 *
 * @created December 10, 2001
 */
public class RdbLayerInterpreter implements RdbInterpreter {

    /**
     * Interpretes then data in the fieldMap and creates a layer that is stored in the
     * specified object container.
     *
     * @param fieldMap Maps field identifiers to field content.
     * @param objectContainer Destination of the interpreted data.
     */
    public void interprete(Map fieldMap, ObjectContainer objectContainer) {
        if (!fieldMap.isEmpty()) {
            Layer layer = new Layer();
            String string;
            string = (String) fieldMap.get("DESCRIPTION");
            if (string != null) {
                layer.setDescription(string);
            }
            string = (String) fieldMap.get("PDB");
            if (string != null) {
                layer.addId("PDB", string);
                layer.setId(string);
            }
            string = (String) fieldMap.get("SWISSPROT");
            if (string != null) {
                layer.addId("SWISSPROT", string);
            }
            string = (String) fieldMap.get("INTERPRO");
            if (string != null) {
                layer.addId("INTERPRO", string);
            }
            Vector3f coordinate = new Vector3f();
            string = (String) fieldMap.get("X");
            if (string != null) {
                coordinate.x = Float.parseFloat(string);
            }
            string = (String) fieldMap.get("Y");
            if (string != null) {
                coordinate.y = Float.parseFloat(string);
            }
            string = (String) fieldMap.get("Z");
            if (string != null) {
                coordinate.z = Float.parseFloat(string);
            }
            layer.setCoordinate(coordinate);
            Vector3f orientation = new Vector3f();
            string = (String) fieldMap.get("U");
            if (string != null) {
                orientation.x = Float.parseFloat(string);
            }
            string = (String) fieldMap.get("V");
            if (string != null) {
                orientation.y = Float.parseFloat(string);
            }
            string = (String) fieldMap.get("W");
            if (string != null) {
                orientation.z = Float.parseFloat(string);
            }
            layer.setOrientation(orientation);
            objectContainer.addObject(layer);
        }
    }

    /**
     * Method description.
     *
     * @param objectContainer Parameter description.
     */
    public void finalizeInterpretation(ObjectContainer objectContainer) {
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public static String getInterpreterId() {
        return "LAYER";
    }
}
