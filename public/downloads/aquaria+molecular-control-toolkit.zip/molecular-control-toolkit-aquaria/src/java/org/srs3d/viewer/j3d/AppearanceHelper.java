/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d;

import java.io.IOException;

import javax.media.j3d.Appearance;
import javax.media.j3d.CapabilityNotSetException;
import javax.media.j3d.ColoringAttributes;
import javax.media.j3d.GLSLShaderProgram;
import javax.media.j3d.LineAttributes;
import javax.media.j3d.Material;
import javax.media.j3d.PointAttributes;
import javax.media.j3d.PolygonAttributes;
import javax.media.j3d.RenderingAttributes;
import javax.media.j3d.Shader;
import javax.media.j3d.ShaderAppearance;
import javax.media.j3d.ShaderAttributeObject;
import javax.media.j3d.ShaderAttributeSet;
import javax.media.j3d.ShaderAttributeValue;
import javax.media.j3d.ShaderProgram;
import javax.media.j3d.SourceCodeShader;
import javax.media.j3d.Texture;
import javax.media.j3d.TextureAttributes;
import javax.media.j3d.TextureUnitState;
import javax.media.j3d.TransparencyAttributes;
import javax.media.j3d.VirtualUniverse;
import javax.vecmath.Color3f;
import javax.vecmath.Color4f;

import org.srs3d.viewer.util.Log;

import com.sun.j3d.utils.shader.StringIO;

/**
 * This classes provides a set of methods to be used in with the java3d appearance class.
 * For performance reasons the helper provides defaults as shared attributes. That means
 * modifying a appearances attributes can also modify the appearance of other objects.
 * If one wants to change an attribute of an appearance, he has to fully replace that
 * attribute by a new one. The user has to be very careful about which attributes should
 * be read-only and which not. The shared instances provided by this class cannot be
 * modified at all. They have to be replaced by new instances. One problem with new
 * instances is that the overhead in copying the content of an attribute can easily
 * grow. Therefore the scope of this classes and its methods is rather limited to the
 * current needs.
 *
 * @author Karsten Klein
 *
 * @created March 20, 2001
 */
public final class AppearanceHelper {
    private static final Log log = new Log(AppearanceHelper.class);
    public static final float EPSILON_TRANSPARENCY = 0.02f;
    public static float SHININESS = 20.0f;
    private static boolean isVerbose = false;
    private static Color3f specularColor = new Color3f(0.6f, 0.6f, 0.6f);
    public static final int JAVA3D_1_2 = 0;
    public static final int JAVA3D_1_3 = 1;
    public static int java3DVersion = JAVA3D_1_3;
    public static final String JAVA3D_1_2_PREFIX = "1.2";
//    private static Color3f silver    = new Color3f(0.75f, 0.75f, 0.75f);
    private static ShaderProgram shaderProgram = null;
    private static ShaderAttributeSet shaderAttributeSet = null;
    static final String[] shaderAttrNames0 = {
    	"normal"
    };
//    static final String[] shaderAttrNames1 = {
//        "Density", "Size", "LightPosition", "Color"
//    };
    static final String[] shaderAttrNames1 = {
    	"Color"
  };


    static enum SHADER {
    	PLAIN,
    	BLOOM
    }

    /**
     * Sets the capabilities of the appearance to the defaults. We have to enable all the
     * capabilities we are going to use.
     *
     * @param appearance The new <code>DefaultCapabilities</code> value
     */
    public static final void setDefaultCapabilities(Appearance appearance) {

        // :FUTURE: Java3D 1.3 has some "frequently used bits" that one can set for
        //   preveneting wrong optimization attempts
        appearance.setCapability(Appearance.ALLOW_TEXTURE_READ);
        appearance.setCapability(Appearance.ALLOW_TEXTURE_WRITE);
        appearance.setCapability(Appearance.ALLOW_TEXTURE_ATTRIBUTES_READ);
        appearance.setCapability(Appearance.ALLOW_TEXTURE_ATTRIBUTES_WRITE);
        appearance.setCapability(Appearance.ALLOW_TEXTURE_UNIT_STATE_READ);
        appearance.setCapability(Appearance.ALLOW_TEXTURE_UNIT_STATE_WRITE);
        appearance.setCapability(Appearance.ALLOW_COLORING_ATTRIBUTES_READ);
        appearance.setCapability(Appearance.ALLOW_COLORING_ATTRIBUTES_WRITE);
        appearance.setCapability(Appearance.ALLOW_MATERIAL_READ);
        appearance.setCapability(Appearance.ALLOW_MATERIAL_WRITE);
        appearance.setCapability(Appearance.ALLOW_RENDERING_ATTRIBUTES_READ);
        appearance.setCapability(Appearance.ALLOW_RENDERING_ATTRIBUTES_WRITE);
        appearance.setCapability(Appearance.ALLOW_LINE_ATTRIBUTES_READ);
        appearance.setCapability(Appearance.ALLOW_LINE_ATTRIBUTES_WRITE);
        appearance.setCapability(Appearance.ALLOW_POINT_ATTRIBUTES_READ);
        appearance.setCapability(Appearance.ALLOW_POINT_ATTRIBUTES_WRITE);
        appearance.setCapability(Appearance.ALLOW_TRANSPARENCY_ATTRIBUTES_READ);
        appearance.setCapability(Appearance.ALLOW_TRANSPARENCY_ATTRIBUTES_WRITE);
        appearance.setCapability(Appearance.ALLOW_POLYGON_ATTRIBUTES_READ);
        appearance.setCapability(Appearance.ALLOW_POLYGON_ATTRIBUTES_WRITE);
    }

    /**
     * Sets the <code>Defaults</code> attribute of the <code>AppearanceHelper
     * </code>class
     *
     * @param appearance The new <code>Defaults</code> value
     */
    public static final void setDefaults(Appearance appearance) {

        // create colors used as defaults
        Color3f color = new Color3f(0.5f, 0.5f, 0.5f);

        // create default coloring attributes
        ColoringAttributes coloringAttributes =
            new ColoringAttributes(color, ColoringAttributes.NICEST);
        coloringAttributes.setCapability(ColoringAttributes.ALLOW_COLOR_READ);
        coloringAttributes.setCapability(ColoringAttributes.ALLOW_COLOR_WRITE);

        // create default material
        Material material = new Material();
        material.setAmbientColor(color);
        material.setDiffuseColor(color);
        material.setSpecularColor(specularColor);
        material.setShininess(SHININESS);
        material.setCapability(Material.ALLOW_COMPONENT_READ);
        material.setCapability(Material.ALLOW_COMPONENT_WRITE);

        // create default rendering attributes
        RenderingAttributes renderingAttributes = new RenderingAttributes();

        // :CHECK: whether we needs these set by default
        renderingAttributes.setIgnoreVertexColors(true);
        renderingAttributes.setCapability(RenderingAttributes.ALLOW_IGNORE_VERTEX_COLORS_READ);
        renderingAttributes.setCapability(RenderingAttributes.ALLOW_IGNORE_VERTEX_COLORS_WRITE);
        appearance.setRenderingAttributes(renderingAttributes);
        appearance.setColoringAttributes(coloringAttributes);
        appearance.setMaterial(material);
        setDefaultCapabilities(appearance);
    }

    /**
     * Sets the default texture attributes for the specified texture in the appearance.
     *
     * @param appearance Appearance to modify; can be null, but rather use the
     *        enableTexture() method for turning off texturing.
     * @param texture Texture to use.
     */
    public static final void setTextureDefaults(Appearance appearance,
        Texture texture) {
        try {
            appearance.setTexture(texture);
            TextureAttributes textureAttributes = new TextureAttributes();
            textureAttributes.setTextureMode(TextureAttributes.MODULATE);
            textureAttributes.setPerspectiveCorrectionMode(TextureAttributes.FASTEST);
            TextureUnitState[] textureUnitState = new TextureUnitState[1];
            textureUnitState[0] =
                new TextureUnitState(texture, textureAttributes, null);
            textureUnitState[0].setCapability(TextureUnitState.ALLOW_STATE_WRITE);
            textureUnitState[0].setCapability(TextureUnitState.ALLOW_STATE_READ);
            appearance.setTextureAttributes(textureAttributes);
            appearance.setTextureUnitState(textureUnitState);
            enableTexture(appearance, texture, true);
        } catch (CapabilityNotSetException e) {
            if (isVerbose()) {
                log.error("cannot set texture defaults.", e);
            }
        }
    }

    /**
     * Sets the <code>TextureDefaults</code> attribute of the
     * <code>AppearanceHelper</code> class
     *
     * @param appearance The appearance to modify.
     * @param texture The texture to be used for the appearance.
     * @param transparency Transparency value (1.0f is opaque).
     */
    public static final void setTextureDefaults(Appearance appearance,
        Texture texture, float transparency) {
        setTextureDefaults(appearance, texture);
        enableTransparency(appearance, transparency);
    }

    /**
     * Sets the <code>verbose</code> attribute of the <code>AppearanceHelper</code>
     * class.
     *
     * @param isVerbose The new <code>verbose</code> value.
     */
    public static void setVerbose(boolean isVerbose) {
        AppearanceHelper.isVerbose = isVerbose;
    }

    /**
     * Gets the <code>color</code> attribute of the <code>AppearanceHelper</code> class.
     *
     * @param appearance Description of parameter.
     * @param color Description of parameter.
     */
    public static void getColor(Appearance appearance, Color3f color) {
        color.x = color.y = color.z = 0;
        try {
            if (appearance.getColoringAttributes() != null) {
                appearance.getColoringAttributes().getColor(color);
            }
        } catch (CapabilityNotSetException e) {
            if (isVerbose()) {
                log.error("cannot retrieve color.", e);
            }
        }
    }

    /**
     * Gets the <code>color</code> attribute of the <code>AppearanceHelper</code> class.
     *
     * @param appearance Description of parameter.
     * @param color Description of parameter.
     */
    public static void getColor(Appearance appearance, Color4f color) {
        Color3f c = new Color3f();
        getColor(appearance, c);
        color.x = c.x;
        color.y = c.y;
        color.z = c.z;
        try {
            if (appearance.getTransparencyAttributes() != null) {
                color.w =
                    appearance.getTransparencyAttributes().getTransparency();
                if (color.w < EPSILON_TRANSPARENCY) {
                    color.w = 0;
                }
            }
        } catch (CapabilityNotSetException e) {
            if (isVerbose()) {
                log.error("cannot retrieve color.", e);
            }
        }
    }

    /**
     * Gets the <code>verbose</code> attribute of the <code>AppearanceHelper</code>
     * class.
     *
     * @return The <code>verbose</code> value.
     */
    public static boolean isVerbose() {
        return isVerbose;
    }

    /**
     * Description of the method.
     *
     * @param appearance Description of parameter.
     * @param transparency Description of parameter.
     */
    public static final void enableTransparency(Appearance appearance,
        float transparency) {
        enableTransparency(appearance, transparency, false);
    }

    /**
     * Enables the transparency for the given appearance object. Note that a transparency
     * of 0 renders a fully opaque object. In the case of transparency set to zero, the
     * transparency attributes are removed. This behavior can be switched off by the
     * isCreate flag. IsCreate of value <code>true</code> will always create
     * transparency attributes for the appearance;
     *
     * @param appearance Appearance for the modification.
     * @param transparency Transparency value.
     * @param isCreate Description of parameter.
     */
    public static final void enableTransparency(Appearance appearance,
        float transparency, boolean isCreate) {
        try {
            if (isCreate || transparency > EPSILON_TRANSPARENCY) {
                TransparencyAttributes transparencyAttributes =
                    new TransparencyAttributes(TransparencyAttributes.BLENDED,
                        transparency);
                appearance.setTransparencyAttributes(transparencyAttributes);
                transparencyAttributes.setCapability(TransparencyAttributes.ALLOW_VALUE_READ);
                transparencyAttributes.setCapability(TransparencyAttributes.ALLOW_VALUE_WRITE);
                transparencyAttributes.setCapability(TransparencyAttributes.ALLOW_MODE_WRITE);
            } else {
                appearance.setTransparencyAttributes(null);
            }
        } catch (CapabilityNotSetException e) {
            if (isVerbose()) {
                log.error("cannot enable transparency.", e);
            }
        }
    }

    /**
     * Description of the method.
     *
     * @param appearance Description of parameter.
     * @param texture Description of parameter.
     * @param isEnable Description of parameter.
     */
    public static final void enableTexture(Appearance appearance,
        Texture texture, boolean isEnable) {
        if (appearance.getTexture() != null) {
            appearance.getTexture().setEnable(isEnable);
        }
        if (isEnable) {
            appearance.setTexture(texture);
            appearance.getTextureUnitState(0).setTexture(texture);
            TextureAttributes textureAttributes = new TextureAttributes();
            textureAttributes.setTextureMode(TextureAttributes.MODULATE);
            textureAttributes.setPerspectiveCorrectionMode(TextureAttributes.FASTEST);
            appearance.setTextureAttributes(textureAttributes);
            appearance.getTextureUnitState(0).setTextureAttributes(textureAttributes);
        } else {
            appearance.setTexture(null);
            appearance.getTextureUnitState(0).setTexture(null);
            appearance.getTextureUnitState(0).setTextureAttributes(null);
            appearance.setTextureAttributes(null);
        }
    }

    /**
     * Description of the method.
     *
     * @param appearance Description of parameter.
     * @param enable Description of parameter.
     */
    public static void enableVertexColors(Appearance appearance, boolean enable) {
        if (enable != areVertexColorsEnabled(appearance)) {
            RenderingAttributes renderingAttributes = null;
            try {
                renderingAttributes = appearance.getRenderingAttributes();
            } catch (CapabilityNotSetException e) {
                if (isVerbose()) {
                    log.error("cannot dis-/enable vertex colors.", e);
                }
            }
            if (renderingAttributes == null) {
                renderingAttributes = createRenderingAttributes(enable);
                try {
                    appearance.setRenderingAttributes(renderingAttributes);
                } catch (CapabilityNotSetException e) {
                    if (isVerbose()) {
                        log.error("cannot dis-/enable vertex colors.", e);
                    }
                }
            } else {
                try {
                    renderingAttributes.setIgnoreVertexColors(!enable);
                } catch (CapabilityNotSetException e) {

                    // assuming it's a default attribute, we don't care about
                    // the other attribute content
                    renderingAttributes = createRenderingAttributes(enable);
                    try {
                        appearance.setRenderingAttributes(renderingAttributes);
                    } catch (CapabilityNotSetException ee) {
                        if (isVerbose()) {
                            log.error("cannot dis-/enable vertex colors.", e);
                        }
                    }
                }
            }
        }
    }

    /**
     * Description of the method.
     *
     * @param appearance Description of parameter.
     *
     * @return Description of the returned value.
     */
    public static boolean areVertexColorsEnabled(Appearance appearance) {
        RenderingAttributes renderingAttributes = null;
        try {
            renderingAttributes = appearance.getRenderingAttributes();
            if (renderingAttributes != null) {
                return !renderingAttributes.getIgnoreVertexColors();
            }
        } catch (CapabilityNotSetException e) {
            if (isVerbose()) {
                log.error("cannot retrieve vertex color setting.", e);
            }
        }
        return false;
    }

    /**
     * Description of the method.
     *
     * @param color Description of parameter.
     *
     * @return Description of the returned value.
     */
    public static Appearance createAppearance(Color4f color) {
        Appearance appearance =
            createAppearance(new Color3f(color.x, color.y, color.z));
        enableTransparency(appearance, color.w);
        return appearance;
    }
    
	private static ShaderProgram createGLSLShaderProgram(SHADER index) {
		String vertexProgram = null;
		String fragmentProgram = null;
		try {
			switch (index) {
			case PLAIN:
				vertexProgram = StringIO.readFully(AppearanceHelper.class.getResource("shaders/myShader.vert"));
				fragmentProgram = StringIO.readFully(AppearanceHelper.class.getResource("shaders/myShader.frag"));
				break;
			case BLOOM:
				vertexProgram = StringIO.readFully(AppearanceHelper.class.getResource("shaders/dimple.vert"));
				fragmentProgram = StringIO.readFully(AppearanceHelper.class.getResource("shaders/dimple.frag"));
				break;
			}
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
		Shader[] shaders = new Shader[2];
		shaders[0] = new SourceCodeShader(Shader.SHADING_LANGUAGE_GLSL,
				Shader.SHADER_TYPE_VERTEX, vertexProgram);
		shaders[1] = new SourceCodeShader(Shader.SHADING_LANGUAGE_GLSL,
				Shader.SHADER_TYPE_FRAGMENT, fragmentProgram);
		ShaderProgram shaderProgram = new GLSLShaderProgram();
		shaderProgram.setShaders(shaders);
		return shaderProgram;
	}
    
    private static ShaderAttributeSet createShaderAttributeSet(Color3f color) {
//    	System.out.println("The colour is: "  + color);
        ShaderAttributeSet shaderAttributeSet = new ShaderAttributeSet();
        ShaderAttributeObject shaderAttribute = null;
        
        //  "Density", "Size", "Scale", "Color", "LightPosition"
//        shaderAttribute = new ShaderAttributeValue("Size", new Float(0.25));
//        shaderAttributeSet.put(shaderAttribute);
//        shaderAttribute = new ShaderAttributeValue("LightPosition",
//                new Point3f(0.0f, 0.0f, 0.5f));
//        shaderAttributeSet.put(shaderAttribute);
//        
////        color = new Color3f(1.0f,0.0f,0.0f);
//        ShaderAttributeObject sao1 = new ShaderAttributeValue("Density", new Float(0));
//        sao1.setCapability(ShaderAttributeObject.ALLOW_VALUE_READ);
//        sao1.setCapability(ShaderAttributeObject.ALLOW_VALUE_WRITE);
//        shaderAttributeSet.put(sao1);
        ShaderAttributeObject sao2 = new ShaderAttributeValue("Color", color);
//        System.out.println("Initial colour:" + sao2 + ", colour" + color);

        sao2.setCapability(ShaderAttributeObject.ALLOW_VALUE_READ);
        sao2.setCapability(ShaderAttributeObject.ALLOW_VALUE_WRITE);
        shaderAttributeSet.put(sao2);     
        
        shaderAttributeSet.setCapability(ShaderAttributeSet.ALLOW_ATTRIBUTES_READ);
        shaderAttributeSet.setCapability(ShaderAttributeSet.ALLOW_ATTRIBUTES_WRITE);

//        sao2.setValue(new Color3f(1.0f, 0f, 0f));
        return shaderAttributeSet;
    }

    public static ShaderProgram createShaderProgram() {
    	
    	ShaderProgram sp1 = createGLSLShaderProgram(SHADER.BLOOM);
        sp1.setShaderAttrNames(shaderAttrNames1);
        return sp1;
    }
    
    public static ShaderProgram getShaderProgram() {
    	if (shaderProgram == null) {
    		shaderProgram = createShaderProgram();
    	}
    	return shaderProgram;
    }


    /**
     * Description of the method
     *
     * @param color Description of parameter
     *
     * @return Description of the returned value
     */
    public static Appearance createAppearance(Color3f color) {
        ShaderAppearance appearance = new ShaderAppearance();
//        Appearance appearance = new Appearance();
        AppearanceHelper.setDefaultCapabilities(appearance);
        AppearanceHelper.setDefaults(appearance);
        
//        appearance.setCapability(ShaderAppearance.ALLOW_SHADER_PROGRAM_READ);
//        appearance.setCapability(ShaderAppearance.ALLOW_SHADER_PROGRAM_WRITE);
//        appearance.setCapability(ShaderAppearance.ALLOW_SHADER_ATTRIBUTE_SET_READ);
//        appearance.setCapability(ShaderAppearance.ALLOW_SHADER_ATTRIBUTE_SET_WRITE);
//
//        appearance.setShaderProgram(getShaderProgram());
//        appearance.setShaderAttributeSet(createShaderAttributeSet(color));
        
        ColoringAttributes coloringAttributes =
            new ColoringAttributes(color, ColoringAttributes.SHADE_GOURAUD);
        coloringAttributes.setCapability(ColoringAttributes.ALLOW_COLOR_READ);
        coloringAttributes.setCapability(ColoringAttributes.ALLOW_COLOR_WRITE);
        appearance.setColoringAttributes(coloringAttributes);
        Material material = new Material();
        material.setAmbientColor(color);
        material.setDiffuseColor(color);
        material.setSpecularColor(specularColor);
        material.setShininess(SHININESS);
        appearance.setMaterial(material);
        material.setCapability(Material.ALLOW_COMPONENT_READ);
        material.setCapability(Material.ALLOW_COMPONENT_WRITE);
        return appearance;
    }

    /**
     * Description of the method.
     *
     * @param appearance Description of parameter.
     * @param color Description of parameter.
     */
    public static void modifyAppearance(Appearance appearance, final Color3f color) {
        try {
//        	System.out.println("Modifying appearance color: " + color);
//            System.out.println("existing color: " + ((ShaderAppearance)appearance).getShaderAttributeSet().getAll()[2].);// ("Color").getUserData());
//        	final ShaderAttributeObject sao = ((ShaderAttributeObject)((ShaderAppearance)appearance).getShaderAttributeSet().get("Color"));
        	
            appearance.getColoringAttributes().setColor(color);
            appearance.getMaterial().setDiffuseColor(color);
            appearance.getMaterial().setAmbientColor(color);
            appearance.getMaterial().setSpecularColor(specularColor);
            appearance.getMaterial().setShininess(SHININESS);
            
           
            
//        	System.out.println("sao colour1: "+ sao.getValue());
//           	sao.setValue(color);

//        	System.out.println("sao colour2: "+ sao.getValue() + " sao: " + sao);
        } catch (CapabilityNotSetException e) {
            if (isVerbose()) {
                log.error("cannot modify appearance.", e);
            }
        }
    }

    /**
     * Description of the method.
     *
     * @param appearance Description of parameter.
     * @param color Description of parameter.
     */
    public static void modifyAppearance(Appearance appearance, Color4f color) {
    	System.out.println("Modifying appearance color4: " + color);
        Color3f c = new Color3f(color.x, color.y, color.z);
        modifyAppearance(appearance, c);
        enableTransparency(appearance, color.w);
//        ((ShaderAppearance)appearance).getShaderAttributeSet().get("Color").setUserData(c);
    }

    /**
     * Description of the method.
     *
     * @param appearance Description of parameter.
     * @param minWidth Description of parameter.
     * @param increase Description of parameter.
     */
    public static void modifyLineWidth(Appearance appearance, float minWidth,
        float increase) {
        LineAttributes lineAttributes = null;
        float width = minWidth;
        try {
            lineAttributes = appearance.getLineAttributes();
            if (lineAttributes != null) {
                width = lineAttributes.getLineWidth() + increase;
                if (minWidth > width) {
                    width = minWidth;
                }
            }
        } catch (CapabilityNotSetException e) {
            if (isVerbose()) {
                log.error("cannot modify line width.", e);
            }
        }
        try {
            if (lineAttributes == null) {
                lineAttributes = new LineAttributes();
                lineAttributes.setCapability(LineAttributes.ALLOW_WIDTH_READ);
                lineAttributes.setCapability(LineAttributes.ALLOW_WIDTH_WRITE);
                lineAttributes.setCapability(LineAttributes.ALLOW_PATTERN_READ);
                lineAttributes.setCapability(LineAttributes.ALLOW_PATTERN_WRITE);
            }
            lineAttributes.setLineWidth(width);
            appearance.setLineAttributes(lineAttributes);
        } catch (CapabilityNotSetException e) {
            if (isVerbose()) {
                log.error("cannot modify line width.", e);
            }
        }
    }

    /**
     * Description of the method.
     *
     * @param appearance Description of parameter.
     * @param minSize Description of parameter.
     * @param increase Description of parameter.
     */
    public static void modifyPointSize(Appearance appearance, float minSize,
        float increase) {
        PointAttributes pointAttributes = null;
        float size = minSize;
        try {
            pointAttributes = appearance.getPointAttributes();
            if (pointAttributes != null) {
                size = pointAttributes.getPointSize() + increase;
                if (minSize > size) {
                    size = minSize;
                }
            }
        } catch (CapabilityNotSetException e) {
            if (isVerbose()) {
                log.error("cannot modify point size.", e);
            }
        }
        try {
            if (pointAttributes == null) {
                pointAttributes = new PointAttributes();
                pointAttributes.setCapability(PointAttributes.ALLOW_SIZE_READ);
                pointAttributes.setCapability(PointAttributes.ALLOW_SIZE_WRITE);
            }
            pointAttributes.setPointSize(size);
            appearance.setPointAttributes(null);
            appearance.setPointAttributes(pointAttributes);
        } catch (CapabilityNotSetException e) {
            if (isVerbose()) {
                log.error("cannot modify point size.", e);
            }
        }
    }

    /**
     * Description of the method.
     *
     * @param appearance Description of parameter.
     * @param isEnable Description of parameter.
     */
    public static void enableCulling(Appearance appearance, boolean isEnable) {
        PolygonAttributes polygonAttributes =
            getPolygonAttributes(appearance, !isEnable);
        try {
            if (polygonAttributes != null) {
                if (isEnable) {
                    polygonAttributes.setCullFace(PolygonAttributes.CULL_BACK);
                } else {
                    polygonAttributes.setCullFace(PolygonAttributes.CULL_NONE);
                }
            }
        } catch (CapabilityNotSetException e) {
            if (isVerbose()) {
                log.error("cannot dis-/enable backface culling.", e);
            }
        }
    }

    /**
     * Gets the <code>polygonAttributes</code> attribute of the
     * <code>AppearanceHelper</code> class.
     *
     * @param appearance Description of parameter.
     *
     * @return The <code>polygonAttributes</code> value.
     */
    private static PolygonAttributes getPolygonAttributes(
        Appearance appearance, boolean isCreate) {
        PolygonAttributes polygonAttributes = null;
        try {
            polygonAttributes = appearance.getPolygonAttributes();
            if (polygonAttributes == null) {
                if (isCreate) {
                    polygonAttributes = new PolygonAttributes();
                    polygonAttributes.setCapability(PolygonAttributes.ALLOW_CULL_FACE_READ);
                    polygonAttributes.setCapability(PolygonAttributes.ALLOW_CULL_FACE_WRITE);
                    polygonAttributes.setCapability(PolygonAttributes.ALLOW_MODE_READ);
                    polygonAttributes.setCapability(PolygonAttributes.ALLOW_MODE_WRITE);
                    appearance.setPolygonAttributes(polygonAttributes);
                }
            }
        } catch (CapabilityNotSetException e) {
            if (isVerbose()) {
                log.error("cannot retrieve polygon attributes.", e);
            }
        }
        return polygonAttributes;
    }

    /**
     * Description of the method.
     *
     * @param enableVertexColoring Description of parameter.
     *
     * @return Description of the returned value.
     */
    private static final RenderingAttributes createRenderingAttributes(
        boolean enableVertexColoring) {
        RenderingAttributes renderingAttributes = new RenderingAttributes();
        renderingAttributes.setCapability(RenderingAttributes.ALLOW_IGNORE_VERTEX_COLORS_READ);
        renderingAttributes.setCapability(RenderingAttributes.ALLOW_IGNORE_VERTEX_COLORS_WRITE);
        renderingAttributes.setIgnoreVertexColors(!enableVertexColoring);
        return renderingAttributes;
    }

    /**
     * Method description.
     *
     * @param appearance Parameter description.
     * @param isEnable Parameter description.
     */
    public static final void enableMesh(Appearance appearance, boolean isEnable) {
        PolygonAttributes pa = getPolygonAttributes(appearance, isEnable);
        if (pa != null) {
            try {
                if (isEnable) {
                    pa.setPolygonMode(PolygonAttributes.POLYGON_LINE);
                } else {
                    pa.setPolygonMode(PolygonAttributes.POLYGON_FILL);
                }
                appearance.setPolygonAttributes(pa);
            } catch (CapabilityNotSetException e) {
                if (isVerbose()) {
                    log.error("cannot dis-/enable mesh.", e);
                }
            }
        }
    }

    /**
     * Method description.
     *
     * @param appearance Parameter description.
     *
     * @return Return description.
     */
    public static boolean isMesh(Appearance appearance) {
        PolygonAttributes pa = getPolygonAttributes(appearance, false);
        try {
            if (pa != null) {
                return pa.getPolygonMode() == PolygonAttributes.POLYGON_LINE;
            }
        } catch (CapabilityNotSetException e) {
            if (isVerbose()) {
                log.error("cannot retrieve mesh setting.", e);
            }
        }
        return false;
    }

    /**
     * Method description.
     *
     * @param appearance Parameter description.
     */
    public static void enableAlternateTransparency(Appearance appearance) {
        TransparencyAttributes ta = appearance.getTransparencyAttributes();
        if (ta != null) {
            if (ta.getTransparency() > EPSILON_TRANSPARENCY) {
                ta.setTransparencyMode(TransparencyAttributes.SCREEN_DOOR);
                ta.setTransparency(0.5f);
            }
        }
    }

    /**
     * Method description.
     */
    public static void initialize() {
        String version =
            VirtualUniverse.getProperties().get("j3d.version").toString();
        log.info("Java 3D version " + version);
        if (version.startsWith(JAVA3D_1_2_PREFIX)) {

            // adapt specular color for consistency reasons with texture coloring
            specularColor.set(0.2f, 0.2f, 0.2f);
            AppearanceHelper.java3DVersion = JAVA3D_1_2;
        } else {
            AppearanceHelper.java3DVersion = JAVA3D_1_3;
        }
    }
}
