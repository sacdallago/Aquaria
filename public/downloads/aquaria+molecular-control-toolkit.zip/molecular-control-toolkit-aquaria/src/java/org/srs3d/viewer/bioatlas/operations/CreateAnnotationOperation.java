/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.operations;

import javax.vecmath.Color3f;

import org.srs3d.viewer.bioatlas.modules.AnnotationModule;
import org.srs3d.viewer.bioatlas.views.CustomView;
import org.srs3d.viewer.j3d.Context;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.objects.Operation;
import org.srs3d.viewer.util.XmlTag;

/**
 * Description of the class.
 *
 * @author Karsten Klein
 *
 * @created April 10, 2002
 */
public class CreateAnnotationOperation extends Operation {
    private Color3f annotationColor = null;
    private String annotationName = null;

    /**
     * <code>CreateAnnotationOperation</code> constructor.
     *
     * @param context Description of parameter.
     * @param id Description of parameter.
     * @param annotationName Description of parameter.
     * @param annotationColor Description of parameter.
     * @param object Description of parameter.
     */
    public CreateAnnotationOperation(Context context, String id,
        String annotationName, Color3f annotationColor, AbstractObject object) {
        super(context, id, object);
        setAnnotationColor(annotationColor);
        setAnnotationName(annotationName);
    }

    /**
     * Sets the annotationName attribute of the CreateAnnotationOperation object.
     *
     * @param annotationName The new annotationName value.
     */
    public void setAnnotationName(String annotationName) {
        this.annotationName = annotationName;
    }

    /**
     * Sets the annotationColor attribute of the CreateAnnotationOperation object.
     *
     * @param annotationColor The new annotationColor value.
     */
    public void setAnnotationColor(Color3f annotationColor) {
        this.annotationColor = annotationColor;
    }

    /**
     * Gets the annotationName attribute of the CreateAnnotationOperation object.
     *
     * @return The annotationName value.
     */
    public String getAnnotationName() {
        return annotationName;
    }

    /**
     * Gets the annotationColor attribute of the CreateAnnotationOperation object.
     *
     * @return The annotationColor value.
     */
    public Color3f getAnnotationColor() {
        return annotationColor;
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     * @param xmlTag Description of parameter.
     *
     * @return Description of the returned value.
     */
    public boolean deserializeAttributes(ContextData contextData, XmlTag xmlTag) {
        if (super.deserializeAttributes(contextData, xmlTag)) {
            String value = xmlTag.getAttribute("annotationColor");
            if (value != null) {
                Color3f color = new Color3f();
                AnnotationModule.readTuple(value, color);
                setAnnotationColor(color);
            }
            value = xmlTag.getAttribute("annotationName");
            if (value != null) {
                setAnnotationName(value);
            }
            return getAnnotationName() != null && getAnnotationColor() != null;
        }
        return false;
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     * @param xmlTag Description of parameter.
     *
     * @return Description of the returned value.
     */
    public boolean serializeAttributes(ContextData contextData, XmlTag xmlTag) {
        if (super.serializeAttributes(contextData, xmlTag)) {
            xmlTag.setAttribute("subId", "CreateAnnotation");
            if (getAnnotationColor() != null) {
                xmlTag.setAttribute("annotationColor",
                    CustomView.convertTuple(getAnnotationColor()));
            }
            if (getAnnotationColor() != null) {
                xmlTag.setAttribute("annotationName", getAnnotationName());
            }
            return getAnnotationName() != null && getAnnotationColor() != null;
        }
        return false;
    }
}
