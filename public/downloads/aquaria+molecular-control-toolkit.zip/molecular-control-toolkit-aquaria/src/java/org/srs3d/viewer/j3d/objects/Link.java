/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.objects;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.StringTokenizer;

import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.util.Log;

/**
 * A Link instance simply contains a url string.
 *
 * @author Karsten Klein
 *
 * @created October 11, 2001
 */
public class Link extends AbstractObject {
    private static final Log log = new Log(Link.class);
    private Map idMap = new HashMap();
    private Collection objects = new HashSet();

    /**
     * Sets the <code>urlString</code> attribute of the <code>Link</code> object.
     *
     * @param id The new <code>link</code> value.
     * @param link The new <code>link</code> value.
     */
    public void addLink(String id, String link) {
        idMap.put(id, link);
    }

    /**
     * Gets the <code>urlString</code> attribute of the <code>Link</code> object.
     *
     * @param id Description of parameter.
     *
     * @return The <code>urlString</code> value.
     */
    public String getLink(String id) {
        return (String) idMap.get(id);
    }

    /**
     * Method description.
     *
     * @param id Parameter description.
     */
    public void removeLink(String id) {
        idMap.remove(id);
    }

    /**
     * Method description.
     *
     * @param string Parameter description.
     */
    public void setLinks(String string) {
        StringTokenizer tokenizer = new StringTokenizer(string.trim(), ";");
        String token;
        while (tokenizer.hasMoreTokens()) {
            token = tokenizer.nextToken();
            int index = token.indexOf(":");
            if (index != -1) {
                addLink(token.substring(0, index), token.substring(index + 1));
            } else {
                log.error("link incomplete: '" + token + "' in " + string);
            }
        }
    }

    /**
     * Method description.
     *
     * @param objects Parameter description.
     */
    public void setObjects(Collection objects) {
        this.objects = objects;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public Collection getObjects() {
        return objects;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public String toString() {
        String string = "Link";
        if (objects != null) {
            Iterator iterator = objects.iterator();
            while (iterator.hasNext()) {
                string += " " + iterator.next();
            }
        }
        return string;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public Collection getIds() {
        return idMap.keySet();
    }

    /**
     * Method description.
     */
    public void cleanup() {
        super.cleanup();
        cleanup(idMap);
        idMap = null;
        cleanup(objects);
        objects = null;
    }
}
