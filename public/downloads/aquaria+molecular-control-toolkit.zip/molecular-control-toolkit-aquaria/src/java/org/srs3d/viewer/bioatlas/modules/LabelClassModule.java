/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.modules;

import java.util.Collection;
import java.util.HashSet;

import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.objects.ObjectManager;
import org.srs3d.viewer.objects.visitors.ObjectCollector;

/**
 * <code>Module</code> implementation displaying a label around the current selection.
 * The label is computed dynamically depending of the current selection.
 *
 * @author Karsten Klein
 *
 * @created May 14, 2001
 */
public class LabelClassModule extends LabelModule {
    private Class objectClass;
    private Class filterClass;

    /**
     * Constructor description.
     *
     * @param name Parameter description.
     * @param contextData Parameter description.
     * @param objectClass Parameter description.
     */
    public LabelClassModule(String name, ContextData contextData,
        Class objectClass) {
        this(name, contextData, objectClass, null);
    }

    /**
     * Constructor description.
     *
     * @param name Parameter description.
     * @param contextData Parameter description.
     * @param objectClass Parameter description.
     * @param isGlobal Parameter description.
     */
    public LabelClassModule(String name, ContextData contextData,
        Class objectClass, boolean isGlobal) {
        super(name, contextData, isGlobal);
        this.objectClass = objectClass;
        this.filterClass = null;
    }

    /**
     * <code>LabelModule</code> constructor.
     *
     * @param name Description of parameter.
     */
    public LabelClassModule(String name, ContextData contextData,
        Class objectClass, Class filterClass) {
        super(name, contextData);
        this.objectClass = objectClass;
        this.filterClass = filterClass;
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     * @param objects Parameter description.
     * @param processedObjects Parameter description.
     * @param useAssociations Parameter description.
     */
    public void preProcess(ContextData contextData, Collection objects,
        Collection processedObjects, boolean useAssociations) {
        if (!objects.isEmpty()) {
            Collection collapsed = new HashSet(objects.size());
            contextData.getObjectManager().collapseUp(objects, collapsed);
            Collection associations;
            if (useAssociations) {
                associations = new HashSet(objects);
                contextData.getObjectManager().getDownAssociations(objects,
                    associations);
            } else {
                ObjectCollector objectCollector = new ObjectCollector(null);
                objectCollector.visit(objects);
                associations = objectCollector.getObjects();
            }
            contextData.getObjectManager().getUpAssociations(collapsed,
                associations);
            collapsed.addAll(associations);

            // module specialized collection manipulation following
            ObjectManager.extract(collapsed, objectClass);
            if (filterClass != null) {
                ObjectManager.filter(collapsed, filterClass);
            }

            // :FIXME: could use a object class filter here
            // :FIXME: could use a expanded/visible filter here
            processedObjects.addAll(collapsed);
        }
    }
}
