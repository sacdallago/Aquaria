/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.behaviors;

import java.awt.event.MouseEvent;

import javax.media.j3d.Transform3D;
import javax.media.j3d.WakeupOnAWTEvent;
import javax.media.j3d.WakeupOr;
import javax.vecmath.Matrix3f;
import javax.vecmath.Point3f;
import javax.vecmath.Tuple3f;
import javax.vecmath.Vector3f;

import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.commands.TranslateCommand;
import org.srs3d.viewer.objects.AbstractObject;

/**
 * @author Karsten Klein
 *
 * @created April 23, 2001
 */
public class AlignmentBehavior extends AbstractBehavior {
    private AbstractObject object = null;
    private Point3f center = new Point3f();
    private Vector3f alignment = new Vector3f();

    /**
     * <code>AlignmentBehavior</code> constructor.
     *
     * @param context Description of parameter.
     * @param object Description of parameter.
     */
    public AlignmentBehavior(ContextData contextData, AbstractObject object) {
        setContextData(contextData);
        this.object = object;
    }

    /**
     * Sets the <code>Center</code> attribute of the <code>AlignmentBehavior
     * </code>object.
     *
     * @param center The new <code>Center</code> value.
     */
    public void setCenter(Tuple3f center) {
        this.center.set(center);
    }

    /**
     * Sets the <code>Alignment</code> attribute of the <code>AlignmentBehavior
     * </code>object.
     *
     * @param alignment The new <code>Alignment</code> value.
     */
    public void setAlignment(Tuple3f alignment) {
        this.alignment.set(alignment);
    }

    /**
     * The processStimulus method is the only method override from the com.sun... class
     * Behavior.
     *
     * @param criteria Description of parameter.
     */
    public void processStimulus(java.util.Enumeration criteria) {
        if (center != null && alignment != null) {
            Transform3D transform =
                getContextData().getContext().getViewingPlatformTransform();

            // extract current view direction
            Matrix3f rotation = new Matrix3f();
            transform.get(rotation);

            // transform the alignment vector into view space
            Vector3f align = new Vector3f(alignment);
            rotation.transform(align);

            // offset the center accoriding to the alignment
            align.add(center);
            ContextData contextData = getContextData();
            TranslateCommand translate = new TranslateCommand(contextData);
            translate.setTranslation(align);
            contextData.getStrategyManager().execute(object, translate);
        }

        // reset wakeup condition
        initialize();
    }

    /**
     * Description of the method. Initializes the wakeup conditions for the behavior.
     */
    public void initialize() {
        WakeupOnAWTEvent[] conditions = new WakeupOnAWTEvent[2];

        // set wakeup condition (waiting for further dragging events)
        conditions[0] = new WakeupOnAWTEvent(MouseEvent.MOUSE_DRAGGED);

        // set wakeup condition (waiting first click)
        conditions[1] = new WakeupOnAWTEvent(MouseEvent.MOUSE_PRESSED);
        wakeupOn(new WakeupOr(conditions));
    }

    /**
     * This method checks the mouseEvent (fail early, fail fast)
     *
     * @param mouseEvent Description of parameter.
     *
     * @return Description of the returned value.
     */
    protected boolean checkCriteria(MouseEvent mouseEvent) {
        if (mouseEvent.getID() != MouseEvent.MOUSE_DRAGGED) {
            return false;
        }
        return true;
    }
}
