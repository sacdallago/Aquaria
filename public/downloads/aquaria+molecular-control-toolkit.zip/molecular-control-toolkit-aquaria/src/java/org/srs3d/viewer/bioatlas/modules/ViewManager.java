/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.modules;

import java.util.HashMap;
import java.util.Map;

import org.srs3d.viewer.bioatlas.views.CustomView;
import org.srs3d.viewer.bioatlas.views.View;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.behaviors.dispatcher.OperationStorage;
import org.srs3d.viewer.objects.Operation;
import org.srs3d.viewer.util.ExceptionHandler;
import org.srs3d.viewer.util.Log;
import org.srs3d.viewer.util.XmlTag;

/**
 * Module that enables saving and restoring views. All reset operations will act on a
 * default view, only.
 *
 * @author Karsten Klein
 *
 * @created February 06, 2002
 */
public class ViewManager implements OperationStorage {
    private static final Log log = new Log(ViewManager.class);
    public static final String DEFAULT_VIEW_ID = "default";
    public static final String DEFAULT_VIEW_TAG = "defaultView";
    public static final String DEFAULT_VIEW_ATTRIBUTE = "id";
    private String id;
    private ContextData contextData;

    // the restore module is based on a set of views
    private Map viewMap = new HashMap();
    private CustomView defaultView;
    private String currentViewId = null;

    /**
     * Constructor description.
     *
     * @param contextData Parameter description.
     * @param id Parameter description.
     */
    public ViewManager(ContextData contextData, String id) {
        this.contextData = contextData;
        this.id = id;

        // create a new default view
        XmlTag viewTag = new XmlTag(CustomView.VIEW_TAG);
        viewTag.setAttribute(CustomView.ID_ATTRIBUTE, DEFAULT_VIEW_ID);
        defaultView = new CustomView(viewTag);
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public ContextData getContextData() {
        return contextData;
    }

    /**
     * Method description.
     *
     * @param viewId Parameter description.
     */
    public void processApplyView(String viewId) {
        CustomView view = getView(viewId, false);
        processApplyView(view);
    }

    /**
     * Description of the method.
     */
    private void processApplyView(CustomView view) {
        if (view != null) {

            // delete all operations in the default view
            defaultView.delete();
            contextData.setProperty("VIEW", view.getName());
            view.apply(getContextData());
            setCurrentViewId(view.getName());
        }
    }

    /**
     * Description of the method.
     *
     * @param operation Description of parameter.
     */
    public static void store(ContextData contextData, Operation operation,
        XmlTag viewTag) {
        try {
            XmlTag xmlTag = operation.serialize(contextData);
            if (xmlTag == null) {

                // write an exception tag
                xmlTag = new XmlTag(("operation"));
                xmlTag.setAttribute("id", "invalid");
                xmlTag.setAttribute("reason", "unable to serialize " +
                    operation);
            }
            viewTag.getSubtags().add(xmlTag);
        } catch (Exception e) {
            ExceptionHandler.handleException(e,
                ExceptionHandler.VISIBLE_IN_RELEASE);
        }
    }

    /**
     * Description of the method.
     *
     * @param operation Description of parameter.
     */
    public void store(Operation operation) {

        // the operation is serialized into the default view
        if (operation.isSerializeable()) {
            store(getContextData(), operation, defaultView.getXmlTag());
        }
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public boolean hasViews() {
        return !viewMap.isEmpty();
    }

    /**
     * Method description.
     *
     * @param viewId Parameter description.
     */
    public void reset(String viewId) {
        defaultView.delete();
    }

    /**
     * Method description.
     *
     * @param viewId Parameter description.
     */
    public void save(String viewId) {

        // saves the current default view under viewId
        XmlTag copyTag = XmlTag.copy(defaultView.getXmlTag());
        copyTag.setAttribute(CustomView.ID_ATTRIBUTE, viewId);
        CustomView view = new CustomView(copyTag);
        view.updateOrientationData(getContextData());
        registerView(view);
        contextData.setProperty("VIEW", viewId);
        setCurrentViewId(viewId);
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public String getId() {
        return id;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    protected Map getViewMap() {
        return viewMap;
    }

    /**
     * Method description.
     *
     * @param view Parameter description.
     */
    public void registerView(View view) {
        log.debug("registering view " + view.getName());
        viewMap.put(view.getName(), view);
    }

    /**
     * Method description.
     *
     * @param viewId Parameter description.
     * @param isCreate Parameter description.
     *
     * @return Return description.
     */
    public CustomView getView(String viewId, boolean isCreate) {
        View view = (View) getViewMap().get(viewId);
        if (view == null && isCreate) {
            System.out.println("creating view " + viewId);
            XmlTag viewTag = new XmlTag(CustomView.VIEW_TAG);
            viewTag.setAttribute(CustomView.ID_ATTRIBUTE, viewId);
            view = new CustomView(viewTag);
        }
        return (CustomView) view;
    }

    /**
     * Method description.
     */
    public void save() {
        if (currentViewId != null) {

            // update the default view to be the current view
            XmlTag viewTag = XmlTag.copy(defaultView.getXmlTag());
            viewTag.setAttribute(CustomView.ID_ATTRIBUTE, currentViewId);
            CustomView view = new CustomView(viewTag);
            view.updateOrientationData(getContextData());
            registerView(view);
        }
    }

    private void setCurrentViewId(String viewId) {
        this.currentViewId = viewId;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public String getCurrentViewId() {
        return currentViewId;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public String getDefaultViewId() {
        return currentViewId;
    }

    /**
     * Method description.
     *
     * @param viewId Parameter description.
     */
    public void removeView(String viewId) {
        getViewMap().remove(viewId);
        setCurrentViewId(null);
        contextData.setProperty("VIEW", null);
    }
}
