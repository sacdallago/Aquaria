/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.creators;

import java.util.HashSet;
import java.util.Iterator;

import javax.media.j3d.BranchGroup;
import javax.media.j3d.Geometry;
import javax.media.j3d.LineArray;
import javax.media.j3d.PointArray;
import javax.media.j3d.Shape3D;
import javax.media.j3d.Transform3D;
import javax.media.j3d.TransformGroup;
import javax.vecmath.Color3f;
import javax.vecmath.Point3f;
import javax.vecmath.Vector3f;

import org.srs3d.viewer.bioatlas.Parameter;
import org.srs3d.viewer.bioatlas.attributes.AtomRepresentation;
import org.srs3d.viewer.bioatlas.attributes.Representation;
import org.srs3d.viewer.bioatlas.objects.Atom;
import org.srs3d.viewer.bioatlas.objects.Residue;
import org.srs3d.viewer.bioatlas.visitors.AtomCollector;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.ShapeManager;
import org.srs3d.viewer.j3d.creators.AbstractGeometryCreator;
import org.srs3d.viewer.j3d.geometry.primitive.Sphere;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.objects.State;

/**
 * Creates geometry of <code>Atom</code> objects.
 *
 * @author Karsten Klein
 *
 * @created March 20, 2001
 */
public class AtomGeometryCreator extends AbstractGeometryCreator {

    /** Use this mode to create the atom as a sphere. */
    private static int ATOM_SPHERE = 1;

    /** Use this mode to create the atom as a single point. */
    private static int ATOM_POINT = 2;
    private static int ATOM_CROSS = 4;

    /**
     * Specifies the radius scaling factor. The atom radius scaled by this factor defines
     * the final radius used for the geometry creation.
     */
    public float atomRadiusScale = 0.25f;

    /** Specifies the geometry mode of the creator. */
    private int atomMode = ATOM_SPHERE;
    private int representationMode = 0;

    /**
     * <code>GeometryCreator</code> interface implementation.
     *
     * @param object Object to create geometry for.
     * @param branchGroup Roots to attach the geometry to.
     */
    public void create(AbstractObject object, BranchGroup branchGroup) {
        Atom atom = (Atom) object;
        if ((atomMode & ATOM_SPHERE) != 0) {
            createSphere(atom, branchGroup);
        }
        if ((atomMode & ATOM_POINT) != 0) {
            createPoint(atom, branchGroup);
        }
        if ((atomMode & ATOM_CROSS) != 0) {
            createCross(atom, branchGroup);
        }
    }

    /**
     * Creates sphere geometry for the specified <code>Atom</code> .
     *
     * @param atom <code>Atom</code> to create geometry for.
     * @param branchGroup Roots to attach the geometry to.
     */
    public void createSphere(Atom atom, BranchGroup branchGroup) {

        // create sphere with the appropriate attributes
        Sphere sphere = new Sphere();
        sphere.getCoordinates().set(atom.getCoordinate());
        sphere.setRadius(atom.getVanDerWaalsRadius() * atomRadiusScale);
        int divisions =
            (int) (sphere.getRadius() * Parameter.sphereSegmentsPerAngstrom);
        if (divisions < Parameter.sphereSegmentsPerAngstrom) {
            divisions = Parameter.sphereSegmentsPerAngstrom;
        }
        sphere.setDivisions(divisions);
        TransformGroup transformGroup = new TransformGroup();
        Transform3D transform = new Transform3D();
        transform.setTranslation(new Vector3f(sphere.getCoordinates().getAt(0)));
        transform.setScale(sphere.getRadius());
        transformGroup.setTransform(transform);

        // construct shape object
        Shape3D shape = sphere.getShape();
        ShapeManager.setCapabilities(shape, atom);
        getContextData().getShapeManager().register(atom, shape);

        // release sphere
        sphere = null;
        transformGroup.addChild(shape);
        branchGroup.addChild(transformGroup);
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     * @param atom Parameter description.
     * @param atomRadiusScale Parameter description.
     *
     * @return Return description.
     */
    public static Shape3D createAtomShape(ContextData contextData, Atom atom,
        float atomRadiusScale) {

        // create sphere with the appropriate attributes
        Sphere sphere = new Sphere();
        sphere.getCoordinates().set(atom.getCoordinate());
        sphere.setRadius(atom.getVanDerWaalsRadius() * atomRadiusScale);
        int divisions =
            (int) (sphere.getRadius() * Parameter.sphereSegmentsPerAngstrom);
        if (divisions < Parameter.sphereSegmentsPerAngstrom) {
            divisions = Parameter.sphereSegmentsPerAngstrom;
        }
        sphere.setDivisions(divisions);

        // construct shape object
        Shape3D shape = sphere.getShape();
        ShapeManager.setCapabilities(shape, atom);

        // release sphere
        sphere = null;
        return shape;
    }

    /**
     * Creates point geometry for the specified <code>Atom</code> .
     *
     * @param atom <code>Atom</code> to create geometry for.
     * @param branchGroup Roots to attach the geometry to.
     */
    public void createPoint(Atom atom, BranchGroup branchGroup) {
        PointArray pointArray = new PointArray(1, PointArray.COORDINATES);
        pointArray.setCoordinate(0, atom.getCoordinate());
        Shape3D shape = new Shape3D(pointArray);
        ShapeManager.setCapabilities(shape, atom);
        getContextData().getShapeManager().register(atom, shape);
        branchGroup.addChild(shape);
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     * @param object Parameter description.
     *
     * @return Return description.
     */
    public static Geometry createPoints(ContextData contextData,
        AbstractObject object) {
        AtomCollector atomCollector = new AtomCollector();
        atomCollector.visit(object);
        PointArray pointArray =
            new PointArray(atomCollector.getObjects().size(),
                PointArray.COORDINATES | PointArray.COLOR_3);
        Iterator iterator = atomCollector.getObjects().iterator();
        Atom atom;
        int index = 0;
        while (iterator.hasNext()) {
            atom = (Atom) iterator.next();
            pointArray.setCoordinate(index, atom.getCoordinate());
            pointArray.setColor(index++,
                BondGeometryCreator.computeColor(contextData, atom, object));
        }
        return pointArray;
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     * @param object Parameter description.
     *
     * @return Return description.
     */
    public static Geometry createCrosses(ContextData contextData,
        AbstractObject object) {
        AtomCollector atomCollector = new AtomCollector();
        atomCollector.visit(object);
        int size = atomCollector.getObjects().size();
        LineArray lineArray =
            new LineArray(size * 6, LineArray.COORDINATES | PointArray.COLOR_3);
        Iterator iterator = atomCollector.getObjects().iterator();
        Atom atom;
        int index = 0;
        Color3f color;
        while (iterator.hasNext()) {
            atom = (Atom) iterator.next();
            color = BondGeometryCreator.computeColor(contextData, atom, object);
            createCross(contextData, atom, lineArray, index, color);
            index += 6;
        }
        return lineArray;
    }

    /**
     * Creates point geometry for the specified <code>Atom</code> .
     *
     * @param atom <code>Atom</code> to create geometry for.
     * @param branchGroup Roots to attach the geometry to.
     */
    public void createCross(Atom atom, BranchGroup branchGroup) {

        // create sphere with the appropriate attributes
        LineArray lineArray =
            new LineArray(6, LineArray.COORDINATES | LineArray.COLOR_3);
        Color3f color =
            BondGeometryCreator.computeColor(getContextData(), atom, atom);
        createCross(getContextData(), atom, lineArray, 0, color);
        Shape3D shape = new Shape3D(lineArray);
        ShapeManager.setCapabilities(shape, atom);
        getContextData().getShapeManager().register(atom, shape);
        branchGroup.addChild(shape);
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     * @param atom Parameter description.
     * @param lineArray Parameter description.
     * @param index Parameter description.
     * @param color Parameter description.
     */
    public static void createCross(ContextData contextData, Atom atom,
        LineArray lineArray, int index, Color3f color) {

        // create sphere with the appropriate attributes
        Point3f position = new Point3f(atom.getCoordinate());
        position.x -= 0.5f;
        lineArray.setColor(index, color);
        lineArray.setCoordinate(index++, position);
        position.x += 1.0f;
        lineArray.setColor(index, color);
        lineArray.setCoordinate(index++, position);
        position.x -= 0.5f;
        position.y -= 0.5f;
        lineArray.setColor(index, color);
        lineArray.setCoordinate(index++, position);
        position.y += 1.0f;
        lineArray.setColor(index, color);
        lineArray.setCoordinate(index++, position);
        position.y -= 0.5f;
        position.z -= 0.5f;
        lineArray.setColor(index, color);
        lineArray.setCoordinate(index++, position);
        position.z += 1.0f;
        lineArray.setColor(index, color);
        lineArray.setCoordinate(index++, position);
    }

    /**
     * Description of the method.
     *
     * @param object Description of parameter.
     * @param contextData Description of parameter.
     */
    public void modifyAttributes(ContextData contextData, AbstractObject object) {
        super.modifyAttributes(contextData, object);
        State.Immutable state =
            getContextData().getStateManager().getImmutableState(object);
        atomMode = ATOM_POINT;
        atomRadiusScale = 0.0f;
        AtomRepresentation.Immutable representation =
            (AtomRepresentation.Immutable) state.getAttribute(AtomRepresentation.class);
        if (representation != null) {
            representationMode = representation.getMode();
            if ((representationMode & Representation.REPRESENTATION_WIREFRAME) != 0) {
                atomMode = ATOM_POINT;
                HashSet residues = new HashSet();
                HashSet bonds = new HashSet();
                getContextData().getObjectManager().getDirectUpAssociations(object,
                    residues);
                Iterator iterator = residues.iterator();
                Residue residue;
                while (iterator.hasNext() && bonds.size() == 0) {
                    residue = (Residue) iterator.next();
                    bonds.addAll(residue.getBonds());
                }
                if (bonds.size() == 0) {
                    atomMode = ATOM_CROSS;
                }
            } else {
                if ((representationMode &
                      Representation.REPRESENTATION_BALL_AND_STICK) != 0) {
                    atomRadiusScale = 0.25f;
                    atomMode = ATOM_SPHERE;
                } else if ((representationMode &
                      Representation.REPRESENTATION_VAN_DER_WAALS) != 0) {
                    atomRadiusScale = 1.0f;
                    atomMode = ATOM_SPHERE;
                }
            }
        }
    }
}
