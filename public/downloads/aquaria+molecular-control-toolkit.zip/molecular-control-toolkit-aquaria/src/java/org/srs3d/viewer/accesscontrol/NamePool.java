/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.accesscontrol;

import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;

import org.srs3d.viewer.util.ExceptionHandler;

/**
 * The name pool is a collection of computer names with appropriate methods for
 * performing the check.
 *
 * @author Karsten Klein
 *
 * @created March 22, 2002
 */
public class NamePool {
    private HashSet names = new HashSet();

    /**
     * Constructor description.
     */
    protected NamePool() {
    }

    /**
     * <code>NamePool</code> constructor.0
     *
     * @param object Creates a NamePool instance from the provided object.
     */
    public NamePool(Object object) {
        try {
            byte[][] strings = (byte[][]) object;
            for (int i = 0; i < strings.length; i++) {
                names.add(new String(strings[i]));
            }
        } catch (ClassCastException e) {

            // backward compatibility
            names.addAll((Collection) object);
            ExceptionHandler.handleException(e, ExceptionHandler.SILENT_IN_DEBUG);
        }
    }

    /**
     * <code>NamePool</code> constructor.
     *
     * @param names Collection of names that build the NamePool.
     */
    protected NamePool(Collection names) {

        // :NOTE: this is important, since we have to map the names to lower case
        //   don't replace with this.names.addAll( names )
        Iterator iterator = names.iterator();
        while (iterator.hasNext()) {
            add((String) iterator.next());
        }
    }

    /**
     * Creates a flattened structure of the NamePool instance.
     *
     * @return Flattened representation.
     */
    protected Object flatten() {
        byte[][] strings = new byte[names.size()][];
        Iterator iterator = names.iterator();
        int index = 0;
        while (iterator.hasNext()) {
            strings[index++] = ((String) iterator.next()).getBytes();
        }
        return strings;
    }

    /**
     * Adds a name to the pool.
     *
     * @param name Name for adding.
     */
    protected void add(String name) {
        names.add(name.toLowerCase());
    }

    /**
     * Checks for inclusion of the provided name in the pool.
     *
     * @param name Name for perfoming check (case insensitive).
     *
     * @return <code>true</code> if covered by the pool.
     */
    public boolean contains(String name) {
        return names.contains(name.toLowerCase());
    }

    protected String dump() {
        String string = "";
        Iterator iterator = names.iterator();
        while (iterator.hasNext()) {
            string += iterator.next();
            if (iterator.hasNext()) {
                string += ", ";
            }
        }
        return string;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public boolean isEmpty() {
        return names.isEmpty();
    }
}
