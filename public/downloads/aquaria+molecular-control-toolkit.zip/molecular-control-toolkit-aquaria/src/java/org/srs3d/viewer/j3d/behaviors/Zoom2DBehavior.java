/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.behaviors;

import java.awt.event.MouseEvent;

import javax.media.j3d.Transform3D;
import javax.media.j3d.WakeupOnAWTEvent;
import javax.media.j3d.WakeupOr;
import javax.vecmath.Matrix3f;
import javax.vecmath.Point3d;
import javax.vecmath.Vector3f;

import org.srs3d.viewer.j3d.Context;
import org.srs3d.viewer.j3d.ContextData;

/**
 * The class <code>ZoomBehavior</code> represents a specialized
 * <code>MouseBehavior</code> . Note that zooming in this behavior is understood as
 * going nearer to an object. Use some other behavior class if you want to scale things.
 *
 * @author Karsten Klein, 11/2000
 *
 * @created March 20, 2001
 * @since 1.0
 */
public class Zoom2DBehavior extends MouseBehavior {

    /** Integers used for saving the mouse positions */
    private int lastY;

    /** Integers used for saving the mouse positions */
    private int y;

    /**
     * <code>ZoomBehavior</code> contructor.
     *
     * @param context Description of parameter.
     */
    public Zoom2DBehavior(ContextData contextData) {
        super(contextData);
    }

    /**
     * Initializes the wakeup conditions for the behavior.
     */
    public void initialize() {
        WakeupOnAWTEvent[] conditions = new WakeupOnAWTEvent[2];

        // set wakeup condition (waiting for further dragging events)
        conditions[0] = new WakeupOnAWTEvent(MouseEvent.MOUSE_DRAGGED);

        // :FIXME: don't know if the following lines are really needed. One should
        //         try once without
        // set wakeup condition (waiting first click)
        conditions[1] = new WakeupOnAWTEvent(MouseEvent.MOUSE_PRESSED);
        wakeupOn(new WakeupOr(conditions));
    }

    /**
     * Processes the mouseEvent. This will directly result in a modification of the
     * viewingPlatform in the activated <code>Context</code> , if the according
     * conditions are met by the mouse event.
     *
     * @param mouseEvent Description of parameter.
     */
    public void processStimulus(MouseEvent mouseEvent) {
        lastY = y;
        y = mouseEvent.getY();
        if (checkCriteria(mouseEvent)) {
            Context context = getContextData().getContext();
            KeyHandler.setCursor(getContextData(), "PanZ", true);

            // get the current transformation of the viewing platform
            Transform3D transform = context.getViewingPlatformTransform();

            // extract current translation
            Vector3f translation = new Vector3f();
            transform.get(translation);

            // extract current view direction
            Vector3f viewDirection = new Vector3f();
            Matrix3f rotation = new Matrix3f();
            transform.get(rotation);
            rotation.getColumn(2, viewDirection);
            float zoomSpeed = (translation.z + 2) / 100;
            int delta = lastY - y;
            delta = Math.min(delta, MAX_DELTA);
            delta = Math.max(delta, -MAX_DELTA);
            viewDirection.scale(zoomSpeed * delta);
            translation.add(viewDirection);

            // apply transformation
            context.setViewingPlatformPosition(new Point3d(translation));
        }
    }

    /**
     * This method checks the mouseEvent (fail early, fail fast)
     *
     * @param mouseEvent Description of parameter.
     *
     * @return Description of the returned value.
     */
    protected boolean checkCriteria(MouseEvent mouseEvent) {
        if (mouseEvent.getID() != MouseEvent.MOUSE_DRAGGED) {
            return false;
        }
        if (mouseEvent.isAltGraphDown()) {
            return false;
        }
        if ((mouseEvent.getModifiers() & MouseEvent.BUTTON3_MASK) != 0) {
            if (!mouseEvent.isControlDown()) {
                return false;
            }
        }
        if ((mouseEvent.getModifiers() & MouseEvent.BUTTON1_MASK) != 0) {
            if (!mouseEvent.isShiftDown()) {
                return false;
            }
        }
        return true;
    }
}
