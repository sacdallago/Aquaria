/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.visitors;

import javax.vecmath.Point3f;

import org.srs3d.viewer.bioatlas.objects.AbstractChain;
import org.srs3d.viewer.bioatlas.objects.Residue;

/**
 * The <code>HelixBackbonePathCreator</code> creates the path of a helix backbone from an
 * <code>AbstractChain</code>.
 *
 * @author Karsten Klein
 *
 * @created May 21, 2001
 */
public class HelixBackbonePathCreator extends PathCreator {

    /**
     * Description of the method.
     *
     * @param chain Description of parameter.
     */
    public void visit(AbstractChain chain) {
        visit(chain.getInitialResidue(), chain.getEndResidue());
    }

    /**
     * Description of the method.
     *
     * @param start Description of parameter.
     * @param end Description of parameter.
     */
    public void visit(Residue start, Residue end) {
        Point3f point = null;
        Residue residue = start;
        Residue limit = end.getProceeding();
        int i = 0;
        while (residue != limit) {
            if (i == 0) {
                point = getResidueCoordinate(residue);
                i = 1;
            } else {
                point.add(getResidueCoordinate(residue));
                i++;
            }
            if (i == 3) {
                point.scale(1.0f / i);
                path.add(point);
                i = 0;
            }
            residue = residue.getProceeding();
        }

        // if no path was extracted yet just take the initial and end residues
        // CA positions
        if (path.size() < 2) {

            // forget all added coordinates
            path.clear();
            point = getResidueCoordinate(start);
            point.scale(10);
            point.add(getResidueCoordinate(end));
            point.scale(1.0f / 11);
            path.add(point);
            point = new Point3f(getResidueCoordinate(end));
            point.scale(10);
            point.add(getResidueCoordinate(start));
            point.scale(1.0f / 11);
            path.add(point);
        }
    }
}
