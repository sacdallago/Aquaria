/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.interfaces;

import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.swing.PopupMenu;

/**
 * Interface used to expose external modules to the structure viewer. External modules
 * are added to the context menu.
 *
 * @author Karsten Klein
 */
public interface ModulePublisher {

    /**
     * This method is called as callback when filling the context menu.
     *
     * @param contextData ContextData for this particular context/application.
     * @param popupMenu PopupMenu to add the published modules to.
     */
    public void publishModules(ContextData contextData, PopupMenu popupMenu);
}
