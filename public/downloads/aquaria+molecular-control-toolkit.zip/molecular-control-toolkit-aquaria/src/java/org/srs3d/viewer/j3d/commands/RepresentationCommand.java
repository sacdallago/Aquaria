/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.commands;


// :FIXME: move this class to the bioATLAS package
import org.srs3d.viewer.bioatlas.attributes.Representation;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.objects.State;
import org.srs3d.viewer.objects.StateManager;

/**
 * Representation command. Used to change the reprentation state of objects.
 *
 * @author Karsten Klein
 *
 * @created April 03, 2001
 */
public class RepresentationCommand extends ObjectCommand {
    public static boolean isVerbose = false;

    /** Description of the field. */
    public static final int REPLACE = 0;

    /** Description of the field. */
    public static final int MERGE = 1;

    /** Description of the field. */
    public static final int REMOVE = 2;
    private Representation representation = null;
    private int mode;

    /**
     * <code>RepresentationCommand</code> constructor.
     *
     * @param contextData Description of parameter.
     */
    public RepresentationCommand(ContextData contextData) {
        this(contextData, REPLACE);
    }

    /**
     * <code>RepresentationCommand</code> constructor.
     *
     * @param contextData Description of parameter.
     * @param mode Description of parameter.
     */
    public RepresentationCommand(ContextData contextData, int mode) {
        super(contextData);
        this.mode = mode;
    }

    /**
     * Sets the <code>representation</code> attribute of the
     * <code>ChangeRepresentationCommand</code> object.
     *
     * @param representation The new <code>representation</code> value.
     */
    public void setRepresentation(Representation representation) {
        this.representation = representation;
    }

    /**
     * Description of the method.
     */
    public void execute() {
        if (representation.getTargetClass().isAssignableFrom(getObject()
                                                                   .getClass())) {
            StateManager stateManager = getContextData().getStateManager();
            State.Immutable immutableState =
                stateManager.getImmutableState(getObject());
            Representation.Immutable immutableRepresentation =
                (Representation.Immutable) immutableState.getAttribute(representation.getClass());
            Representation rep;
            if (immutableRepresentation != null) {
                rep = (Representation) immutableRepresentation.getCopy();
            } else {

                // in case the attribute doesn't have a represenation attribute yet
                rep = (Representation) org.srs3d.viewer.objects.Attribute.getInstance(representation.getClass());
            }
            if (mode == MERGE) {
                if (immutableRepresentation != null) {
                    rep.merge(representation);
                } else {
                    rep = representation;
                }
            } else if (mode == REPLACE) {
                rep = representation;
            } else if (mode == REMOVE) {
                int temp = representation.getMode();
                temp = -representation.getMode() - 1;
                if (immutableRepresentation != null) {
                    rep.setMode(temp & rep.getMode());
                } else {

                    // nothing to remove
                }
            }
            if (immutableRepresentation == null ||
                  (rep.getMode() != immutableRepresentation.getMode())) {
                State state = immutableState.getCopy();
                state.setAttribute(rep);
                stateManager.register(getObject(), state);

                //        objects.add( getObject() );
            }
        }
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public String getDescription() {
        return "representation command";
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public int getMode() {
        return mode;
    }

    //  public Collection getObjects() {
    //
    //    return objects;
    //
    //  }
    //
}
