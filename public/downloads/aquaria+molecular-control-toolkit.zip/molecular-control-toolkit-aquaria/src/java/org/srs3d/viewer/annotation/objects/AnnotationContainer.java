/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.annotation.objects;

import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeSet;

import org.srs3d.viewer.bioatlas.Parameter;
import org.srs3d.viewer.bioatlas.objects.Residue;
import org.srs3d.viewer.objects.AbstractObject;

/**
 * Annotation object.
 *
 * @author Karsten Klein
 * @author Christian Zofka
 *
 * @created March 28, 2001
 * @modified July 08, 2001
 */
public class AnnotationContainer extends AbstractObject {
    private Collection alignmentSet =
        new TreeSet(new Comparator() {

                /**
                 * Description of the method.
                 *
                 * @param object1 Description of parameter.
                 * @param object2 Description of parameter.
                 *
                 * @return Description of the returned value.
                 */
                public int compare(Object object1, Object object2) {
                    Object o1 = null;
                    Object o2 = null;
                    int returnValue = 0;
                    int index1 = 0;
                    int index2 = 0;
                    Iterator iterator;
                    iterator =
                        ((Alignment) object1).getChainAnnotations().iterator();
                    while (o1 == null && iterator.hasNext()) {
                        o1 = iterator.next();
                        index1++;
                    }
                    iterator =
                        ((Alignment) object2).getChainAnnotations().iterator();
                    while (o2 == null && iterator.hasNext()) {
                        o2 = iterator.next();
                        index2++;
                    }
                    returnValue = index1 - index2;
                    if (returnValue == 0) {
                        String string1 = o1.toString();
                        String string2 = o2.toString();
                        returnValue = string1.compareToIgnoreCase(string2);
                        if (returnValue == 0) {
                            iterator =
                                ((ChainAnnotation) o1).getSegments().iterator();
                            Segment segment;
                            if (iterator.hasNext()) {
                                segment = (Segment) iterator.next();
                                if (segment.getInitialResidue() != null) {
                                    index1 =
                                        segment.getInitialResidue().getId();
                                } else {
                                    index1 = 0;
                                }
                            }
                            iterator =
                                ((ChainAnnotation) o2).getSegments().iterator();
                            if (iterator.hasNext()) {
                                segment = (Segment) iterator.next();
                                if (segment.getInitialResidue() != null) {
                                    index2 =
                                        segment.getInitialResidue().getId();
                                } else {
                                    index2 = 0;
                                }
                            }
                            returnValue = index1 - index2;
                        }
                    }
                    if (returnValue == 0) {
                        returnValue = o1.hashCode() - o2.hashCode();
                    }
                    return returnValue;
                }

                /**
                 * Description of the method.
                 *
                 * @param obj Description of parameter.
                 *
                 * @return Description of the returned value.
                 */
                public boolean equals(Object obj) {
                    return false;
                }
            });

    /** Maps residues to their mapped couterparts */
    private Map alignmentMap = new HashMap();

    /** Maps layers to a map with residue-residue aligments */
    private Map layerAlignmentMap = null;
    private float length = -1;
    private float height = 1;
    private int maxChainAnnotationCount = 0;

    /**
     * Sets the <code>layerAlignmentMap</code> attribute of the
     * <code>AnnotationContainer</code> object.
     *
     * @param layerAlignmentMap The new <code>layerAlignmentMap</code> value.
     */
    public void setLayerAlignmentMap(Map layerAlignmentMap) {
        this.layerAlignmentMap = layerAlignmentMap;
    }

    /**
     * Gets the <code>Length</code> attribute of the <code>Annotation</code> object.
     *
     * @return The <code>Length</code> value.
     */
    public float getLength() {
        return length;
    }

    /**
     * Gets the <code>alignmentUpMap</code> attribute of the <code>Annotation </code>
     * object.
     *
     * @return The <code>alignmentUpMap</code> value.
     */
    public Map getAlignmentMap() {
        return alignmentMap;
    }

    /**
     * Gets the <code>AlignmentCount</code> attribute of the <code>Annotation </code>
     * object.
     *
     * @return The <code>AlignmentCount</code> value.
     */
    public int getAlignmentCount() {
        return getAlignments().size();
    }

    /**
     * Gets the <code>AllObjects</code> attribute of the <code>Annotation</code> object.
     *
     * @param collection Description of parameter.
     */
    public void getAllObjects(Collection collection) {
        if (getAlignments() != null) {
            collection.addAll(getAlignments());
        }
    }

    /**
     * Gets the <code>Alignments</code> attribute of the <code>Annotation</code> object.
     *
     * @return The <code>Alignments</code> value.
     */
    public Collection getAlignments() {
        return alignmentSet;
    }

    /**
     * Gets the <code>Position</code> attribute of the <code>Annotation</code> object.
     *
     * @param alignment Description of parameter.
     *
     * @return The <code>Position</code> value.
     */
    public float getPosition(Alignment alignment) {
        Iterator iterator = getAlignments().iterator();
        Alignment candidate;
        float position = -0.5f * length;
        while (iterator.hasNext()) {
            candidate = (Alignment) iterator.next();
            if (candidate != alignment) {
                position += alignment.getLength();
                if (iterator.hasNext()) {
                    position += Parameter.alignmentDistance;
                }
            } else {
                return position;
            }
        }
        return 0;
    }

    /**
     * Gets the <code>chainAnnotationCount</code> attribute of the
     * <code>AnnotationContainer</code> object.
     *
     * @return The <code>chainAnnotationCount</code> value.
     */
    public int getChainAnnotationCount() {
        return maxChainAnnotationCount;
    }

    /**
     * Gets the <code>layerAlignmentMap</code> attribute of the
     * <code>AnnotationContainer</code> object.
     *
     * @return The <code>layerAlignmentMap</code> value.
     */
    public Map getLayerAlignmentMap() {
        return layerAlignmentMap;
    }

    /**
     * Description of the method.
     */
    public void createAlignmentMap() {
        alignmentMap.clear();
        createAlignmentMap(layerAlignmentMap, alignmentMap);
    }

    /**
     * Description of the method.
     *
     * @return Description of the returned value.
     */
    public String toString() {
        return new String("Annotation Container");
    }

    /**
     * Description of the method.
     */
    public void cleanup() {
        super.cleanup();
        cleanup(alignmentMap);
        alignmentMap = null;
        cleanup(alignmentSet);
        alignmentSet = null;
        cleanup(layerAlignmentMap);
        layerAlignmentMap = null;
    }

    /**
     * Description of the method.
     */
    public void update() {

        // calculate sum length of the all alignments
        Iterator iterator = getAlignments().iterator();
        Alignment alignment;
        length = 0;
        height = 0;
        maxChainAnnotationCount = 0;

        // compute max alignment height and overall length
        while (iterator.hasNext()) {
            alignment = (Alignment) iterator.next();
            alignment.update();
            length += alignment.getLength();
            if (iterator.hasNext()) {
                length += Parameter.alignmentDistance;
            }
            if (maxChainAnnotationCount < alignment.getChainAnnotationCount()) {
                maxChainAnnotationCount = alignment.getChainAnnotationCount();
            }
        }
    }

    /**
     * Description of the method.
     *
     * @param alignment Description of parameter.
     */
    public void add(Alignment alignment) {
        getAlignments().add(alignment);
    }

    /**
     * Description of the method.
     *
     * @param residue Description of parameter.
     *
     * @return Description of the returned value.
     */
    public Residue mapResidue(Residue residue) {
        if (alignmentMap != null) {
            Collection alignedResidues = (Collection) alignmentMap.get(residue);
            if (alignedResidues != null) {
                return (Residue) alignedResidues.iterator().next();
            }
        }
        return null;
    }

    /**
     * Description of the method.
     *
     * @param residue Description of parameter.
     *
     * @return Description of the returned value.
     */
    public Collection mapResidues(Residue residue) {
        return mapResidues(alignmentMap, residue);
    }

    /**
     * Creates a bidirectional alignment map. A residue is mapped to a set of aligned
     * residues.
     *
     * @param layerAlignmentMap Description of parameter.
     * @param alignmentMap Description of parameter.
     */
    public static void createAlignmentMap(Map layerAlignmentMap,
        Map alignmentMap) {
        Iterator iterator = layerAlignmentMap.values().iterator();
        Map map;
        Collection alignedResidues;
        Collection referenceResidues;
        Iterator alignedResidueIterator;
        Object alignedResidue;
        Object residue;
        Map referenceMap = new HashMap();

        // iterate over all layer alignments
        while (iterator.hasNext()) {

            // this map contains residue to residue mappings
            map = (Map) iterator.next();
            alignedResidueIterator = map.keySet().iterator();

            // iterator over all residues that are aligned in that layer map
            while (alignedResidueIterator.hasNext()) {
                alignedResidue = alignedResidueIterator.next();
                residue = (Residue) map.get(alignedResidue);

                // also store the other direction (aligned to reference)
                referenceResidues =
                    (Collection) alignmentMap.get(alignedResidue);
                if (referenceResidues == null) {
                    referenceResidues = new HashSet();
                    alignmentMap.put(alignedResidue, referenceResidues);
                }
                referenceResidues.add(residue);

                // aligned --> reference
                alignedResidues = (Collection) referenceMap.get(residue);
                if (alignedResidues == null) {
                    alignedResidues = new HashSet();
                    referenceMap.put(residue, alignedResidues);
                }

                // add a residue to the set of aligned residues
                alignedResidues.add(alignedResidue);

                // reference -> aligned
            }
        }
        Map supplementMap = new HashMap();
        iterator = alignmentMap.keySet().iterator();
        Iterator referenceResidueIterator;
        while (iterator.hasNext()) {
            alignedResidue = (Residue) iterator.next();
            referenceResidues = (Collection) alignmentMap.get(alignedResidue);
            referenceResidueIterator =
                new HashSet(referenceResidues).iterator();
            while (referenceResidueIterator.hasNext()) {
                residue = (Residue) referenceResidueIterator.next();
                alignedResidues = (Collection) referenceMap.get(residue);
                referenceResidues.addAll(alignedResidues);
                referenceResidues.remove(alignedResidue);
            }
        }
        alignmentMap.putAll(referenceMap);
        alignmentMap.putAll(supplementMap);
    }

    /**
     * Description of the method.
     *
     * @param alignmentMap Description of parameter.
     * @param residue Description of parameter.
     *
     * @return Description of the returned value.
     */
    public static final Collection mapResidues(Map alignmentMap, Residue residue) {
        Residue mappedResidue = null;
        Map map;
        if (alignmentMap != null) {
            return (Collection) alignmentMap.get(residue);
        }
        return null;
    }
}
