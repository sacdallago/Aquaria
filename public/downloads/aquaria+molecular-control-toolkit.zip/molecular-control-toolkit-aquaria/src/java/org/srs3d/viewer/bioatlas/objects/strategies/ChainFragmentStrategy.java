/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.objects.strategies;

import org.srs3d.viewer.bioatlas.objects.AbstractChain;
import org.srs3d.viewer.bioatlas.objects.ChainFragment;
import org.srs3d.viewer.bioatlas.objects.Residue;
import org.srs3d.viewer.j3d.Reaction;
import org.srs3d.viewer.j3d.attributes.Visible;
import org.srs3d.viewer.j3d.commands.ColorCommand;
import org.srs3d.viewer.j3d.commands.ExpandCommand;
import org.srs3d.viewer.j3d.commands.IdentificationCommand;
import org.srs3d.viewer.j3d.commands.PreSelectCommand;
import org.srs3d.viewer.j3d.commands.RepresentationCommand;
import org.srs3d.viewer.j3d.objects.strategies.AbstractStrategy;
import org.srs3d.viewer.j3d.objects.strategies.reactions.EmptyReaction;
import org.srs3d.viewer.objects.Attribute;
import org.srs3d.viewer.objects.Command;
import org.srs3d.viewer.objects.State;
import org.srs3d.viewer.objects.StateManager;

/**
 * @author Karsten Klein
 *
 * @created April 03, 2001
 */
public class ChainFragmentStrategy extends AbstractStrategy {

    /**
     * Constructor description.
     */
    public ChainFragmentStrategy() {
        register(RepresentationCommand.class, EmptyReaction.getSharedInstance());
        register(PreSelectCommand.class, EmptyReaction.getSharedInstance());
        register(ColorCommand.class, EmptyReaction.getSharedInstance());

        //    register( ExpandCommand.class, new ExpandReaction() );
        register(IdentificationCommand.class, new IdentificationReaction());
    }

    /**
     * Class description.
     *
     * @author Karsten Klein, LION bioscience AG
     */
    public class ExpandReaction implements Reaction {

        /**
         * Method description.
         *
         * @param command Parameter description.
         */
        public void execute(Command command) {
            ExpandCommand expandCommand = (ExpandCommand) command;
            if (expandCommand.isExpand()) {
                AbstractChain chain = (AbstractChain) command.getObject();
                if (chain.isLigand()) {
                    Residue residue = chain.getInitialResidue();
                    Residue limit = chain.getEndResidue().getProceeding();
                    StateManager stateManager =
                        expandCommand.getContextData().getStateManager();
                    State state;
                    while (residue != null && residue != limit) {
                        state = stateManager.getState(residue);
                        state.setAttribute(Attribute.getInstance(Visible.class));
                        stateManager.register(residue, state);
                        residue = residue.getProceeding();
                    }
                }

                // let the command do the rest
                command.execute();
            }
        }
    }

    /**
     * Reaction for retrieving the object identification.
     *
     * @author Karsten Klein
     *
     * @created March 26, 2002
     */
    public static class IdentificationReaction implements Reaction {

        /**
         * Execute implementation of the reaction interface.
         *
         * @param command Command to react to.
         */
        public void execute(Command command) {
            IdentificationCommand idCommand = (IdentificationCommand) command;
            ChainFragment chainFragment = (ChainFragment) command.getObject();
            idCommand.setObjectId("CF:" + (int) chainFragment.getId() + "-" +
                chainFragment.getSerial());
            idCommand.execute();
        }
    }
}
