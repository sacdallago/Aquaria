/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d;

import java.awt.image.BufferedImage;

import javax.media.j3d.Canvas3D;
import javax.media.j3d.ImageComponent2D;
import javax.media.j3d.Screen3D;

import org.srs3d.viewer.util.ExceptionHandler;

import com.sun.j3d.utils.universe.SimpleUniverse;
import com.sun.j3d.utils.universe.Viewer;

/**
 * Description of the class.
 *
 * @author Karsten Klein
 *
 * @created April 28, 2003
 */
public class OffscreenContext extends Canvas3D {
    private Context referenceContext = null;
    private boolean isInitialized = false;

    /**
     * OffscreenContext constructor.
     *
     * @param referenceContext Description of parameter.
     */
    public OffscreenContext(Context referenceContext) {
        super(Context.getOffscreenGraphicsConfiguration(), true);
        this.referenceContext = referenceContext;
    }

    /**
     * Description of the method.
     */
    public void setup() {
        if (!isInitialized) {
            Viewer viewer =
                ((SimpleUniverse) referenceContext.getUniverse()).getViewer();
            viewer.getView().addCanvas3D(this);
            isInitialized = true;
        }
    }

    /**
     * Retrieves the image attribute of the OffscreenContext object.
     *
     * @return The image value.
     */
    public BufferedImage getImage() {
        BufferedImage buffer = null;
        ImageComponent2D image = null;
        try {
            int width = referenceContext.getWidth();
            int height = referenceContext.getHeight();
            Screen3D referenceScreen = referenceContext.getScreen3D();
            Screen3D screen = getScreen3D();

            // adapt all sizes to the reference context size
            setSize(width, height);
            screen.setSize(referenceScreen.getSize());
            screen.setPhysicalScreenHeight(referenceScreen.getPhysicalScreenHeight());
            screen.setPhysicalScreenWidth(referenceScreen.getPhysicalScreenWidth());
            buffer =
                new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
            image = new ImageComponent2D(ImageComponent2D.FORMAT_RGB, buffer);
            setOffScreenBuffer(image);
            renderOffScreenBuffer();
            waitForOffScreenRendering();
        } catch (Exception e) {
            ExceptionHandler.handleException(e,
                ExceptionHandler.TRACE_IN_RELEASE);
        }
        if (image != null) {
            return image.getImage();
        }
        return null;
    }

    /**
     * Description of the method.
     */
    public void cleanup() {
        if (isInitialized) {
            Viewer viewer =
                ((SimpleUniverse) referenceContext.getUniverse()).getViewer();
            viewer.getView().removeCanvas3D(this);
            isInitialized = false;
        }
    }
}
