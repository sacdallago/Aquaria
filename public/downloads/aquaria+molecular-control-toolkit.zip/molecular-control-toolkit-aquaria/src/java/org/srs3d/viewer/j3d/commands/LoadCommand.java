/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.commands;

import java.net.URL;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;

import javax.media.j3d.BranchGroup;
import javax.vecmath.Point3f;

import org.srs3d.viewer.bioatlas.creators.LayerGeometryCreator;
import org.srs3d.viewer.bioatlas.loaders.GenericLoader;
import org.srs3d.viewer.bioatlas.objects.Layer;
import org.srs3d.viewer.bioatlas.styles.FirstImpressionStyle;
import org.srs3d.viewer.bioatlas.styles.Style;
import org.srs3d.viewer.bioatlas.visitors.AtomCollector;
import org.srs3d.viewer.j3d.BranchGroupHelper;
import org.srs3d.viewer.j3d.Context;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.Junction;
import org.srs3d.viewer.j3d.Selection;
import org.srs3d.viewer.j3d.Transform;
import org.srs3d.viewer.j3d.attributes.Visible;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.objects.ObjectContainer;
import org.srs3d.viewer.objects.State;
import org.srs3d.viewer.objects.StrategyManager;

/**
 * Load command.
 *
 * @author Karsten Klein
 *
 * @created April 03, 2001
 */
public class LoadCommand extends ObjectCommand {

    /** Description of the field */
    private float accuracy = 1.0f;

    /**
     * <code>LoadCommand</code> constructor.
     *
     * @param contextData Description of parameter.
     */
    public LoadCommand(ContextData contextData) {
        super(contextData);
    }

    /**
     * Sets the <code>Accuracy</code> attribute of the <code>LoadCommand</code> object.
     *
     * @param accuracy The new <code>Accuracy</code> value.
     */
    public void setAccuracy(float accuracy) {
        this.accuracy = accuracy;
    }

    /**
     * Description of the method.
     */
    public void execute() {
        LoadThread.schedule(this);
    }

    /**
     * Description of the method.
     *
     * @return Description of the returned value.
     */
    public boolean load() {
        ContextData contextData = getContextData();
        Context context = contextData.getContext();
        if (context != null) {
            if (getObject() != null) {
                State.Immutable state =
                    contextData.getStateManager().getImmutableState(getObject());
                if (state.hasAttribute(Visible.class)) {
                    Layer layer = (Layer) getObject();
                    clearLayer(layer);
                    Transform transform =
                        contextData.getTransformManager().getTransform(layer);
                    if (transform == null) {
                        transform = new Transform();
                        transform.setTransform(layer.getCoordinate());
                        contextData.getTransformManager().register(layer,
                            transform);
                    }
                    StrategyManager strategyManager =
                        contextData.getStrategyManager();
                    if (accuracy == 1) {
                        try {
                            String composedUrl =
                                org.srs3d.viewer.bioatlas.Parameter.pdbUrlPrefix +
                                layer.getId("PDB") + ".brk.gz";
                            URL url = new URL(composedUrl);
                            GenericLoader loader = new GenericLoader();
                            ObjectContainer localContainer = loader.load(url);
                            if (localContainer != null) {
                                Iterator iterator = layer.getIterator();
                                AbstractObject object;
                                layer.merge(localContainer);

                                // center the all atoms in the database
                                AtomCollector atomCollector =
                                    new AtomCollector();
                                atomCollector.visit((AbstractObject) localContainer);
                                Point3f translation =
                                    new Point3f(atomCollector.getCenter());
                                translation.negate();
                                atomCollector.translateAtoms(translation);
                                transform.attachRotateBehaviors(contextData,
                                    layer);
                            }
                        } catch (Exception e) {

                            // :SILENT EXCEPTION:
                        }
                        Junction junction =
                            contextData.getJunctionManager().getJunction(layer);
                        Style style = new FirstImpressionStyle(contextData);
                        style.applyStateChange(layer);

                        // spawn new geometry
                        SpawnCommand spawn = new SpawnCommand(contextData);
                        spawn.setObject(layer);
                        spawn.setBranchGroup(junction.getOnBranch());
                        strategyManager.execute(layer, spawn);
                        BranchGroup branch = new BranchGroup();
                        BranchGroupHelper.setDefaultCapabilities(branch);
                        LayerGeometryCreator pgc =
                            (LayerGeometryCreator) contextData.getGeometryCreatorFactory()
                                                              .getGeometryCreator(layer);
                        pgc.modifyAttributes(contextData, layer);
                        pgc.createAlternate(layer, branch);
                        BranchGroupHelper.detach(contextData,
                            junction.getOffBranch());
                        junction.getOffBranch().addChild(branch);
                        style.applyColorScheme(layer);
                        Selection selection =
                            contextData.getSelectionManager().getSelection();
                        if (selection.contains(layer)) {

                            // contextData.getStrategyManager().propagate( layer, new SelectCommand( contextData, true ) );
                        }
                    } else {

                        // spawn without further data (point)
                        SpawnCommand spawn = new SpawnCommand(contextData);
                        spawn.setObject(layer);
                        strategyManager.execute(layer, spawn);

                        // detach rotate behavior
                    }
                }
            }
            context = null;
            return true;
        }
        return false;
    }

    /**
     * Description of the method.
     *
     * @param layer Description of parameter.
     */
    private void clearLayer(Layer layer) {
        ContextData contextData = getContextData();
        Iterator iterator = layer.getIterator();
        Collection data = new HashSet();
        if (iterator.hasNext()) {
            AbstractObject object;
            while (iterator.hasNext()) {
                object = (AbstractObject) iterator.next();
                contextData.getStrategyManager().propagate(object,
                    new GeometryLockCommand(contextData, false));
                contextData.getStrategyManager().propagate(object,
                    new RegisterCommand(contextData, false));
                contextData.getSpawnerManager().remove(object);
                contextData.getShapeManager().remove(object);
                ObjectContainer.clearDeep(object);
                iterator.remove();
            }
        }
        layer.clear();
    }
}
