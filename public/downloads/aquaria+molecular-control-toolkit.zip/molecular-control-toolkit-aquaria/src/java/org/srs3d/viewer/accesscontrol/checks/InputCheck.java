/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.accesscontrol.checks;

import java.applet.AppletStub;
import java.net.URL;
import java.util.Iterator;
import java.util.Map;
import java.util.StringTokenizer;

import org.srs3d.viewer.util.ExceptionHandler;
import org.srs3d.viewer.util.XmlTag;

/**
 * This AccessCheck implementation checks the loaded structure for inclusion in the
 * licesen key file.
 *
 * @author Karsten Klein
 *
 * @created August 23, 2002
 */
public class InputCheck extends ExpirationCheck {
    private transient Map accessibleInputFiles;

    /**
     * Gets the <code>name</code> attribute of the <code>InputCheck</code> object.
     *
     * @return The <code>name</code> value.
     */
    public String getName() {
        return "InputCheck-1.0";
    }

    /**
     * Check implementation.
     *
     * @param appletStub AppletStub with all necessary information.
     *
     * @return <code>true</code> if the access check was successful.
     */
    public boolean check(AppletStub appletStub) {
        if (super.check(appletStub)) {
            try {

                // extract the structure parameters
                String structures =
                    appletStub.getParameter("structures").trim();
                int index = structures.indexOf("{");
                structures = structures.substring(index + 1);
                index = structures.indexOf("}");
                structures = structures.substring(0, index);

                // got the plain structure block now
                StringTokenizer tokenizer =
                    new StringTokenizer(structures, ";");
                String token;
                while (tokenizer.hasMoreTokens()) {
                    token = tokenizer.nextToken();
                    if (!isValidInputFile(appletStub, token)) {
                        return false;
                    }
                }
                return true;
            } catch (Exception e) {
                ExceptionHandler.handleException(e,
                    ExceptionHandler.SILENT_IN_RELEASE, this);
            }
        }
        return false;
    }

    /**
     * Description of the method.
     *
     * @param object Description of parameter.
     */
    public void read(Object object) {
        super.read(object);
        Map map = (Map) object;

        // read accesible input files
        accessibleInputFiles = (Map) map.get("AccessibleInputFiles");
    }

    /**
     * Description of the method.
     *
     * @param object Description of parameter.
     */
    public void write(Object object) {
        super.write(object);
        Map map = (Map) object;

        // write accesible input files
        map.put("AccessibleInputFiles", accessibleInputFiles);
    }

    /**
     * Description of the method.
     */
    public XmlTag createXmlTag() {
        XmlTag xmlTag = super.createXmlTag();
        XmlTag subtag;
        Iterator iterator = accessibleInputFiles.keySet().iterator();
        Object object;
        while (iterator.hasNext()) {
            object = iterator.next();
            subtag = new XmlTag("file");
            subtag.setAttribute("name", object.toString());
            subtag.setAttribute("size",
                accessibleInputFiles.get(object).toString());
            xmlTag.getSubtags().add(subtag);
        }
        return xmlTag;
    }

    /**
     * Gets the <code>validInputFile</code> attribute of the <code>InputCheck</code>
     * object.
     *
     * @param appletStub Description of parameter.
     * @param string Description of parameter.
     *
     * @return The <code>validInputFile</code> value.
     */
    private boolean isValidInputFile(AppletStub appletStub, String string) {
        try {

            // :NOTE: this is related to the stucture input parameter
            // cut away everything but the filename
            string = string.substring(string.indexOf(",") + 1);
            string = string.substring(0, string.indexOf(",")).trim();

            // url are more general and also work for the static web pages
            URL url =
                org.srs3d.viewer.bioatlas.Parameter.supplementUrl(appletStub.getCodeBase(),
                    string);

            // request length of a file
            long length = url.openConnection().getContentLength();

            // extract filename from the path
            String id = url.getFile();
            int index = id.lastIndexOf("/");
            if (index != 1) {
                id = id.substring(index + 1);
            }

            // read the expected length (extracted from the license ley file)
            Long validLength = ((Long) accessibleInputFiles.get(id));
            if (validLength == null) {

                // try with lower case (case insensitive)
                validLength = ((Long) accessibleInputFiles.get(id.toLowerCase()));
            }

            // return true if the file sizes are equal
            return validLength.longValue() == length;
        } catch (Exception e) {

            // catch silently; file not in list
            ExceptionHandler.handleException(e,
                ExceptionHandler.SILENT_IN_RELEASE, this);
        }

        // ... and false if any exception happens
        return false;
    }
}
