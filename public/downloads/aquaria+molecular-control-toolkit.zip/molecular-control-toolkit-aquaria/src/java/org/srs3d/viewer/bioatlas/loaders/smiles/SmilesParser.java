/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.loaders.smiles;

import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.vecmath.Point3f;

import org.srs3d.viewer.bioatlas.factories.ResidueTemplateFactory;
import org.srs3d.viewer.bioatlas.loaders.AbstractParser;
import org.srs3d.viewer.bioatlas.objects.Atom;
import org.srs3d.viewer.bioatlas.objects.Bond;
import org.srs3d.viewer.bioatlas.objects.Chain;
import org.srs3d.viewer.bioatlas.objects.Residue;
import org.srs3d.viewer.bioatlas.visitors.ChainAnalyser;
import org.srs3d.viewer.objects.ObjectContainer;
import org.srs3d.viewer.objects.visitors.ObjectUpdater;
import org.srs3d.viewer.util.Log;

/**
 * This class implements a parser reading sdf files/urls. The method <code>parse</code>
 * files all extracted data in a database.
 *
 * @author Karsten Klein
 *
 * @created March 7, 2003
 */
public class SmilesParser implements AbstractParser {
    private static final Log log = new Log(SmilesParser.class);
    private static final boolean isVerbose = false;
    private Object parameterObject = null;

    /**
     * <code>SdfParser</code> constructor.
     *
     * @param filename Description of parameter.
     *
     * @exception FileNotFoundException Description of exception.
     */
    public SmilesParser(String filename) throws FileNotFoundException {
    }

    /**
     * <code>PdbParser</code> contructor.
     *
     * @param inputStream Description of parameter.
     */
    public SmilesParser(InputStream inputStream) {
    }

    /**
     * Sets the <code>parameterObject</code> attribute of the <code>SdfParser</code>
     * object.
     *
     * @param parameterObject The new <code>parameterObject</code> value.
     */
    public void setParameterObject(Object parameterObject) {
        this.parameterObject = parameterObject;
    }

    /**
     * Description of the method.
     *
     * @return Description of the returned value.
     */
    public ObjectContainer parse() {
        ObjectContainer objectContainer = new ObjectContainer();
        String line;
        ArrayList atoms = null;
        ArrayList bonds = null;
        String name = null;
        float scaleFactor = 1.0f;
        String moleculeId = null;
        int startLineIndex = 0;
        int nameLineIndex = 0;
        int lineIndex = 0;
        String alternativeName = "structure";
        org.openscience.cdk.Molecule molecule = null;
        try {

            // parse information from parameter object
            if (parameterObject != null) {
                String smiles = (String) parameterObject;
                alternativeName = "Smile " + smiles;
                try {
                    org.openscience.cdk.smiles.SmilesParser parser =
                        new org.openscience.cdk.smiles.SmilesParser();
                    molecule = parser.parseSmiles(smiles);
                } catch (Throwable t) {
                    log.debug(t, t);
                }
                if (molecule != null) {
                    org.openscience.cdk.layout.StructureDiagramGenerator processor =
                        new org.openscience.cdk.layout.StructureDiagramGenerator();
                    processor.setMolecule(molecule, false);
                    processor.generateCoordinates();
                    molecule = processor.getMolecule();
                    atoms = new ArrayList();
                    bonds = new ArrayList();
                    org.openscience.cdk.Atom[] smilesAtoms =
                        molecule.getAtoms();
                    org.openscience.cdk.Atom smilesAtom;
                    Map atomMap = new HashMap();
                    for (int i = 0; i < smilesAtoms.length; i++) {
                        smilesAtom = smilesAtoms[i];
                        Atom atom = new Atom();
                        if (smilesAtom.getPoint2D() != null) {
                            atom.setCoordinate(new Point3f(
                                    (float) smilesAtom.getX2D(),
                                    (float) smilesAtom.getY2D(), 0));
                        }
                        if (smilesAtom.getPoint3D() != null) {
                            atom.setCoordinate(new Point3f(
                                    (float) smilesAtom.getX3D(),
                                    (float) smilesAtom.getY3D(),
                                    (float) smilesAtom.getZ3D()));
                        }
                        String template = smilesAtom.getSymbol();
                        if (template.length() == 1) {
                            template = " " + template;
                        }
                        while (template.length() < 4) {
                            template += " ";
                        }
                        atom.setTemplate(org.srs3d.viewer.bioatlas.factories.AtomTemplateFactory.getTemplate(
                                template));
                        atoms.add(atom);
                        atomMap.put(smilesAtom, atom);
                    }
                    org.openscience.cdk.Bond[] smilesBonds =
                        molecule.getBonds();
                    org.openscience.cdk.Bond smilesBond;
                    for (int i = 0; i < smilesBonds.length; i++) {
                        smilesBond = smilesBonds[i];

                        // bonds
                        Bond bond = new Bond();

                        // index numbers have been merged (second one exceeds 99)
                        bond.setAtom0((Atom) atomMap.get(smilesBond.getAtomAt(0)));
                        bond.setAtom1((Atom) atomMap.get(smilesBond.getAtomAt(1)));
                        bonds.add(bond);
                        Bond bond1 = new Bond();
                        bond1.setAtom1(bond.getAtom0());
                        bond1.setAtom0(bond.getAtom1());
                        bond1.setType(bond.getType());
                        bonds.add(bond1);
                    }
                }
            }
        } catch (Exception e) {
            log.error(e, e);
        }

        // convert current atom and bond list into appropraite data structure
        if (atoms != null) {
            if (!atoms.isEmpty()) {
                if (name == null) {
                    name = alternativeName;
                }
                Residue residue = new Residue();
                residue.setTemplate(ResidueTemplateFactory.getTemplate(name));
                residue.getAtoms().addAll(atoms);
                residue.getBonds().addAll(bonds);
                Chain chain = new Chain();
                chain.addResidue(residue);
                chain.getExceptionalResidues().add(residue);
                objectContainer.setName(name);
                objectContainer.addObject(chain);
                line = null;
            }
        }

        // run chain split
        ChainAnalyser chainAnalyser = new ChainAnalyser();
        chainAnalyser.visit(objectContainer);

        // run object update (deep)
        ObjectUpdater objectUpdater = new ObjectUpdater();
        objectUpdater.visit(objectContainer);
        return objectContainer;
    }

    /**
     * Gets the <code>verbose</code> attribute of the <code>SdfParser</code> class.
     *
     * @return The <code>verbose</code> value.
     */
    public static final boolean isVerbose() {
        return isVerbose;
    }
}
