/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.annotation.contexts;

import java.awt.GraphicsConfiguration;

import javax.media.j3d.AmbientLight;
import javax.media.j3d.BoundingSphere;
import javax.media.j3d.BranchGroup;
import javax.media.j3d.PointLight;
import javax.media.j3d.Transform3D;
import javax.media.j3d.TransformGroup;
import javax.vecmath.Color3f;
import javax.vecmath.Matrix4f;
import javax.vecmath.Point3d;
import javax.vecmath.Point3f;

import org.srs3d.viewer.j3d.Context;
import org.srs3d.viewer.j3d.Selection;

/**
 * AbstractAnnotationContext; All Known Implementing Classes:
 * <code>AnnotationContext</code> , <code>SequenceContext</code>
 *
 * @author Christian Zofka
 *
 * @created August 13, 2001
 */
public abstract class AbstractAnnotationContext extends Context {

    /** Description of the field. */
    protected boolean usesInternalTransformation = false;

    /**
     * <code>AnnotationContext</code> contructor.
     */
    public AbstractAnnotationContext() {
        super();
    }

    /**
     * Constructs a context with the appropriate <code>GraphicsContext</code>
     *
     * @param graphicsConfiguration Description of parameter
     */
    public AbstractAnnotationContext(
        GraphicsConfiguration graphicsConfiguration) {
        super(graphicsConfiguration, false);
    }

    /**
     * Constructs a context with the appropriate <code>GraphicsContext</code> and offset
     * screen flag
     *
     * @param graphicsConfiguration Description of parameter
     * @param offScreen Description of parameter
     */
    public AbstractAnnotationContext(
        GraphicsConfiguration graphicsConfiguration, boolean offScreen) {
        super(graphicsConfiguration, offScreen);
    }

    /**
     * Method description.
     *
     * @param isBlackBackground Parameter description.
     */
    public void setupLights(boolean isBlackBackground) {
        BranchGroup lightBranch = new BranchGroup();
        lightBranch.setCapability(BranchGroup.ALLOW_DETACH);
        setLightBranch(lightBranch);
        BoundingSphere bounds =
            new BoundingSphere(new Point3d(), Double.MAX_VALUE);
        AmbientLight ambientLight;
        PointLight pointLight0;
        if (isBlackBackground) {

            // create lights
            ambientLight = new AmbientLight(new Color3f(0.4f, 0.4f, 0.4f));
            pointLight0 =
                new PointLight(new Color3f(0.7f, 0.7f, 0.7f),
                    new Point3f(-420000, 220000, 420000), new Point3f(1, 0, 0));
        } else {
            ambientLight = new AmbientLight(new Color3f(0.6f, 0.6f, 0.6f));
            pointLight0 =
                new PointLight(new Color3f(1.9f, 1.9f, 1.9f),
                    new Point3f(-420000, 0, 420000), new Point3f(1, 0, 0));
        }
        lightBranch.addChild(ambientLight);
        lightBranch.addChild(pointLight0);

        // set the influencing bounds
        ambientLight.setInfluencingBounds(bounds);
        pointLight0.setInfluencingBounds(bounds);
        getViewerAvatar().addChild(lightBranch);
    }

    /**
     * Gets the <code>viewingPlatformTransform</code> attribute of the
     * <code>AnnotationContext</code> object.
     *
     * @return The <code>viewingPlatformTransform</code> value.
     */
    public Transform3D getViewingPlatformTransform() {
        if (getViewingPlatform() != null) {
            TransformGroup transformGroup =
                getViewingPlatform().getViewPlatformTransform();
            Transform3D transform = new Transform3D();
            transformGroup.getTransform(transform);
            if (getSceneTransform() != null && usesInternalTransformation) {

                // modifies the transform
                Matrix4f matrix = new Matrix4f();
                transform.get(matrix);
                Transform3D transformS = new Transform3D();
                getSceneTransform().getTransform(transformS);
                Matrix4f matrixScene = new Matrix4f();
                transformS.get(matrixScene);
                matrix.m03 /= matrixScene.m00;
                matrix.m23 = 350 / matrixScene.m00;
                transform.set(matrix);
            }
            return transform;
        }
        return null;
    }

    /**
     * Description of the method.
     */
    public void clearContent() {
        Selection selection =
            getContextData().getSelectionManager().getSelection();
        selection.clear();
        getContextData().getAppearanceManager().clear();
        getContextData().getSpawnerManager().clear();
        getContextData().getStateManager().clear();
        getContextData().getTransformManager().clear();
        getContextData().getObjectManager().clear();
    }

    /**
     * Description of the method.
     */
    public void adjustClipping() {
        super.adjustClipping();
        getView().setBackClipDistance(350);

        // :FIXME: we have to assure this clipping 'factor' works on EVERY machine
        getView().setFrontClipDistance(400 / 75);
    }

    /**
     * Initialize the <code>ContextData</code> attribute of the
     * <code>AbstractAnnotationContext</code> object.
     */
    protected void initializeContextData() {
        setContextData(new AnnotationContextData(this));
    }
}
