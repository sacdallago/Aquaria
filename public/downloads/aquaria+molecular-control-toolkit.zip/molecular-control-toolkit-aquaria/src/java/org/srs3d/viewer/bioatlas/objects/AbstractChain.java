/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.objects;

import java.util.Collection;
import java.util.HashSet;

import org.srs3d.viewer.bioatlas.factories.ResidueTemplateFactory;
import org.srs3d.viewer.bioatlas.objects.templates.ResidueTemplate;
import org.srs3d.viewer.objects.AbstractObject;

/**
 * General abstract baseclass defining for residue chain objects. The
 * <code>AbstractChain</code> implements a double linked list of <code>Residue</code>
 * objects.
 *
 * @author Karsten Klein
 *
 * @created March 27, 2001
 */
public abstract class AbstractChain extends AbstractObject {

    /** Reference to the first residue in the chain */
    private Residue initialResidue = null;

    /** Reference to the last residue in the chain */
    private Residue endResidue = null;

    /** Length of the chain. This value can be computed and is chached in this parameter */
    private int length = -1;
    private byte ligandState = -1;

    /** List of residues that have to be excluded from any type of classification. */
    private Collection exceptionalResidues = null;

    /** Indicates terminition state */
    private boolean terminated = false;

    /**
     * Sets the <code>initialResidue</code> of the <code>AbstractChain</code> object.
     *
     * @param initialResidue The new <code>initialResidue</code> value.
     */
    public void setInitialResidue(Residue initialResidue) {
        this.initialResidue = initialResidue;
        invalidate();
    }

    /**
     * Sets the <code>EndResidue</code> attribute of the <code>AbstractChain
     * </code>object.
     *
     * @param endResidue The new <code>EndResidue</code> value.
     */
    public void setEndResidue(Residue endResidue) {
        this.endResidue = endResidue;
        invalidate();
    }

    /**
     * Sets the <code>Terminated</code> attribute of the <code>AbstractChain
     * </code>object.
     *
     * @param terminated The new <code>Terminated</code> value.
     */
    public final void setTerminated(boolean terminated) {
        this.terminated = terminated;
    }

    /**
     * Sets the <code>Length</code> attribute of the <code>AbstractChain</code> object.
     */
    public void invalidate() {
        this.length = -1;
        this.ligandState = -1;
    }

    /**
     * Gets the <code>InitialResidue</code> attribute of the <code>AbstractChain
     * </code>object.
     *
     * @return The <code>InitialResidue</code> value.
     */
    public final Residue getInitialResidue() {
        return initialResidue;
    }

    /**
     * Gets the <code>EndResidue</code> attribute of the <code>AbstractChain
     * </code>object.
     *
     * @return The <code>EndResidue</code> value.
     */
    public final Residue getEndResidue() {
        return endResidue;
    }

    /**
     * Gets the <code>Terminated</code> attribute of the <code>AbstractChain
     * </code>object.
     *
     * @return The <code>Terminated</code> value.
     */
    public final boolean isTerminated() {
        return terminated;
    }

    /**
     * Gets the length of the <code>AbstractChain</code> object.
     *
     * @return Length of the chain.
     */
    public final int getLength() {
        if (length == -1) {
            length = computeLength();
        }
        if (length == -1) {
            return 0;
        } else {
            return length;
        }
    }

    /**
     * Searches for a <code>Residue</code> with the specified attributes.
     *
     * @param residueName Name of the residue.
     * @param residueId Id of the residue.
     * @param residueICode Insertion code of the residue.
     *
     * @return Found residue (in the chain) of <code>null</code> if no residue with these
     *         attributes was found..
     */
    public Residue getResidue(String residueName, int residueId,
        char residueICode) {
        Residue residue = getEndResidue();
        Residue limit = getInitialResidue();
        if (limit != null) {
            limit = limit.getPreceeding();
        }
        while (residue != null && residue != limit) {
            if (residue.getId() == residueId &&
                  residue.getICode() == residueICode) {
                if (residueName != null) {
                    ResidueTemplate template =
                        ResidueTemplateFactory.getTemplate(residueName);
                    if (template == residue.getTemplate()) {
                        return residue;
                    }
                } else {
                    return residue;
                }
            }
            residue = residue.getPreceeding();
        }
        return null;
    }

    /**
     * Determines the chains classification in terms of nucleic chain or none nucleic
     * chain.
     *
     * @return <code>true</code> if the nuceic chain criteria was met.
     */
    public boolean isNucleic() {
        Residue residue = getInitialResidue();
        Residue limit = getEndResidue().getProceeding();
        boolean isNucleic = true;
        while (isNucleic && residue != limit) {
            if (!isExceptionalResidue(residue)) {
                isNucleic &= residue.getTemplate().isNucleicAcid();
            }
            residue = residue.getProceeding();
        }
        return isNucleic;
    }

    /**
     * Determines the chains classification in terms of a water chain or none water
     * chain.
     *
     * @return <code>true</code> if chain contains at least one water residue.
     */
    public boolean isWater() {
        Residue residue = getInitialResidue();
        Residue limit = getEndResidue().getProceeding();
        boolean isWater = false;
        while (!isWater && residue != limit) {
            if (!isExceptionalResidue(residue)) {
                isWater |= residue.getTemplate().isWater();
            }
            residue = residue.getProceeding();
        }
        return isWater;
    }

    /**
     * Checks the chain for ligand chain. Note that chains of length 1 are classified as
     * ligand.
     *
     * @return <code>true</code> if chain contains at least one ligand residue.
     */
    public boolean isLigand() {
        if (getLength() == 1) {
            return true;
        } else {
            if (exceptionalResidues != null &&
                  exceptionalResidues.size() == getLength()) {
                return true;
            }
            return containsLigandResidues();
        }
    }

    /**
     * Checks the list of exceptional residues whether it includes the given residue.
     *
     * @param residue Residue to examinate.
     *
     * @return <code>true</code> if the specified residue is in the exceptional list.
     */
    public boolean isExceptionalResidue(Residue residue) {
        if (exceptionalResidues != null) {
            return exceptionalResidues.contains(residue);
        }
        return false;
    }

    /**
     * Checks all residues in the chain for ligand classification.
     *
     * @return Description of the returned value.
     */
    public boolean containsLigandResidues() {
        if (ligandState == -1) {
            ligandState = 0;
            Residue residue = getInitialResidue();
            Residue limit = getEndResidue().getProceeding();
            ResidueTemplate template;
            boolean isChecked = false;
            boolean isPolypeptide = false;
            while (residue != limit) {
                isChecked = true;
                if (residue.isLigand()) {
                    if (!isExceptionalResidue(residue)) {
                        ligandState = 1;
                    }

                    //          else {
                    //
                    //            isPolypeptide = true;
                    //
                    //          }
                } else {
                    isPolypeptide = true;
                }

                //        else {
                //
                //          isPolypeptide = true;
                //
                //        }
                residue = residue.getProceeding();
            }
            if (!isPolypeptide) {
                ligandState = 1;
            }
            if (!isChecked) {
                return false;
            }
            return false;
        } else {
            return ligandState == 1;
        }
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public boolean allLigandResidues() {
        Residue residue = getInitialResidue();
        Residue limit = getEndResidue().getProceeding();
        ResidueTemplate template;
        boolean isChecked = false;
        while (residue != limit) {
            isChecked = true;
            template = residue.getTemplate();
            if (template != null) {
                if (!template.isLigand()) {
                    return false;
                }
                residue = residue.getProceeding();
            }
        }
        return true;
    }

    /**
     * Determines the length of the chain by counting the residues.
     *
     * @return Length of the chain.
     */
    public int computeLength() {
        Residue residue = getInitialResidue();
        Residue limit = getEndResidue();
        if (limit != null) {
            limit = limit.getProceeding();
            int length = 0;
            while (residue != limit) {
                length++;
                residue = residue.getProceeding();
            }
            return length;
        }
        return -1;
    }

    /**
     * Appends the residue at the end of the current chain. Note that the method doesn't
     * check for multiple adding, which ruins the double linked residue association.
     *
     * @param residue The residue to be added to the chain.
     */
    public void addResidue(Residue residue) {
        if (!isTerminated()) {
            residue.setPreceeding(null);
            residue.setProceeding(null);
            if (getInitialResidue() == null) {
                setInitialResidue(residue);
            }
            residue.setPreceeding(getEndResidue());
            if (getEndResidue() != null) {
                getEndResidue().setProceeding(residue);
            }
            setEndResidue(residue);
        }
    }

    /**
     * Computes the index (0 is index of initial residue) of the given residue.
     *
     * @param searchResidue Residue to compute the index for.
     *
     * @return Index of the Residue in the chain; <code>-1</code> if residue was not
     *         encountered.
     */
    public int computeResidueIndex(Residue searchResidue) {
        if (searchResidue == null) {
            return -1;
        }
        Residue residue = getInitialResidue();
        Residue limit = getEndResidue().getProceeding();
        int index = 0;
        while (residue != null && residue != limit) {
            if (residue == searchResidue) {
                return index;
            }
            residue = residue.getProceeding();
            index++;
        }
        return -1;
    }

    /**
     * Marks the provided residue as exceptional residue.
     *
     * @param residue Residue to include into the list of exceptional residues of the
     *        chain.
     */
    public void markExceptionalResidue(Residue residue) {
        if (exceptionalResidues == null) {
            exceptionalResidues = new HashSet();
        }
        exceptionalResidues.add(residue);
    }

    /**
     * Cleanup all attributes of the object.
     */
    public void cleanup() {
        super.cleanup();
        setInitialResidue(null);
        setEndResidue(null);
        cleanup(exceptionalResidues);
        exceptionalResidues = null;
    }

    /**
     * Method description.
     *
     * @param exceptionalResidues Parameter description.
     */
    public void setExceptionalResidues(Collection exceptionalResidues) {
        this.exceptionalResidues = exceptionalResidues;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public Collection getExceptionalResidues() {
        if (exceptionalResidues == null) {
            exceptionalResidues = new HashSet();
        }
        return exceptionalResidues;
    }
}
