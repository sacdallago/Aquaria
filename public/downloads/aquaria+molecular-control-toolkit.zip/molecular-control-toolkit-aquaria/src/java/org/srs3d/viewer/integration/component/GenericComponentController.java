/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.integration.component;

import java.awt.Component;

import org.srs3d.viewer.integration.event.ComponentEvent;
import org.srs3d.viewer.integration.interfaces.DataProvider;

/**
 * Generic implementation of the ComponentController interface. This implementation
 * facilitates the MultiplexEventController class. Minimal information for the component
 * controller has to be passed in the constructor. Inherit your implementation of the
 * ComponentController from this class and benefit from the default implementations.
 *
 * @author Karsten Klein
 *
 * @created September 20, 2002
 */
public class GenericComponentController extends MultiplexEventController
    implements ComponentController {
    private static int componentSequence = 0;
    private Component component = null;
    private DataProvider dataProvider = null;
    private String componentName;
    private int id;

    /**
     * <code>GenericComponentController</code> constructor.
     *
     * @param component Description of parameter.
     * @param dataProvider Description of parameter.
     */
    public GenericComponentController(Component component,
        DataProvider dataProvider) {

        // no parental event controller
        super(null);
        this.component = component;
        this.dataProvider = dataProvider;
        synchronized (getClass()) {
            id = componentSequence++;
            setComponentName(getClass().getName());
        }
    }

    /**
     * Sets the componentName attribute of the GenericComponentController object.
     *
     * @param componentName The new componentName value.
     */
    public void setComponentName(String componentName) {
        this.componentName = componentName;
    }

    /**
     * Returns the AWT component for this controller (the view).
     *
     * @return The AWT component.
     */
    public Component getComponent() {
        return component;
    }

    /**
     * Use this method to access the data provider. You may want to implement a method
     * that performs the cast to you DataProvider type automatically and store the cast
     * instance.
     *
     * @return The DataProvider.
     */
    public DataProvider getDataProvider() {
        return dataProvider;
    }

    /**
     * Retrieves the identifier attribute of the GenericComponentController object.
     *
     * @return The identifier value.
     */
    public String getIdentifier() {
        return "urn:" + componentName + ":" + id;
    }

    /**
     * Retrieves the componentName attribute of the GenericComponentController object.
     *
     * @return The componentName value.
     */
    public String getComponentName() {
        return componentName;
    }

    /**
     * Overwrite this class to process external events
     *
     * @param event Event that was received.
     */
    public void receive(ComponentEvent event) {
    }

    /**
     * Description of the method.
     *
     * @param event Description of parameter.
     */
    public void publish(ComponentEvent event) {

        // setting source id before publishing the event
        event.setSourceId(getIdentifier());
        super.publish(event);
    }

    /**
     * Description of the method.
     */
    public void destroy() {
    }

    /**
     * Default implementation. Always returns true
     *
     * @return Boolean value. True if closing possible without data loss.
     */
    public boolean canClose() {
        return true;
    }
}
