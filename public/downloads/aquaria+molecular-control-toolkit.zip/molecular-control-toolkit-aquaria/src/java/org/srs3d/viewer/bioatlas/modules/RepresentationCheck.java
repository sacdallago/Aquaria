/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.modules;

import java.util.Collection;
import java.util.HashSet;

import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.ProcessedSelection;
import org.srs3d.viewer.objects.ObjectManager;

/**
 * @author Karsten Klein
 *
 * @created August 06, 2001
 */
public abstract class RepresentationCheck {
    public static final int CHECK_YES = 1;
    public static final int CHECK_NO = 2;
    public static final int CHECK_LIMIT = 4;
    public static final int CHECK_FAIL = 8;

    /**
     * Description of the method.
     *
     * @param objects Description of parameter.
     *
     * @return Description of the returned value.
     */
    public abstract int check(ContextData contextData, Collection objects);

    /**
     * Description of the method.
     *
     * @param checkResult Description of parameter.
     *
     * @return Description of the returned value.
     */
    public boolean checkAll(int checkResult) {
        return (checkResult & CHECK_YES) != 0 && (checkResult & CHECK_NO) == 0;
    }

    /**
     * Description of the method.
     *
     * @param checkResult Description of parameter.
     *
     * @return Description of the returned value.
     */
    public boolean checkSome(int checkResult) {

        //    return ( checkResult & CHECK_YES ) != 0 && ( checkResult & CHECK_NO ) != 0;
        return (checkResult & CHECK_YES) != 0;
    }

    /**
     * Description of the method.
     *
     * @param checkResult Description of parameter.
     *
     * @return Description of the returned value.
     */
    public boolean checkFailed(int checkResult) {
        return (checkResult & CHECK_FAIL) != 0;
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     * @param objects Parameter description.
     * @param objectClass Parameter description.
     *
     * @return Return description.
     */
    public Collection extractDownAssociated(ContextData contextData,
        Collection objects, Class objectClass) {

        // try to use cached selection
        ProcessedSelection processedSelection =
            contextData.getSelectionManager().getProcessedSelection(contextData.getSelectionManager()
                                                                               .getSelection());
        Collection extracted = null;
        extracted =
            processedSelection.getObjectCollection("DownAssociated-" +
                objectClass.getName());
        if (extracted == null) {
            extracted = extractDownAssociated(contextData, objects);

            // create new, because we don't want to modify the stored version on the set
            extracted = new HashSet(extracted);
            ObjectManager.extract(extracted, objectClass);
            processedSelection.setObjectCollection("DownAssociated-" +
                objectClass.getName(), extracted);
        }
        return extracted;
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     * @param objects Parameter description.
     *
     * @return Return description.
     */
    public static Collection extractDownAssociated(ContextData contextData,
        Collection objects) {

        // try to use cached selection
        ProcessedSelection processedSelection =
            contextData.getSelectionManager().getProcessedSelection(contextData.getSelectionManager()
                                                                               .getSelection());
        Collection extracted =
            processedSelection.getObjectCollection(
                "RepresentationCheck:DownAssociated");
        if (extracted == null) {
            extracted = new HashSet(objects);
            contextData.getObjectManager().getDownAssociations(objects,
                extracted);
            processedSelection.setObjectCollection("RepresentationCheck:DownAssociated",
                extracted);
        }
        return extracted;
    }
}
