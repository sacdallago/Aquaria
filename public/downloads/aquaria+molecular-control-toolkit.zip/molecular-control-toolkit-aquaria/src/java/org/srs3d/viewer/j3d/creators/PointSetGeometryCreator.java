/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.creators;

import java.util.Collection;
import java.util.Iterator;

import javax.media.j3d.BranchGroup;
import javax.media.j3d.PointArray;
import javax.media.j3d.Shape3D;

import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.ShapeManager;
import org.srs3d.viewer.j3d.objects.Point;
import org.srs3d.viewer.j3d.objects.PointSet;
import org.srs3d.viewer.objects.AbstractObject;

/**
 * Creates geometry of <code>Atom</code> objects.
 *
 * @author Karsten Klein
 *
 * @created March 20, 2001
 */
public class PointSetGeometryCreator extends AbstractGeometryCreator {
    private int mode = 0;

    /**
     * <code>GeometryCreator</code> interface implementation.
     *
     * @param object Object to create geometry for.
     * @param branchGroup Roots to attach the geometry to.
     */
    public void create(AbstractObject object, BranchGroup branchGroup) {
        PointSet pointSet = (PointSet) object;
        createPoints(pointSet, branchGroup);
    }

    /**
     * Creates point geometry for the specified <code>Atom</code> .
     *
     * @param atom <code>Atom</code> to create geometry for.
     * @param branchGroup Roots to attach the geometry to.
     */
    public void createPoints(PointSet pointSet, BranchGroup branchGroup) {
        Collection points = pointSet.getPoints();

        // create sphere with the appropriate attributes
        PointArray pointArray =
            new PointArray(points.size(), PointArray.COORDINATES);
        Iterator iterator = points.iterator();
        int index = 0;
        while (iterator.hasNext()) {
            pointArray.setCoordinate(index++,
                ((Point) iterator.next()).getCoordinate());
        }
        Shape3D shape = new Shape3D(pointArray);
        ShapeManager.setCapabilities(shape, pointSet);
        getContextData().getShapeManager().register(pointSet, shape);
        branchGroup.addChild(shape);
    }

    /**
     * Description of the method.
     *
     * @param object Description of parameter.
     * @param contextData Description of parameter.
     */
    public void modifyAttributes(ContextData contextData, AbstractObject object) {
        super.modifyAttributes(contextData, object);
        mode = PointGeometryCreator.POINT;
    }
}
