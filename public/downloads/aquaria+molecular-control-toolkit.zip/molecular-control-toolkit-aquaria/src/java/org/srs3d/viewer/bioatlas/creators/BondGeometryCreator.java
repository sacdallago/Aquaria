/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.creators;

import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;

import javax.media.j3d.Appearance;
import javax.media.j3d.BranchGroup;
import javax.media.j3d.LineArray;
import javax.media.j3d.Shape3D;
import javax.media.j3d.TransformGroup;
import javax.vecmath.Color3f;
import javax.vecmath.Color4f;
import javax.vecmath.Matrix3f;
import javax.vecmath.Vector3f;

import org.srs3d.viewer.bioatlas.attributes.AtomRepresentation;
import org.srs3d.viewer.bioatlas.attributes.Representation;
import org.srs3d.viewer.bioatlas.objects.Atom;
import org.srs3d.viewer.bioatlas.objects.Bond;
import org.srs3d.viewer.j3d.AppearanceHelper;
import org.srs3d.viewer.j3d.ColorSchemeBucket;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.ShapeManager;
import org.srs3d.viewer.j3d.creators.AbstractGeometryCreator;
import org.srs3d.viewer.j3d.geometry.GeometryHelper;
import org.srs3d.viewer.j3d.geometry.primitive.Cylinder;
import org.srs3d.viewer.j3d.geometry.primitive.Line;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.objects.State;

/**
 * Creates bond geometry.
 *
 * @author Karsten Klein
 *
 * @created March 20, 2001
 */
public class BondGeometryCreator extends AbstractGeometryCreator {

    /** Represents the bond as a simple line */
    public static int BOND_WIREFRAME = 2;

    /** Generate a cylindric bond representation */
    private static int BOND_CYLINDER = 1;
    private float bondRadius = 0.25f;
    private boolean isShapeLocking = false;
    private int bondMode = BOND_CYLINDER;

    /**
     * Description of the method
     *
     * @param object Description of parameter
     * @param branchGroup Description of parameter
     */
    public void create(AbstractObject object, BranchGroup branchGroup) {
        create((Bond) object, branchGroup);
    }

    /**
     * Description of the method
     *
     * @param bond Description of parameter
     * @param branchGroup Description of parameter
     */
    public void create(Bond bond, BranchGroup branchGroup) {
        if ((bondMode & BOND_CYLINDER) != 0) {
            createCylinder(bond, branchGroup);
        }
        if ((bondMode & BOND_WIREFRAME) != 0) {
            createLine(bond, branchGroup);
        }
    }

    /**
     * Description of the method.
     *
     * @param bond Description of parameter.
     * @param branchGroup Description of parameter.
     */
    public void createCylinder(Bond bond, BranchGroup branchGroup) {
        Cylinder cylinder = new Cylinder();
        cylinder.setUniformRadius(bondRadius);
        cylinder.setDivisionY(org.srs3d.viewer.bioatlas.Parameter.cylinderDivisions);
        Vector3f vector = new Vector3f(bond.getAtom1().getCoordinate());
        vector.sub(bond.getAtom0().getCoordinate());
        vector.scale(0.5f);
        vector.add(bond.getAtom0().getCoordinate());
        Matrix3f matrix = null;
        if (bond.getType() == Bond.SINGLE) {
            cylinder.getCoordinates().set(bond.getAtom0().getCoordinate(),
                vector);
            Shape3D shape = cylinder.getShape();
            ShapeManager.setCapabilities(shape, bond.getAtom0());
            getContextData().getShapeManager().register(bond.getAtom0(), shape);
            getContextData().getShapeManager().setShapeLock(shape,
                isShapeLocking);
            TransformGroup transformGroup = cylinder.getTransformGroup();
            transformGroup.addChild(shape);
            branchGroup.addChild(transformGroup);
        } else {
            if (matrix == null) {
                matrix = new Matrix3f();
            }
            cylinder.getCoordinates().set(bond.getAtom0().getCoordinate(),
                vector);
            cylinder.computeRotation(matrix);
            Vector3f start = new Vector3f(bond.getAtom0().getCoordinate());
            Vector3f v = new Vector3f();
            matrix.getColumn(0, v);
            v.scale(0.25f);
            int count = getBondCount(bond);
            v.scale(0.5f * (count - 1));
            start.sub(v);
            vector.sub(v);
            v.scale(1.0f / (0.5f * (count - 1)));
            for (int i = 0; i < count; i++) {
                cylinder.getCoordinates().set(start, vector);
                cylinder.setUniformRadius(0.5f * bondRadius);
                start.add(v);
                vector.add(v);
                Shape3D shape = cylinder.getShape();
                ShapeManager.setCapabilities(shape, bond.getAtom0());
                getContextData().getShapeManager().register(bond.getAtom0(),
                    shape);
                getContextData().getShapeManager().setShapeLock(shape,
                    isShapeLocking);
                TransformGroup transformGroup = cylinder.getTransformGroup();
                transformGroup.addChild(shape);
                branchGroup.addChild(transformGroup);
            }
        }

        // release cylinder
        cylinder = null;
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     * @param bond Parameter description.
     * @param bondRadius Parameter description.
     *
     * @return Return description.
     */
    public static Shape3D createBondCylinderShape(ContextData contextData,
        Bond bond, float bondRadius) {
        Cylinder cylinder = new Cylinder();
        cylinder.setUniformRadius(bondRadius);
        Vector3f vector = new Vector3f(bond.getAtom1().getCoordinate());
        vector.sub(bond.getAtom0().getCoordinate());
        vector.scale(0.5f);
        vector.add(bond.getAtom0().getCoordinate());
        cylinder.getCoordinates().set(bond.getAtom0().getCoordinate(), vector);
        return cylinder.getShape();
    }

    /**
     * Description of the method.
     *
     * @param bond Description of parameter.
     * @param branchGroup Description of parameter.
     */
    public void createLine(Bond bond, BranchGroup branchGroup) {
        HashSet bonds = new HashSet();
        bonds.add(bond);
        Shape3D shape =
            BondGeometryCreator.createLines(getContextData(), bonds,
                bond.getAtom0());
        ShapeManager.setCapabilities(shape, bond.getAtom0());
        getContextData().getShapeManager().register(bond.getAtom0(), shape);
        getContextData().getShapeManager().setShapeLock(shape, isShapeLocking);
        branchGroup.addChild(shape);
    }

    /**
     * Description of the method.
     *
     * @param object Description of parameter.
     * @param contextData Description of parameter.
     */
    public void modifyAttributes(ContextData contextData, AbstractObject object) {
        super.modifyAttributes(contextData, object);
        Bond bond = (Bond) object;

        // :NOTE: we use the state of the atom for setting the representation
        Atom atom = bond.getAtom0();
        State.Immutable state =
            getContextData().getStateManager().getImmutableState(atom);
        if (state.hasAttribute(org.srs3d.viewer.j3d.attributes.Visible.class)) {

            // defaults to wireframe
            bondRadius = 0.0f;
            bondMode = BOND_WIREFRAME;
            AtomRepresentation.Immutable representation =
                (AtomRepresentation.Immutable) state.getAttribute(AtomRepresentation.class);
            int representationMode = 0;
            if (representation != null) {
                representationMode = representation.getMode();
                if ((representationMode &
                      Representation.REPRESENTATION_WIREFRAME) != 0) {
                    bondMode = BOND_WIREFRAME;
                } else {
                    if ((representationMode &
                          Representation.REPRESENTATION_VAN_DER_WAALS) != 0) {
                        bondRadius = 0;
                        bondMode = 0;
                    } else if ((representationMode &
                          Representation.REPRESENTATION_BALL_AND_STICK) != 0) {
                        bondRadius = 0.25f;
                        bondMode = BOND_CYLINDER;
                    }
                }
            }
        } else {
            bondMode = 0;
        }
    }

    /**
     * Description of the method.
     *
     * @param bonds Description of parameter.
     *
     * @return Description of the returned value.
     */
    public static Shape3D createLines(ContextData contextData,
        Collection bonds, AbstractObject object) {
        Iterator iterator = bonds.iterator();
        Bond bond;
        int lineCount = 0;
        while (iterator.hasNext()) {
            bond = (Bond) iterator.next();
            lineCount += getBondCount(bond);
        }
        LineArray lineArray =
            GeometryHelper.getDefaultLineArray(lineCount, LineArray.COLOR_4);
        iterator = bonds.iterator();
        Line line = new Line();
        int index = 0;
        Color3f color;
        Vector3f vector = new Vector3f();
        int count;
        Matrix3f matrix = null;
        while (iterator.hasNext()) {
            bond = (Bond) iterator.next();
            line.getCoordinates().set(bond.getAtom0().getCoordinate(),
                bond.getAtom1().getCoordinate());
            vector.set(bond.getAtom1().getCoordinate());
            vector.sub(bond.getAtom0().getCoordinate());
            vector.scale(0.52f);
            vector.add(bond.getAtom0().getCoordinate());
            count = getBondCount(bond);
            color = computeColor(contextData, bond.getAtom0(), object);
            line.getColors().setUniform(new Color4f(color.x, color.y, color.z,
                    1f));
            if (count == 1) {
                line.getCoordinates().set(bond.getAtom0().getCoordinate(),
                    vector);
                line.insertInto(index++, lineArray);
            } else {
                line.getCoordinates().set(bond.getAtom0().getCoordinate(),
                    vector);
                if (matrix == null) {
                    matrix = new Matrix3f();
                }
                line.computeRotation(matrix);
                Vector3f start = new Vector3f(bond.getAtom0().getCoordinate());
                Vector3f v = new Vector3f();
                matrix.getColumn(0, v);
                v.scale(0.15f);
                v.scale(0.5f * (count - 1));
                start.sub(v);
                vector.sub(v);
                v.scale(1.0f / (0.5f * (count - 1)));
                for (int i = 0; i < count; i++) {
                    line.getCoordinates().set(start, vector);
                    line.insertInto(index++, lineArray);
                    start.add(v);
                    vector.add(v);
                }
            }
        }
        Shape3D shape = new Shape3D(lineArray);
        return shape;
    }

    /**
     * Method description.
     *
     * @param mode Parameter description.
     */
    public void setMode(int mode) {
        this.bondMode = mode;
    }

    /**
     * Method description.
     *
     * @param isShapeLocking Parameter description.
     */
    public void setShapeLocking(boolean isShapeLocking) {
        this.isShapeLocking = isShapeLocking;
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     * @param object Parameter description.
     * @param bucketObject Parameter description.
     *
     * @return Return description.
     */
    public static Color3f computeColor(ContextData contextData,
        AbstractObject object, AbstractObject bucketObject) {
        Color3f color = new Color3f();
        Appearance appearance = new Appearance();
        AppearanceHelper.setDefaults(appearance);
        ColorSchemeBucket colorSchemeBucket =
            contextData.getColorSchemeManager().getColorSchemeBucket(bucketObject);
        if (colorSchemeBucket == null || colorSchemeBucket.isEmpty()) {
            colorSchemeBucket = contextData.getColorSchemeBucket();
        }
        if (colorSchemeBucket != null) {
            colorSchemeBucket.modify(object, appearance);
        }
        AppearanceHelper.getColor(appearance, color);
        return color;
    }

    private static int getBondCount(Bond bond) {
        return bond.getType() & 3;
    }
}
