/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.objects;

import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.vecmath.PointArray3f;

/**
 * Instances of this class describe a line that can be displayed in 3d.
 *
 * @author Karsten Klein
 *
 * @created March 20, 2001
 */
public class Line extends AbstractObject {
    private PointArray3f coordinates = null;

    /**
     * <code>Box</code> contructor.
     */
    public Line() {
        coordinates = new PointArray3f(2);
        coordinates.setAt(0, -0.5f, -0.5f, -0.5f);
        coordinates.setAt(1, 0.5f, 0.5f, 0.5f);
    }

    /**
     * Gets the <code>Coordinates</code> attribute of the <code>Box</code> object.
     *
     * @return The <code>coordinates</code> value.
     */
    public PointArray3f getCoordinates() {
        return coordinates;
    }

    /**
     * Description of the method.
     */
    public void cleanup() {
        super.cleanup();
        coordinates = null;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public String toString() {
        return "Line";
    }
}
