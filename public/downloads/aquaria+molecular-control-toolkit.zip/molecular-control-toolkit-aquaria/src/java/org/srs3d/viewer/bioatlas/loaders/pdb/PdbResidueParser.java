/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.loaders.pdb;

import org.srs3d.viewer.bioatlas.factories.ResidueTemplateFactory;
import org.srs3d.viewer.bioatlas.objects.Chain;
import org.srs3d.viewer.bioatlas.objects.Residue;

/**
 * This class parses strings for pdb ATOM tags and tranfers/builts the appropriate
 * datastructure in a <code>ObjectContainer</code> .
 *
 * @author Karsten Klein, 01/2001
 *
 * @created May 18, 2001
 * @since 1.0
 */
public abstract class PdbResidueParser extends PdbChainParser {

    /** The number of the residue, which contains the atom */
    protected int residueNumber = 0;

    /** The identifier of the residue, which contains the atom */
    protected int residueId = 0;

    /** The insertion code of the residue, which contains the atom */
    protected char residueICode = ' ';

    /** The residue name of the residue, which contains the atom */
    protected String residueName = null;

    /**
     * Method description.
     *
     * @param chain Parameter description.
     */
    public void visit(Chain chain) {
        if (!chain.isTerminated()) {
            super.visit(chain);

            // search for already existing residue in the chain
            Residue residue =
                chain.getResidue(residueName, residueId, residueICode);
            if (residue == null) {
                residue = new Residue();
                visit(residue);
                if (isSuccess()) {
                    chain.addResidue(residue);
                }
            } else {
                visit(residue);
            }
        }
    }

    /**
     * Visits a residue. Since this class is abstract no success flag is set.
     *
     * @param residue Description of parameter.
     */
    public void visit(Residue residue) {
        residue.setId(residueId);
        residue.setICode(residueICode);
        residue.setTemplate(ResidueTemplateFactory.getTemplate(residueName));
    }

    /**
     * Description of the method.
     */
    public void clear() {
        super.clear();
        residueNumber = -1;
        residueId = Residue.INVALID_ID;
        residueICode = Residue.INVALID_ICODE;
        residueName = null;
    }
}
