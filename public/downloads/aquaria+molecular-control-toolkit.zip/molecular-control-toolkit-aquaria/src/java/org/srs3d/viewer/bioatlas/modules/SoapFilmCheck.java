/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.modules;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Vector;

import org.srs3d.viewer.bioatlas.attributes.Representation;
import org.srs3d.viewer.bioatlas.attributes.ResidueRepresentation;
import org.srs3d.viewer.bioatlas.attributes.SubchainRepresentation;
import org.srs3d.viewer.bioatlas.objects.Residue;
import org.srs3d.viewer.bioatlas.objects.Subchain;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.commands.CommandCollection;
import org.srs3d.viewer.j3d.commands.ExecuteClassCommand;
import org.srs3d.viewer.j3d.commands.ParentCommand;
import org.srs3d.viewer.j3d.commands.PreSelectCommand;
import org.srs3d.viewer.j3d.commands.PropagateClassCommand;
import org.srs3d.viewer.j3d.commands.RepresentationCommand;
import org.srs3d.viewer.objects.Attribute;
import org.srs3d.viewer.objects.Command;
import org.srs3d.viewer.objects.State;

/**
 * @author Karsten Klein
 *
 * @created August 06, 2001
 */
public class SoapFilmCheck extends SubchainToResidueCheck {
    public static final SoapFilmCheck sharedInstance = new SoapFilmCheck();

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     * @param objects Parameter description.
     *
     * @return Return description.
     */
    public int check(ContextData contextData, Collection objects) {
        if (org.srs3d.viewer.annotation.colorschemes.HomologyColorScheme.getAnnotation(
                  contextData) != null) {
            return super.check(contextData, objects);
        } else {
            return CHECK_FAIL;
        }
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     * @param subchain Parameter description.
     *
     * @return Return description.
     */
    public int check(ContextData contextData, Subchain subchain) {
        State.Immutable state =
            contextData.getStateManager().getImmutableState(subchain);
        SubchainRepresentation.Immutable representation =
            (SubchainRepresentation.Immutable) state.getAttribute(SubchainRepresentation.class);
        if (representation != null) {
            if ((representation.getMode() &
                  Representation.REPRESENTATION_SOAPFILM) != 0) {
                return CHECK_YES;
            } else {
                return CHECK_NO;
            }
        }
        return CHECK_YES;
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     * @param residue Parameter description.
     *
     * @return Return description.
     */
    public int check(ContextData contextData, Residue residue) {
        if (residue.isLigand()) {

            //      return CHECK_FAIL;
            return CHECK_NO;
        } else {
            State.Immutable state =
                contextData.getStateManager().getImmutableState(residue);
            ResidueRepresentation.Immutable representation =
                (ResidueRepresentation.Immutable) state.getAttribute(ResidueRepresentation.class);
            if (representation != null) {
                if ((representation.getMode() &
                      Representation.REPRESENTATION_SOAPFILM) != 0) {
                    return CHECK_YES;
                } else {
                    return CHECK_NO;
                }
            }
        }
        return CHECK_YES;
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     * @param onCommands Parameter description.
     */
    public void getResidueOnCommands(ContextData contextData,
        Collection onCommands) {
        RepresentationCommand representationCommand;
        ResidueRepresentation residueRepresentation;

        // switching on soap film also causes CA-trace representation
        CATraceCheck.sharedInstance.getResidueOnCommands(contextData, onCommands);
        residueRepresentation =
            (ResidueRepresentation) Attribute.getInstance(ResidueRepresentation.class);
        residueRepresentation.setMode(Representation.REPRESENTATION_SOAPFILM);
        representationCommand =
            new RepresentationCommand(contextData, RepresentationCommand.MERGE);
        representationCommand.setRepresentation(residueRepresentation);
        onCommands.add(representationCommand);
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     * @param onCommands Parameter description.
     */
    public void getSubchainOnCommands(ContextData contextData,
        Collection onCommands) {
        RepresentationCommand representationCommand;
        SubchainRepresentation subchainRepresentation;
        CATraceCheck.sharedInstance.getSubchainOnCommands(contextData,
            onCommands);
        subchainRepresentation =
            (SubchainRepresentation) Attribute.getInstance(SubchainRepresentation.class);
        subchainRepresentation.setMode(Representation.REPRESENTATION_SOAPFILM);
        representationCommand =
            new RepresentationCommand(contextData, RepresentationCommand.MERGE);
        representationCommand.setRepresentation(subchainRepresentation);
        onCommands.add(representationCommand);
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     * @param offCommands Parameter description.
     */
    public void getResidueOffCommands(ContextData contextData,
        Collection offCommands) {
        RepresentationCommand representationCommand;
        ResidueRepresentation residueRepresentation;
        residueRepresentation =
            (ResidueRepresentation) Attribute.getInstance(ResidueRepresentation.class);
        residueRepresentation.setMode(Representation.REPRESENTATION_SOAPFILM);
        representationCommand =
            new RepresentationCommand(contextData, RepresentationCommand.REMOVE);
        representationCommand.setRepresentation(residueRepresentation);
        offCommands.add(representationCommand);
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     * @param offCommands Parameter description.
     */
    public void getSubchainOffCommands(ContextData contextData,
        Collection offCommands) {
        RepresentationCommand representationCommand;
        SubchainRepresentation subchainRepresentation;
        subchainRepresentation =
            (SubchainRepresentation) Attribute.getInstance(SubchainRepresentation.class);
        subchainRepresentation.setMode(Representation.REPRESENTATION_SOAPFILM);
        representationCommand =
            new RepresentationCommand(contextData, RepresentationCommand.REMOVE);
        representationCommand.setRepresentation(subchainRepresentation);
        offCommands.add(representationCommand);
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     * @param commands Parameter description.
     */
    public void getResidueCommands(ContextData contextData, Collection commands) {
        RepresentationCommand representationCommand;
        ResidueRepresentation residueRepresentation;
        residueRepresentation =
            (ResidueRepresentation) Attribute.getInstance(ResidueRepresentation.class);
        residueRepresentation.setMode(Representation.REPRESENTATION_SOAPFILM);
        representationCommand = new RepresentationCommand(contextData);
        representationCommand.setRepresentation(residueRepresentation);
        commands.add(representationCommand);
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     * @param commands Parameter description.
     */
    public void getSubchainCommands(ContextData contextData, Collection commands) {
        RepresentationCommand representationCommand;
        SubchainRepresentation subchainRepresentation;
        subchainRepresentation =
            (SubchainRepresentation) Attribute.getInstance(SubchainRepresentation.class);
        subchainRepresentation.setMode(Representation.REPRESENTATION_SOAPFILM);
        representationCommand = new RepresentationCommand(contextData);
        representationCommand.setRepresentation(subchainRepresentation);
        commands.add(representationCommand);
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     * @param commands Parameter description.
     */
    public void getAllCommands(ContextData contextData, Collection commands) {
        getSubchainCommands(contextData, commands);
        getResidueCommands(contextData, commands);
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     *
     * @return Return description.
     */
    public static RepresentationModule createRepresentationModule(
        ContextData contextData) {
        Vector onCommands = new Vector();
        Vector offCommands = new Vector();
        sharedInstance.getAllOnCommands(contextData, onCommands);
        sharedInstance.getAllOffCommands(contextData, offCommands);
        return new RepresentationModule("Soap Film", contextData, onCommands,
            offCommands, sharedInstance);
    }

    /**
     * Gets the <code>allOnCommands</code> attribute of the <code>WireframeCheck</code>
     * class.
     *
     * @param contextData Description of parameter.
     * @param onCommands Description of parameter.
     */
    public void getAllOnCommands(ContextData contextData, Collection onCommands) {
        Command subchainCommand =
            new ExecuteClassCommand(contextData,
                new PreSelectCommand(contextData), Subchain.class);
        onCommands.add(new ExecuteClassCommand(contextData,
                new ParentCommand(contextData, subchainCommand), Residue.class));
        Collection commandCollection = new Vector();
        Vector commands = new Vector();
        getResidueOnCommands(contextData, commands);
        Command command = new CommandCollection(contextData, commands);
        command = new ExecuteClassCommand(contextData, command, Residue.class);
        commandCollection.add(command);
        commands = new Vector();
        getSubchainOnCommands(contextData, commands);
        command = new CommandCollection(contextData, commands);
        command = new ExecuteClassCommand(contextData, command, Subchain.class);
        commandCollection.add(command);
        command = new CommandCollection(contextData, commandCollection);
        command =
            new PropagateClassCommand(contextData, command, Residue.class);
        onCommands.add(command);
    }

    /**
     * Gets the <code>allOffCommands</code> attribute of the <code>WireframeCheck</code>
     * class.
     *
     * @param contextData Description of parameter.
     * @param offCommands Description of parameter.
     */
    public void getAllOffCommands(ContextData contextData,
        Collection offCommands) {

        // residues and subchains
        Collection commandCollection = new ArrayList();
        Collection commands = new ArrayList();
        getResidueOffCommands(contextData, commands);
        Command command = new CommandCollection(contextData, commands);
        command = new ExecuteClassCommand(contextData, command, Residue.class);
        commandCollection.add(command);
        commands = new ArrayList();
        getSubchainOffCommands(contextData, commands);
        command = new CommandCollection(contextData, commands);
        command = new ExecuteClassCommand(contextData, command, Subchain.class);
        commandCollection.add(command);
        command = new CommandCollection(contextData, commandCollection);
        command =
            new PropagateClassCommand(contextData, command, Residue.class);
        offCommands.add(command);
    }
}
