/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.geometry.primitive;

import javax.media.j3d.Shape3D;
import javax.media.j3d.TriangleArray;
import javax.vecmath.Vector3f;

import org.srs3d.viewer.j3d.geometry.GeometryHelper;
import org.srs3d.viewer.vecmath.ColorArray4f;
import org.srs3d.viewer.vecmath.PointArray3f;
import org.srs3d.viewer.vecmath.TexCoordArray2f;
import org.srs3d.viewer.vecmath.VectorArray3f;

/**
 * The <code>Triangle</code> class contains the coordinates and normal data concerning a
 * single triangle. The class implements the <code>AbstractPrimitive</code> interface
 * providing special methods for shape creation.
 *
 * @author Karsten Klein
 *
 * @created March 20, 2001
 */
public class Triangle implements AbstractPrimitive {

    /** Coordinates of the triangle vertices */
    private PointArray3f coordinates = null;

    /** Per vertex normals of the triangle vertices */
    private VectorArray3f normals = null;

    /** Per vertex colors */
    private ColorArray4f colors = null;
    private TexCoordArray2f textureCoordinates = null;

    /**
     * <code>Triangle</code> contructor.
     */
    public Triangle() {
        coordinates = new PointArray3f(3);
        normals = new VectorArray3f(3);
        colors = new ColorArray4f(3);
    }

    /**
     * Gets the <code>Coordinates</code> attribute of the <code>Triangle</code> object
     *
     * @return The <code>Coordinates</code> value
     */
    public PointArray3f getCoordinates() {
        return coordinates;
    }

    /**
     * Gets the <code>Normals</code> attribute of the <code>Triangle</code> object
     *
     * @return The <code>Normals</code> value
     */
    public VectorArray3f getNormals() {
        return normals;
    }

    /**
     * Gets the <code>Colors</code> attribute of the <code>Triangle</code> object
     *
     * @return The <code>Colors</code> value
     */
    public ColorArray4f getColors() {
        return colors;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public TexCoordArray2f getTextureCoordinates() {
        if (textureCoordinates == null) {
            textureCoordinates = new TexCoordArray2f(3);
        }
        return textureCoordinates;
    }

    /**
     * Use this method create a shape that represents a single triangle.
     *
     * @return The <code>Shape</code> value
     *
     * @see AbstractPrimitive
     */
    public Shape3D getShape() {
        TriangleArray triangleArray =
            GeometryHelper.getDefaultTriangleArray(1, TriangleArray.COLOR_4);
        insertInto(0, triangleArray);
        Shape3D shape = new Shape3D(triangleArray);
        return shape;
    }

    /**
     * Compute the normal of the triangle assuming clockwise ordering
     *
     * @return <code>Vector3f</code> - computed normal.
     */
    public Vector3f computeNormal() {
        Vector3f connect1 = new Vector3f(coordinates.getAt(1));
        connect1.sub(coordinates.getAt(0));
        Vector3f connect2 = new Vector3f(coordinates.getAt(2));
        connect2.sub(coordinates.getAt(0));
        Vector3f normal = new Vector3f();
        normal.cross(connect1, connect2);
        normal.normalize();
        return normal;
    }

    /**
     * This methods inserts the information from this triangle instance at the given
     * index into the triangle array.
     *
     * @param index index of the triangle in the triangle array. Note that this is the
     *        index of the triangle and not of the vertices.
     * @param triangleArray the according triangle array.
     */
    public void insertInto(int index, TriangleArray triangleArray) {
        int format = triangleArray.getVertexFormat();
        index *= 3;
        if ((format & TriangleArray.COORDINATES) != 0) {
            triangleArray.setCoordinates(index, coordinates.getBuffer());
        }
        if ((format & TriangleArray.NORMALS) != 0) {
            triangleArray.setNormals(index, normals.getBuffer());
        }
        if ((format & TriangleArray.COLOR_4) != 0) {
            triangleArray.setColors(index, colors.getBuffer());
        }
        if (textureCoordinates != null) {
            if ((format & TriangleArray.TEXTURE_COORDINATE_2) != 0) {
                triangleArray.setTextureCoordinate(0, index,
                    textureCoordinates.getAt(0));
                triangleArray.setTextureCoordinate(0, index + 1,
                    textureCoordinates.getAt(1));
                triangleArray.setTextureCoordinate(0, index + 2,
                    textureCoordinates.getAt(2));
            }
        }
    }
}
