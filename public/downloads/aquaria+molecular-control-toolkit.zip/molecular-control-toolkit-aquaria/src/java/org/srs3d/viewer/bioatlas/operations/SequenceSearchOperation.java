/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.operations;

import org.srs3d.viewer.j3d.Context;
import org.srs3d.viewer.objects.Operation;

/**
 * Description of the class.
 *
 * @author Karsten Klein
 *
 * @created April 10, 2002
 */
public class SequenceSearchOperation extends Operation {
    private String sequence;

    /**
     * Constructor description.
     *
     * @param context Parameter description.
     * @param id Parameter description.
     * @param sequence Parameter description.
     */
    public SequenceSearchOperation(Context context, String id, String sequence) {
        super(context, id, null);
        this.sequence = sequence;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public String getSequence() {
        return sequence;
    }
}
