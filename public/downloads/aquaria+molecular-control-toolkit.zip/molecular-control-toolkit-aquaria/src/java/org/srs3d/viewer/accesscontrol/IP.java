/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.accesscontrol;

import java.io.Serializable;
import java.util.StringTokenizer;

/**
 * General IP class. One IP instance defines a range of ips.
 *
 * @author Karsten Klein
 *
 * @created March 4, 2002
 * @modified August 23, 2002 (ranges possible in all 4 bytes)
 */
public class IP implements Serializable {

    /** IP values */
    protected transient int[][] address;

    /**
     * <code>IP</code> constructor.
     *
     * @param ip Array of 4 ip values.
     */
    public IP(int[][] ip) {
        address = new int[4][2];
        address[0][0] = ip[0][0];
        address[1][0] = ip[1][0];
        address[2][0] = ip[2][0];
        address[3][0] = ip[3][0];
        int dummy;
        for (int i = 0; i < 4; i++) {
            address[i][1] = ip[i][1];
            if (address[i][1] < address[i][0]) {
                dummy = address[i][1];
                address[i][1] = address[i][0];
                address[i][0] = dummy;
            }
        }
    }

    // :COMPATIBILITY: legacy code for reading old license files
    public IP(int[] ip) {
        address = new int[4][2];
        address[0][0] = ip[0];
        address[1][0] = ip[1];
        address[2][0] = ip[2];
        address[3][0] = ip[3];
        address[0][1] = ip[0];
        address[1][1] = ip[1];
        address[2][1] = ip[2];
        address[3][1] = ip[4];
        int dummy;
        for (int i = 0; i < 4; i++) {
            if (address[i][1] < address[i][0]) {
                dummy = address[i][1];
                address[i][1] = address[i][0];
                address[i][0] = dummy;
            }
        }
    }

    /**
     * <code>IP</code> copy constructor.
     *
     * @param ip Existing ip instabce.
     */
    public IP(IP ip) {
        address = (int[][]) ip.address.clone();
    }

    /**
     * <code>IP</code> constructor.
     *
     * @param string String representation of an ip. Example: 255.255.255.1.10
     */
    public IP(String string) {
        StringTokenizer dotTokenizer = new StringTokenizer(string, ".");
        StringTokenizer dashTokenizer;
        int index = 0;
        String token;
        address = new int[4][2];
        while (dotTokenizer.hasMoreTokens()) {
            token = dotTokenizer.nextToken().trim();
            dashTokenizer = new StringTokenizer(token, "-");
            address[index][0] =
                (int) Integer.parseInt(dashTokenizer.nextToken().trim());
            if (dashTokenizer.hasMoreTokens()) {
                address[index][1] =
                    (int) Integer.parseInt(dashTokenizer.nextToken().trim());
            } else {
                address[index][1] = address[index][0];
            }
            index++;
        }
    }

    /**
     * Description of the method.
     *
     * @param ip Description of parameter.
     *
     * @return Description of the returned value.
     */
    public boolean contains(IP ip) {
        for (int i = 0; i < 4; i++) {
            if (address[i][0] > ip.address[i][0] ||
                  address[i][1] < ip.address[i][1]) {
                return false;
            }
        }
        return true;
    }

    /**
     * Converts the IP to its string representation.
     *
     * @return String specifying the IP.
     */
    public String toString() {
        String string = "";
        for (int i = 0; i < 4; i++) {
            if (address[i][0] == address[i][1]) {
                string += address[i][0];
            } else {
                string += address[i][0] + "-" + address[i][1];
            }
            if (i < 3) {
                string += ".";
            }
        }
        return string;
    }

    /**
     * Description of the method.
     */
    protected void dump() {
        System.out.print(toString());
        System.out.println();
    }
}
