/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.constraints;

import javax.vecmath.Point3d;
import javax.vecmath.Tuple3d;
import javax.vecmath.Vector3d;

/**
 * This class is a concrete implementation of the <code>Constraint</code> class. Use it
 * to constrain a position to the half space the plane defines.
 *
 * @author Karsten Klein
 *
 * @created November, 2000
 * @since 1.0
 */
public class PlaneConstraint implements Constraint {

    /** Defines the orientation of the plane */
    private Vector3d normal = null;

    /** Defines the position of the plane */
    private Point3d anchor = null;

    /** This vector defines the permitted direction the modification must comply to */
    private Vector3d permittedDirection = null;

    /**
     * Creates a <code>PlaneConstraint</code> with the appropriate plane defined by the
     * specified parameters. Note that this constructor sets the
     * <code>permittedDirection</code> attribute to the negated <code>normal</code>.
     *
     * @param normal Description of parameter.
     * @param anchor Description of parameter.
     */
    public PlaneConstraint(Tuple3d normal, Tuple3d anchor) {
        this(normal, anchor, normal);
        this.permittedDirection.negate();
    }

    /**
     * Creates a <code>PlaneConstraint</code> with the appropriate plane defined by the
     * specified parameters.
     *
     * @param normal Description of parameter.
     * @param anchor Description of parameter.
     * @param permittedDirection Description of parameter.
     */
    public PlaneConstraint(Tuple3d normal, Tuple3d anchor,
        Tuple3d permittedDirection) {
        this.normal = new Vector3d(normal);
        this.anchor = new Point3d(anchor);
        this.permittedDirection = new Vector3d(permittedDirection);
        this.normal.normalize();
        this.permittedDirection.normalize();
    }

    /**
     * Sets the <code>anchor</code> attribute of the <code>PlaneConstraint</code> object.
     *
     * @param anchor The new <code>anchor</code> value.
     */
    public void setAnchor(Tuple3d anchor) {
        this.anchor = new Point3d(anchor);
    }

    /**
     * Sets the <code>normal</code> attribute of the <code>PlaneConstraint</code> object.
     *
     * @param normal The new <code>normal</code> value.
     */
    public void setNormal(Tuple3d normal) {
        this.normal = new Vector3d(normal);
        this.normal.normalize();
    }

    /**
     * Sets the <code>permittedDirection</code> attribute of the
     * <code>PlaneConstraint</code> object.
     *
     * @param direction The new <code>permittedDirection</code> value.
     */
    public void setPermittedDirection(Tuple3d direction) {
        permittedDirection = new Vector3d(direction);
        permittedDirection.normalize();
    }

    /**
     * This method implements the according <code>Constraint</code> method. Note that
     * only Point3d objects are processed.
     *
     * @param object Description of parameter.
     *
     * @return Description of the returned value.
     */
    public boolean process(Object object) {
        if (object instanceof Tuple3d) {
            return process((Tuple3d) object, permittedDirection);
        }
        return false;
    }

    /**
     * Processes the point only allowing changes in <code>permittedDirection</code>
     * permit. The method simply computes the intersection of ray (point, permit) with
     * the plane.
     *
     * @param point Description of parameter.
     * @param permittedDirection Description of parameter.
     * @param point the <code>permittedDirection</code> vector must be normalized
     *
     * @return <code>boolean</code> - <code>true</code> if a modification was applied to
     *         point
     */
    private boolean process(Tuple3d point, Vector3d permittedDirection) {

        // the method stakes the parametric line represenation into the
        // implicit plane representation to compute the intersection
        double normalDotAnchor = normal.dot(new Vector3d(anchor));
        double normalDotPoint = normal.dot(new Vector3d(point));
        double normalDotPermitted = normal.dot(permittedDirection);
        if (normalDotPermitted != 0) {
            double parameter = normalDotAnchor - normalDotPoint;
            parameter /= normalDotPermitted;
            if (parameter > 0) {
                Vector3d vector = new Vector3d(permittedDirection);
                vector.scale(parameter);
                point.add(vector);
                return true;
            }
        }
        return false;
    }
}
