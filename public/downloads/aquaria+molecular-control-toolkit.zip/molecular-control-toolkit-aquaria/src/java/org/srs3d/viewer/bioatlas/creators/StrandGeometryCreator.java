/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.creators;

import javax.media.j3d.BranchGroup;
import javax.vecmath.Matrix3f;
import javax.vecmath.Point3f;
import javax.vecmath.TexCoord2f;
import javax.vecmath.Vector3f;

import org.srs3d.viewer.bioatlas.objects.AbstractChain;
import org.srs3d.viewer.bioatlas.objects.Residue;
import org.srs3d.viewer.bioatlas.objects.Strand;
import org.srs3d.viewer.bioatlas.visitors.StrandNormalPathCreator;
import org.srs3d.viewer.bioatlas.visitors.StrandPathCreator;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.vecmath.CubicBezierCurve3f;
import org.srs3d.viewer.vecmath.SweepingSurface;

/**
 * <code>GeometryCreator</code> implementation concentrating on <code>Strand </code>
 * objects.
 *
 * @author Karsten Klein
 *
 * @created March 27, 2001
 */
public class StrandGeometryCreator extends SubchainGeometryCreator {

    /**
     * Description of the method.
     *
     * @param object Description of parameter.
     * @param branchGroup Description of parameter.
     */
    public void create(AbstractObject object, BranchGroup branchGroup) {
        createGeometry((Strand) object, branchGroup);
    }

    /**
     * Description of the Method
     *
     * @param chain Description of Parameter
     * @param branchGroup Description of Parameter
     */
    public void createSubchainGeometry(AbstractChain chain,
        BranchGroup branchGroup) {
        SweepingSurface sweepingSurface = createSweepingSurface(chain);
        createSubchainGeometry(chain, branchGroup, sweepingSurface);
    }

    /**
     * Description of the Method
     *
     * @param chain Description of Parameter
     * @param branchGroup Description of Parameter
     */
    public void createResidueGeometry(AbstractChain chain,
        BranchGroup branchGroup) {
        SweepingSurface sweepingSurface = createSweepingSurface(chain);
        createResidueGeometry(chain, 0, 1, branchGroup, sweepingSurface);
    }

    /**
     * Description of the Method
     *
     * @param chain Description of Parameter
     *
     * @return Description of the Returned Value
     */
    public SweepingSurface createSweepingSurface(AbstractChain chain) {
        Residue start = computeStartResidue(chain);
        Residue end = computeEndResidue(chain);
        int steps = (chain.getLength()) * (framesPerResidue - 1) + 1;
        int frames = steps + 1;
        SweepingSurface sweepingSurface =
            new SweepingSurface(getSurfaceContour());
        AbstractChain strand = chain;
        StrandPathCreator caPathCreator = new StrandPathCreator();
        caPathCreator.visit(start, end);

        // create ca interpolation curve and plug in the created path
        CubicBezierCurve3f caCurve = new CubicBezierCurve3f();
        caCurve.tangentScale = 1.0f / 6;
        caCurve.setCoordinates(caPathCreator.path);
        StrandNormalPathCreator normalPathCreator =
            new StrandNormalPathCreator();
        normalPathCreator.visit(start, end);
        normalPathCreator.smooth(1);

        // create normal interpolation curve and plug in the created path
        CubicBezierCurve3f normalCurve = new CubicBezierCurve3f();
        normalCurve.tangentScale = 1.0f / 6;
        normalCurve.setCoordinates(normalPathCreator.path);
        float deltaT = 1.0f / (steps - 1);
        Point3f point;
        Point3f computed;
        Vector3f vector0 = new Vector3f();
        Vector3f vector1 = new Vector3f();
        Vector3f vector2;

        // compute frames
        Matrix3f rotation = new Matrix3f();
        Vector3f scale = getScale();
        float t = 0;
        int arrowFrames = framesPerResidue;
        int arrowStart = framesPerResidue;
        float arrowScale = 2.0f / (arrowStart - 1);
        float endSize = getEndSize(chain);
        float width = chain.getLength();
        float widthPowerOf2 =
            org.srs3d.viewer.vecmath.Constants.computeNextHigherPowerOf2(width);
        float deltaTexture = width / widthPowerOf2 * deltaT;
        TexCoord2f textureCoordinate = new TexCoord2f();
        sweepingSurface.setTextured(true);
        int frame = 0;
        for (int i = 0; i < steps; i++) {
            t = i * deltaT;
            point = caCurve.computePoint(t);
            vector2 = caCurve.computeTangent(t);
            vector2.normalize();
            vector0.set(normalCurve.computePoint(t));
            vector0.normalize();
            vector1.cross(vector0, vector2);
            vector1.normalize();
            vector0.cross(vector2, vector1);
            vector0.normalize();
            vector1.cross(vector0, vector2);
            vector1.normalize();
            rotation.setColumn(0, vector0);
            rotation.setColumn(1, vector1);
            rotation.setColumn(2, vector2);
            if (i == steps - 1) {

                // :NOTE: store the frame info; ensure that the spawn command preserves
                //   the ordering when the subchains are spawned!!!
                //        setFrame( strand.getEndResidue(), new Matrix3f( rotation ) );
            }
            scale = getScale();
            if (i == steps - arrowStart && i != 0) {
                textureCoordinate.x -= deltaTexture / 8;
                sweepingSurface.addFrame(rotation, point, scale, true,
                    textureCoordinate);
                textureCoordinate.x += deltaTexture / 4;
            }

            // scaling for the arrow
            if (i >= steps - arrowStart) {
                scale.x = endSize + arrowScale * (steps - i - 1);
            }
            sweepingSurface.addFrame(rotation, point, scale,
                i == 0 || i == steps - 1 || i == steps - arrowStart,
                textureCoordinate);

            // this prevents flickering in the textured colors (on frame closing geometry)
            if (i == steps - framesPerResidue && i != 0) {
                textureCoordinate.x -= deltaTexture / 4;
            }
            textureCoordinate.x += deltaTexture;
        }
        return sweepingSurface;
    }

    /**
     * Description of the method.
     *
     * @param object Description of parameter.
     * @param contextData Description of parameter.
     */
    public void modifyAttributes(ContextData contextData, AbstractObject object) {
        super.modifyAttributes(contextData, object);

        // :FIXME:
        useCircleContour =
            org.srs3d.viewer.bioatlas.Parameter.strandUseCircleContour;
        framesPerResidue =
            org.srs3d.viewer.bioatlas.Parameter.strandFramesPerResidue;
        divisionsPerFrame =
            org.srs3d.viewer.bioatlas.Parameter.strandDivisionsPerFrame;
        setScale(1, 0.17f, 1);
    }

    /**
     * Gets the <code>endSize</code> attribute of the <code>StrandGeometryCreator </code>
     * object.
     *
     * @param chain Description of parameter.
     *
     * @return The <code>endSize</code> value.
     */
    protected float getEndSize(AbstractChain chain) {
        float endSize = 0.17f;
        if (chain.getEndResidue().getProceeding() == null) {
            endSize = 0;
        }
        return endSize;
    }
}
