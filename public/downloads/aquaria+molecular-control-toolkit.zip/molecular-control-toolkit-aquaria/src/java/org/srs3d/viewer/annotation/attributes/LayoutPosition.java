/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.annotation.attributes;

import javax.vecmath.Point3f;
import javax.vecmath.Tuple3f;

import org.srs3d.viewer.objects.Attribute;

/**
 * Layout position attribute.
 *
 * @author Karsten Klein
 *
 * @created April 30, 2001
 */
public class LayoutPosition extends Attribute {

    /** Postion attribute. */
    private Point3f position = new Point3f();

    /**
     * Sets the <code>position</code> attribute of the <code>LayoutPosition
     * </code>object.
     *
     * @param position The new <code>position</code> value.
     */
    public void setPosition(Tuple3f position) {
        this.position.set(position);
    }

    /**
     * Gets the <code>position</code> attribute of the <code>LayoutPosition
     * </code>object.
     *
     * @return The <code>position</code> value.
     */
    public Point3f getPosition() {
        return new Point3f(position);
    }

    /**
     * Copies the attributes content.
     *
     * @return Copied instance of the attribute.
     */
    public Attribute copy() {
        LayoutPosition layoutPosition = (LayoutPosition) super.copy();
        layoutPosition.setPosition(position);
        return layoutPosition;
    }

    /**
     * Checks for equal content.
     *
     * @param attribute Second attribute to compare.
     *
     * @return Boolean flag indicating eual content.
     */
    public boolean isEqual(Attribute attribute) {
        LayoutPosition layoutPosition = (LayoutPosition) attribute;
        return position.epsilonEquals(layoutPosition.getPosition(), 0.0001f);
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public Attribute.Immutable getImmutable() {
        return new Immutable();
    }

    /**
     * Class description.
     *
     * @author Karsten Klein, LION bioscience AG
     */
    public class Immutable extends Attribute.Immutable {

        /**
         * Method description.
         *
         * @return Return description.
         */
        public Point3f getPosition() {
            return new Point3f(LayoutPosition.this.getPosition());
        }
    }
}
