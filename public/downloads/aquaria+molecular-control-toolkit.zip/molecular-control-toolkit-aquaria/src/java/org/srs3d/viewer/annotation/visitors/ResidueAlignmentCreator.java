/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.annotation.visitors;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;

import javax.vecmath.Vector3f;

import org.srs3d.viewer.bioatlas.objects.Residue;

/**
 * collects all residuepairs within squaredDistance and filters the result
 *
 * @author Christian Zofka
 *
 * @created July 08, 2001
 */
public class ResidueAlignmentCreator {

    // max. distance of 3.2A between 2 alligned residues
    private static final double MAX_CA_DISTANCE_SQUARED = 10.24;

    // min. count for aligned residues in a row (used in filter)
    private static final int MIN_ALIGNED_RESIDUES = 3;
    private Map alignmentsDown_ = new HashMap();
    private Map alignmentsUp_ = new HashMap();

    /**
     * Gets the <code>alignments</code> attribute of the
     * <code>ResidueAnnotationCreator</code> object.
     *
     * @return The <code>alignments</code> value.
     */
    public Map getAlignmentsDown() {
        return alignmentsDown_;
    }

    /**
     * Gets the <code>alignmentsUp</code> attribute of the
     * <code>ResidueAlignmentCreator</code> object.
     *
     * @return The <code>alignmentsUp</code> value.
     */
    public Map getAlignmentsUp() {
        return alignmentsUp_;
    }

    /**
     * collects all residuepairs within squaredDistance and filters the result
     *
     * @param referenceResidues all residues of reference
     * @param alignResidues all residues of align
     */
    public void visit(Collection referenceResidues, Collection alignResidues) {
        Residue reference = null;
        Residue checkback = null;
        Residue align = null;
        Iterator referenceIterator = referenceResidues.iterator();
        Iterator checkbackIterator = null;
        Iterator alignIterator = null;
        Vector3f v0 = new Vector3f();
        Vector3f v1 = new Vector3f();
        float min;
        float d;
        while (referenceIterator.hasNext()) {
            reference = (Residue) referenceIterator.next();
            v0.set(reference.getCoordinate());
            Residue match = null;
            min = 20.0f;
            alignIterator = alignResidues.iterator();
            while (alignIterator.hasNext()) {
                align = (Residue) alignIterator.next();
                v1.set(align.getCoordinate());
                v1.sub(v0);
                d = v1.lengthSquared();
                if ((d <= MAX_CA_DISTANCE_SQUARED) && (d < min)) {
                    min = d;
                    match = align;
                }
            }
            if (match != null) {
                Residue checkbackMatch = null;
                v1.set(match.getCoordinate());
                checkbackIterator = referenceResidues.iterator();
                while ((checkbackMatch == null) && checkbackIterator.hasNext()) {
                    checkback = (Residue) checkbackIterator.next();
                    v0.set(checkback.getCoordinate());
                    v0.sub(v1);
                    d = v0.lengthSquared();
                    if ((d <= MAX_CA_DISTANCE_SQUARED) && (d < min)) {
                        min = d;
                        checkbackMatch = checkback;
                    }
                }
                if ((checkbackMatch != null) && (match != checkbackMatch)) {
                    match = null;
                }
            }
            if (match != null) {
                getAlignmentsDown().put(reference, match);
                getAlignmentsUp().put(match, reference);
            }
        }
        filter();
    }

    /**
     * iterates from start to end residue and collects all n residues in a row that are
     * aligned (checked with map); n is defined in alignLength; notice: for optimization
     * the done residues are removed from the map
     *
     * @param start residue to start from
     * @param end residue to stop at
     * @param map corresponding alignment map
     *
     * @return collection of the found residues
     */
    private Collection subFilter(Residue start, Residue end, Map map) {
        Collection hits = new HashSet();
        Collection tempHits = new HashSet();
        int counter = 0;
        Residue lastAlign = null;
        Residue align = null;
        Residue residue = start;
        while (residue != end) {
            counter = tempHits.size();
            align = (Residue) map.get(residue);
            if (align != null) {
                map.remove(residue);
                if (counter > 0) {
                    if (compare(lastAlign, align) > 0) {
                        tempHits.add(residue);
                        lastAlign = align;
                    } else {
                        hits.addAll(finishHits(tempHits));
                        tempHits.clear();
                        tempHits.add(residue);
                        lastAlign = align;
                    }
                } else {
                    tempHits.add(residue);
                    lastAlign = align;
                }
            } else {
                hits.addAll(finishHits(tempHits));
                tempHits.clear();
                lastAlign = null;
            }
            residue = residue.getProceeding();
        }
        hits.addAll(finishHits(tempHits));
        return hits;
    }

    /**
     * tests if we have enough (alignLength) residuehits to finally add them to the
     * alignmentMap
     *
     * @param hits collection of hits
     *
     * @return elements to insert in the alignmentMap
     */
    private Collection finishHits(Collection hits) {
        if (hits.size() < MIN_ALIGNED_RESIDUES) {
            hits.clear();
        }
        return hits;
    }

    /**
     * condition for a residuepair to stay in the alignment map: 1) min. 'alignLength'
     * residues in a row (are neighbours in chain); 2) aligned residues are ordered; (Rn
     * key residue, An value/aligned residue, alignLength=3 ); i.e: R1=A1, R2=A2, R3=A3
     * (residue pairs); R1&lt;R2&lt;R3 and R1 neighbour of R2, R2 neighbour of R3;
     * A1&lt;A2&lt;A3; notice we have two maps
     */
    private void filter() {
        Map downMap = new HashMap();
        Map upMap = new HashMap();
        downMap.putAll(getAlignmentsDown());
        upMap.putAll(getAlignmentsUp());
        Collection downHits = new HashSet();
        Collection upHits = new HashSet();
        Residue residue;
        Residue align;
        while (!downMap.isEmpty()) {

            // have to begin from the start because subFilter removes entries from downMap
            Iterator iterator = downMap.keySet().iterator();
            residue = (Residue) iterator.next();

            // find startresidue from reference chain
            while (residue.getPreceeding() != null) {
                residue = residue.getPreceeding();
            }
            downHits.addAll(subFilter(residue, null, downMap));
        }
        while (!upMap.isEmpty()) {

            // have to begin from the start because subFilter removes entries from upMap
            Iterator iterator = upMap.keySet().iterator();
            residue = (Residue) iterator.next();

            // find startresidue from align
            while (residue.getPreceeding() != null) {
                residue = residue.getPreceeding();
            }
            upHits.addAll(subFilter(residue, null, upMap));
        }

        // insert corresponding residues in the corresponding collection;
        // both ways (from reference to align and vice versa) are only done for safty
        Collection tempDown = new HashSet();
        Collection tempUp = new HashSet();
        Iterator iterator = downHits.iterator();
        while (iterator.hasNext()) {
            residue = (Residue) iterator.next();
            tempUp.add(getAlignmentsDown().get(residue));
        }
        iterator = upHits.iterator();
        while (iterator.hasNext()) {
            residue = (Residue) iterator.next();
            tempDown.add(getAlignmentsUp().get(residue));
        }
        downHits.addAll(tempDown);
        upHits.addAll(tempUp);

        // remove filtered out pairs in alignment maps
        iterator = getAlignmentsDown().keySet().iterator();
        while (iterator.hasNext()) {
            residue = (Residue) iterator.next();
            align = (Residue) getAlignmentsDown().get(residue);
            if (!downHits.contains(residue)) {
                iterator.remove();
            }
            if (!upHits.contains(align)) {
                getAlignmentsUp().remove(align);
            }
        }
    }

    /**
     * calculates distance between 2 residues
     *
     * @param first first residue
     * @param second second residue
     *
     * @return distance from first to second, negative if second $lt; first, 0 if
     *         residues are the same or not in the same chain
     */
    private int compare(Residue first, Residue second) {
        if (first != null && second != null) {
            if (first != second) {
                Residue residue = first;
                int counter = 0;
                while (residue != null) {
                    residue = residue.getProceeding();
                    counter++;
                    if (residue == second) {
                        return counter;
                    }
                }
                residue = first;
                counter = 0;
                while (residue != null) {
                    residue = residue.getPreceeding();
                    counter--;
                    if (residue == second) {
                        return counter;
                    }
                }
            }
        }
        return 0;
    }
}
