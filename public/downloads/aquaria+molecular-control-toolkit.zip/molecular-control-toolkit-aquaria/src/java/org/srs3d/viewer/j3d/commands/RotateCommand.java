/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.commands;

import javax.media.j3d.Transform3D;
import javax.vecmath.Matrix3f;
import javax.vecmath.Point3d;
import javax.vecmath.Point3f;
import javax.vecmath.Vector3f;

import org.srs3d.viewer.j3d.Context;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.Transform;

/**
 * Rotate command.
 *
 * @author Karsten Klein
 *
 * @created April 03, 2001
 */
public class RotateCommand extends ObjectCommand {

    /** Description of the field */
    Matrix3f matrix = new Matrix3f(1, 0, 0, 0, 1, 0, 0, 0, 1);

    /**
     * <code>RotateCommand</code> constructor.
     *
     * @param contextData Description of parameter.
     */
    public RotateCommand(ContextData contextData) {
        super(contextData);
    }

    /**
     * Sets the <code>Matrix</code> attribute of the <code>RotateCommand</code> object.
     *
     * @param matrix The new <code>Matrix</code> value.
     */
    public void setMatrix(Matrix3f matrix) {
        this.matrix = matrix;
    }

    /**
     * Gets the <code>Matrix</code> attribute of the <code>RotateCommand</code> object.
     *
     * @return The <code>Matrix</code> value.
     */
    public Matrix3f getMatrix() {
        return matrix;
    }

    /**
     * Description of the method.
     */
    public void execute() {
        Transform transform =
            getContextData().getTransformManager().getTransform(getObject());
        if (transform != null && transform.isEnabled()) {
            Transform3D transform3D = transform.getTransform();
            rotate(transform3D, getContextData().getContext(), matrix,
                transform.isEnabled());
            transform.setTransform(transform3D);
        }
    }

    /**
     * Description of the method.
     *
     * @param transform Description of parameter.
     * @param context Description of parameter.
     * @param matrix Description of parameter.
     * @param apply Description of parameter.
     */
    private void rotate(Transform3D transform, Context context,
        Matrix3f matrix, boolean apply) {
        Vector3f oldTranslation = new Vector3f();
        transform.get(oldTranslation);

        // get center of rotation from context
        Point3f translation = context.getCenterOfRotation();

        // get current translation of the ViewingPlatform
        Point3f viewPosition =
            new Point3f(context.getViewingPlatformPosition());
        Vector3f correction = new Vector3f(viewPosition);
        correction.sub(translation);
        transform.setTranslation(new Vector3f(0, 0, 0));
        translation.sub(oldTranslation);
        Transform3D dummy = new Transform3D();
        dummy.setRotation(matrix);
        dummy.transform(translation);
        transform.mul(dummy, transform);
        transform.setTranslation(oldTranslation);
        translation.add(oldTranslation);
        context.setCenterOfRotation(translation);
        translation.add(correction);

        // :FIXME: execute this in a callback
        context.setViewingPlatformPosition(new Point3d(translation));
    }
}
