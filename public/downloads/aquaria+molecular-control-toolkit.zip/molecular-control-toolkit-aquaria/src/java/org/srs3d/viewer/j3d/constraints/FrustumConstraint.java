/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.constraints;

import javax.vecmath.Point3d;
import javax.vecmath.Tuple3d;
import javax.vecmath.Vector3d;

/**
 * The frustum can assure a valid position of a camera object or
 * <code>ViewingPlatform</code> . It's a concrete Implementation of
 * <code>Constraint</code> and can be added to any class implementing the
 * <code>Constrainable</code> interface.
 *
 * @author Karsten Klein, 11/2000
 *
 * @created September 10, 2001
 * @since 1.0
 */
public class FrustumConstraint implements Constraint {
    private PlaneConstraint front = null;
    private PlaneConstraint back = null;
    private PlaneConstraint top = null;
    private PlaneConstraint bottom = null;
    private PlaneConstraint right = null;
    private PlaneConstraint left = null;

    /**
     * Construct a frustum constraint defined by the given parameters.
     *
     * @param centerFront center of the frustums front.
     * @param centerBack center of the frustums back (camera position).
     * @param up vector defining the up direction of the camera.
     * @param fieldOfViewX scalar value defining the slope of the plane in camera x
     *        direction.
     * @param fieldOfViewY scalar value defining the slope of the plane in camera y
     *        direction.
     */
    public FrustumConstraint(Point3d centerFront, Point3d centerBack,
        Vector3d up, double fieldOfViewX, double fieldOfViewY) {
        Vector3d direction = new Vector3d(centerFront);
        direction.sub(centerBack);
        direction.normalize();
        Vector3d front = new Vector3d(direction);
        Vector3d back = new Vector3d(front);
        back.negate();
        Vector3d top = new Vector3d(up);
        Vector3d topPermitted = new Vector3d(up);
        topPermitted.negate();
        Vector3d bottom = new Vector3d(up);
        bottom.negate();
        Vector3d bottomPermitted = new Vector3d(up);
        Vector3d right = new Vector3d();
        right.cross(back, up);
        Vector3d rightPermitted = new Vector3d(right);
        rightPermitted.negate();
        Vector3d left = new Vector3d(right);
        left.negate();
        Vector3d leftPermitted = new Vector3d(right);

        // correct plane vectors on the sides (still coinciding with permitted
        // direction defining a single view ray)
        Vector3d backDirection = new Vector3d(back);
        backDirection.scale(fieldOfViewX);
        right.add(backDirection);
        left.add(backDirection);
        backDirection.set(back);
        backDirection.scale(fieldOfViewY);
        top.add(backDirection);
        bottom.add(backDirection);
        this.front = new PlaneConstraint(front, centerFront);
        this.back = new PlaneConstraint(back, centerBack);

        // the other planes are treated differently, due their
        // behavior to apply changes to the point according to their
        // normals instead of in parallel to the front and back
        // frustum planes
        this.bottom = new PlaneConstraint(bottom, centerBack, bottomPermitted);
        this.top = new PlaneConstraint(top, centerBack, topPermitted);
        this.left = new PlaneConstraint(left, centerBack, leftPermitted);
        this.right = new PlaneConstraint(right, centerBack, rightPermitted);
    }

    /**
     * Implementation of the <code>Constraint</code> interface. The processed objects are
     * limitied to <code>Point3d</code> instances.
     *
     * @param object the object to be processed in place. Only <code>Point3d</code>
     *        instances are processed.
     *
     * @return <code>boolean</code> - <Code>true</code> if object was modified.
     */
    public boolean process(Object object) {
        boolean isModified = false;
        if (object instanceof Tuple3d) {
            Tuple3d point = (Tuple3d) object;
            isModified |= front.process(point);
            isModified |= back.process(point);
            isModified |= top.process(point);
            isModified |= bottom.process(point);
            isModified |= right.process(point);
            isModified |= left.process(point);
        } else {

            // the object couldn't be processed by the constraint.
            // :FIXME: we can throw an exception (should be a special
            //         class e.g. ConstraintNotHandledException)
            // :NOTE: this would have to comply with the Constraint
            //        interface that currenly assumes unknown object to be
            //        skipped
        }
        return isModified;
    }
}
