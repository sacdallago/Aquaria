/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.annotation.visitors;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Vector;

import org.srs3d.viewer.bioatlas.objects.Layer;

/**
 * @author Christian Zofka
 *
 * @created January 24, 2002
 */
public class SequenceAlignmentCreator
    extends org.srs3d.viewer.objects.visitors.AbstractVisitor {

    /** maps layers to Vector representing the sequence (residues) */
    private Map layerSequenceMap = new HashMap();
    private Map layerAlignmentMap = null;
    private Layer referenceLayer;
    private Vector referenceSequence = null;
    private Vector templates;

    /**
     * <code>SequenceAlignmentCreator</code> constructor.
     *
     * @param layerAlignmentMap Description of parameter.
     * @param referenceSequence Description of parameter.
     * @param layers Description of parameter.
     */
    public SequenceAlignmentCreator(Layer layer, Vector referenceSequence,
        Map layerAlignmentMap, Vector layers) {
        this.layerAlignmentMap = layerAlignmentMap;
        this.referenceSequence = referenceSequence;
        templates = layers;
        referenceLayer = layer;
    }

    /**
     * Sets the <code>referenceSequence</code> attribute of the
     * <code>SequenceAlignmentCreator</code> object.
     *
     * @param sequence The new <code>referenceSequence</code> value.
     */
    public void setReferenceSequence(Vector sequence) {
        referenceSequence = sequence;
    }

    /**
     * Gets the <code>sequence</code> attribute of the
     * <code>SequenceAlignmentCreator</code> object.
     *
     * @param layer Description of parameter.
     *
     * @return The <code>sequence</code> value.
     */
    public Vector getSequence(Layer layer) {
        return (Vector) layerSequenceMap.get(layer);
    }

    /**
     * Gets the <code>referenceSequence</code> attribute of the
     * <code>SequenceAlignmentCreator</code> object.
     *
     * @return The <code>referenceSequence</code> value.
     */
    public Vector getReferenceSequence() {
        return referenceSequence;
    }

    /**
     * Description of the method.
     */
    public void alignSequences() {
        Map alignmentMap;
        ResidueGapCreator residueGapCreator;
        for (int i = 0; i < templates.size(); i++) {
            alignmentMap = (Map) layerAlignmentMap.get(templates.elementAt(i));
            if (alignmentMap != null) {
                residueGapCreator = new ResidueGapCreator(alignmentMap, this);
                residueGapCreator.visit(getReferenceSequence());
                layerSequenceMap.put(templates.elementAt(i),
                    residueGapCreator.getAlignSequence());
                setReferenceSequence(residueGapCreator.getReferenceSequence());
            }
        }
    }

    /**
     * Description of the method.
     *
     * @param index Description of parameter.
     * @param insertions Description of parameter.
     */
    public void insertInAligned(int index, int insertions) {
        Iterator iterator = layerAlignmentMap.keySet().iterator();
        Vector sequence;
        Layer layer;
        while (iterator.hasNext()) {
            layer = (Layer) iterator.next();
            sequence = (Vector) layerSequenceMap.get(layer);
            if (sequence != null) {
                insertInSequence(layer, sequence, index, insertions);
            }
        }
    }

    /**
     * Description of the method.
     *
     * @param sequence Description of parameter.
     * @param index Description of parameter.
     * @param insertions Description of parameter.
     * @param layer Description of parameter.
     */
    public void insertInSequence(Layer layer, Vector sequence, int index,
        int insertions) {
        insertInSequence(sequence, index, insertions);
        layerSequenceMap.put(layer, sequence);
    }

    /**
     * Description of the method.
     *
     * @param sequence Description of parameter.
     * @param index Description of parameter.
     * @param insertions Description of parameter.
     */
    public static void insertInSequence(Vector sequence, int index,
        int insertions) {
        for (int i = 0; i < insertions; i++) {
            sequence.insertElementAt(null, index);
        }
    }
}
