/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.objects.strategies;

import java.util.ArrayList;

import javax.media.j3d.Appearance;
import javax.media.j3d.CapabilityNotSetException;
import javax.media.j3d.LineAttributes;
import javax.vecmath.Color3f;
import javax.vecmath.Point3f;
import javax.vecmath.Vector3f;

import org.srs3d.viewer.j3d.AppearanceHelper;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.Reaction;
import org.srs3d.viewer.j3d.commands.ColorCommand;
import org.srs3d.viewer.j3d.commands.ComputeCenterCommand;
import org.srs3d.viewer.j3d.commands.ExpandCommand;
import org.srs3d.viewer.j3d.commands.IntersectCommand;
import org.srs3d.viewer.j3d.commands.LabelCommand;
import org.srs3d.viewer.j3d.objects.Line;
import org.srs3d.viewer.j3d.objects.strategies.reactions.EmptyReaction;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.objects.Command;
import org.srs3d.viewer.util.ExceptionHandler;

/**
 * Line Strategy.
 *
 * @author Karsten Klein
 *
 * @created April 03, 2001
 */
public class LineStrategy extends AbstractStrategy {

    /**
     * <code>LineStrategy</code> constructor.
     */
    public LineStrategy() {
        register(ComputeCenterCommand.class, new ComputeCenterReaction());
        register(IntersectCommand.class, new IntersectReaction());
        register(ColorCommand.class, new ColorReaction());

        //    register( IdentificationCommand.class, new IdentificationReaction() );
        register(ExpandCommand.class, EmptyReaction.getSharedInstance());
        register(LabelCommand.class, EmptyReaction.getSharedInstance());
    }

    /**
     * ComputeCenterReaction implementation for reaction on ComputeCenterCommands.
     *
     * @author Karsten Klein
     *
     * @created March 26, 2002
     */
    public static class ComputeCenterReaction implements Reaction {

        /**
         * Uses the line coordidates to determine center and extend
         *
         * @param command ComputeCenterCommand.
         */
        public void execute(Command command) {
            ComputeCenterCommand computeCenterCommand =
                (ComputeCenterCommand) command;
            Line line = (Line) computeCenterCommand.getObject();
            Point3f center = new Point3f(line.getCoordinates().getAt(1));
            center.add(line.getCoordinates().getAt(0));
            center.scale(0.5f);
            Vector3f extend = new Vector3f(line.getCoordinates().getAt(1));
            extend.sub(line.getCoordinates().getAt(0));
            computeCenterCommand.modifyCenter(center, extend);
        }
    }

    /**
     * Description of the class.
     *
     * @author Karsten Klein
     *
     * @created March 26, 2002
     */
    public static class IntersectReaction implements Reaction {

        /**
         * The line is understood as part of, that is contained in a ObjectContainer
         * instance. The IntersectCommand maps the line to its container.
         *
         * @param command IntersectionCommand.
         */
        public void execute(Command command) {
            IntersectCommand intersectCommand = (IntersectCommand) command;
            Line line = (Line) intersectCommand.getObject();
            ContextData contextData = intersectCommand.getContextData();
            ArrayList containers = new ArrayList();
            contextData.getObjectManager().getDirectUpAssociations(line,
                containers);
            if (containers.size() > 0) {
                command.setObject((AbstractObject) containers.get(0));
            }
        }
    }

    /**
     * Class description.
     *
     * @author Karsten Klein, LION bioscience AG
     */
    public class ColorReaction implements Reaction {

        /**
         * Method description.
         *
         * @param command Parameter description.
         */
        public void execute(Command command) {
            command.execute();
            ContextData contextData = ((ColorCommand) command).getContextData();
            Appearance appearance =
                contextData.getAppearanceManager().getAppearance(command.getObject());
            AppearanceHelper.modifyAppearance(appearance, new Color3f(0, 0, 0));
            try {
                LineAttributes la = appearance.getLineAttributes();
                if (la == null) {
                    la = new LineAttributes();
                }
                la.setLinePattern(LineAttributes.PATTERN_DASH_DOT);
                appearance.setLineAttributes(la);
            } catch (CapabilityNotSetException e) {
                ExceptionHandler.handleException(e,
                    ExceptionHandler.SILENT_IN_DEBUG);
            }
            ColorCommand.apply(contextData, command.getObject(), appearance);
        }
    }

    //  /**
    //   *  Reaction for retrieving the object identification.
    //   *
    //   * @author     Karsten Fries, LION bioscience AG
    //   * @version    March 26, 2002
    //   */
    //  public static class IdentificationReaction implements Reaction {
    //
    //    /**
    //     *  Execute implementation of the reaction interface.
    //     *
    //     * @param  command  Command to react to.
    //     */
    //    public void execute( Command command ) {
    //
    //      IdentificationCommand idCommand = ( IdentificationCommand ) command;
    //      AbstractObject object = command.getObject();
    //
    //      ArrayList parents = new ArrayList();
    //      ObjectManager.extract( idCommand.getObjects(), parents, ObjectContainer.class );
    //
    //      if ( !parents.isEmpty() ) {
    //
    //        ObjectContainer parent = (ObjectContainer) parents.get( 0 );
    //        ArrayList lines = new ArrayList();
    //
    //        ObjectManager.extract( parent.getObjects(), lines, Line.class );
    //
    //        Vector3f start = new Vector3f( ( (Line) object).getCoordinates().getAt( 1 ) );
    //        Vector3f end = new Vector3f( ( (Line) object).getCoordinates().getAt( 1 ) );
    //
    //        float startDistance = start.length();
    //        float endDistance = end.length();
    //
    //        startDistance = ( ( float ) ( ( int ) ( startDistance * 100 ) ) / 100 );
    //        endDistance = ( ( float ) ( ( int ) ( endDistance * 100 ) ) / 100 );
    //
    //        idCommand.setObjectId( "LINE:" + startDistance + "-" + endDistance );
    //        idCommand.execute();
    //
    //      }
    //
    //    }
    //
    //  }
}
