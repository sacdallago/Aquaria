/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.net.URL;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.StringTokenizer;

import javax.media.j3d.BoundingSphere;
import javax.media.j3d.BranchGroup;
import javax.swing.JComponent;
import javax.swing.JSplitPane;
import javax.vecmath.Color3f;
import javax.vecmath.Point3d;
import javax.vecmath.Point3f;
import javax.vecmath.Tuple3f;
import javax.vecmath.Vector3f;

import org.srs3d.viewer.annotation.modules.AnnotationModule;
import org.srs3d.viewer.bioatlas.contexts.CellContext;
import org.srs3d.viewer.bioatlas.contexts.OverviewContext;
import org.srs3d.viewer.bioatlas.dispatcher.NavigateUpDispatcher;
import org.srs3d.viewer.bioatlas.dispatcher.OverviewDispatcher;
import org.srs3d.viewer.bioatlas.dispatcher.ThreadedDispatcher;
import org.srs3d.viewer.bioatlas.loaders.GenericLoader;
import org.srs3d.viewer.bioatlas.objects.Feature;
import org.srs3d.viewer.bioatlas.objects.Layer;
import org.srs3d.viewer.j3d.BranchGroupHelper;
import org.srs3d.viewer.j3d.Context;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.ContextManager;
import org.srs3d.viewer.j3d.DispatchManager;
import org.srs3d.viewer.j3d.Junction;
import org.srs3d.viewer.j3d.Transform;
import org.srs3d.viewer.j3d.behaviors.DistanceBehavior;
import org.srs3d.viewer.j3d.behaviors.KeyHandler;
import org.srs3d.viewer.j3d.behaviors.SelectBehavior;
import org.srs3d.viewer.j3d.commands.LoadCommand;
import org.srs3d.viewer.j3d.commands.RegisterCommand;
import org.srs3d.viewer.j3d.commands.SpawnCommand;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.objects.Command;
import org.srs3d.viewer.objects.ObjectContainer;
import org.srs3d.viewer.objects.ObjectManager;
import org.srs3d.viewer.objects.Operation;
import org.srs3d.viewer.objects.StrategyManager;
import org.srs3d.viewer.swing.CursorManager;
import org.srs3d.viewer.swing.SwingSettings;
import org.srs3d.viewer.util.Log;

/**
 * Description of the class
 *
 * @author Karsten Klein
 *
 * @created March 20, 2001
 */
public class BioAtlasPlugin extends Capture {
    private static final Log log = new Log(BioAtlasPlugin.class);

    /** Description of the field. */
    public static final String version =
        new String(org.srs3d.viewer.bioatlas.Parameter.applicationName +
            " - plugin, build 14 (external layer selection as feature)");

    /** Description of the field. */
    protected OverviewContext overviewContext = null;

    /** Description of the field. */
    protected JSplitPane overviewSplitPane = null;

    /** Description of the field. */
    protected JSplitPane contextSplitPane = null;

    /**
     * <code>BioAtlasPlugin</code> constructor.
     */
    public BioAtlasPlugin() {
        log.info(version);
    }

    /**
     * Method description.
     */
    public void preprocessObjectContainer() {
        String selectionString = getAppletStub().getParameter("selection");
        if (selectionString != null) {

            // collect all layers
            Collection layers = new HashSet();
            context.getContextData().getObjectContainer().getAllObjects(layers);
            ObjectManager.extract(layers, Layer.class);
            Iterator iterator = layers.iterator();
            Layer layer;
            Feature feature = new Feature();
            feature.setColor(new Color3f(1, 1, -1));
            feature.setName("Layer Selection");
            HashSet selectionSet = new HashSet();
            StringTokenizer stringTokenizer =
                new StringTokenizer(selectionString, ";");
            while (stringTokenizer.hasMoreTokens()) {
                selectionSet.add(stringTokenizer.nextToken().trim().toLowerCase());
            }
            while (iterator.hasNext()) {
                layer = ((Layer) iterator.next());
                if (selectionSet.contains(layer.getId("SWISSPROT").trim()
                                                 .toLowerCase())) {
                    feature.getObjects().add(layer);
                    log.info("selecting " + layer);
                }
            }
            if (!feature.getObjects().isEmpty()) {
                features.add(feature);
                activeFeatures.add(feature);
                org.srs3d.viewer.bioatlas.modules.FeatureModule.activateFeatures(context.getContextData(),
                    activeFeatures);
            }
        }
    }

    /**
     * Method description.
     */
    public void preprocessView() {
        NavigateUpDispatcher.processZoomOut(context.getContextData(),
            new Operation(context, "ZOOM_OUT", null), 0);
        ((CellContext) context).resetConstraint((float) context.getViewingPlatformPosition().z);
    }

    /**
     * Description of the method Description of the method
     */
    public void initializeView() {
        log.info("in initialize view");
        initializeMainView();
        initializeOverviewContext();
        DispatchManager.register(context, overviewContext);
        DispatchManager.register(overviewContext, context);
        if (getAppletStub() != null) {
            String string = getAppletStub().getParameter("annotationView");
            if (string == null || string.equalsIgnoreCase("on")) {
                initializeAnnotationView();

                // register dispatcher communication
                DispatchManager.register(context, annotationContext);
                DispatchManager.register(annotationContext, context);
            }
            string = getAppletStub().getParameter("sequenceView");
            if (string == null || string.equalsIgnoreCase("on")) {
                initializeSequenceView();

                // register dispatcher communication
                DispatchManager.register(context, sequenceContext);
                DispatchManager.register(sequenceContext, context);
            }
            if (annotationContext != null && sequenceContext != null) {
                DispatchManager.register(annotationContext, sequenceContext);
                DispatchManager.register(sequenceContext, annotationContext);
            }
            if (annotationContext != null && sequenceContext != null) {
                annotationSplitPane =
                    new JSplitPane(JSplitPane.VERTICAL_SPLIT,
                        annotationContext, sequenceContext);
                annotationSplitPane.setDividerSize(2);
            } else {
                if (annotationContext != null) {
                    annotationSplitPane =
                        new JSplitPane(JSplitPane.VERTICAL_SPLIT,
                            annotationContext, null);
                    annotationSplitPane.setDividerSize(2);
                } else if (sequenceContext != null) {
                    annotationSplitPane =
                        new JSplitPane(JSplitPane.VERTICAL_SPLIT,
                            sequenceContext, null);
                    annotationSplitPane.setDividerSize(2);
                }
            }

            //      if ( splitPane == null ) {
            context.setSize(300, 300);
            overviewSplitPane =
                new JSplitPane(JSplitPane.VERTICAL_SPLIT, overviewContext,
                    org.srs3d.viewer.bioatlas.modules.HierarchyViewModule.createPanel(
                        context.getContextData()));
            contextSplitPane =
                new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, context,
                    overviewSplitPane);
            contextSplitPane.setDividerSize(2);
            overviewSplitPane.setDividerSize(2);
            overviewSplitPane.setDividerLocation(0.2);
            splitPane =
                new JSplitPane(JSplitPane.VERTICAL_SPLIT, contextSplitPane,
                    annotationSplitPane);
            splitPane.setBottomComponent(annotationSplitPane);
            splitPane.setTopComponent(contextSplitPane);
            splitPane.setDividerSize(2);
        }
        JComponent panel = (JComponent) getComponent();
        panel.setLayout(new BorderLayout());
        panel.setBackground(Color.black);
        SwingSettings.update();
        panel.add(splitPane, BorderLayout.CENTER);
    }

    /**
     * Description of the method.
     */
    public void initializeMainView() {
        log.info("in initialize view");
        context = new CellContext();
        context.getContextData().setComponent(getParent());
        context.setIncludeTransform(true);
        context.getContextData().setProperty("DialogComponent", getParent());
        ContextManager.addContext(context);

        // setup environment
        CellConfiguration.configure(context.getContextData());

        // context must be managed by ContextManager
        context.setup();
        URL jpgUrl = null;
        URL epsUrl = null;
        Vector3f scale = new Vector3f(1, 1, 1);
        String scaleString = getAppletStub().getParameter("spaceScaleFactors");
        if (scaleString != null) {
            readVector(scaleString, scale);
        }
        String prefix = getAppletStub().getParameter("fileUrlPrefix");
        if (prefix != null) {
            jpgUrl =
                Parameter.supplementUrl(getAppletStub().getDocumentBase(),
                    prefix + "background.jpg");
            epsUrl =
                Parameter.supplementUrl(getAppletStub().getDocumentBase(),
                    prefix + "vector.eps");
            ((CellContext) context).setup(jpgUrl, epsUrl, scale);
        }
        context.finalizeSetup();
        Cursor cursor = CursorManager.getCursor("Select");
        CursorManager.setCursor(context, cursor);
        ContextData contextData = context.getContextData();

        // set default dispatcher
        // set default dispatcher
        NavigateUpDispatcher dispatcher = new NavigateUpDispatcher();
        dispatcher.registerKeys(contextData);
        contextData.setDispatcher(dispatcher);
        DispatchManager.register(dispatcher, context);

        // register modules not covered by the menu or that are needed in advance
        instantiateModules();
        BranchGroup branchGroup = new BranchGroup();
        BranchGroupHelper.setDefaultCapabilities(branchGroup);
        SelectBehavior selectBehavior =
            new SelectBehavior(context.getContextData());
        branchGroup.addChild(selectBehavior);
        BoundingSphere bounds =
            new BoundingSphere(new Point3d(0, 0, 0), Double.MAX_VALUE);
        selectBehavior.setSchedulingBounds(bounds);
        context.getBehaviorLevel().addChild(branchGroup);
        context.getContextData().setAppletStub(getAppletStub());
        KeyHandler keyHandler = new KeyHandler(contextData);
        context.addKeyListener(keyHandler);

        //    parentContainer.addKeyListener( keyHandler );
        getParent().addKeyListener(keyHandler);
        context.getContextData().setProperty("KeyHandler", keyHandler);
        keyHandler.registerComponent(context);
        keyHandler.registerComponent(getParent());

        //    keyHandler.registerComponent( parentContainer );
    }

    /**
     * Description of the method.
     */
    public void initializeOverviewContext() {
        overviewContext = new OverviewContext();
        overviewContext.getContextData().setComponent(getParent());
        ContextManager.addContext(overviewContext);

        // setup environment
        CellConfiguration.configure(overviewContext.getContextData());

        // context must be managed by ContextManager
        overviewContext.setup();
        Vector3f scale = new Vector3f(1, 1, 1);
        String scaleString = getAppletStub().getParameter("spaceScaleFactors");
        if (scaleString != null) {
            readVector(scaleString, scale);
        }
        String prefix = getAppletStub().getParameter("fileUrlPrefix");
        URL jpgUrl = null;
        if (prefix != null) {
            jpgUrl =
                Parameter.supplementUrl(getAppletStub().getDocumentBase(),
                    prefix + "overview.jpg");
            overviewContext.setup(jpgUrl, scale);
        }
        overviewContext.finalizeSetup();
        Cursor cursor = new Cursor(Cursor.CROSSHAIR_CURSOR);
        CursorManager.setCursor(overviewContext, cursor);

        // set default dispatcher
        ThreadedDispatcher dispatcher = new OverviewDispatcher();
        overviewContext.getContextData().setDispatcher(dispatcher);
        DispatchManager.register(dispatcher, overviewContext);
        overviewContext.getContextData().setAppletStub(getAppletStub());
        initializeZoomBox(scale);
    }

    /**
     * Description of the method.
     */
    public void initializeZoomBox(Tuple3f tuple) {
        org.srs3d.viewer.j3d.objects.Rectangle zoomBox =
            new org.srs3d.viewer.j3d.objects.Rectangle();
        zoomBox.setCoordinate(new Point3f());
        zoomBox.setHeight(tuple.x);
        zoomBox.setWidth(tuple.y);
        zoomBox.setMinimumExtend(tuple.x);
        org.srs3d.viewer.annotation.contexts.AnnotationContextData contextData =
            (org.srs3d.viewer.annotation.contexts.AnnotationContextData) overviewContext.getContextData();

        // register/saves zoomBox, current alignment, zoomBoxThread
        contextData.setZoomBox(zoomBox);
        org.srs3d.viewer.annotation.Configuration.registerGeometryCreators(contextData);
        org.srs3d.viewer.annotation.Configuration.registerSpawners(contextData);
        org.srs3d.viewer.annotation.Configuration.registerPrototypes(contextData);
        org.srs3d.viewer.annotation.Configuration.registerStrategies(contextData);
        SpawnCommand spawn = new SpawnCommand(contextData);
        spawn.setBranchGroup(overviewContext.getSceneLevel());
        contextData.getStrategyManager().execute(zoomBox, spawn);
        org.srs3d.viewer.annotation.behaviors.ZoomBoxBehavior zoomBoxBehavior =
            new org.srs3d.viewer.annotation.behaviors.ZoomBoxBehavior(overviewContext.getContextData());
        zoomBoxBehavior.setSchedulingBounds(new BoundingSphere(new Point3d(),
                Float.MAX_VALUE));
        BranchGroup behaviorGroup = new BranchGroup();
        BranchGroupHelper.setDefaultCapabilities(behaviorGroup);
        behaviorGroup.addChild(zoomBoxBehavior);
        overviewContext.getBehaviorLevel().addChild(behaviorGroup);
    }

    /**
     * Description of the Method
     *
     * @param filename Description of Parameter
     * @param scale Description of parameter.
     */
    public void loadRdbFile(String filename, Vector3f scale) {
        if (filename != null) {
            try {
                GenericLoader loader = new GenericLoader();
                URL url =
                    Parameter.supplementUrl(getAppletStub().getCodeBase(),
                        filename);
                log.info("loading rdb file...");
                ObjectContainer localContainer = loader.load(url);
                log.info("loaded rdb file.");
                ContextData contextData = context.getContextData();
                if (localContainer != null) {
                    Vector3f translation = new Vector3f();
                    Iterator iterator = localContainer.getIterator();
                    AbstractObject object;
                    while (iterator.hasNext()) {
                        object = (AbstractObject) iterator.next();

                        // :FIXME: the approriate instance of a GeometryCreator should be
                        //   selected by a generic GeometryCreator visitor
                        if (object instanceof Layer) {
                            Layer layer = (Layer) object;

                            // adjust coordinate first
                            translation.set(layer.getCoordinate());
                            translation.x *= scale.x;
                            translation.y *= scale.y;
                            translation.z *= scale.z;
                            translation.z = 50;
                            layer.setCoordinate(translation);

                            // create distance behavior schedule
                            //              double[] distances = new double[3];
                            //              Command[] commands = new Command[4];
                            //              LoadCommand load;
                            //
                            //              distances[0] = 4000;
                            //              load = new LoadCommand( contextData );
                            //              load.setObject( object );
                            //              load.setAccuracy( 0.2f );
                            //              commands[0] = load;
                            //
                            //              distances[1] = 1000;
                            //              load = new LoadCommand( contextData );
                            //              load.setObject( object );
                            //              load.setAccuracy( 0.5f );
                            //              commands[1] = load;
                            //
                            //              load = new LoadCommand( contextData );
                            //              load.setObject( object );
                            //              load.setAccuracy( 1.0f );
                            //              commands[2] = load;
                            // create distance behavior schedule
                            double[] distances = new double[1];
                            Command[] commands = new Command[2];
                            LoadCommand load;
                            distances[0] = 500;
                            load = new LoadCommand(contextData);
                            load.setObject(object);
                            load.setAccuracy(0.0f);
                            commands[0] = load;
                            load = new LoadCommand(contextData);
                            load.setObject(object);
                            load.setAccuracy(1.0f);
                            commands[1] = load;
                            DistanceBehavior distanceBehavior =
                                new DistanceBehavior(contextData,
                                    new Point3d(translation), distances,
                                    commands);
                            BranchGroup branchGroup = new BranchGroup();
                            BranchGroupHelper.setDefaultCapabilities(branchGroup);
                            branchGroup.addChild(distanceBehavior);
                            context.getBehaviorLevel().addChild(branchGroup);

                            //              attachLabel( layer, context );
                            contextData.getObjectContainer().addObject(layer);
                        }
                    }
                }
                log.info(this + " processed all layers!");
            } catch (Exception e) {
                log.debug(e, e);
            }
        }
    }

    /**
     * Visualizes a <code>ObjectContainer</code> of layers of the method in the specified
     * context.
     *
     * @param context Context to display the layers in.
     */
    public void visualize(Context context) {
        log.info("visualizing context " + context);
        ContextData contextData = context.getContextData();
        Iterator iterator = contextData.getObjectContainer().getIterator();
        Layer layer;
        int counter = 0;
        while (iterator.hasNext()) {
            layer = (Layer) iterator.next();
            visualize(layer, context);
            counter++;
        }
        preprocessView();
    }

    /**
     * Visualizes a <code>ObjectContainer</code> of layers of the method in the specified
     * context.
     *
     * @param context Context to display the layers in.
     * @param layer Description of parameter.
     */
    public void visualize(Layer layer, Context context) {
        ContextData contextData = context.getContextData();

        // use a transform node with appropriate behaviors
        Transform transform = new Transform();

        //    transform.attachRotateBehaviors( context, layer );
        transform.setTransform(layer.getCoordinate());

        // register transform
        contextData.getTransformManager().register(layer, transform);

        // use a junction to able to switch betwwen two representations
        Junction junction = new Junction();
        contextData.getJunctionManager().register(layer, junction);

        // 1st representation
        // use spawn strategy to built the layer geometry (dynamic geometry)
        StrategyManager strategyManager = contextData.getStrategyManager();
        SpawnCommand spawn = new SpawnCommand(contextData);
        spawn.setBranchGroup(junction.getOnBranch());

        //    spawn.setBranchGroup( branchGroup );
        strategyManager.execute(layer, spawn);

        //    LayerGeometryCreator pgc = new LayerGeometryCreator();
        //    pgc.modifyAttributes( contextData, layer );
        //    pgc.createAlternate( layer, junction.right );
        // built the rest of the layer scene graph anchor
        transform.transformGroup.addChild(junction.getEntry());

        //    transform.transformGroup.addChild( branchGroup );
        //    transform.entry.compile();
        // stick it into the life scene graph of the context
        context.getSceneLevel().addChild(transform.getEntry());
    }

    /**
     * Method description.
     *
     * @param string Parameter description.
     * @param tuple Parameter description.
     */
    public void readVector(String string, Tuple3f tuple) {
        StringTokenizer tokenizer = new StringTokenizer(string, ",");
        int index = 0;
        while (tokenizer.hasMoreTokens()) {
            switch (index) {

                case 0:
                    tuple.x = Float.parseFloat(tokenizer.nextToken());
                    break;

                case 1:
                    tuple.y = Float.parseFloat(tokenizer.nextToken());
                    break;

                case 2:
                    tuple.z = Float.parseFloat(tokenizer.nextToken());
                    break;

                default:
                    tokenizer.nextToken();
            }
            index++;
        }
    }

    /**
     * Description of the method
     */
    public void interpreteParameters() {
        commonInterpreteParameters();
        String string;

        // load scale factors
        string = getAppletStub().getParameter("rdbScaleFactors");
        Vector3f scale = new Vector3f(1, 1, 1);
        if (string != null) {
            readVector(string, scale);
        }
        string = getAppletStub().getParameter("rdbUrl");
        if (string != null) {
            loadRdbFile(string, scale);
        }
        string = getAppletStub().getParameter("pdbUrlPrefix");
        if (string != null) {
            log.info("using pdbUrlPrefix " + string);
            URL url =
                Parameter.supplementUrl(getAppletStub().getCodeBase(), string);
            Parameter.pdbUrlPrefix = url.toString();
        }
        string = getAppletStub().getParameter("fileUrlPrefix");
        if (string != null) {
            log.info("using fileUrlPrefix " + string);
            URL url =
                Parameter.supplementUrl(getAppletStub().getCodeBase(), string);
            Parameter.fileUrlPrefix = url.toString();
        }
    }

    /**
     * Adds a <code>DynamicMenuItems</code> object to the <code>BioAtlasPlugin</code>
     * object.
     *
     * @param contextData The <code>DynamicMenuItems</code> object to be added.
     * @param popupMenu The <code>DynamicMenuItems</code> object to be added.
     */
    public boolean addDynamicMenuItems(ContextData contextData,
        org.srs3d.viewer.swing.PopupMenu popupMenu) {
        super.addDynamicMenuItems(contextData, popupMenu);
        org.srs3d.viewer.swing.Menu m;
        popupMenu.add(new AnnotationModule("Annotation", context,
                annotationContext, sequenceContext));
        popupMenu.getLastModule().addActionListener(this);
        return true;
    }

    /**
     * Description of the method.
     */
    public void validate_() {
        if (splitPane != null) {
            contextSplitPane.setDividerLocation(0.80);
            contextSplitPane.doLayout();
            if (sequenceContext != null && annotationContext != null) {
                splitPane.setDividerLocation(0.80);
            } else {
                if (sequenceContext == null && annotationContext == null) {
                    splitPane.setDividerLocation(1.0);
                } else {
                    splitPane.setDividerLocation(0.90);
                }
            }
            overviewSplitPane.setDividerLocation(0.40);
            overviewSplitPane.doLayout();
            splitPane.validate();
            splitPane.doLayout();
            if (annotationSplitPane != null) {
                annotationSplitPane.setDividerLocation(0.50);
                annotationSplitPane.validate();
                annotationSplitPane.doLayout();
            }
            if (sequenceContext != null) {
                sequenceContext.update();
            }
        }
    }

    /**
     * Description of the method.
     */

    //  protected void lockAll() {
    //
    //    super.lockAll();
    //
    //    overviewContext.lockRenderer();
    //
    //  }

    /**
     * Description of the method.
     */

    //  protected void unlockAll() {
    //
    //    overviewContext.unlockRenderer();
    //
    //    super.unlockAll();
    //
    //  }

    /**
     * Description of the method.
     *
     * @param layer Description of parameter.
     * @param context Description of parameter.
     */
    void attachLabel(Layer layer, Context context) {
        ContextData contextData = context.getContextData();
        String text = layer.getId();
        if (text == null || text.length() == 0) {
            text = layer.getId("PDB");
        }
        org.srs3d.viewer.j3d.objects.Label label =
            new org.srs3d.viewer.j3d.objects.Label();
        label.setString(text);
        label.setAligned(true);
        label.getCoordinate().set(layer.getCoordinate());
        Vector3f alignment = new Vector3f(50, 0, 0);
        label.setAlignment(alignment);
        RegisterCommand register = new RegisterCommand(contextData);
        register.setParent(layer);
        contextData.getStrategyManager().execute(label, register);
        SpawnCommand spawn = new SpawnCommand(contextData);
        spawn.setBranchGroup(context.getSceneLevel());
        contextData.getStrategyManager().execute(label, spawn);
    }
}
