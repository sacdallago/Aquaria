package org.srs3d.viewer.j3d.behaviors;

import javax.vecmath.Matrix3f;

public interface InteractiveRotate {

	/**
	 * Processes the mouseEvent. This will directly result in a modification of the
	 * viewingPlatform in the activated <code>Context</code> , if the according
	 * conditions are met by the mouse event.
	 *
	 * @param mouseEvent Description of parameter.
	 */
	public abstract void processStimulus(int rotationX, int rotationY,
			int rotationZ);

	/**
	 * Processes the mouseEvent. This will directly result in a modification of the
	 * viewingPlatform in the activated <code>Context</code> , if the according
	 * conditions are met by the mouse event.
	 *
	 * @param mouseEvent Description of parameter.
	 */
	public abstract void processStimulus(Matrix3f matrix);

}