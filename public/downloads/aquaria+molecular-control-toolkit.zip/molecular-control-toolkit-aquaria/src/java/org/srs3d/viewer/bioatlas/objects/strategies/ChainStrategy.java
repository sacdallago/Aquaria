/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.objects.strategies;

import java.util.ArrayList;

import org.srs3d.viewer.bioatlas.filters.ChainIdFilter;
import org.srs3d.viewer.bioatlas.objects.Chain;
import org.srs3d.viewer.bioatlas.objects.ChainFragment;
import org.srs3d.viewer.bioatlas.objects.Layer;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.Reaction;
import org.srs3d.viewer.j3d.commands.ColorCommand;
import org.srs3d.viewer.j3d.commands.ExpandCommand;
import org.srs3d.viewer.j3d.commands.IdentificationCommand;
import org.srs3d.viewer.j3d.commands.PreSelectCommand;
import org.srs3d.viewer.j3d.commands.RepresentationCommand;
import org.srs3d.viewer.j3d.commands.VisibleCommand;
import org.srs3d.viewer.j3d.objects.strategies.AbstractStrategy;
import org.srs3d.viewer.j3d.objects.strategies.reactions.EmptyReaction;
import org.srs3d.viewer.objects.Command;
import org.srs3d.viewer.objects.ObjectManager;
import org.srs3d.viewer.objects.visitors.ObjectCollector;

/**
 * @author Karsten Klein
 *
 * @created April 03, 2001
 */
public class ChainStrategy extends AbstractStrategy {

    /**
     * Constructor description.
     */
    public ChainStrategy() {
        register(RepresentationCommand.class, EmptyReaction.getSharedInstance());
        register(PreSelectCommand.class, EmptyReaction.getSharedInstance());
        register(ColorCommand.class, EmptyReaction.getSharedInstance());
        register(IdentificationCommand.class, new IdentificationReaction());
        register(ExpandCommand.class, new ExpandReaction());
        register(VisibleCommand.class, new VisibleReaction());
    }

    /**
     * Class description.
     *
     * @author Karsten Klein, LION bioscience AG
     */
    public static class VisibleReaction implements Reaction {

        /**
         * Method description.
         *
         * @param command Parameter description.
         */
        public void execute(Command command) {
            VisibleCommand visibleCommand = (VisibleCommand) command;
            if (visibleCommand.isShow()) {
                Chain chain = (Chain) command.getObject();
                if (chain.isWater()) {
                    ContextData contextData = visibleCommand.getContextData();

                    // trigger expansion
                    ExpandCommand expandCommand =
                        new ExpandCommand(contextData);
                    contextData.getStrategyManager().propagate(chain,
                        expandCommand, ChainFragment.class);
                }
            }
            command.execute();
        }
    }

    /**
     * Class description.
     *
     * @author Karsten Klein, LION bioscience AG
     */
    public class ExpandReaction implements Reaction {

        /**
         * Method description.
         *
         * @param command Parameter description.
         */
        public void execute(Command command) {
            ExpandCommand expandCommand = (ExpandCommand) command;
            if (expandCommand.isExpand()) {
                command.execute();
            }
        }
    }

    /**
     * Reaction for retrieving the object identification.
     *
     * @author Karsten Klein
     *
     * @created March 26, 2002
     */
    public static class IdentificationReaction implements Reaction {

        /**
         * Execute implementation of the reaction interface.
         *
         * @param command Command to react to.
         */
        public void execute(Command command) {
            IdentificationCommand idCommand = (IdentificationCommand) command;
            ArrayList layers = new ArrayList(1);
            ObjectManager.extract(idCommand.getObjects(), layers, Layer.class);
            if (layers.size() == 1) {
                Chain chain = (Chain) command.getObject();
                Layer layer = (Layer) layers.get(0);
                ObjectCollector objectCollector =
                    new ObjectCollector(new ChainIdFilter(chain.getId()));
                ArrayList chains = new ArrayList(layer.getObjects().size());
                objectCollector.setObjects(chains);
                objectCollector.visit(layer.getObjects());
                idCommand.setObjectId("C:" + (int) chain.getId() + "-" +
                    chains.indexOf(chain));
                idCommand.execute();
            }
        }
    }
}
