/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.colorschemes;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;

import javax.media.j3d.Appearance;
import javax.vecmath.Color3f;

import org.srs3d.viewer.j3d.AbstractColorScheme;
import org.srs3d.viewer.j3d.AppearanceHelper;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.util.ExceptionHandler;
import org.srs3d.viewer.vecmath.AbstractCurve3f;
import org.srs3d.viewer.vecmath.CubicBezierCurve3f;

/**
 * The <code>DarkenColorScheme</code> isused to reduce the bighness of the assigned
 * objects.
 *
 * @author Karsten Klein
 *
 * @created March 20, 2001
 */
public class DarkenColorScheme extends AbstractColorScheme {

    /**
     * The <code>DarkenColorScheme</code> brightens the current color of an object by the
     * specifed values.
     */
    private Color3f color = new Color3f(0.2f, 0.2f, 0.2f);

    /**
     * Constructor description.
     *
     * @param contextData Parameter description.
     */
    public DarkenColorScheme(ContextData contextData) {
        super(contextData);
    }

    /**
     * Constructor description.
     *
     * @param contextData Parameter description.
     * @param color Parameter description.
     */
    public DarkenColorScheme(ContextData contextData, Color3f color) {
        this(contextData);
        this.color = color;
    }

    /**
     * Gets the Volatile attribute of the SelectionColorScheme object
     *
     * @return The Volatile value
     */
    public boolean isVolatile() {
        return false;
    }

    /**
     * Description of the method.
     *
     * @param object Description of parameter.
     * @param appearance Description of parameter.
     */
    public boolean modify(AbstractObject object, Appearance appearance) {
        Color3f color = new Color3f();
        if (appearance.getColoringAttributes() != null) {
            appearance.getColoringAttributes().getColor(color);
        } else {
            color.set(this.color);
        }
        darken(color);
        AppearanceHelper.modifyAppearance(appearance, color);
        return true;
    }

    /**
     * Method description.
     *
     * @param color Parameter description.
     */
    public void setColor(Color3f color) {
        this.color = color;
    }

    /**
     * Method description.
     *
     * @param map Parameter description.
     *
     * @return Return description.
     */
    public Map getInformation(Map map) {
        map = super.getInformation(map);
        map.remove("NAME");

        // step through map and darken all colors
        Iterator iterator = map.keySet().iterator();
        Color3f color;
        Object key;
        while (iterator.hasNext()) {
            key = iterator.next();
            try {
                color = (Color3f) map.get(key);
                color = new Color3f(color);
                darken(color);
                map.put(key, color);
            } catch (ClassCastException e) {

                // catch silently
                ExceptionHandler.handleException(e,
                    ExceptionHandler.SILENT_IN_DEBUG, this);
            }
        }
        AbstractCurve3f colorCurve = (AbstractCurve3f) map.get("GRADIENT");
        if (colorCurve != null) {
            CubicBezierCurve3f newColorCurve = new CubicBezierCurve3f();
            iterator = colorCurve.getCoordinates().iterator();
            ArrayList newColors = new ArrayList();
            while (iterator.hasNext()) {
                color = (Color3f) iterator.next();
                color = new Color3f(color);
                darken(color);
                newColors.add(color);
            }
            newColorCurve.setCoordinates(newColors);
            map.put("GRADIENT", newColorCurve);
        }
        return map;
    }

    /**
     * Method description.
     *
     * @param color Parameter description.
     */
    public void darken(Color3f color) {
        color.add(this.color);
        color.scale(0.5f);
    }
}
