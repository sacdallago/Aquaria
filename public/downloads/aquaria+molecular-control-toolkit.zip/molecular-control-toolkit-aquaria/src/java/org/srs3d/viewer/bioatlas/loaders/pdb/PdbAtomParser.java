/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.loaders.pdb;

import javax.vecmath.Point3f;

import org.srs3d.viewer.bioatlas.factories.AtomTemplateFactory;
import org.srs3d.viewer.bioatlas.objects.Atom;
import org.srs3d.viewer.bioatlas.objects.Residue;

/**
 * This class parses strings for pdb ATOM tags and tranfers/builts the appropriate
 * datastructure in a <code>ObjectContainer</code> . Note that the class is reading the
 * full ATOM record, except the atom segment identifier and the atom element symbol.
 *
 * @author Karsten Klein, 01/2001
 *
 * @created May 18, 2001
 * @since 1.0
 */
public class PdbAtomParser extends PdbResidueParser {

    /** Record identification string */
    public static final String TAG = new String("ATOM  ");

    /** Threedimensional coordinate of the atom */
    private Point3f atomCoordinate = null;

    /** The atom element name */
    private String atomName = null;

    //  /**  The atom serial */
    //  public int atomId = Atom.INVALID_ID;

    /** Alternate location indicator */
    private char atomAlternateLocation = Atom.INVALID_ALTERNATE_LOCATION;

    /** Occupancy probability */
    private float atomOccupancy = 1.0f;

    /** Atom temparature factor */
    private float atomTempFactor = 0.0f;

    /** Atom charge */
    private float atomCharge = 0.0f;

    /**
     * Parses the formated pdb string for ATOM data. The data is stored locally and no
     * <code>Atom</code> instance is created.
     *
     * @param string Description of parameter.
     */
    public void create(String string) {
        clear();

        // read residue number
        residueNumber = extractInt(string, 22, 26);

        // read atom name
        atomName = extractString(string, 12, 16);

        // read atom serial
        // atomId = extractInt( string, 6, 11 );
        // read alternate location
        atomAlternateLocation = extractChar(string, 16);

        // read coordinate:
        atomCoordinate = new Point3f();
        atomCoordinate.x = extractFloat(string, 30, 38);
        atomCoordinate.y = extractFloat(string, 38, 46);
        atomCoordinate.z = extractFloat(string, 46, 54);

        // read the rest of the stuff not directly associated with the atom but
        // the hierachical upper structure the atom is embedded in
        residueId = extractInt(string, 22, 26);
        residueICode = extractChar(string, 26);
        chainId = extractChar(string, 21);
        residueName = extractString(string, 17, 20);

        // read the rest of the atom data
        atomOccupancy = extractFloat(string, 54, 60);

        // :FIXME: default of 0.0f for temparature factor might be not useful
        atomTempFactor = extractFloat(string, 60, 66);

        // :NOTE: the segment identifier and the element symbol are not read,
        //   because their occurence is not reliable throughout the pdb db.
        // :FIXME: a charge of 0.0f is assumed to be neutral
        if (string.length() >= 80) {
            String chargeString = extractString(string, 78, 80, true);
            if (chargeString.length() != 0) {
                atomCharge = extractFloat(string, 78, 80);
            }
        }
    }

    /**
     * Visits a partially built residue, tests the residue for affiliation and adds the
     * atom to the residue.
     *
     * @param residue the residue to apply the atom data to
     */
    public void visit(Residue residue) {
        super.visit(residue);
        Atom atom = new Atom();
        visit(atom);
        if (isSuccess()) {
            residue.addAtom(atom);
        }
    }

    /**
     * Visits an atom in order to transfer the atom specific data.
     *
     * @param atom the atom to tranfer the data to
     */
    public void visit(Atom atom) {
        atom.setTemplate(AtomTemplateFactory.getTemplate(atomName));
        atom.setCoordinate(atomCoordinate);
        atom.setTemperature(atomTempFactor);
        atom.setCharge(atomCharge);
        atom.setOccupancy(atomOccupancy);
        atom.setAlternateLocation(atomAlternateLocation);
        setSuccess(true);
    }

    /**
     * Description of the method.
     */
    public void clear() {
        super.clear();
        atomCoordinate = null;
        atomName = null;

        // atomId = Atom.INVALID_ID;
        atomAlternateLocation = Atom.INVALID_ALTERNATE_LOCATION;
        atomOccupancy = 1.0f;
        atomTempFactor = 0.0f;
        atomCharge = 0.0f;
    }
}
