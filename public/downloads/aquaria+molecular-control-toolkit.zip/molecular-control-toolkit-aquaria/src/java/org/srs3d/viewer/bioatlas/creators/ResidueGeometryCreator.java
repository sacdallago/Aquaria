/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.creators;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;

import javax.media.j3d.BranchGroup;
import javax.media.j3d.CapabilityNotSetException;
import javax.media.j3d.Geometry;
import javax.media.j3d.GeometryArray;
import javax.media.j3d.LineArray;
import javax.media.j3d.RestrictedAccessException;
import javax.media.j3d.Shape3D;
import javax.media.j3d.TriangleArray;
import javax.vecmath.Point3f;
import javax.vecmath.TexCoord2f;
import javax.vecmath.Vector3f;

import org.srs3d.viewer.annotation.colorschemes.HomologyColorScheme;
import org.srs3d.viewer.bioatlas.attributes.Representation;
import org.srs3d.viewer.bioatlas.attributes.ResidueRepresentation;
import org.srs3d.viewer.bioatlas.objects.AbstractChain;
import org.srs3d.viewer.bioatlas.objects.Atom;
import org.srs3d.viewer.bioatlas.objects.Bond;
import org.srs3d.viewer.bioatlas.objects.Residue;
import org.srs3d.viewer.bioatlas.objects.Subchain;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.ShapeManager;
import org.srs3d.viewer.j3d.attributes.Expanded;
import org.srs3d.viewer.j3d.attributes.ExternalGeometry;
import org.srs3d.viewer.j3d.commands.RegisterCommand;
import org.srs3d.viewer.j3d.creators.AbstractGeometryCreator;
import org.srs3d.viewer.j3d.geometry.GeometryHelper;
import org.srs3d.viewer.j3d.geometry.primitive.Line;
import org.srs3d.viewer.j3d.geometry.primitive.Triangle;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.objects.ObjectManager;
import org.srs3d.viewer.objects.State;
import org.srs3d.viewer.util.ExceptionHandler;
import org.srs3d.viewer.vecmath.Constants;

/**
 * Geometry creator implementation for residues.
 *
 * @author Karsten Klein
 *
 * @created March 22, 2001
 */
public class ResidueGeometryCreator extends AbstractGeometryCreator {
    public static int RESIDUE_GEOMETRY = 1;
    public static int RESIDUE_WIREFRAME = 2;
    public static int RESIDUE_CATRACE = 4;
    public static int RESIDUE_SOAPFILM = 8;
    public static int RESIDUE_BALL_AND_STICK = 16;
    public static int RESIDUE_VAN_DER_WAALS = 32;

    /** Representation mode of the residue */
    private int residueMode = 0;

    /** Geometry plug-in. Drawn in RESIDUE_GEOMETRY mode */
    private Shape3D externalGeometry = null;

    /**
     * Sets the <code>mode</code> attribute of the <code>ResidueGeometryCreator</code>
     * object.
     *
     * @param mode The new <code>mode</code> value.
     */
    public void setMode(int mode) {
        this.residueMode = mode;
    }

    /**
     * Description of the Method
     *
     * @param residue Description of Parameter
     * @param branchGroup Description of Parameter
     */
    public void create(Residue residue, BranchGroup branchGroup) {
        try {
            if ((residueMode & RESIDUE_GEOMETRY) != 0 &&
                  externalGeometry != null) {
                createGeometry(residue, branchGroup);
            }
            if ((residueMode & RESIDUE_WIREFRAME) != 0) {
                createWireframeGeometry(residue, branchGroup);
            }
            if ((residueMode & RESIDUE_SOAPFILM) != 0) {
                createSoapFilmGeometry(residue, branchGroup);
            }

            //    if ( ( residueMode & RESIDUE_BALL_AND_STICK ) != 0 ) {
            //
            //      createBallAndStickGeometry( residue, branchGroup );
            //
            //    }
            //    if ( ( residueMode & RESIDUE_VAN_DER_WAALS ) != 0 ) {
            //
            //      createVanDerWaalsGeometry( residue, branchGroup );
            //
            //    }
            if ((residueMode & RESIDUE_CATRACE) != 0) {
                if (!residue.isLigand()) {
                    createCATraceGeometry(residue, branchGroup);
                }
            }
        } catch (Exception e) {
            ExceptionHandler.handleException(e,
                ExceptionHandler.SILENT_IN_RELEASE, this);
        }
    }

    /**
     * Description of the Method
     *
     * @param object Description of Parameter
     * @param branchGroup Description of Parameter
     */
    public void create(AbstractObject object, BranchGroup branchGroup) {
        create((Residue) object, branchGroup);
    }

    /**
     * Description of the Method
     *
     * @param residue Description of Parameter
     * @param branchGroup Description of Parameter
     */
    public void createGeometry(Residue residue, BranchGroup branchGroup) {

        // :FIXME: this can be solved by using a list of Geometry (the sharing
        //   problem will not occur then (this might be basically, what happens here)
        // Shape3D shape = ( Shape3D ) externalGeometry.cloneNode( true );
        // :STATUS: this is better than cloning the shape node, because the geometry
        //   is stored only once. We use the shape as geometry container. This few
        //   lines should be lifted to a ShapeHelper class, as soon as we can need
        //   it more often.
        Shape3D shape = new Shape3D();
        Enumeration enumeration = externalGeometry.getAllGeometries();
        while (enumeration.hasMoreElements()) {
            shape.addGeometry((Geometry) enumeration.nextElement());
        }
        try {
            ShapeManager.setCapabilities(shape, residue);
        } catch (CapabilityNotSetException e) {

            // silent
            ExceptionHandler.handleException(e,
                ExceptionHandler.SILENT_IN_DEBUG, this);
        } catch (RestrictedAccessException e) {

            // silent
            ExceptionHandler.handleException(e,
                ExceptionHandler.SILENT_IN_DEBUG, this);
        }
        getContextData().getShapeManager().register(residue, shape);
        branchGroup.addChild(shape);
    }

    /**
     * Description of the Method
     *
     * @param residue Description of Parameter
     * @param branchGroup Description of Parameter
     */
    public void createWireframeGeometry(Residue residue, BranchGroup branchGroup) {
        Collection bonds = residue.getBonds();
        if (bonds.isEmpty()) {
            bonds.addAll(residue.computeBonds());
        }
        RegisterCommand registerCommand =
            new RegisterCommand(getContextData(), true);
        getContextData().getStrategyManager().propagate(residue,
            registerCommand, null);
        Shape3D shape;
        if (!bonds.isEmpty()) {
            shape =
                BondGeometryCreator.createLines(getContextData(), bonds, residue);
            ShapeManager.setCapabilities(shape, residue);
            getContextData().getShapeManager().register(residue, shape);
            branchGroup.addChild(shape);
            shape =
                new Shape3D(AtomGeometryCreator.createPoints(getContextData(),
                        residue));
            ShapeManager.setCapabilities(shape, residue);
            getContextData().getShapeManager().register(residue, shape);
            branchGroup.addChild(shape);
        } else {
            shape =
                new Shape3D(AtomGeometryCreator.createCrosses(
                        getContextData(), residue));
            ShapeManager.setCapabilities(shape, residue);
            getContextData().getShapeManager().register(residue, shape);
            branchGroup.addChild(shape);
        }
    }

    /**
     * Method description.
     *
     * @param residue Parameter description.
     * @param branchGroup Parameter description.
     */
    public void createSoapFilmGeometry(Residue residue, BranchGroup branchGroup) {
        Collection triangles = new ArrayList();
        createSoapFilmTriangles(getContextData(), triangles, residue, null);
        Shape3D shape = createShape(triangles, 0);
        if (shape != null) {
            getContextData().getShapeManager().register(residue, shape);
            ShapeManager.setCapabilities(shape, residue);
            branchGroup.addChild(shape);
        }
    }

    private static Shape3D createShape(Collection triangles, int additionalFlags) {
        if (triangles.size() > 0) {
            TriangleArray triangleArray =
                GeometryHelper.getDefaultTriangleArray(triangles.size(),
                    additionalFlags);
            Iterator iterator = triangles.iterator();
            int index = 0;
            Triangle triangle;
            while (iterator.hasNext()) {
                triangle = (Triangle) iterator.next();
                triangle.insertInto(index++, triangleArray);
            }
            Shape3D shape = new Shape3D(triangleArray);
            return shape;
        }
        return null;
    }

    /**
     * Method description.
     *
     * @param residue Parameter description.
     * @param branchGroup Parameter description.
     */
    public void createBallAndStickGeometry(Residue residue,
        BranchGroup branchGroup) {
        Shape3D shape = createBallAndStickShape(getContextData(), residue);
        if (shape != null) {
            getContextData().getShapeManager().register(residue, shape);
            ShapeManager.setCapabilities(shape, residue);
            branchGroup.addChild(shape);
        }
    }

    /**
     * Method description.
     *
     * @param residue Parameter description.
     * @param branchGroup Parameter description.
     */
    public void createVanDerWaalsGeometry(Residue residue,
        BranchGroup branchGroup) {
        Shape3D shape = createVanDerWaalsShape(getContextData(), residue);
        if (shape != null) {
            getContextData().getShapeManager().register(residue, shape);
            ShapeManager.setCapabilities(shape, residue);
            branchGroup.addChild(shape);
        }
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     * @param triangles Parameter description.
     * @param residue Parameter description.
     * @param textureCoordinate Parameter description.
     */
    public static void createSoapFilmTriangles(ContextData contextData,
        Collection triangles, Residue residue, TexCoord2f textureCoordinate) {
        Map map =
            (Map) HomologyColorScheme.getAnnotation(contextData)
                                     .getAlignmentMap();
        Residue[] residues = new Residue[6];
        if (map != null) {
            residues[0] = residue.getPreceeding();
            residues[1] = residue;
            residues[2] = residue.getProceeding();
            residues[4] = getMappedResidue(map, residue);
            if (residues[4] != null) {
                residues[3] = residues[4].getPreceeding();
                residues[5] = residues[4].getProceeding();
                if (residues[3] != null) {
                    createSoapFilmTriangles(residues[0].getCoordinate(),
                        residues[1].getCoordinate(),
                        residues[3].getCoordinate(),
                        residues[4].getCoordinate(), triangles,
                        textureCoordinate);
                }
                if (residues[5] != null) {
                    createSoapFilmTriangles(residues[2].getCoordinate(),
                        residues[1].getCoordinate(),
                        residues[5].getCoordinate(),
                        residues[4].getCoordinate(), triangles,
                        textureCoordinate);
                }
            }
        }
    }

    /**
     * Creates triangles for the Soap Film representation and deposits them in the
     * specified triangle collection. There are some assumptions towards the provided
     * coordinates. The point p1 and p2 are the points for the resiudes that have the
     * focus, while the other two are those of the previous or the next residues (not
     * neccesarilly aligned).
     *
     * @param p0 Coordinate of previous or next residue of the focus residue.
     * @param p1 Coordinate of the residue in focus.
     * @param p2 Coordinate of the residue aligned to the residue in focus.
     * @param p3 Coordinate of previous or next residue of the aligned residue.
     * @param triangles Here the triangles will be collected.
     * @param texture Texture coordinate for the residue in focus. Can be null.
     */
    private static void createSoapFilmTriangles(Point3f p0, Point3f p1,
        Point3f p2, Point3f p3, Collection triangles, TexCoord2f texture) {

        // copy p2, p3 because the content would be modified
        p2 = new Point3f(p2);
        p3 = new Point3f(p3);
        Vector3f center0 = new Vector3f();
        Vector3f center1 = new Vector3f();
        Triangle triangle;
        p2.add(p0);
        p3.add(p1);
        p2.scale(0.5f);
        p3.scale(0.5f);
        center0.set(p1);
        center0.add(p0);
        center0.scale(0.5f);
        center1.set(p3);
        center1.add(p2);
        center1.scale(0.5f);
        triangle = new Triangle();
        triangle.getCoordinates().setAt(0, center0);
        triangle.getCoordinates().setAt(1, p3);
        triangle.getCoordinates().setAt(2, p1);
        triangle.getNormals().setUniform(triangle.computeNormal());
        triangle.getTextureCoordinates().setUniform(texture);
        triangles.add(triangle);
        triangle = new Triangle();
        triangle.getCoordinates().setAt(0, p3);
        triangle.getCoordinates().setAt(1, center0);
        triangle.getCoordinates().setAt(2, center1);
        triangle.getNormals().setUniform(triangle.computeNormal());
        triangle.getTextureCoordinates().setUniform(texture);
        triangles.add(triangle);
        triangle = new Triangle();
        triangle.getCoordinates().setAt(0, center0);
        triangle.getCoordinates().setAt(1, p1);
        triangle.getCoordinates().setAt(2, p3);
        triangle.getNormals().setUniform(triangle.computeNormal());
        triangle.getTextureCoordinates().setUniform(texture);
        triangles.add(triangle);
        triangle = new Triangle();
        triangle.getCoordinates().setAt(0, p3);
        triangle.getCoordinates().setAt(1, center1);
        triangle.getCoordinates().setAt(2, center0);
        triangle.getNormals().setUniform(triangle.computeNormal());
        triangle.getTextureCoordinates().setUniform(texture);
        triangles.add(triangle);
    }

    /**
     * Description of the method.
     *
     * @param residue Description of parameter.
     * @param branchGroup Description of parameter.
     */
    public void createCATraceGeometry(Residue residue, BranchGroup branchGroup) {
        int length = 0;
        int mode = 0;
        if (org.srs3d.viewer.bioatlas.visitors.ChainAnalyser.isConnected(
                  residue.getPreceeding(), residue)) {
            length += 1;
            mode |= 1;
        }
        if (org.srs3d.viewer.bioatlas.visitors.ChainAnalyser.isConnected(
                  residue, residue.getProceeding())) {
            length += 1;
            mode |= 2;
        }
        if (length > 0) {
            LineArray lineArray = GeometryHelper.getDefaultLineArray(length, 0);
            Line line = new Line();
            createCALines(residue, lineArray, line, 0, mode);
            Shape3D shape = new Shape3D(lineArray);
            ShapeManager.setCapabilities(shape, residue);
            getContextData().getShapeManager().register(residue, shape);
            branchGroup.addChild(shape);
        }
    }

    /**
     * Description of the method.
     *
     * @param object Description of parameter.
     * @param contextData Description of parameter.
     */
    public void modifyAttributes(ContextData contextData, AbstractObject object) {
        super.modifyAttributes(contextData, object);
        State.Immutable state =
            getContextData().getStateManager().getImmutableState(object);
        residueMode = 0;
        int representationMode = 0;
        externalGeometry = null;
        ResidueRepresentation.Immutable representation =
            (ResidueRepresentation.Immutable) state.getAttribute(ResidueRepresentation.class);
        if (representation != null) {
            representationMode = representation.getMode();
        }
        if ((representationMode & Representation.REPRESENTATION_RIBBON) != 0 ||
              (representationMode & Representation.REPRESENTATION_COIL) != 0) {
            ExternalGeometry.Immutable externalGeometry =
                (ExternalGeometry.Immutable) state.getAttribute(ExternalGeometry.class);
            if (externalGeometry != null) {
                this.externalGeometry = externalGeometry.getShape();
                residueMode |= RESIDUE_GEOMETRY;
            } else {
                getExternalGeometry(object);

                // reinquire state
                state =
                    getContextData().getStateManager().getImmutableState(object);
                externalGeometry =
                    (ExternalGeometry.Immutable) state.getAttribute(ExternalGeometry.class);
                if (externalGeometry != null) {
                    this.externalGeometry = externalGeometry.getShape();
                    residueMode |= RESIDUE_GEOMETRY;
                }
            }
        }
        if ((representationMode & Representation.REPRESENTATION_WIREFRAME) != 0) {
            if (!state.hasAttribute(Expanded.class)) {
                residueMode |= RESIDUE_WIREFRAME;
            }
        }
        if (!state.hasAttribute(Expanded.class)) {
            if ((representationMode &
                  Representation.REPRESENTATION_BALL_AND_STICK) != 0) {
                residueMode |= RESIDUE_BALL_AND_STICK;
            }
            if ((representationMode &
                  Representation.REPRESENTATION_VAN_DER_WAALS) != 0) {
                residueMode |= RESIDUE_VAN_DER_WAALS;
            }
        }
        if ((representationMode & Representation.REPRESENTATION_CATRACE) != 0) {
            residueMode |= RESIDUE_CATRACE;
        }
        if ((representationMode & Representation.REPRESENTATION_SOAPFILM) != 0) {
            residueMode |= RESIDUE_SOAPFILM;
        }
    }

    /**
     * Gets the <code>externalGeometry</code> attribute of the
     * <code>ResidueGeometryCreator</code> object.
     *
     * @param object Description of parameter.
     */
    private void getExternalGeometry(AbstractObject object) {
        Collection subchains = new HashSet();
        getContextData().getObjectManager().getDirectUpAssociations(object,
            subchains);
        ObjectManager.extract(subchains, Subchain.class);
        if (subchains.size() == 1) {
            Subchain subchain = (Subchain) subchains.iterator().next();
            if (!SubchainGeometryCreator.isSinglePeptideChain(
                      getContextData(), subchain)) {
                SubchainGeometryCreator geometryCreator =
                    (SubchainGeometryCreator) getContextData()
                                                  .getGeometryCreatorFactory()
                                                  .getGeometryCreator(subchain);
                if (geometryCreator != null) {
                    geometryCreator.modifyAttributes(getContextData(), subchain);
                    geometryCreator.subchainMode =
                        SubchainGeometryCreator.RESIDUE;

                    // provide representation attributes of residue to the subchain
                    State.Immutable state =
                        getContextData().getStateManager().getImmutableState(object);
                    Representation.Immutable rep =
                        (Representation.Immutable) state.getAttribute(ResidueRepresentation.class);
                    if ((rep.getMode() & Representation.REPRESENTATION_COIL) != 0) {
                        geometryCreator.subchainMode += SubchainGeometryCreator.COIL;
                    }
                    geometryCreator.createGeometry(subchain, null);
                }
            }
        }
    }

    /**
     * Description of the method.
     *
     * @param chain Description of parameter.
     * @param startResidue Description of parameter.
     * @param endResidue Description of parameter.
     *
     * @return Description of the returned value.
     */
    public static Shape3D createCATraceGeometry(final AbstractChain chain,
        final Residue startResidue, final Residue endResidue) {
        Residue residue = startResidue;
        Residue limit = endResidue.getProceeding();

        // determine the length
        int length = 0;
        while (residue != null && residue != limit) {
            length++;
            residue = residue.getProceeding();
        }
        int textureMax =
            org.srs3d.viewer.vecmath.Constants.computeNextHigherPowerOf2(chain.computeLength());
        float deltaTexture = (float) 1.0f / textureMax;
        float deltaTextureHalf = deltaTexture / 2;
        float texture = 0;

        // number of lines needed (max)
        length *= 2;
        residue = startResidue;
        int initialMode = 3;
        int finalMode = 3;
        if (!org.srs3d.viewer.bioatlas.visitors.ChainAnalyser.isConnected(
                  residue.getPreceeding(), residue)) {
            length--;
            initialMode -= 1;
        }
        if (!org.srs3d.viewer.bioatlas.visitors.ChainAnalyser.isConnected(
                  endResidue, endResidue.getProceeding())) {
            length--;
            finalMode -= 2;
        }
        if (length > 0) {
            LineArray lineArray =
                GeometryHelper.getDefaultLineArray(length,
                    LineArray.TEXTURE_COORDINATE_2);
            Line line = new Line();
            int index = 0;
            if (startResidue == endResidue) {
                createCALines(startResidue, lineArray, line, index,
                    (initialMode - 2) | (finalMode - 1), texture,
                    deltaTextureHalf);
            } else {
                index =
                    createCALines(residue, lineArray, line, index, initialMode,
                        texture, deltaTextureHalf);
                texture += deltaTexture;
                residue = residue.getProceeding();
                if (index < length) {
                    while (residue != null && residue != endResidue) {
                        index =
                            createCALines(residue, lineArray, line, index, 3,
                                texture, deltaTextureHalf);
                        texture += deltaTexture;
                        residue = residue.getProceeding();
                    }
                }
                if (index < length) {
                    index =
                        createCALines(endResidue, lineArray, line, index,
                            finalMode, texture, deltaTextureHalf);
                }
            }
            Shape3D shape = new Shape3D(lineArray);
            return shape;
        } else {
            return new Shape3D();
        }
    }

    /**
     * Description of the method.
     *
     * @param chain Description of parameter.
     * @param startResidue Description of parameter.
     * @param endResidue Description of parameter.
     *
     * @return Description of the returned value.
     */
    public static Shape3D createSoapFilmShape(ContextData contextData,
        AbstractChain chain) {
        Collection triangles = new ArrayList();
        TexCoord2f textureCoordinate;
        float length = chain.getLength();
        float widthPowerOf2 = Constants.computeNextHigherPowerOf2(length);
        float deltaTexture = 1.0f / widthPowerOf2;
        float textureX = 0.5f * deltaTexture;
        Residue residue = chain.getInitialResidue();
        Residue limit = chain.getEndResidue().getProceeding();
        while (residue != limit) {
            textureCoordinate = new TexCoord2f(textureX, 0);
            createSoapFilmTriangles(contextData, triangles, residue,
                textureCoordinate);
            residue = residue.getProceeding();
            textureX += deltaTexture;
        }
        return createShape(triangles, GeometryArray.TEXTURE_COORDINATE_2);
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     * @param residue Parameter description.
     *
     * @return Return description.
     */
    public static Shape3D createBallAndStickShape(ContextData contextData,
        Residue residue) {
        Shape3D compositionShape = new Shape3D();
        Shape3D shape;
        Iterator iterator = residue.getAtoms().iterator();
        Atom atom;
        while (iterator.hasNext()) {
            atom = (Atom) iterator.next();
            shape =
                AtomGeometryCreator.createAtomShape(contextData, atom, 0.25f);
            if (shape != null) {
                GeometryHelper.copyGeometry(shape, compositionShape);
            }
        }
        if (residue.getBonds().isEmpty()) {
            residue.getBonds().addAll(residue.computeBonds());
        }
        iterator = residue.getBonds().iterator();
        Bond bond;
        while (iterator.hasNext()) {
            bond = (Bond) iterator.next();
            shape =
                BondGeometryCreator.createBondCylinderShape(contextData, bond,
                    0.25f);
            if (shape != null) {
                GeometryHelper.copyGeometry(shape, compositionShape);
            }
        }
        return compositionShape;
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     * @param residue Parameter description.
     *
     * @return Return description.
     */
    public static Shape3D createVanDerWaalsShape(ContextData contextData,
        Residue residue) {
        Shape3D compositionShape = new Shape3D();
        Shape3D shape;
        Iterator iterator = residue.getAtoms().iterator();
        Atom atom;
        while (iterator.hasNext()) {
            atom = (Atom) iterator.next();
            shape = AtomGeometryCreator.createAtomShape(contextData, atom, 1);
            if (shape != null) {
                GeometryHelper.copyGeometry(shape, compositionShape);
            }
        }
        return compositionShape;
    }

    /**
     * Description of the method.
     *
     * @param residue Description of parameter.
     * @param lineArray Description of parameter.
     * @param line Description of parameter.
     * @param index Description of parameter.
     * @param mode Description of parameter.
     *
     * @return Description of the returned value.
     */
    private static int createCALines(Residue residue, LineArray lineArray,
        Line line, int index, int mode, float texture, float deltaTextureHalf) {
        Residue previous = residue.getPreceeding();
        Residue next = residue.getProceeding();
        Vector3f vector = new Vector3f();
        TexCoord2f textureCoordinate = new TexCoord2f(texture, 0);

        // connects to the previous residue
        if ((mode & 1) != 0) {
            if (previous != null) {
                vector.set(previous.getCoordinate());
                vector.sub(residue.getCoordinate());
                vector.scale(0.5f);
                vector.add(residue.getCoordinate());
                line.getCoordinates().set(vector, residue.getCoordinate());
                line.insertInto(index, lineArray);
                lineArray.setTextureCoordinate(0, index * 2, textureCoordinate);
                textureCoordinate.x += deltaTextureHalf;
                lineArray.setTextureCoordinate(0, index * 2 + 1,
                    textureCoordinate);
                index++;
            }
        }
        textureCoordinate.x = texture + deltaTextureHalf;

        // connects to the next residue
        if ((mode & 2) != 0) {
            if (next != null) {
                vector.set(next.getCoordinate());
                vector.sub(residue.getCoordinate());
                vector.scale(0.5f);
                vector.add(residue.getCoordinate());
                line.getCoordinates().set(residue.getCoordinate(), vector);
                line.insertInto(index, lineArray);
                lineArray.setTextureCoordinate(0, index * 2, textureCoordinate);
                textureCoordinate.x += deltaTextureHalf;
                lineArray.setTextureCoordinate(0, index * 2 + 1,
                    textureCoordinate);
                index++;
            }
        }
        return index;
    }

    private static int createCALines(Residue residue, LineArray lineArray,
        Line line, int index, int mode) {
        Residue previous = residue.getPreceeding();
        Residue next = residue.getProceeding();
        Vector3f vector = new Vector3f();

        // connects to the previous residue
        if ((mode & 1) != 0) {
            if (previous != null) {
                vector.set(previous.getCoordinate());
                vector.sub(residue.getCoordinate());
                vector.scale(0.5f);
                vector.add(residue.getCoordinate());
                line.getCoordinates().set(vector, residue.getCoordinate());
                line.insertInto(index, lineArray);
                index++;
            }
        }

        // connects to the next residue
        if ((mode & 2) != 0) {
            if (next != null) {
                vector.set(next.getCoordinate());
                vector.sub(residue.getCoordinate());
                vector.scale(0.5f);
                vector.add(residue.getCoordinate());
                line.getCoordinates().set(vector, residue.getCoordinate());
                line.insertInto(index, lineArray);
                index++;
            }
        }
        return index;
    }

    /**
     * Method description.
     *
     * @param map Parameter description.
     * @param residue Parameter description.
     *
     * @return Return description.
     */
    public static Residue getMappedResidue(Map map, Residue residue) {
        Residue mappedResidue = null;
        Collection mappedResidues;
        mappedResidues = (Collection) map.get(residue);
        if (mappedResidues != null) {
            if (!mappedResidues.isEmpty()) {
                mappedResidue = (Residue) mappedResidues.iterator().next();
            }
        }
        return mappedResidue;
    }
}
