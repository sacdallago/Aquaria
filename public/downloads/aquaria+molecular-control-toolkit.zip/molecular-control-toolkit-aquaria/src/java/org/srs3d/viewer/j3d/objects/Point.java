/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.objects;

import javax.vecmath.Color3f;
import javax.vecmath.Point3f;
import javax.vecmath.Tuple3f;

import org.srs3d.viewer.j3d.Colorable;
import org.srs3d.viewer.objects.AbstractObject;

/**
 * Instances of this class describe a line that can be displayed in 3d.
 *
 * @author Karsten Klein
 *
 * @created March 20, 2001
 */
public class Point extends AbstractObject implements Colorable {
    private Point3f coordinate = new Point3f();
    private Color3f color = new Color3f(0.3f, 0.3f, 0.3f);
    private float radius = 0.5f;
    private String link = "";
    private String name = "<default>";

    /**
     * Method description.
     *
     * @param name Parameter description.
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public String getName() {
        return name;
    }

    /**
     * Gets the <code>Coordinates</code> attribute of the <code>Box</code> object.
     */
    public Point3f getCoordinate() {
        return coordinate;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public float getRadius() {
        return radius;
    }

    /**
     * Method description.
     *
     * @param radius Parameter description.
     */
    public void setRadius(float radius) {
        this.radius = radius;
    }

    /**
     * Description of the method.
     */
    public void cleanup() {
        super.cleanup();
        coordinate = null;
        color = null;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public Color3f getColor() {
        return color;
    }

    /**
     * Method description.
     *
     * @param color Parameter description.
     */
    public void setColor(Color3f color) {
        this.color = color;
    }

    /**
     * Method description.
     *
     * @param coordinate Parameter description.
     */
    public void setCoordinate(Tuple3f coordinate) {
        this.coordinate.set(coordinate);
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public String toString() {
        return name;
    }
}
