/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.loaders.pdb;

import org.srs3d.viewer.objects.ObjectContainer;
import org.srs3d.viewer.util.ExceptionHandler;
import org.srs3d.viewer.util.Log;

/**
 * This class is part of the pdb file parsing architecture. It summarizes the common
 * interface of the parsers and implements default methods. Note that you have to
 * distinguish between retained and immediate parsers. Retained parsers are not
 * transfering their data until the whole file was parsed with immediate parsers. The
 * parser mode is retrieved using the <code>isRetained() </code>method.
 *
 * @author Karsten Klein
 *
 * @created January 28, 2001
 */
public abstract class AbstractPdbParser {
    private static final Log log = new Log(AbstractPdbParser.class);
    private boolean success = false;

    /**
     * Sets the <code>Success</code> attribute of the <code>AbstractPdbParser
     * </code>object.
     *
     * @param success The new <code>Success</code> value.
     */
    public void setSuccess(boolean success) {
        this.success = success;
    }

    /**
     * Default implementation of the mode retrieval method. All subclasses not
     * overwritting this method returning <code>true</code> are immediate parsers.
     *
     * @return The <code>Retained</code> value.
     */
    public boolean isRetained() {
        return false;
    }

    /**
     * Gets the <code>Success</code> attribute of the <code>AbstractPdbParser
     * </code>object.
     *
     * @return The <code>Success</code> value.
     */
    public boolean isSuccess() {
        return success;
    }

    /**
     * Abstract creation method. It reads all required data from the specified string.
     *
     * @param string Description of parameter.
     */
    public abstract void create(String string);

    /**
     * Default implementation visiting all objects contained in the specified
     * <code>ObjectContainer</code> instance. The <code>visit(...)</code> method
     * transfers all the available data to the according objects, building the internal
     * representation.
     *
     * @param ObjectContainer the <code>ObjectContainer</code> instance to visit
     */
    public abstract void visit(ObjectContainer ObjectContainer);

    /**
     * Default <code>clear()</code> implementation. Subclasses implement this method to
     * clear all the class member data and get the parser object back to its default
     * state. This method is called before finalization. Therefore its advised that no
     * nonbasic datatype member is instatiated. All references should be set to
     * <code>null</code>
     */
    public void clear() {
        setSuccess(false);
    }

    /**
     * Description of the method.
     *
     * @param string Description of parameter.
     * @param start Description of parameter.
     * @param end Description of parameter.
     *
     * @return Description of the returned value.
     */
    public static final int extractInt(String string, int start, int end) {
        int result = 0;
        try {
            result = Integer.parseInt(string.substring(start, end).trim());
        } catch (java.lang.NumberFormatException e) {
            ExceptionHandler.handleException(e,
                ExceptionHandler.SILENT_IN_DEBUG, AbstractPdbParser.class);
            displayError(string, start);

            // using default value; do nothing
        }
        return result;
    }

    /**
     * Description of the method.
     *
     * @param string Description of parameter.
     * @param start Description of parameter.
     * @param end Description of parameter.
     * @param trim Description of parameter.
     *
     * @return Description of the returned value.
     */
    public static final String extractString(String string, int start, int end,
        boolean trim) {
        String substring = extractString(string, start, end);
        if (trim && substring != null) {
            return substring.trim();
        }
        return substring;
    }

    /**
     * Description of the method.
     *
     * @param string Description of parameter.
     * @param start Description of parameter.
     * @param end Description of parameter.
     *
     * @return Description of the returned value.
     */
    public static final String extractString(String string, int start, int end) {
        String result = null;
        try {
            result = string.substring(start, end);
        } catch (Exception e) {
            ExceptionHandler.handleException(e,
                ExceptionHandler.SILENT_IN_DEBUG, AbstractPdbParser.class);
            displayError(string, start);
            result = new String();
        }
        return result;
    }

    /**
     * Description of the method.
     *
     * @param string Description of parameter.
     * @param start Description of parameter.
     * @param end Description of parameter.
     *
     * @return Description of the returned value.
     */
    public static float extractFloat(String string, int start, int end) {
        float result = 0;
        try {
            result = Float.parseFloat(extractString(string, start, end, true));
        } catch (java.lang.NumberFormatException e) {
            if (PdbParser.isVerbose()) {
                ExceptionHandler.handleException(e,
                    ExceptionHandler.SILENT_IN_DEBUG, AbstractPdbParser.class);
                displayError(string, start);
            }
        }
        return result;
    }

    /**
     * Description of the method.
     *
     * @param string Description of parameter.
     * @param index Description of parameter.
     *
     * @return Description of the returned value.
     */
    public static final char extractChar(String string, int index) {
        return string.charAt(index);
    }

    /**
     * Description of the method.
     *
     * @param string Description of parameter.
     * @param index Description of parameter.
     */
    public static final void displayError(String string, int index) {
        if (PdbParser.isVerbose()) {
            log.error(string);
            string = "";
            for (int i = 0; i < index; i++) {
                string += " ";
            }
            log.error(string + '^');
        }
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public boolean isTerminal() {
        return false;
    }
}
