/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.commands;

import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;

import javax.media.j3d.Appearance;
import javax.vecmath.Color3f;

import org.srs3d.viewer.bioatlas.attributes.Representation;
import org.srs3d.viewer.bioatlas.attributes.ResidueRepresentation;
import org.srs3d.viewer.bioatlas.attributes.SubchainRepresentation;
import org.srs3d.viewer.j3d.AppearanceHelper;
import org.srs3d.viewer.j3d.ColorScheme;
import org.srs3d.viewer.j3d.ColorSchemeBucket;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.attributes.Expanded;
import org.srs3d.viewer.j3d.attributes.Visible;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.objects.Command;
import org.srs3d.viewer.objects.State;
import org.srs3d.viewer.util.Log;

/**
 * Color command. The color command is supposed to be the only way to modify the coloring
 * attributes of an object. This implementation directly operates on the Appearance
 * instances (See javax.media.j3d.Appearance). The ColorCommand is instantiated with a
 * ColorScheme or a ColorSchemeBucket for active change of the object coloring. The
 * ColorCommand can also be instantiated with a null colorscheme or colorschemebucket
 * or, consequently without specifying a additional coloring. This is useful as it
 * enable the recoloring of an object. Recoloring can also be enforced using the
 * isRecoloring flag of the color command. Geometry that is colored by vertex color
 * assignment are handled by the color command too. These geometry are accumulated in
 * the respawnCandidates collection for further investigation. If the appearance shows
 * the vertex coloring flag set, the accumulated object geometry is recreated using the
 * SpawnCommand. For applying parental color scheme buckets to children this class
 * provides a static method that takes care of setting the flags in a reasonable
 * fashion. E.g. if the children already have a coloring bucket, it should not be
 * overwritten. For this case the isInvertExtension flag is used which inserts the
 * parental coloring before the existing color bucket (Cparent,Cchild --> Cparent+Cchild
 * rather than Cchild+Cparent).
 *
 * @author Karsten Klein
 *
 * @created April 03, 2001
 * @rewritten January 21, 2002
 */
public class ColorCommand extends ObjectCommand {
    public static final Log log = new Log(ColorCommand.class);

    /** Verbose flag. */
    public static boolean isVerbose = false;
    private static final Color3f defaultColor = new Color3f(0, 0, 0);
    private Collection explicitColoredObject = new HashSet();
    private Collection updateObjects = new HashSet();

    /** Indicates whether the respawn is automatic or not. */
    private boolean isRespawning = true;
    private boolean isExpanding = false;

    /** Controls the extension of the coloring bucket. */
    private boolean isExtendingBucket = true;

    /** Forces the application of the whole bucket if true. */
    private boolean isForceRecoloring = false;

    /** The color command is to remove the colorschemes in the provided buckets. */
    private boolean isRemoving = false;

    /** Inverts the bucket extension if true. */
    private boolean isInvertExtension = false;

    /** Indicated that explicit object list should be maintained or not. */
    private boolean isCollecting = true;

    /** The bucket of the command. */
    private ColorSchemeBucket bucket = null;

    /** Collection of found respawn candiates during (multiple) command executions. */
    private transient Collection respawnCandidates = null;
    private transient Collection preSelectCandidates = null;

    /**
     * <code>ColorCommand</code> constructor.
     *
     * @param contextData ContextData the command is operating on.
     * @param colorScheme ColorScheme for bucket extension, active coloring. Null is also
     *        accepted (use other constructor).
     */
    public ColorCommand(ContextData contextData, ColorScheme colorScheme) {
        super(contextData);
        if (colorScheme != null) {
            bucket = new ColorSchemeBucket(colorScheme);
        }
    }

    /**
     * <code>ColorCommand</code> constructor.
     *
     * @param contextData ContextData the command operates on.
     * @param colorSchemeBucket ColorSchemeBucket for active coloring.
     */
    public ColorCommand(ContextData contextData,
        ColorSchemeBucket colorSchemeBucket) {
        super(contextData);
        bucket = colorSchemeBucket;
    }

    /**
     * <code>ColorCommand</code> constructor. This contructor is useful for recoloring of
     * objects. Note that one should set the isForceRecoloring flag to force full
     * appearance recoloring.
     *
     * @param contextData ContextData the commadn operates on.
     */
    public ColorCommand(ContextData contextData) {
        super(contextData);
        bucket = null;
    }

    /**
     * Sets the colorScheme of the <code>ColorCommand</code> object.
     *
     * @param colorScheme The <code>colorScheme</code> for the command.
     */
    public void setColorScheme(ColorScheme colorScheme) {
        bucket = new ColorSchemeBucket(colorScheme);
    }

    /**
     * Sets the colorSchemeBucket of the <code>ColorCommand</code> object.
     *
     * @param colorSchemeBucket The colorSchemeBucket for the command.
     */
    public void setColorSchemeBucket(ColorSchemeBucket colorSchemeBucket) {
        bucket = colorSchemeBucket;
    }

    /**
     * Sets the isRespawning flag. This flag prevents the respawning of vertex colored
     * objects when set to false. This is useful if the objects are to spawned
     * (unexpanded parent).
     *
     * @param isRespawning New isRespawning setting.
     */
    public void setRespawning(boolean isRespawning) {
        this.isRespawning = isRespawning;
    }

    /**
     * Sets the <code>Expanding</code> attribute of the <code>ColorCommand</code> object.
     *
     * @param isExpanding The new <code>Expanding</code> value.
     */
    public void setExpanding(boolean isExpanding) {
        this.isExpanding = isExpanding;
    }

    /**
     * This inverts the extension of the commands color bucket with the objects bucket.
     * Normally the command bucket is appended to the objects bucket. This is not
     * applicable for parents coloring their children, when the children were already
     * colored specifically. It would overwritte the child specific coloring. When
     * expanding on object and coloring its children use the isInvertExtension set to
     * true.
     *
     * @param isInvertExtension The new isInvertExtension value.
     */
    public void setInvertExtension(boolean isInvertExtension) {
        this.isInvertExtension = isInvertExtension;
    }

    /**
     * The coloring must not extend the bucket of the object. It is said to behave
     * volatile. The change of the coloring is only reflected in the appearance if
     * IsExtendingBucket flag is set to false.
     *
     * @param isExtendingBucket The new isExtendingBucket.
     */
    public void setExtendBucket(boolean isExtendingBucket) {
        this.isExtendingBucket = isExtendingBucket;
    }

    /**
     * Sets the <code>removing</code> attribute of the <code>ColorCommand</code> object.
     *
     * @param isRemoving The new <code>removing</code> value.
     */
    public void setRemoving(boolean isRemoving) {
        this.isRemoving = isRemoving;
    }

    /**
     * Appearances are cached by the AppearanceManager in the context data. At some stage
     * one might have to do full recoloring. Rather than executing a ColorCommand with
     * the full object bucket (which is not always possibe when coloring sets or
     * propagating a certain colorscheme) this flag enables to force a full application
     * of the buckets. If this flag is set to true. The object bucket and after that the
     * color command bucket is assigned (isInvertExtension consequenlty inverts the
     * application).
     *
     * @param isForceRecoloring The new isForceRecoloring value.
     */
    public void setForceRecoloring(boolean isForceRecoloring) {
        this.isForceRecoloring = isForceRecoloring;
    }

    /**
     * Sets the <code>collecting</code> attribute of the <code>ColorCommand</code>
     * object.
     *
     * @param isCollecting The new <code>collecting</code> value.
     */
    public void setCollecting(boolean isCollecting) {
        this.isCollecting = isCollecting;
    }

    /**
     * Gets the colorScheme.
     *
     * @return The colorScheme of the color command.
     */
    public ColorSchemeBucket getColorSchemeBucket() {
        return bucket;
    }

    /**
     * Gets the isRespawning flag.
     *
     * @return The isRespawning flag.
     */
    public boolean isRespawning() {
        return this.isRespawning;
    }

    /**
     * Gets the <code>expanding</code> attribute of the <code>ColorCommand</code> object.
     *
     * @return The <code>expanding</code> value.
     */
    public boolean isExpanding() {
        return this.isExpanding;
    }

    /**
     * Gets the <code>explicitColoredObjects</code> attribute of the
     * <code>ColorCommand</code> object.
     *
     * @return The <code>explicitColoredObjects</code> value.
     */
    public Collection getExplicitColoredObjects() {
        if (!isCollecting) {
            explicitColoredObject.clear();
        }
        return explicitColoredObject;
    }

    /**
     * Gets the <code>forceRecoloring</code> attribute of the <code>ColorCommand</code>
     * object.
     *
     * @return The <code>forceRecoloring</code> value.
     */
    public boolean isForceRecoloring() {
        return isForceRecoloring;
    }

    /**
     * Gets the <code>removing</code> attribute of the <code>ColorCommand</code> object.
     *
     * @return The <code>removing</code> value.
     */
    public boolean isRemoving() {
        return isRemoving;
    }

    /**
     * Executed the color command.
     */
    public void execute() {
        if (isVerbose) {
            log.debug("coloring " + getObject() + " in " + getContextData());
        }
        if (AppearanceHelper.java3DVersion == AppearanceHelper.JAVA3D_1_3) {

            // :WORKAROUND: modify flag when dealing with 1.3 release of Java 3D
            setForceRecoloring(true);
        }
        performExecute(getObject());
        performPreSelect();
        performRespawn();
    }

    /**
     * Propagate the command on the specified object. This implementation can be much
     * more efficient than the conventional StrategyManager propagate, since it controls
     * the automatic repspawn.
     *
     * @param object Description of parameter.
     */
    public void propagate(AbstractObject object) {

        // save current flag
        boolean isRespawning = isRespawning();
        boolean isExpanding = isExpanding();
        setRespawning(false);
        setExpanding(false);
        getContextData().getStrategyManager().propagate(object, this);

        // restore the flag
        setRespawning(isRespawning);
        setExpanding(isExpanding);
        performPreSelect();
        performRespawn();
    }

    /**
     * Method description.
     *
     * @param objects Parameter description.
     */
    public void propagate(Collection objects) {
        propagate(objects, true);
    }

    /**
     * Propagate the command on the specified objects. This implementation can be much
     * more efficient than the conventional StrategyManager propagate, since it controls
     * the automatic repspawn.
     *
     * @param objects Description of parameter.
     */
    public void propagate(Collection objects, boolean isCollapseUp) {

        // save current flag
        boolean isRespawning = isRespawning();
        boolean isExpanding = isExpanding();
        setRespawning(false);
        setExpanding(false);
        getContextData().getStrategyManager().propagate(objects, this,
            isCollapseUp);

        // restore the flag
        setRespawning(isRespawning);
        setExpanding(isExpanding);
        performPreSelect();
        performRespawn();
    }

    /**
     * Description of the method.
     *
     * @param objects Description of parameter.
     */
    public void execute(Collection objects) {

        // save current flag
        boolean isRespawning = isRespawning();
        boolean isExpanding = isExpanding();
        setRespawning(false);
        setExpanding(false);
        getContextData().getStrategyManager().execute(objects, this);

        // restore the flag
        setRespawning(isRespawning);
        setExpanding(isExpanding);
        performPreSelect();
        performRespawn();
    }

    /**
     * Description of the method.
     *
     * @param candidates Description of parameter.
     *
     * @return Description of the returned value.
     */
    private final Collection filterCandidates(Collection candidates) {
        HashSet filtered = new HashSet(candidates.size());
        Iterator iterator = candidates.iterator();
        AbstractObject object;
        while (iterator.hasNext()) {
            object = (AbstractObject) iterator.next();
            State.Immutable state =
                getContextData().getStateManager().getImmutableState(object);
            if (!state.hasAttribute(Expanded.class) &&
                  state.hasAttribute(Visible.class)) {
                Representation.Immutable representation =
                    (Representation.Immutable) state.getAttribute(ResidueRepresentation.class);
                if (representation == null) {
                    representation =
                        (Representation.Immutable) state.getAttribute(SubchainRepresentation.class);
                }
                if (representation != null) {
                    if ((representation.getMode() &
                          Representation.REPRESENTATION_WIREFRAME) != 0) {
                        filtered.add(object);
                    }
                }
            }
        }
        return filtered;
    }

    /**
     * Respawn all collected respawn candidates.
     */
    private final void performRespawn() {
        if (isRespawning && respawnCandidates != null) {
            if (isVerbose) {
                log.debug("respawn candidates " + preSelectCandidates);
            }
            Collection filtered = filterCandidates(respawnCandidates);
            if (!filtered.isEmpty()) {
                HashSet collapsed = new HashSet(filtered.size());
                getContextData().getObjectManager().collapseUpExtended(filtered,
                    collapsed);
                HashSet spawners = new HashSet(collapsed);
                SpawnCommand.searchSpawners(getContextData(), spawners);
                SpawnCommand spawnCommand = new SpawnCommand(getContextData());
                getContextData().getStrategyManager().execute(spawners,
                    spawnCommand);
                recolor(filtered);
            }
            respawnCandidates.clear();
        }
    }

    /**
     * Expands object that need to be colored by themselves.
     */
    private final void performPreSelect() {
        if (isExpanding && preSelectCandidates != null) {
            if (isVerbose) {
                log.debug("preselect candidates " + preSelectCandidates);
            }
            Collection filtered = filterCandidates(preSelectCandidates);
            if (!filtered.isEmpty()) {
                HashSet collapsed = new HashSet(filtered.size());
                getContextData().getObjectManager().collapseUpExtended(filtered,
                    collapsed);

                // :TODO: check if this is correct; whole coil is colored; doesn't need
                //   to be preSelected??
                //        collapsed.removeAll( filtered );
                PreSelectCommand preSelectCommand =
                    new PreSelectCommand(getContextData());
                Command command =
                    new ExecuteClassCommand(getContextData(), preSelectCommand,
                        org.srs3d.viewer.bioatlas.objects.Subchain.class);
                command = new ParentCommand(getContextData(), command);
                getContextData().getStrategyManager().execute(collapsed, command);
                if (preSelectCommand.isExpansion()) {
                    recolor(filtered);
                }
            }
            preSelectCandidates.clear();
        }
    }

    /**
     * Description of the method.
     *
     * @param objects Description of parameter.
     */
    private final void recolor(Collection objects) {
        setExpanding(false);
        setRespawning(false);
        getExplicitColoredObjects().clear();
        getContextData().getStrategyManager().execute(objects, this);
    }

    /**
     * Performs the command execution.
     *
     * @param object Object to execute on.
     */
    private final void performExecute(AbstractObject object) {
        if (!isRemoving) {
            boolean isForceRecoloring = this.isForceRecoloring;
            boolean isApplied = false;
            ColorSchemeBucket applicationBucket = new ColorSchemeBucket();
            ColorSchemeBucket existingBucket =
                getContextData().getColorSchemeManager().getColorSchemeBucket(object);
            if (bucket != null) {
                if (isInvertExtension) {
                    applicationBucket.extend(bucket);
                    applicationBucket.extend(existingBucket);

                    // replace the objects bucket
                    getContextData().getColorSchemeManager().register(object,
                        applicationBucket);
                    isForceRecoloring = true;
                } else {
                    applicationBucket.extend(existingBucket);
                    applicationBucket.extend(bucket);
                    if (isExtendingBucket) {

                        // replace the bucket
                        getContextData().getColorSchemeManager().register(object,
                            applicationBucket);
                    }
                }
            } else {
                applicationBucket.extend(existingBucket);
                isForceRecoloring = true;
            }

            // application and object buckets should be correct at this stage
            Appearance appearance;

            // existing bucket coloring
            if (isForceRecoloring) {

                // invalidate appearance; next access will update
                getContextData().getAppearanceManager().remove(object);
            }
            appearance =
                getContextData().getAppearanceManager().getAppearance(object);
            boolean isModified = isForceRecoloring;
            isModified |= applicationBucket.modify(object, appearance);
            if (isModified) {

                // geometry with enabled vertex colors is a candidate for respawning
                if (AppearanceHelper.areVertexColorsEnabled(appearance)) {
                    addRespawnCandidate(object);
                }
                addPreSelectCandidate(object);
                apply(getContextData(), object, appearance);
            } else {

                // unmodified object
            }
        } else {
            Appearance appearance =
                AppearanceHelper.createAppearance(defaultColor);
            getContextData().getAppearanceManager().register(object, appearance);
            ColorSchemeBucket existingBucket =
                getContextData().getColorSchemeManager().getColorSchemeBucket(object);
            if (existingBucket != null) {
                existingBucket.remove(bucket);
                existingBucket.modify(object, appearance);

                // geometry with enabled vertex colors is a candidate for respawning
                if (AppearanceHelper.areVertexColorsEnabled(appearance)) {
                    addRespawnCandidate(object);
                }
                addPreSelectCandidate(object);
            }
            apply(getContextData(), object, appearance);
        }
    }

    /**
     * Adds a <code>RespawnCandidate</code> object to the <code>ColorCommand</code>
     * object.
     *
     * @param object The <code>RespawnCandidate</code> object to be added.
     */
    private void addRespawnCandidate(AbstractObject object) {
        if (respawnCandidates == null) {
            respawnCandidates = new HashSet();
        }
        respawnCandidates.add(object);
    }

    /**
     * Adds a <code>PreSelectCandidate</code> object to the <code>ColorCommand</code>
     * object.
     *
     * @param object The <code>PreSelectCandidate</code> object to be added.
     */
    private void addPreSelectCandidate(AbstractObject object) {
        if (preSelectCandidates == null) {
            preSelectCandidates = new HashSet();
        }
        preSelectCandidates.add(object);
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     * @param object Description of parameter.
     * @param appearance Description of parameter.
     */
    public static final void apply(ContextData contextData,
        AbstractObject object, Appearance appearance) {
        contextData.getShapeManager().setUniformAppearance(object, appearance);
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     * @param object Description of parameter.
     */
    public static void propagateColorSchemeBucket(ContextData contextData,
        AbstractObject object) {
        Collection children = new HashSet();
        object.getAllObjects(children);

        // propagate parents color settings
        ColorSchemeBucket bucket =
            new ColorSchemeBucket(contextData.getColorSchemeManager()
                                             .getColorSchemeBucket(object));
        if (bucket == null) {
            bucket = contextData.getColorSchemeBucket();
        }
        ColorCommand colorCommand = new ColorCommand(contextData, bucket);
        colorCommand.setRespawning(false);
        colorCommand.setInvertExtension(true);
        colorCommand.setForceRecoloring(true);
        colorCommand.propagate(children, false);
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public boolean isExtendingBucket() {
        return isExtendingBucket;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public String getDescription() {
        return "color command";
    }
}
