/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.objects.strategies;

import java.util.Iterator;

import javax.vecmath.Vector3f;

import org.srs3d.viewer.j3d.Reaction;
import org.srs3d.viewer.j3d.commands.ComputeCenterCommand;
import org.srs3d.viewer.j3d.objects.Point;
import org.srs3d.viewer.j3d.objects.PointSet;
import org.srs3d.viewer.objects.Command;

/**
 * @author Karsten Klein
 *
 * @created April 03, 2001
 */
public class PointSetStrategy extends AbstractStrategy {

    /**
     * Constructor description.
     */
    public PointSetStrategy() {
        register(ComputeCenterCommand.class, new ComputeCenterReaction());
    }

    /**
     * Class description.
     *
     * @author Karsten Klein, LION bioscience AG
     */
    public class ComputeCenterReaction implements Reaction {

        /**
         * Method description.
         *
         * @param command Parameter description.
         */
        public void execute(Command command) {
            ComputeCenterCommand computeCenterCommand =
                (ComputeCenterCommand) command;
            PointSet pointSet = (PointSet) computeCenterCommand.getObject();
            if (pointSet.getPoints().size() > 0) {
                Iterator iterator = pointSet.getPoints().iterator();
                Vector3f center = new Vector3f();
                while (iterator.hasNext()) {
                    center.add(((Point) iterator.next()).getCoordinate());
                }
                center.scale(1.0f / pointSet.getPoints().size());
                iterator = pointSet.getPoints().iterator();
                Vector3f distanceVector = new Vector3f();
                float distance = 0;
                while (iterator.hasNext()) {
                    distanceVector =
                        new Vector3f(((Point) iterator.next()).getCoordinate());
                    distanceVector.sub(center);
                    distance = Math.max(distanceVector.length(), distance);
                }
                computeCenterCommand.modifyCenter(center,
                    new Vector3f(distance, distance, distance));
            }
        }
    }
}
