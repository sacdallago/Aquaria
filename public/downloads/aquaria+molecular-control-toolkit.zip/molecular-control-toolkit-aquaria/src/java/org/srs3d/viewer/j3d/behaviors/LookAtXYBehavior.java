/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.behaviors;

import java.awt.event.MouseEvent;

import javax.media.j3d.Transform3D;
import javax.media.j3d.WakeupOnAWTEvent;
import javax.media.j3d.WakeupOr;
import javax.vecmath.AxisAngle4f;
import javax.vecmath.Matrix3f;
import javax.vecmath.Vector3f;

import org.srs3d.viewer.j3d.ContextData;

/**
 * The class <code>LookAtXYBehavior</code> represents a specialized
 * <code>MouseBehavior</code>. It acts on the current viewport of the context
 *
 * @author Karsten Klein
 *
 * @created November 20, 2000
 */
public class LookAtXYBehavior extends MouseBehavior {

    /** Description of the field. */
    public static int deltaX = 0;

    /** Description of the field. */
    public static int deltaY = 0;

    /** Description of the field */
    private float speedX = 4.0f / 180;
    private float speedY = 4.0f / 180;

    /** Integers used for saving the mouse positions */
    private int lastX;

    /** Integers used for saving the mouse positions */
    private int x;

    /** Description of the field */
    private int lastY;

    /** Description of the field */
    private int y;

    /**
     * <code>RotateBehavior</code> contructor.
     *
     * @param contextData Description of parameter.
     */
    public LookAtXYBehavior(ContextData contextData) {
        super(contextData);
    }

    /**
     * Sets the speed of the behavior. The speed is measured in readians per pixel of
     * mouse the movement.
     *
     * @param speedX The new <code>speed</code> value.
     * @param speedY The new <code>speed</code> value.
     */
    public void setSpeed(float speedX, float speedY) {
        this.speedX = speedX;
        this.speedY = speedY;
    }

    /**
     * Initializes the wakeup conditions for the behavior.
     */
    public void initialize() {
        WakeupOnAWTEvent[] conditions = new WakeupOnAWTEvent[2];

        // set wakeup condition (waiting for further dragging events)
        conditions[0] = new WakeupOnAWTEvent(MouseEvent.MOUSE_DRAGGED);

        // set wakeup condition (waiting first click)
        conditions[1] = new WakeupOnAWTEvent(MouseEvent.MOUSE_PRESSED);
        wakeupOn(new WakeupOr(conditions));
    }

    /**
     * Processes the mouseEvent. This will directly result in a modification of the
     * viewingPlatform in the activated <code>Context</code> , if the according
     * conditions are met by the mouse event.
     *
     * @param mouseEvent Description of parameter.
     */
    public void processStimulus(MouseEvent mouseEvent) {
        lastX = x;
        lastY = y;
        x = mouseEvent.getX();
        y = mouseEvent.getY();
        if (checkCriteria(mouseEvent)) {
            KeyHandler.setCursor(getContextData(), "RotateXY", true);
            deltaX = x - lastX;
            deltaY = y - lastY;
            deltaX = Math.min(deltaX, MAX_DELTA);
            deltaX = Math.max(deltaX, -MAX_DELTA);
            deltaY = Math.min(deltaY, MAX_DELTA);
            deltaY = Math.max(deltaY, -MAX_DELTA);
            rotate(getContextData(), speedX * deltaX, speedY * deltaY);
        }
    }

    /**
     * This method checks the mouseEvent (fail early, fail fast)
     *
     * @param mouseEvent Description of parameter.
     *
     * @return Description of the returned value.
     */
    protected boolean checkCriteria(MouseEvent mouseEvent) {
        if (mouseEvent.getID() != MouseEvent.MOUSE_DRAGGED) {
            return false;
        }
        if ((mouseEvent.getModifiers() & MouseEvent.BUTTON3_MASK) != 0) {
            return false;
        }
        if (mouseEvent.isShiftDown()) {
            return false;
        }
        if (mouseEvent.isControlDown()) {
            return false;
        }
        if (mouseEvent.isAltGraphDown()) {
            return false;
        }
        mouseEvent.consume();
        return true;
    }

    /**
     * Description of the method.
     *
     * @param context Description of parameter.
     * @param deltaX Description of parameter.
     * @param deltaY Description of parameter.
     */
    public static void rotate(ContextData contextData, float deltaX,
        float deltaY) {

        // read viewing platform transform
        Transform3D transform =
            contextData.getContext().getViewingPlatformTransform();
        Matrix3f matrix = new Matrix3f();
        Vector3f vector = new Vector3f();
        transform.get(matrix);
        matrix.getColumn(1, vector);
        AxisAngle4f axisAngleX = new AxisAngle4f(vector, -deltaX);
        matrix.getColumn(0, vector);
        AxisAngle4f axisAngleY = new AxisAngle4f(vector, -deltaY);
        matrix.set(axisAngleX);
        Matrix3f dummy = new Matrix3f();
        dummy.set(axisAngleY);
        matrix.mul(dummy);

        // extract rotation and translation parts
        Vector3f translation = new Vector3f();
        Matrix3f rotation = new Matrix3f();
        transform.get(rotation);
        transform.get(translation);

        // modify translation and rotation
        translation.sub(contextData.getContext().getCenterOfRotation());
        rotation.mul(matrix, rotation);
        matrix.transform(translation);
        translation.add(contextData.getContext().getCenterOfRotation());
        transform.setRotation(rotation);
        transform.setTranslation(translation);
        transform.normalize();
        contextData.getContext().setViewingPlatformTransform(transform);
    }
}
