/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.filters;

import org.srs3d.viewer.bioatlas.objects.ChainFragment;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.objects.filters.ObjectClassFilter;

/**
 * <code>ObjectFilter</code> extracting Ligand chains.
 *
 * @author Karsten Klein
 *
 * @created May 14, 2001
 */
public final class LigandFilter extends ObjectClassFilter {
    private boolean isIgnoreWater = false;
    private boolean stopAtNext = false;
    private AbstractObject found = null;
    private boolean iteratedPastObject = false;
    /**
     * <code>LigandFilter</code> constructor.
     */
    public LigandFilter() {
        super(ChainFragment.class);
    }

    /**
     * Constructor description.
     *
     * @param isIgnoreWater Parameter description.
     */
    public LigandFilter(boolean isIgnoreWater) {
        super(ChainFragment.class);
        this.isIgnoreWater = isIgnoreWater;
    }

    /**
     * Constructor description.
     *
     * @param isIgnoreWater Parameter description.
     */
    public LigandFilter(boolean isIgnoreWater, boolean stopAtNext) {
        super(ChainFragment.class);
        this.isIgnoreWater = isIgnoreWater;
        this.stopAtNext = stopAtNext;
    }

    public void prepareForNext() {
    	iteratedPastObject = false;    	
    }

    public void reset() {
    	iteratedPastObject = false;    	
    	found = null;
    }
    /**
     * Description of the method.
     *
     * @param object Description of parameter.
     *
     * @return Description of the returned value.
     */
    public boolean filter(AbstractObject object) {
    	if (stopAtNext && found == object) {
    		iteratedPastObject = true;
    	}
    	else {
    		if (stopAtNext && found != null && !iteratedPastObject) {
    			//waiting till we get to the next Ligand
    			// or we already have our object, exit quickly
    		}
    		else {
    			
		        if (super.filter(object)) {
		            if (((ChainFragment) object).isLigand()) {
		                if (isIgnoreWater) {
		                    if (!((ChainFragment) object).isWater()) {
		                    	if (stopAtNext) {
		                    		found = object;
		                    		iteratedPastObject = false;
		                    	}
		                        return true;
		                    }
		                } else {
	                    	if (stopAtNext) {
	                    		found = object;
	                    		iteratedPastObject = false;
	                    	}
		                    return true;
		                }
		            }
		        }
    		}
    	}
        return false;
    }
}
