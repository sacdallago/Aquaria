/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.modules;

import java.awt.event.ActionEvent;
import java.util.Collection;
import java.util.Iterator;

import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.behaviors.UpdateBehavior;
import org.srs3d.viewer.j3d.commands.LabelCommand;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.objects.State;
import org.srs3d.viewer.objects.StateManager;
import org.srs3d.viewer.objects.visitors.ObjectCollector;

/**
 * Description of the class.
 *
 * @author Karsten Klein
 *
 * @created April 29, 2002
 */
public class RemoveLabelModule extends ProcessModule {

    /** Description of the field. */
    public transient Collection objects = null;

    /**
     * <code>CommandModule</code> constructor.
     *
     * @param name Description of parameter.
     * @param contextData Description of parameter.
     */
    public RemoveLabelModule(String name, ContextData contextData) {
        super(name, contextData, true, true);
    }

    /**
     * Gets the <code>moduleIdPrefix</code> attribute of the
     * <code>RemoveSurfaceModule</code> object.
     *
     * @return The <code>moduleIdPrefix</code> value.
     */
    public String getModuleIdPrefix() {
        return "";
    }

    /**
     * Gets the <code>moduleId</code> attribute of the <code>RemoveSurfaceModule</code>
     * object.
     *
     * @return The <code>moduleId</code> value.
     */
    public String getModuleId() {
        return "REMOVE_ALL_LABELS";
    }

    /**
     * Description of the method.
     *
     * @param e Description of parameter.
     */
    public void process(ActionEvent e) {
        getContextData().getContext().addUpdateCallback(new UpdateBehavior.Callback() {
                public void execute() {
                    remove(objects);
                }
            });
    }

    /**
     * Description of the method.
     */
    public void updateIntern() {
        ObjectCollector objectCollector = new ObjectCollector(null);
        objectCollector.visit(getContextData().getObjectContainer().getObjects());
        objects = objectCollector.getObjects();
        Iterator iterator = objects.iterator();
        AbstractObject object;
        State.Immutable state;
        StateManager stateManager = getContextData().getStateManager();
        while (iterator.hasNext()) {
            object = (AbstractObject) iterator.next();
            state = stateManager.getImmutableState(object);
            if (!state.hasAttribute(
                      org.srs3d.viewer.bioatlas.attributes.Labeled.class)) {
                iterator.remove();
            }
        }
        if (getComponent() != null) {
            getComponent().setEnabled(!objects.isEmpty());
        }
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     */
    public void remove(Collection objects) {
        if (objects != null && !objects.isEmpty()) {
            LabelCommand labelCommand =
                new LabelCommand(getContextData(), null, false);
            getContextData().getStrategyManager().execute(objects, labelCommand);
        }
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     * @param object Description of parameter.
     */
    public void remove(AbstractObject object) {
        if (object != null) {
            LabelCommand labelCommand =
                new LabelCommand(getContextData(), null, false);
            getContextData().getStrategyManager().execute(object, labelCommand);
        }
    }
}
