/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.loaders.rdb;

import java.util.HashSet;
import java.util.Map;

import javax.vecmath.Color3f;
import javax.vecmath.Point3f;

import org.srs3d.viewer.j3d.objects.Box;
import org.srs3d.viewer.j3d.objects.Link;
import org.srs3d.viewer.j3d.objects.Point;
import org.srs3d.viewer.j3d.objects.PointSet;
import org.srs3d.viewer.objects.ObjectContainer;

/**
 * The RdbLayerInterpreter class.
 *
 * @author Karsten Klein
 *
 * @created December 10, 2001
 */
public class RdbPointInterpreter implements RdbInterpreter {
    private transient Box box = null;
    private transient PointSet pointSet = new PointSet();

    /**
     * Interpretes then data in the fieldMap and creates a layer that is stored in the
     * specified object container.
     *
     * @param fieldMap Maps field identifiers to field content.
     * @param objectContainer Destination of the interpreted data.
     */
    public void interprete(Map fieldMap, ObjectContainer objectContainer) {
        Point point = new Point();
        String string;
        string = (String) fieldMap.get("NAME");
        if (string != null) {
            point.setName(string);
        }
        Point3f coordinate = new Point3f();
        string = (String) fieldMap.get("X");
        if (string != null) {
            coordinate.x = Float.parseFloat(string);
        }
        string = (String) fieldMap.get("Y");
        if (string != null) {
            coordinate.y = Float.parseFloat(string);
        }
        string = (String) fieldMap.get("Z");
        if (string != null) {
            coordinate.z = Float.parseFloat(string);
        }

        // :TODO: provide the scale as parameter in the parameters of the rdb or the
        // rdb itself
        //    coordinate.scale(100);
        point.setCoordinate(coordinate);
        Color3f color = new Color3f(0.3f, 0.3f, 0.3f);
        string = (String) fieldMap.get("RED");
        if (string != null) {
            color.x = Float.parseFloat(string);
        }
        string = (String) fieldMap.get("GREEN");
        if (string != null) {
            color.y = Float.parseFloat(string);
        }
        string = (String) fieldMap.get("BLUE");
        if (string != null) {
            color.z = Float.parseFloat(string);
        }
        String links = (String) fieldMap.get("LINKS");
        if (links != null) {
            Link link = new Link();
            link.setLinks(links);
            HashSet objects = new HashSet();
            objects.add(point);
            link.setObjects(objects);
            objectContainer.addObject(link);
        }
        point.setColor(color);
        if (box == null) {
            box = new Box();
            box.getCoordinates().setAt(0, point.getCoordinate());
            box.getCoordinates().setAt(1, point.getCoordinate());
            objectContainer.addObject(box);
        } else {
            box.getCoordinates().min(0, point.getCoordinate());
            box.getCoordinates().max(1, point.getCoordinate());
        }
        pointSet.addPoint(point);
    }

    /**
     * Method description.
     *
     * @param objectContainer Parameter description.
     */
    public void finalizeInterpretation(ObjectContainer objectContainer) {
        objectContainer.addObject(pointSet);
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public static String getInterpreterId() {
        return "POINT";
    }
}
