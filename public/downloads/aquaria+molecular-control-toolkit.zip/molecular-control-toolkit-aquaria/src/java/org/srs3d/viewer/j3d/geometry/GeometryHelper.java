/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.geometry;

import java.util.Enumeration;

import javax.media.j3d.CapabilityNotSetException;
import javax.media.j3d.Geometry;
import javax.media.j3d.GeometryArray;
import javax.media.j3d.LineArray;
import javax.media.j3d.QuadArray;
import javax.media.j3d.Shape3D;
import javax.media.j3d.TriangleArray;

import org.srs3d.viewer.util.Log;

/**
 * This class <code>GeometryHelper</code> can be employed to create default geometry
 * instance. It therefore summarizes the the general cases of various geometry classes.
 *
 * @author Karsten Klein
 *
 * @created September 24, 2001
 */
public class GeometryHelper {
    private static final Log log = new Log(GeometryHelper.class);

    /**
     * Gets the <code>defaultTriangleArray</code> attribute of the
     * <code>GeometryHelper</code> class.
     *
     * @param size Description of parameter.
     * @param additionalFlags Description of parameter.
     *
     * @return The <code>defaultTriangleArray</code> value.
     */
    public static TriangleArray getDefaultTriangleArray(int size,
        int additionalFlags) {
        TriangleArray triangleArray =
            new TriangleArray(size * 3,
                GeometryArray.COORDINATES | GeometryArray.NORMALS |
                additionalFlags);
        return triangleArray;
    }

    /**
     * Gets the <code>defaultLineArray</code> attribute of the
     * <code>GeometryHelper</code> class.
     *
     * @param size Description of parameter.
     * @param additionalFlags Description of parameter.
     *
     * @return The <code>defaultLineArray</code> value.
     */
    public static LineArray getDefaultLineArray(int size, int additionalFlags) {
        return new LineArray(size * 2,
            GeometryArray.COORDINATES | additionalFlags);
    }

    /**
     * Gets the <code>defaultQuadArray</code> attribute of the
     * <code>GeometryHelper</code> class.
     *
     * @param size Description of parameter.
     * @param additionalFlags Description of parameter.
     *
     * @return The <code>defaultQuadArray</code> value.
     */
    public static QuadArray getDefaultQuadArray(int size, int additionalFlags) {
        return new QuadArray(size * 4,
            GeometryArray.COORDINATES | additionalFlags);
    }

    /**
     * Tries to copy all the geometries form the source shape to the destination shape.
     *
     * @param source Source shape.
     * @param destination destination shape.
     */
    public static void copyGeometry(Shape3D source, Shape3D destination) {
        Enumeration geometries = source.getAllGeometries();
        while (geometries.hasMoreElements()) {
            try {
                destination.addGeometry((Geometry) geometries.nextElement());
            } catch (CapabilityNotSetException e) {
                log.debug(e, e);
            }
        }
    }

    /**
     * Method description.
     *
     * @param source Parameter description.
     * @param destination Parameter description.
     */
    public static void copyGeometryContent(Shape3D source, Shape3D destination) {
        Enumeration geometries = source.getAllGeometries();
        Geometry geometry;
        while (geometries.hasMoreElements()) {
            try {
                geometry = (Geometry) geometries.nextElement();
                if (geometry != null) {
                    destination.addGeometry((Geometry) (geometry).cloneNodeComponent(
                            true));
                }
            } catch (CapabilityNotSetException e) {
                log.debug(e, e);
            }
        }
    }
}
