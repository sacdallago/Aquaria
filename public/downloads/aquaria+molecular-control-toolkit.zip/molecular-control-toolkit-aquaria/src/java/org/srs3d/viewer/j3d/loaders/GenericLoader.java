/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.loaders;

import java.net.URL;

import com.sun.j3d.loaders.IncorrectFormatException;
import com.sun.j3d.loaders.Loader;
import com.sun.j3d.loaders.LoaderBase;
import com.sun.j3d.loaders.ParsingErrorException;
import com.sun.j3d.loaders.Scene;

/**
 * @author Karsten Klein, 11/2000
 *
 * @created September 6, 2001
 * @since 1.0
 */
public class GenericLoader extends LoaderBase {

    /**
     * Description of the method.
     *
     * @param filename Description of parameter.
     *
     * @return Description of the returned value.
     *
     * @exception java.io.FileNotFoundException Description of exception.
     * @exception IncorrectFormatException Description of exception.
     * @exception ParsingErrorException Description of exception.
     */
    public Scene load(String filename)
        throws java.io.FileNotFoundException, IncorrectFormatException, 
            ParsingErrorException {
        Loader loader = mapNameToLoader(filename);
        return loader.load(filename);
    }

    /**
     * Description of the method.
     *
     * @param reader Description of parameter.
     *
     * @return Description of the returned value.
     *
     * @exception java.io.FileNotFoundException Description of exception.
     * @exception IncorrectFormatException Description of exception.
     * @exception ParsingErrorException Description of exception.
     */
    public Scene load(java.io.Reader reader)
        throws java.io.FileNotFoundException, IncorrectFormatException, 
            ParsingErrorException {
        Loader loader = mapNameToLoader(null);
        return loader.load(reader);
    }

    /**
     * Description of the method.
     *
     * @param url Description of parameter.
     *
     * @return Description of the returned value.
     *
     * @exception java.io.FileNotFoundException Description of exception.
     * @exception IncorrectFormatException Description of exception.
     * @exception ParsingErrorException Description of exception.
     */
    public Scene load(URL url)
        throws java.io.FileNotFoundException, IncorrectFormatException, 
            ParsingErrorException {
        Loader loader = mapNameToLoader(url.getFile());
        return loader.load(url);
    }

    /**
     * Description of the method.
     *
     * @param name Description of parameter.
     *
     * @return Description of the returned value.
     */
    private Loader mapNameToLoader(String name) {
        Loader loader = null;
        if (name.endsWith("raster3d")) {
            loader = new org.srs3d.viewer.j3d.loaders.Raster3D();
        } else if (name.endsWith("eps")) {
            loader = new org.srs3d.viewer.j3d.loaders.Postscript();
        } else {
            loader = new com.sun.j3d.loaders.objectfile.ObjectFile();
        }
        return loader;
    }
}
