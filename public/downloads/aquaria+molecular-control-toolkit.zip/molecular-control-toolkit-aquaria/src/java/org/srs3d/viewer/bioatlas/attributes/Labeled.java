/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.attributes;

import org.srs3d.viewer.j3d.objects.Label;
import org.srs3d.viewer.objects.Attribute;

/**
 * Label attribute.
 *
 * @author Karsten Klein
 *
 * @created April 03, 2001
 */
public class Labeled extends Attribute {
    Label label = null;

    /**
     * Sets the <code>label</code> attribute of the <code>Labeled</code> object.
     *
     * @param label The new <code>label</code> value.
     */
    public void setLabel(Label label) {
        this.label = label;
    }

    /**
     * Gets the <code>label</code> attribute of the <code>Labeled</code> object.
     *
     * @return The <code>label</code> value.
     */
    public Label getLabel() {
        return label;
    }

    /**
     * Checks for equal content.
     *
     * @param attribute Second attribute to compare.
     *
     * @return Boolean flag indicating eual content.
     */
    public boolean isEqual(Attribute attribute) {
        Labeled labeled = (Labeled) attribute;
        return getLabel() == labeled.getLabel();
    }

    /**
     * Gets the <code>immutable</code> attribute of the <code>Labeled</code> object.
     *
     * @return The <code>immutable</code> value.
     */
    public Attribute.Immutable getImmutable() {
        return new Immutable();
    }

    /**
     * Creates a copied instance.
     *
     * @return New instance of the attribute with the same content.
     */
    public Attribute copy() {
        Labeled labeled = (Labeled) super.copy();
        labeled.setLabel(getLabel());
        return labeled;
    }

    /**
     * Description of the class.
     *
     * @author Karsten Klein
     *
     * @created December 14, 2001
     */
    public class Immutable extends Attribute.Immutable {

        /**
         * The returned object is mutable; we violate the immutable priciple here at the
         * Attribute.Immutable-attribute lvele
         *
         * @return The <code>label</code> value.
         */
        public Label getLabel() {
            return Labeled.this.getLabel();
        }
    }
}
