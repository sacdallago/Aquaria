/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.visitors;

import java.util.ArrayList;

import javax.vecmath.Point3f;
import javax.vecmath.Tuple3f;

import org.srs3d.viewer.bioatlas.objects.Residue;

/**
 * General path creator class. Last change: 20.12.2001: included covalent connection
 * check for pre- and postPoint cumputation.
 *
 * @author Karsten Klein
 *
 * @created May 21, 2001
 */
public class PathCreator {

    /** vector where the path is produced. */
    public ArrayList path = new ArrayList();

    /** point that is used for continous transition */
    public Tuple3f prePoint = null;

    /** point that is used for continous transition */
    public Tuple3f postPoint = null;

    /**
     * Gets the residue coordinate of an <code>Residue</code>.
     *
     * @param residue Residue used for coordinate computation.
     *
     * @return The <code>residueCoordinate</code> value.
     */
    public Point3f getResidueCoordinate(Residue residue) {
        if (residue != null) {
            if (residue.refCA != null) {

                // take coordinate of c alpha if available
                return new Point3f(residue.refCA.getCoordinate());
            } else if (residue.refP != null) {

                // take coordinate of p if available
                return new Point3f(residue.refP.getCoordinate());
            } else {

                // compute center of mass
                AtomCollector atomCollector = new AtomCollector();
                atomCollector.visit(residue);
                Point3f point = atomCollector.getCenter();
                atomCollector = null;
                return point;
            }
        } else {
            return null;
        }
    }

    /**
     * Description of the method.
     *
     * @param start Description of parameter.
     * @param stop Description of parameter.
     */
    public void visit(Residue start, Residue stop) {
        Residue residue = start;
        Residue limit = stop.getProceeding();
        if (residue.getPreceeding() != null) {
            if (ChainAnalyser.isBackboneCovalentlyConnected(
                      residue.getPreceeding(), residue)) {
                prePoint =
                    (Tuple3f) getResidueCoordinate(residue.getPreceeding());
            }
        }
        while (residue != limit) {
            if (residue != null) {
                path.add(getResidueCoordinate(residue));
            }
            residue = residue.getProceeding();
        }
        if (limit != null) {
            if (ChainAnalyser.isBackboneCovalentlyConnected(stop, limit)) {
                postPoint = (Tuple3f) getResidueCoordinate(limit);
            }
        }

        // if no path was extracted yet just take the initial and end residues
        // CA positions
        if (path.size() < 2) {
            Point3f point0;
            Point3f point1;
            Point3f point;

            // forget all added coordinates
            path.clear();
            point0 = getResidueCoordinate(start);
            point1 = getResidueCoordinate(stop);
            point = new Point3f(point0);
            point.scale(10);
            point.add(point1);
            point.scale(1.0f / 11);
            path.add(point);
            point = new Point3f(point1);
            point.scale(10);
            point.add(point0);
            point.scale(1.0f / 11);
            path.add(point);
        }
    }

    /**
     * Description of the method.
     *
     * @param residue Description of parameter.
     */
    public void visit(Residue residue) {
        if (residue.getPreceeding() != null) {
            prePoint = (Tuple3f) getResidueCoordinate(residue.getPreceeding());
        }
        path.add(getResidueCoordinate(residue));
        if (residue.getProceeding() != null) {
            postPoint = (Tuple3f) getResidueCoordinate(residue.getProceeding());
        }
    }

    /**
     * Description of the method.
     *
     * @param loopCount Description of parameter.
     */
    public void smooth(int loopCount) {
        Tuple3f current;
        for (int i = 0; i < loopCount; i++) {
            for (int j = 1; j < path.size() - 1; j += 1) {
                current = (Tuple3f) path.get(j);
                current.add((Tuple3f) path.get(j - 1));
                current.add((Tuple3f) path.get(j + 1));
                current.scale(1.0f / 3);
            }
        }
    }
}
