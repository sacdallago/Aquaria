/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.loaders;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.util.zip.GZIPInputStream;
import java.util.zip.ZipInputStream;

import org.srs3d.viewer.objects.ObjectContainer;
import org.srs3d.viewer.util.ExceptionHandler;
import org.srs3d.viewer.util.Log;

/**
 * @author Karsten Klein
 *
 * @created November 11, 2000
 */
public class GenericLoader implements Loader {
    private static final Log log = new Log(GenericLoader.class);
    private Object parameterObject = null;

    private InputStream attemptGZipped(URLConnection connection) {
        try {
            InputStream inputStream = connection.getInputStream();
            inputStream = new GZIPInputStream(inputStream);
            inputStream.read();

            // reset the stream
            connection.getInputStream().close();
            inputStream = connection.getURL().openConnection().getInputStream();
            inputStream = new GZIPInputStream(inputStream);
            return inputStream;
        } catch (Exception e) {
            ExceptionHandler.handleException(e,
                ExceptionHandler.SILENT_IN_RELEASE);
        }
        return null;
    }

    private InputStream attemptZipped(URLConnection connection) {
        try {
            InputStream inputStream = connection.getInputStream();
            inputStream = new ZipInputStream(inputStream);
            if (inputStream.read() != -1) {

                // reset the stream
                connection.getInputStream().close();
                inputStream =
                    connection.getURL().openConnection().getInputStream();
                inputStream = new ZipInputStream(inputStream);
                return inputStream;
            }
        } catch (Exception e) {
            ExceptionHandler.handleException(e,
                ExceptionHandler.SILENT_IN_RELEASE);
        }
        return null;
    }

    /**
     * Method description.
     *
     * @param url Parameter description.
     *
     * @return Return description.
     *
     * @throws java.io.IOException Exception description.
     */
    public InputStream getStream(URL url) throws java.io.IOException {
        InputStream inputStream = null;
        URLConnection connection = url.openConnection();
        inputStream = attemptGZipped(connection);
        if (inputStream == null) {
            inputStream = attemptZipped(connection);
        }
        if (inputStream == null) {
            inputStream = connection.getInputStream();
        }
        return inputStream;
    }

    /**
     * Loads the file with the specified <code>url</code> . The found data is accumulated
     * in a <code>ObjectContainer</code> instance.
     *
     * @param url url of the file to be loaded.
     *
     * @return containes the read data.
     *
     * @exception IOException Description of exception.
     */
    public ObjectContainer load(URL url) throws IOException {
        ObjectContainer container = null;
        Loader loader;
        if (url == null) {
            try {
                loader = new org.srs3d.viewer.bioatlas.loaders.SmilesLoader();
                loader.setParameterObject(parameterObject);
                container = loader.load(url);
                if (container != null && container.getSize() > 0) {
                    return container;
                }
            } catch (Exception e) {
                ExceptionHandler.handleException(e,
                    ExceptionHandler.SILENT_IN_RELEASE);
            }
        }
        InputStream inputStream = null;
        inputStream = getStream(url);
        try {
            loader = new org.srs3d.viewer.bioatlas.loaders.PdbLoader();
            container = loader.load(inputStream);
            if (container != null && container.getSize() > 0) {
                return container;
            }
        } catch (Exception e) {
            ExceptionHandler.handleException(e,
                ExceptionHandler.SILENT_IN_RELEASE);
        }
        inputStream = getStream(url);
        try {
            loader = new org.srs3d.viewer.bioatlas.loaders.SdfLoader();
            loader.setParameterObject(parameterObject);
            container = loader.load(inputStream);
            if (container != null && container.getSize() > 0) {
                return container;
            }
        } catch (Exception e) {
            ExceptionHandler.handleException(e,
                ExceptionHandler.SILENT_IN_RELEASE);
        }
        inputStream = getStream(url);
        try {
            loader = new org.srs3d.viewer.bioatlas.loaders.RdbLoader();
            container = loader.load(inputStream);
            if (container != null && container.getSize() > 0) {
                return container;
            }
        } catch (Exception e) {
            ExceptionHandler.handleException(e,
                ExceptionHandler.SILENT_IN_RELEASE);
        }
        return container;
    }

    /**
     * Description of the method.
     *
     * @param inputStream Parameter description.
     *
     * @return Return parameter description.
     *
     * @throws IOException Exception description.
     */
    public ObjectContainer load(java.io.InputStream inputStream)
        throws IOException {

        // :FIXME: should do something; at least throw an exeption
        // niot implemented
        return null;
    }

    /**
     * Method description.
     *
     * @param parameterObject Parameter description.
     */
    public void setParameterObject(Object parameterObject) {
        this.parameterObject = parameterObject;
    }
}
