/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.annotation.colorschemes;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Vector;

import javax.media.j3d.Appearance;
import javax.vecmath.Color3f;
import javax.vecmath.Vector3f;

import org.srs3d.viewer.annotation.objects.AnnotationContainer;
import org.srs3d.viewer.bioatlas.objects.Atom;
import org.srs3d.viewer.bioatlas.objects.Residue;
import org.srs3d.viewer.bioatlas.objects.templates.ResidueTemplate;
import org.srs3d.viewer.j3d.AbstractColorScheme;
import org.srs3d.viewer.j3d.AppearanceHelper;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.objects.ObjectManager;
import org.srs3d.viewer.vecmath.CubicBezierCurve3f;

/**
 * @author Karsten Klein
 *
 * @created March 20, 2001
 */
public class DisplacementColorScheme extends AbstractColorScheme {
    private static float maxDistance = 2.0f * 3.8f;
    private static float minDistance = 0f;

    /** a cubic bezier curve is used for the color interpolation. */
    private CubicBezierCurve3f colorCurve = null;
    private Color3f closeColor = new Color3f(0.1f, 0.8f, 0.1f);
    private Color3f nearColor = new Color3f(0.1f, 0.1f, 0.8f);
    private Color3f farColor = new Color3f(0.35f, 0.35f, 0.35f);

    /**
     * <code>DisplacementColorScheme</code> constructor.
     *
     * @param contextData Description of parameter.
     */
    public DisplacementColorScheme(ContextData contextData) {
        super(contextData);
        setComplete(true);

        // we use a cubic bezier curve for interpolation of the colors
        colorCurve = new CubicBezierCurve3f();
        ArrayList colors = new ArrayList();
        colors.add(closeColor);
        colors.add(nearColor);
        colors.add(farColor);
        colorCurve.setCoordinates(colors);
    }

    /**
     * Gets the <code>information</code> attribute of the
     * <code>DisplacementColorScheme</code> object.
     *
     * @param map Description of parameter.
     *
     * @return The <code>information</code> value.
     */
    public Map getInformation(Map map) {
        map = super.getInformation(map);
        map.put("NAME", "Displacement");
        map.put("GRADIENT_START", "0.0 Angstrom");
        map.put("   0.0 Angstrom", closeColor);
        map.put("   3.8 Angstrom", nearColor);
        map.put("> 7.6 Angstrom", farColor);
        map.put("GRADIENT_END", "> 7.6 Angstrom");
        Vector vector = new Vector();
        vector.add("GRADIENT_START");
        vector.add("   0.0 Angstrom");
        vector.add("   3.8 Angstrom");
        vector.add("> 7.6 Angstrom");
        vector.add("GRADIENT_END");
        map.put("ORDER", vector);
        map.put("GRADIENT", colorCurve);
        return map;
    }

    /**
     * Colors the annotation objects as their counterparts in the molecule view.
     *
     * @param object Description of Parameter
     * @param appearance Description of parameter.
     *
     * @return Description of the returned value.
     */
    public boolean modify(AbstractObject object, Appearance appearance) {
        if (isApplicable(object)) {

            // color max distance
            Color3f color = farColor;
            if (object instanceof Residue) {
                color = computeColor(computeDistance((Residue) object));
            } else {

                // color atoms
                Collection residues = new HashSet();
                getContextData().getObjectManager().getUpAssociations(object,
                    residues);
                ObjectManager.extract(residues, Residue.class);
                if (residues.size() > 0) {
                    Iterator iterator = residues.iterator();
                    float distance = 0;
                    while (iterator.hasNext()) {
                        distance += computeDistance((Residue) iterator.next());
                    }
                    distance /= residues.size();
                    color = computeColor(distance);
                }
            }
            AppearanceHelper.enableVertexColors(appearance,
                object.getClass() != Atom.class);
            AppearanceHelper.modifyAppearance(appearance, color);
            return true;
        }
        return false;
    }

    /**
     * @param distance Description of parameter.
     *
     * @return <code>Color3f</code> - the color mapped to the specified temperature.
     */
    private Color3f computeColor(float distance) {
        float map = (distance - minDistance) / (maxDistance - minDistance);
        if (map < 0) {
            map = 0;
        }
        if (map > 1) {
            map = 1;
        }
        Color3f color = new Color3f();
        color.set(colorCurve.computePoint(map));
        return color;
    }

    /**
     * Description of the method.
     *
     * @param residueA Description of parameter.
     *
     * @return Description of the returned value.
     */
    private float computeDistance(Residue residueA) {
        ResidueTemplate templateA = residueA.getTemplate();
        AnnotationContainer annotationContainer =
            (AnnotationContainer) HomologyColorScheme.getAnnotation(getContextData());
        if (!templateA.isLigand() && annotationContainer != null) {
            Collection residues = annotationContainer.mapResidues(residueA);
            if (residues != null) {
                Iterator iterator = residues.iterator();
                Residue residueB;
                float length = 0;
                int count = 0;
                Vector3f vector = new Vector3f();
                while (iterator.hasNext()) {
                    residueB = (Residue) iterator.next();
                    vector.set(residueB.getCoordinate());
                    vector.sub(residueA.getCoordinate());
                    length += vector.length();
                    count++;
                }
                if (count == 0) {
                    return maxDistance;
                } else if (count > 1) {
                    return length / count;
                }
                return length;
            }
        }
        return maxDistance;
    }

    private boolean isApplicable(AbstractObject object) {
        if (object.getClass() == Residue.class) {
            return true;
        }
        if (object.getClass() == Atom.class) {
            return true;
        }
        return false;
    }
}
