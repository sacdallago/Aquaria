/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.behaviors;

import javax.media.j3d.Alpha;
import javax.media.j3d.WakeupOnElapsedFrames;
import javax.vecmath.Point3d;
import javax.vecmath.Tuple3f;
import javax.vecmath.Vector3f;

import org.srs3d.viewer.j3d.Context;
import org.srs3d.viewer.j3d.ContextData;

/**
 * @author Karsten Klein, 11/2000
 *
 * @since 1.0
 */
public class PositionInterpolator extends AutonomicBehavior {
    private Tuple3f origin = null;
    private Tuple3f destination = null;

    /**
     * Constructor description.
     *
     * @param contextData Parameter description.
     */
    public PositionInterpolator(ContextData contextData) {
        setContextData(contextData);
    }

    /**
     * The processStimulus method is the only method override from the com.sun... class
     * Behavior.
     */
    public void processStimulus(java.util.Enumeration criteria) {
        Alpha alpha = getAlpha();
        if (alpha != null && origin != null && destination != null) {
            Context context = getContextData().getContext();
            if (!alpha.finished()) {
                Vector3f vector = new Vector3f(destination);
                vector.sub(origin);
                float value = 1.0f - alpha.value();
                value *= value;
                value = 1 - value;
                vector.scale(value);
                vector.add(origin);
                context.setViewingPlatformPosition(new Point3d(vector));
                if (context != null) {

                    // check constraints for viewing platform
                    Point3d position = context.getViewingPlatformPosition();
                    if (context.hasViewingPlatformChanged()) {
                        if (processConstraints(position)) {

                            // apply modification
                            context.setViewingPlatformPosition(position);
                        }
                    }
                }
            } else {
                setEnable(false);
                context.setViewingPlatformPosition(new Point3d(destination));
                context.interpolationStopped();
            }
        }
        dumpImage(getContextData());

        // reset wakeup condition
        initialize();
    }

    /**
     * Method description.
     *
     * @param origin Parameter description.
     */
    public void setOrigin(Tuple3f origin) {
        this.origin = origin;
    }

    /**
     * Method description.
     *
     * @param destination Parameter description.
     */
    public void setDestination(Tuple3f destination) {
        this.destination = destination;
    }

    /**
     * Method description.
     */
    public void initialize() {

        // set wakeup condition:
        WakeupOnElapsedFrames criterion = new WakeupOnElapsedFrames(1);
        wakeupOn(criterion);
    }
}
