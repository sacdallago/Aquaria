/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.annotation.visitors;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Vector;

import org.srs3d.viewer.bioatlas.objects.Chain;
import org.srs3d.viewer.bioatlas.objects.ChainFragment;
import org.srs3d.viewer.bioatlas.objects.Residue;

/**
 * This class can be used in two ways. Firstly, it can build a seqeunce for a given
 * chain. Secondly, it provides a tool used in the alignment process.
 *
 * @author Christian Zofka
 * @author Karsten Klein
 *
 * @created July 16, 2001
 */
public class SequenceCreator {
    private Vector sequence = null;

    // residues, that are added to alignedSequence, are reomved from alignmentMap
    private Map alignmentMap = null;

    /**
     * <code>SequenceCreator</code> constructor.
     */
    public SequenceCreator() {
    }

    /**
     * <code>SequenceCreator</code> constructor.
     *
     * @param map Description of parameter.
     */
    public SequenceCreator(Map map) {
        this.alignmentMap = new HashMap(map);
    }

    /**
     * Gets the <code>alignedSequence</code> attribute of the
     * <code>SequenceAlignmentCreator</code> object.
     *
     * @return The <code>alignedSequence</code> value.
     */
    public Vector getSequence() {
        if (sequence == null) {
            sequence = new Vector();
        }
        return sequence;
    }

    /**
     * Gets the <code>alignmentMap</code> attribute of the
     * <code>SequenceAlignmentCreator</code> object.
     *
     * @return The <code>alignmentMap</code> value.
     */
    public Map getAlignmentMap() {
        if (alignmentMap == null) {
            alignmentMap = new HashMap();
        }
        return alignmentMap;
    }

    /**
     * Creates the sequence for the specified chain. A gap of length three is introduced
     * for split chains (more than one chain fragment).
     *
     * @param chain Chain to creates sequence for.
     */
    public void visit(Chain chain) {
        if (!chain.containsLigandResidues()) {
            Residue residue = chain.getInitialResidue();
            Residue limit = chain.getEndResidue();
            if (limit != null) {
                limit = limit.getProceeding();
            }
            sequence = new Vector(chain.getLength());
            while (residue != null && residue != limit) {
                sequence.add(residue);
                residue = residue.getProceeding();
            }
            if (chain.getChainFragments().size() > 1) {
                Iterator iterator = chain.getChainFragments().iterator();
                ChainFragment chainFragment;
                while (iterator.hasNext()) {
                    chainFragment = (ChainFragment) iterator.next();
                    if (iterator.hasNext()) {
                        SequenceAlignmentCreator.insertInSequence(sequence,
                            sequence.indexOf(chainFragment.getEndResidue()) +
                            1, 3);
                    }
                }
            }
        }
    }

    /**
     * adds residue
     *
     * @param residue either residue or null (=gap)
     */
    public void add(Residue residue) {
        getSequence().add(residue);
        if (residue != null) {

            // remove only for performance and debugging reasons
            getAlignmentMap().remove(residue);
        }
    }
}
