/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.accesscontrol;

import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;

/**
 * Description of the class.
 *
 * @author Karsten Klein
 *
 * @created March 4, 2002
 */
public class IPList {
    private HashSet ips = new HashSet();

    /**
     * Sets the <code>iP</code> attribute of the <code>IPList</code> object.
     *
     * @param index The new <code>iP</code> value.
     * @param ip The new <code>iP</code> value.
     */
    public void add(IP ip) {
        ips.add(ip);
    }

    /**
     * Gets the <code>plainIp</code> attribute of the <code>IPList</code> object.
     *
     * @param ip Description of parameter.
     *
     * @return The <code>plainIp</code> value.
     */
    public String getPlainIp(String ip) {
        int index = ip.indexOf("/");
        if (index != -1) {
            ip = ip.substring(index);
        }
        return ip;
    }

    /**
     * Adds a <code>IP</code> object to the <code>IPList</code> object.
     *
     * @param string The <code>IP</code> object to be added.
     */
    public void addIP(String string) {
        add(new IP(string));
    }

    /**
     * Description of the method.
     *
     * @param ip Description of parameter.
     *
     * @return Description of the returned value.
     */
    public boolean contains(String ipString) {
        Iterator iterator = ips.iterator();
        IP ip = new IP(ipString);
        while (iterator.hasNext()) {
            if (((IP) iterator.next()).contains(ip)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public Collection getIPs() {
        return ips;
    }
}
