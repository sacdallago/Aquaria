/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.creators;

import javax.media.j3d.BranchGroup;
import javax.vecmath.Matrix3f;
import javax.vecmath.Point3f;
import javax.vecmath.TexCoord2f;
import javax.vecmath.Vector3f;

import org.srs3d.viewer.bioatlas.objects.AbstractChain;
import org.srs3d.viewer.bioatlas.objects.Helix;
import org.srs3d.viewer.bioatlas.objects.Residue;
import org.srs3d.viewer.bioatlas.visitors.HelixBackbonePathCreator;
import org.srs3d.viewer.bioatlas.visitors.PathCreator;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.vecmath.CubicBezierCurve3f;
import org.srs3d.viewer.vecmath.SweepingSurface;

/**
 * Special geometry creator implementation concentrating on <code>Helix</code> objects.
 *
 * @author Karsten Klein
 *
 * @created March 20, 2001
 */
public class HelixGeometryCreator extends SubchainGeometryCreator {

    /** widht scale factor for the large end of the arrow. */
    public float arrowSizeFactor = 2.0f;

    /**
     * Description of the method.
     *
     * @param object Description of parameter.
     * @param branchGroup Description of parameter.
     */
    public void create(AbstractObject object, BranchGroup branchGroup) {
        createGeometry((Helix) object, branchGroup);
    }

    /**
     * Description of the Method
     *
     * @param chain Description of Parameter
     *
     * @return Description of the Returned Value
     */
    public SweepingSurface createSweepingSurface(AbstractChain chain) {
        Residue start = computeStartResidue(chain);
        Residue end = computeEndResidue(chain);
        int chainLength = chain.getLength();
        int steps = chainLength * (framesPerResidue - 1) + 1;
        int frames = steps + 1;
        SweepingSurface sweepingSurface =
            new SweepingSurface(getSurfaceContour());
        sweepingSurface.setTextured(true);
        float t = 0;
        float deltaT = 1.0f / (steps - 1);
        float scaleFactor = 1.0f / framesPerResidue;
        Point3f point;
        Point3f computed;
        Vector3f vector0 = new Vector3f();
        Vector3f vector1 = new Vector3f();
        Vector3f vector2;
        float width = chainLength;
        float widthPowerOf2 =
            org.srs3d.viewer.vecmath.Constants.computeNextHigherPowerOf2(width);
        float deltaTexture = width / widthPowerOf2 * deltaT;
        TexCoord2f textureCoordinate = new TexCoord2f();
        PathCreator pathCreator = new PathCreator();
        pathCreator.visit(start, end);

        // create interpolation curve and plug in the created path
        CubicBezierCurve3f caCurve = new CubicBezierCurve3f();
        caCurve.setCoordinates(pathCreator.path);
        caCurve.prePoint = pathCreator.prePoint;
        caCurve.postPoint = pathCreator.postPoint;
        HelixBackbonePathCreator backbonePathCreator =
            new HelixBackbonePathCreator();
        backbonePathCreator.visit(start, end);

        // create backbone interpolation curve and plug in the created path
        CubicBezierCurve3f backboneCurve = new CubicBezierCurve3f();
        backboneCurve.setCoordinates(backbonePathCreator.path);

        // compute frames
        Matrix3f rotation = new Matrix3f();
        Vector3f scale = getScale();
        float projection;
        float initialSize = 0.17f;
        if (start.getPreceeding() == null) {
            initialSize = 0;
        }
        float endSize = 0.17f;
        if (end == null || end.getProceeding() == null) {
            endSize = 0;
        }
        int frame = 0;
        for (int i = 0; i < steps; i++) {
            t = i * deltaT;
            point = caCurve.computePoint(t);
            vector2 = caCurve.computeTangent(t);
            vector2.normalize();
            vector0.set(backboneCurve.computeTangent(t));
            vector1.cross(vector2, vector0);
            vector1.normalize();
            vector0.cross(vector2, vector1);
            vector0.normalize();
            rotation.setColumn(0, vector0);
            rotation.setColumn(1, vector1);
            rotation.setColumn(2, vector2);
            scale = getScale();
            if (i < framesPerResidue) {
                scale.x = initialSize + scaleFactor * i;
            }
            if (i == steps - framesPerResidue && i != 0) {
                textureCoordinate.x -= deltaTexture / 8;
                sweepingSurface.addFrame(rotation, point, scale, true,
                    textureCoordinate);
                textureCoordinate.x += deltaTexture / 4;
            }

            // scale arrow
            if (i >= steps - framesPerResidue) {
                scale.x =
                    endSize + arrowSizeFactor * scaleFactor * (steps - i - 1);
            }
            sweepingSurface.addFrame(rotation, point, scale,
                i == 0 || i == steps - 1 || i == steps - framesPerResidue,
                textureCoordinate);
            if (i == steps - framesPerResidue && i != 0) {
                textureCoordinate.x -= deltaTexture / 4;
            }
            textureCoordinate.x += deltaTexture;
        }
        return sweepingSurface;
    }

    /**
     * Description of the Method
     *
     * @param chain Description of Parameter
     * @param branchGroup Description of Parameter
     */
    public void createSubchainGeometry(AbstractChain chain,
        BranchGroup branchGroup) {
        SweepingSurface sweepingSurface = createSweepingSurface(chain);
        createSubchainGeometry(chain, branchGroup, sweepingSurface);

        // release sweeping surface
        sweepingSurface = null;
    }

    /**
     * Description of the Method
     *
     * @param chain Description of Parameter
     * @param branchGroup Description of Parameter
     */
    public void createResidueGeometry(AbstractChain chain,
        BranchGroup branchGroup) {
        SweepingSurface sweepingSurface = createSweepingSurface(chain);
        createResidueGeometry(chain, 0, 1, branchGroup, sweepingSurface);
    }

    /**
     * Description of the method.
     *
     * @param object Description of parameter.
     * @param contextData Description of parameter.
     */
    public void modifyAttributes(ContextData contextData, AbstractObject object) {
        super.modifyAttributes(contextData, object);
        useCircleContour =
            org.srs3d.viewer.bioatlas.Parameter.helixUseCircleContour;
        framesPerResidue =
            org.srs3d.viewer.bioatlas.Parameter.helixFramesPerResidue;
        divisionsPerFrame =
            org.srs3d.viewer.bioatlas.Parameter.helixDivisionsPerFrame;
        setScale(0.17f, 0.17f, 1);
    }
}
