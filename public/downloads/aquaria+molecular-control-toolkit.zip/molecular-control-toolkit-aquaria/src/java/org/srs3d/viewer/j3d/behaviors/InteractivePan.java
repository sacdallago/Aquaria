package org.srs3d.viewer.j3d.behaviors;

public interface InteractivePan {

	/**
	 * When processStilmulus is called by the framework the behavior will adjust scaling
	 * and translation values of the viewplatform tranformation
	 *
	 * @param mouseEvent Description of parameter
	 */
	public abstract void processStimulus(int p_panX, int p_panY);

}