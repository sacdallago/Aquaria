/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.creators;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

import javax.media.j3d.BranchGroup;
import javax.media.j3d.Shape3D;
import javax.vecmath.Matrix3f;
import javax.vecmath.Tuple3f;
import javax.vecmath.Vector3f;

import org.srs3d.viewer.bioatlas.attributes.Representation;
import org.srs3d.viewer.bioatlas.attributes.ResidueRepresentation;
import org.srs3d.viewer.bioatlas.attributes.SubchainRepresentation;
import org.srs3d.viewer.bioatlas.objects.AbstractChain;
import org.srs3d.viewer.bioatlas.objects.ChainFragment;
import org.srs3d.viewer.bioatlas.objects.Residue;
import org.srs3d.viewer.bioatlas.objects.Subchain;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.ShapeManager;
import org.srs3d.viewer.j3d.attributes.Expanded;
import org.srs3d.viewer.j3d.attributes.ExternalGeometry;
import org.srs3d.viewer.j3d.commands.RegisterCommand;
import org.srs3d.viewer.j3d.creators.AbstractGeometryCreator;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.objects.Attribute;
import org.srs3d.viewer.objects.ObjectManager;
import org.srs3d.viewer.objects.State;
import org.srs3d.viewer.vecmath.Contour;
import org.srs3d.viewer.vecmath.SweepingSurface;

/**
 * Abstract <code>GeometryCreator</code> implementation concentrating on specializations
 * of <code>Subchain</code> implementations.
 *
 * @author Karsten Klein
 *
 * @created March 20, 2001
 */
public abstract class SubchainGeometryCreator extends AbstractGeometryCreator {

    /** Description of the field. */
    public static final int SUBCHAIN = 1;

    /** Description of the field. */
    public static final int RESIDUE = 2;

    /** Description of the field. */
    public static final int WIREFRAME = 4;

    /** Description of the field. */
    public static final int COIL = 8;

    /** Description of the field. */
    public static final int CATRACE = 16;

    /** Description of the field. */
    public static final int SOAPFILM = 32;

    /** Description of the field. */
    public static final int BALL_AND_STICK = 64;

    /** Description of the field. */
    public static final int VAN_DER_WAALS = 128;

    /** Description of the field. */
    public int subchainMode = SUBCHAIN;

    /** Description of the field. */
    public int framesPerResidue = 7;

    /** Description of the field. */
    public int divisionsPerFrame = 5;

    /** flag indicating the use of a round contour, rather than a rectagular */
    public boolean useCircleContour = true;
    private Vector3f scale = new Vector3f(0.17f, 0.17f, 1);
    private boolean isShapeLocking = false;
    private boolean isUpdateCoil = false;

    /**
     * Sets the <code>mode</code> attribute of the <code>SubchainGeometryCreator</code>
     * object.
     *
     * @param mode The new <code>mode</code> value.
     */
    public void setMode(int mode) {
        this.subchainMode = mode;
    }

    /**
     * Sets the <code>shapeLocking</code> attribute of the
     * <code>SubchainGeometryCreator</code> object.
     *
     * @param isShapeLocking The new <code>shapeLocking</code> value.
     */
    public void setShapeLocking(boolean isShapeLocking) {
        this.isShapeLocking = isShapeLocking;
    }

    /**
     * Sets the <code>frame</code> attribute of the <code>SubchainGeometryCreator</code>
     * object.
     *
     * @param residue The new <code>frame</code> value.
     * @param rotation The new <code>frame</code> value.
     */
    public void setFrame(Residue residue, Matrix3f rotation) {
        getFrameMap().put(residue, rotation);
    }

    /**
     * Gets the <code>frame</code> attribute of the <code>SubchainGeometryCreator</code>
     * object.
     *
     * @param residue Description of parameter.
     *
     * @return The <code>frame</code> value.
     */
    public Matrix3f getFrame(Residue residue) {
        return (Matrix3f) getFrameMap().get(residue);
    }

    /**
     * Description of the Method
     *
     * @param subchain Description of Parameter
     * @param branchGroup Description of Parameter
     */
    public void createGeometry(Subchain subchain, BranchGroup branchGroup) {
        Collection chainFragments = new HashSet();
        getContextData().getObjectManager().getDirectUpAssociations(subchain,
            chainFragments);
        ChainFragment chainFragment;
        if ((subchainMode & COIL) != 0) {
            CoilGeometryCreator coilGeometryCreator = new CoilGeometryCreator();
            coilGeometryCreator.modifyAttributes(getContextData(), subchain);
            coilGeometryCreator.subchainMode = subchainMode;
            coilGeometryCreator.setUpdateCoil(true);
            if ((coilGeometryCreator.subchainMode & COIL) != 0) {
                coilGeometryCreator.subchainMode -= COIL;
            }
            coilGeometryCreator.createGeometry(subchain, branchGroup);
        } else {
            if ((subchainMode & SUBCHAIN) != 0) {
                createSubchainGeometry(subchain, branchGroup);
            }
            if ((subchainMode & RESIDUE) != 0) {
                createResidueGeometry(subchain, branchGroup);
            }
        }
        if ((subchainMode & WIREFRAME) != 0) {
            createWireframeGeometry(subchain, branchGroup);
        }
        if ((subchainMode & CATRACE) != 0) {
            createCATraceGeometry(subchain, branchGroup);
        }
        if ((subchainMode & SOAPFILM) != 0) {
            createSoapFilmGeometry(subchain, branchGroup);
        }

        //    if ( ( subchainMode & BALL_AND_STICK ) != 0 ) {
        //
        //      createBallAndStickGeometry( subchain, branchGroup );
        //
        //    }
        //    if ( ( subchainMode & VAN_DER_WAALS ) != 0 ) {
        //
        //      createVanDerWaalsGeometry( subchain, branchGroup );
        //
        //    }
    }

    /**
     * Description of the Method
     *
     * @param chain Description of Parameter
     * @param branchGroup Description of Parameter
     */
    public abstract void createSubchainGeometry(AbstractChain chain,
        BranchGroup branchGroup);

    /**
     * Description of the Method
     *
     * @param chain Description of Parameter
     * @param branchGroup Description of parameter.
     */
    public abstract void createResidueGeometry(AbstractChain chain,
        BranchGroup branchGroup);

    /**
     * Description of the method.
     *
     * @param chain Description of parameter.
     * @param branchGroup Description of parameter.
     */
    public void createWireframeGeometry(AbstractChain chain,
        BranchGroup branchGroup) {
        Residue residue = chain.getInitialResidue();
        Residue limit = chain.getEndResidue().getProceeding();
        Collection bonds = new HashSet();
        Collection residueBonds;

        // collect all the bonds
        while (residue != null && residue != limit) {
            residueBonds = residue.getBonds();
            if (residueBonds.isEmpty()) {
                residueBonds.addAll(residue.computeBonds());
            }
            bonds.addAll(residueBonds);
            residue = residue.getProceeding();
        }
        if (!bonds.isEmpty()) {
            RegisterCommand registerCommand =
                new RegisterCommand(getContextData(), true);
            getContextData().getStrategyManager().propagate(chain,
                registerCommand, null);
            residue = chain.getInitialResidue();
            Shape3D shape =
                BondGeometryCreator.createLines(getContextData(), bonds, chain);

            // :TRICK: normally the geometry (wireframe on suchain level) was registered
            // to the subchain (abstract chain here) itself. Since we use texture
            // coloring the vertex coloring cannot be enabled anymore (or we'd have
            // to save the atom colors in the texture as well, which means a lot of
            // time consuming orderings and additional code).
            // The texture based color is not used on the residue level. The trick
            // here is to attach the subchain catrace geometry not to the chain, but
            // to the first residue in the chain.
            // Once the chain is expanded this geometry is not used anymore.
            // Note that this applies to the alternative geometry to.
            //      getContextData().getShapeManager().register( chain, shape );
            ShapeManager.setCapabilities(shape, chain);
            getContextData().getShapeManager().register(residue, shape);
            getContextData().getShapeManager().setShapeLock(shape,
                isShapeLocking);
            branchGroup.addChild(shape);

            // create atom dots
            shape =
                new Shape3D(AtomGeometryCreator.createPoints(getContextData(),
                        chain));
            ShapeManager.setCapabilities(shape, chain);
            getContextData().getShapeManager().register(residue, shape);
            getContextData().getShapeManager().setShapeLock(shape,
                isShapeLocking);
            branchGroup.addChild(shape);
        }
    }

    /**
     * Description of the method.
     *
     * @param chain Description of parameter.
     * @param branchGroup Description of parameter.
     */
    public void createBallAndStickGeometry(AbstractChain chain,
        BranchGroup branchGroup) {
        Residue residue = chain.getInitialResidue();
        Residue limit = chain.getEndResidue().getProceeding();
        Shape3D compositionShape = new Shape3D();
        Shape3D shape;
        while (residue != null && residue != limit) {
            shape =
                ResidueGeometryCreator.createBallAndStickShape(getContextData(),
                    residue);
            if (shape != null) {
                org.srs3d.viewer.j3d.geometry.GeometryHelper.copyGeometry(shape,
                    compositionShape);
            }
            residue = residue.getProceeding();
        }
        ShapeManager.setCapabilities(compositionShape, chain);
        getContextData().getShapeManager().register(chain, compositionShape);
        getContextData().getShapeManager().setShapeLock(compositionShape,
            isShapeLocking);
        branchGroup.addChild(compositionShape);
    }

    /**
     * Description of the method.
     *
     * @param chain Description of parameter.
     * @param branchGroup Description of parameter.
     */
    public void createVanDerWaalsGeometry(AbstractChain chain,
        BranchGroup branchGroup) {
        Residue residue = chain.getInitialResidue();
        Residue limit = chain.getEndResidue().getProceeding();
        Shape3D compositionShape = new Shape3D();
        Shape3D shape;
        while (residue != null && residue != limit) {
            shape =
                ResidueGeometryCreator.createVanDerWaalsShape(getContextData(),
                    residue);
            if (shape != null) {
                org.srs3d.viewer.j3d.geometry.GeometryHelper.copyGeometry(shape,
                    compositionShape);
            }
            residue = residue.getProceeding();
        }
        ShapeManager.setCapabilities(compositionShape, chain);
        getContextData().getShapeManager().register(chain, compositionShape);
        getContextData().getShapeManager().setShapeLock(compositionShape,
            isShapeLocking);
        branchGroup.addChild(compositionShape);
    }

    /**
     * Description of the method.
     *
     * @param chain Description of parameter.
     * @param branchGroup Description of parameter.
     */
    public void createCATraceGeometry(AbstractChain chain,
        BranchGroup branchGroup) {
        if (chain.getInitialResidue() != null) {
            Shape3D shape =
                ResidueGeometryCreator.createCATraceGeometry(chain,
                    chain.getInitialResidue(), chain.getEndResidue());
            ShapeManager.setCapabilities(shape, chain);
            getContextData().getShapeManager().register(chain, shape);
            getContextData().getShapeManager().setShapeLock(shape,
                isShapeLocking);
            branchGroup.addChild(shape);
        }
    }

    /**
     * Description of the method.
     *
     * @param chain Description of parameter.
     * @param branchGroup Description of parameter.
     */
    public void createSoapFilmGeometry(AbstractChain chain,
        BranchGroup branchGroup) {
        if (chain.getInitialResidue() != null) {
            Shape3D shape =
                ResidueGeometryCreator.createSoapFilmShape(getContextData(),
                    chain);
            if (shape != null) {
                ShapeManager.setCapabilities(shape, chain);
                getContextData().getShapeManager().register(chain, shape);
                getContextData().getShapeManager().setShapeLock(shape,
                    isShapeLocking);
                branchGroup.addChild(shape);
            }
        }
    }

    /**
     * Description of the Method
     *
     * @param sweepingSurface Description of Parameter
     *
     * @return Description of the Returned Value
     */
    public Shape3D createSubchainGeometry(SweepingSurface sweepingSurface) {
        int frameCount = sweepingSurface.getFrameCount();
        return sweepingSurface.getFullGeometry(0, frameCount - 1);
    }

    /**
     * Updates the geometry for the specified residue.
     *
     * @param residue Residue to be updated.
     * @param shape Shape3D instance for the residue.
     */
    public void updateResidueGeometryAttribute(Residue residue, Shape3D shape) {
        State state = getContextData().getStateManager().getState(residue);
        Representation representation =
            (Representation) state.getAttribute(ResidueRepresentation.class);
        boolean isUpdate = false;
        if ((representation.getMode() & Representation.REPRESENTATION_COIL) == 0) {
            isUpdate = (subchainMode & COIL) == 0;
        } else {
            isUpdate = isUpdateCoil;
        }
        if (isUpdate) {
            ExternalGeometry externalGeometry =
                (ExternalGeometry) Attribute.getInstance(ExternalGeometry.class);
            externalGeometry.setShape(shape);
            state.setAttribute(externalGeometry);
            getContextData().getStateManager().register(residue, state);
        }
    }

    /**
     * Description of the method.
     *
     * @param chain Description of parameter.
     *
     * @return Description of the returned value.
     */
    public Residue computeStartResidue(AbstractChain chain) {
        if (chain.getLength() == 1) {
            Residue initialResidue = chain.getInitialResidue();
            Residue preceeding = initialResidue.getPreceeding();
            if (preceeding != null) {
                if (org.srs3d.viewer.bioatlas.visitors.ChainAnalyser.isConnected(
                          preceeding, initialResidue)) {
                    Residue proceeding = initialResidue.getProceeding();
                    if (proceeding != null) {
                        if (!org.srs3d.viewer.bioatlas.visitors.ChainAnalyser.isConnected(
                                  initialResidue, proceeding)) {
                            return preceeding;
                        }
                    } else {

                        // check with 2dnj
                        return preceeding;
                    }
                }
            }
            return initialResidue;
        } else {
            return chain.getInitialResidue();
        }
    }

    /**
     * Description of the method.
     *
     * @param chain Description of parameter.
     *
     * @return Description of the returned value.
     */
    public Residue computeEndResidue(AbstractChain chain) {
        Residue end = chain.getEndResidue();
        if (end.getProceeding() != null) {
            if (org.srs3d.viewer.bioatlas.visitors.ChainAnalyser.isConnected(
                      end, end.getProceeding())) {
                Residue proceeding = end.getProceeding().getProceeding();
                if (proceeding != null) {
                    if (!org.srs3d.viewer.bioatlas.visitors.ChainAnalyser.isConnected(
                              end.getProceeding(), proceeding)) {
                        return end;
                    }
                } else {
                    return end;
                }
                end = end.getProceeding();
            }
        }
        return end;
    }

    /**
     * Description of the method.
     *
     * @param object Description of parameter.
     * @param contextData Description of parameter.
     */
    public void modifyAttributes(ContextData contextData, AbstractObject object) {
        super.modifyAttributes(contextData, object);
        int representationMode = 0;
        subchainMode = 0;
        State.Immutable state =
            getContextData().getStateManager().getImmutableState(object);
        boolean isExpanded = state.hasAttribute(Expanded.class);
        SubchainRepresentation.Immutable subchainRepresentation =
            (SubchainRepresentation.Immutable) state.getAttribute(SubchainRepresentation.class);
        if (subchainRepresentation != null) {
            representationMode = subchainRepresentation.getMode();
            if (representationMode != 0) {
                if ((representationMode & Representation.REPRESENTATION_RIBBON) != 0 ||
                      (representationMode & Representation.REPRESENTATION_COIL) != 0) {
                    if (isExpanded) {
                        subchainMode |= RESIDUE;
                    } else {
                        subchainMode |= SUBCHAIN;
                    }
                    Subchain subchain = (Subchain) object;
                    if (subchain.getLength() < 3) {
                        subchainMode |= COIL;
                    }
                }
            }
            if ((representationMode & Representation.REPRESENTATION_COIL) != 0) {
                subchainMode |= COIL;
            }
            if (!isExpanded) {
                if ((representationMode &
                      Representation.REPRESENTATION_WIREFRAME) != 0) {
                    subchainMode |= WIREFRAME;
                }
                if ((representationMode &
                      Representation.REPRESENTATION_CATRACE) != 0) {
                    subchainMode |= CATRACE;
                }
                if ((representationMode &
                      Representation.REPRESENTATION_SOAPFILM) != 0) {
                    subchainMode |= SOAPFILM;
                }
                if ((representationMode &
                      Representation.REPRESENTATION_VAN_DER_WAALS) != 0) {
                    subchainMode |= VAN_DER_WAALS;
                }
                if ((representationMode &
                      Representation.REPRESENTATION_BALL_AND_STICK) != 0) {
                    subchainMode |= BALL_AND_STICK;
                }
            }
        }

        // no representation for sinple peptide chains
        if (isSinglePeptideChain(contextData, (Subchain) object)) {
            subchainMode = 0;
        }
    }

    /**
     * Sets the <code>scale</code> attribute of the <code>SubchainGeometryCreator</code>
     * object.
     *
     * @param scale The new <code>scale</code> value.
     */
    protected void setScale(Tuple3f scale) {
        this.scale.set(scale);
    }

    /**
     * Sets the <code>scale</code> attribute of the <code>SubchainGeometryCreator</code>
     * object.
     *
     * @param x The new <code>scale</code> value.
     * @param y The new <code>scale</code> value.
     * @param z The new <code>scale</code> value.
     */
    protected void setScale(float x, float y, float z) {
        this.scale.set(x, y, z);
    }

    /**
     * Gets the <code>surfaceContour</code> attribute of the
     * <code>SubchainGeometryCreator</code> object.
     *
     * @return The <code>surfaceContour</code> value.
     */
    protected Contour getSurfaceContour() {
        if (useCircleContour) {
            return Contour.getCircleContour(divisionsPerFrame,
                (float) Math.PI / 4);
        } else {
            return Contour.getRectangleContour();
        }
    }

    /**
     * Gets the Scale attribute of the SubchainGeometryCreator object
     *
     * @return The Scale value
     */
    protected Vector3f getScale() {
        return scale;
    }

    /**
     * Description of the Method
     *
     * @param chain Description of Parameter
     * @param addFramesInitial Description of Parameter
     * @param addFramesEnd Description of Parameter
     * @param sweepingSurface Description of Parameter
     * @param branchGroup Description of parameter.
     */
    protected void createResidueGeometry(AbstractChain chain,
        int addFramesInitial, int addFramesEnd, BranchGroup branchGroup,
        SweepingSurface sweepingSurface) {
        sweepingSurface.setTextured(false);
        int frameCount = sweepingSurface.getFrameCount();
        Residue residue = chain.getInitialResidue();
        Residue limit = chain.getEndResidue().getProceeding();
        int index = 0;
        int frameIndex;
        int offset;
        while (residue != limit) {
            frameIndex = index * (framesPerResidue - 1);
            offset = frameIndex + framesPerResidue - 1;
            if (frameIndex == 0) {
                offset += addFramesInitial;
            } else {
                frameIndex += addFramesInitial;
                offset += addFramesInitial;
            }
            if (frameIndex >= frameCount - framesPerResidue - 1) {
                offset += addFramesEnd;
                frameIndex += addFramesEnd;
            }

            // update state of the residue with new geometry
            updateResidueGeometryAttribute(residue,
                sweepingSurface.getFullGeometry((int) frameIndex, (int) offset));
            residue = residue.getProceeding();
            index++;
        }
    }

    /**
     * Description of the Method
     *
     * @param chain Description of Parameter
     * @param branchGroup Description of Parameter
     * @param sweepingSurface Description of Parameter
     */
    protected void createSubchainGeometry(AbstractChain chain,
        BranchGroup branchGroup, SweepingSurface sweepingSurface) {
        Shape3D shape = createSubchainGeometry(sweepingSurface);
        ShapeManager.setCapabilities(shape, chain);
        getContextData().getShapeManager().register(chain, shape);
        getContextData().getShapeManager().setShapeLock(shape, isShapeLocking);
        branchGroup.addChild(shape);
    }

    /**
     * Gets the <code>frameMap</code> attribute of the
     * <code>SubchainGeometryCreator</code> object.
     *
     * @return The <code>frameMap</code> value.
     */
    private Map getFrameMap() {
        Map frameMap = (Map) getContextData().getProperty("FRAMEMAP");
        if (frameMap == null) {
            frameMap = new HashMap();
            getContextData().setProperty("FRAMEMAP", frameMap);
        }
        return frameMap;
    }

    /**
     * Gets the <code>singlePeptideChain</code> attribute of the
     * <code>SubchainGeometryCreator</code> class.
     *
     * @param contextData Description of parameter.
     * @param subchain Description of parameter.
     *
     * @return The <code>singlePeptideChain</code> value.
     */
    public static boolean isSinglePeptideChain(ContextData contextData,
        Subchain subchain) {
        Collection chainFragments = new HashSet();
        contextData.getObjectManager().getDirectUpAssociations(subchain,
            chainFragments);
        ObjectManager.extract(chainFragments, ChainFragment.class);
        ChainFragment chainFragment = null;
        if (!chainFragments.isEmpty()) {
            chainFragment = (ChainFragment) chainFragments.iterator().next();
        }
        boolean isSinglePeptideChain = false;
        if (chainFragment != null) {
            if (chainFragment.getLength() == 1) {
                isSinglePeptideChain = true;
            }
        }
        return isSinglePeptideChain;
    }

    /**
     * Method description.
     *
     * @param isUpdateCoil Parameter description.
     */
    public void setUpdateCoil(boolean isUpdateCoil) {
        this.isUpdateCoil = isUpdateCoil;
    }
}
