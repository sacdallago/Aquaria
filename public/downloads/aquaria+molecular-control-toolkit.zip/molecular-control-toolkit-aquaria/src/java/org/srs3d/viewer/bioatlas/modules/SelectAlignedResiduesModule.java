/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.modules;

import java.awt.event.ActionEvent;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;

import org.srs3d.viewer.annotation.objects.AnnotationContainer;
import org.srs3d.viewer.bioatlas.objects.Residue;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.Selection;
import org.srs3d.viewer.objects.ObjectManager;
import org.srs3d.viewer.objects.Operation;
import org.srs3d.viewer.util.SetUtility;

/**
 * Description of the class.
 *
 * @author Karsten Klein
 *
 * @created April 29, 2002
 */
public class SelectAlignedResiduesModule extends ProcessModule {
    private Collection residues = null;

    /**
     * <code>SelectAlignedResiduesModule</code> constructor.
     *
     * @param name Description of parameter.
     * @param contextData Description of parameter.
     */
    public SelectAlignedResiduesModule(String name, ContextData contextData) {
        super(name, contextData, true, true);
    }

    /**
     * Gets the <code>moduleIdPrefix</code> attribute of the
     * <code>SelectAlignedResiduesModule</code> object.
     *
     * @return The <code>moduleIdPrefix</code> value.
     */
    public String getModuleIdPrefix() {
        return "SELECT-";
    }

    /**
     * Description of the method.
     *
     * @param e Description of parameter.
     */
    public void process(ActionEvent e) {
        final ContextData contextData = getContextData();
        AnnotationContainer annotationContainer =
            (AnnotationContainer) org.srs3d.viewer.annotation.colorschemes.HomologyColorScheme.getAnnotation(getContextData());
        Selection selection = contextData.getSelectionManager().getSelection();
        Collection allAlignedResidues = new HashSet();
        Collection residues = new HashSet(selection);
        if (!selection.isEmpty()) {
            contextData.getObjectManager().getAssociations(selection, residues);
            ObjectManager.extract(residues, Residue.class);
            if (annotationContainer != null) {
                Iterator iterator = residues.iterator();
                Collection alignedResidues;
                while (iterator.hasNext()) {
                    alignedResidues =
                        annotationContainer.mapResidues((Residue) iterator.next());
                    if (alignedResidues != null) {
                        allAlignedResidues.addAll(alignedResidues);
                    }
                }
            }
            allAlignedResidues.addAll(residues);
            allAlignedResidues.addAll(selection);
        } else {

            // collect all aligned residues
            Iterator iterator =
                annotationContainer.getAlignmentMap().values().iterator();
            while (iterator.hasNext()) {
                allAlignedResidues.addAll((Collection) iterator.next());
            }
        }
        residues.clear();
        contextData.getObjectManager().collapseUpExtended(allAlignedResidues,
            residues);
        Operation operation =
            new Operation(contextData.getContext(), "TRANSFER_SELECTION", null);
        operation.setObjects(residues);
        operation.setSerializable(false);
        contextData.getDispatcher().runDispatch(operation);
    }

    /**
     * Description of the method.
     */
    public void updateIntern() {
        computeResidues();
        if (getComponent() != null) {
            AnnotationContainer annotationContainer =
                (AnnotationContainer) org.srs3d.viewer.annotation.colorschemes.HomologyColorScheme.getAnnotation(getContextData());
            if (annotationContainer != null) {
                if (!annotationContainer.getAlignmentMap().keySet().isEmpty()) {
                    getComponent().setEnabled(SetUtility.hasIntersection(
                            annotationContainer.getAlignmentMap().keySet(),
                            residues));
                }
            }
        }
    }

    /**
     * Description of the method.
     */
    public void computeResidues() {
        Selection selection =
            getContextData().getSelectionManager().getSelection();
        residues = new HashSet(selection);
        if (!selection.isEmpty()) {
            getContextData().getObjectManager().getAssociations(selection,
                residues);
            ObjectManager.extract(residues, Residue.class);
        } else {
            AnnotationContainer annotationContainer =
                (AnnotationContainer) org.srs3d.viewer.annotation.colorschemes.HomologyColorScheme.getAnnotation(getContextData());
            residues.addAll(annotationContainer.getAlignmentMap().keySet());
        }
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public boolean checkVisible() {
        AnnotationContainer annotationContainer =
            (AnnotationContainer) org.srs3d.viewer.annotation.colorschemes.HomologyColorScheme.getAnnotation(getContextData());
        if (annotationContainer != null) {
            if (!annotationContainer.getAlignmentMap().keySet().isEmpty()) {
                if (super.checkVisible()) {
                    return true;
                }
            }
        }
        return false;
    }
}
