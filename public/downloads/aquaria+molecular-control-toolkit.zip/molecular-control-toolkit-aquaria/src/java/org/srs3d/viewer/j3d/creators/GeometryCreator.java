/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.creators;

import javax.media.j3d.BranchGroup;

import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.Contextual;
import org.srs3d.viewer.objects.AbstractObject;

/**
 * Unified interface for all <code>GeometryCreator</code> implementations.
 *
 * @author Karsten Klein
 *
 * @created March 20, 2001
 */
public interface GeometryCreator extends Contextual {

    /**
     * Creates the description (subscenegraph) of an <code>AbstractObject</code>.
     *
     * @param object Object to display.
     * @param branchGroup Root for the created subscenegraph.
     */
    public void create(AbstractObject object, BranchGroup branchGroup);

    /**
     * Description of the method.
     *
     * @param object Description of parameter.
     */
    public void modifyAttributes(ContextData contextData, AbstractObject object);
}
