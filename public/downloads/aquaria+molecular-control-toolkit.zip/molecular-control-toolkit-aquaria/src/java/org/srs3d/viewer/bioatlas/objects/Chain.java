/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.objects;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;

import org.srs3d.viewer.bioatlas.visitors.BondCreator;
import org.srs3d.viewer.bioatlas.visitors.DbRefAnalyser;
import org.srs3d.viewer.j3d.objects.Link;
import org.srs3d.viewer.util.SetUtility;

/**
 * Special <code>AbstractObject</code> implementation defining a <code>Chain </code> of
 * <code>Residue</code> s. The implementation contains only the intrinsic data of the
 * object.
 *
 * @author Karsten Klein
 *
 * @created March 22, 2001
 */
public final class Chain extends AbstractChain
    implements org.srs3d.viewer.j3d.Linkable {

    /** Description of the field. */
    public static final char INVALID_ID = 0;
    private char id = INVALID_ID;
    private Compound compound = null;
    private ArrayList dbRefs = new ArrayList();
    private ArrayList chainFragments = new ArrayList();
    private ArrayList subchains = new ArrayList();

    /**
     * Sets the <code>Id</code> attribute of the <code>Chain</code> object.
     *
     * @param id The new <code>Id</code> value.
     */
    public void setId(char id) {
        this.id = id;
    }

    /**
     * Gets the <code>Id</code> attribute of the <code>Chain</code> object.
     *
     * @return The <code>Id</code> value.
     */
    public char getId() {
        return id;
    }

    /**
     * Gets the <code>Subchains</code> attribute of the <code>Chain</code> object.
     *
     * @return The <code>Subchains</code> value.
     */
    public ArrayList getSubchains() {
        ArrayList ArrayList = new ArrayList();
        if (chainFragments.isEmpty()) {
            ArrayList.addAll(subchains);
        } else {
            Collection fragmentSubchains;
            for (int i = 0; i < chainFragments.size(); i++) {
                fragmentSubchains =
                    ((ChainFragment) chainFragments.get(i)).getSubchains();
                if (fragmentSubchains != null) {
                    ArrayList.addAll(fragmentSubchains);
                }
            }
        }
        return ArrayList;
    }

    /**
     * Gets the <code>dbRefs</code> attribute of the <code>Chain</code> object.
     *
     * @return The <code>dbRefs</code> value.
     */
    public ArrayList getDbRefs() {
        return dbRefs;
    }

    /**
     * Gets the <code>AllObjects</code> attribute of the <code>Chain</code> object.
     *
     * @param collection Description of parameter.
     */
    public void getAllObjects(Collection collection) {
        if (chainFragments.isEmpty()) {
            collection.addAll(getSubchains());
        } else {
            collection.addAll(chainFragments);
        }
    }

    /**
     * Adds a feature to the <code>Subchain</code> attribute of the <code>Chain
     * </code>object.
     *
     * @param subchain The feature to be added to the <code>Subchain</code> attribute.
     */
    public void addSubchain(Subchain subchain) {
        subchains.add(subchain);
    }

    /**
     * Method description.
     *
     * @param subchains Parameter description.
     */
    public void addSubchains(Collection subchains) {
        this.subchains.addAll(subchains);
    }

    /**
     * Method description.
     *
     * @param subchain Parameter description.
     */
    public void removeSubchain(Subchain subchain) {
        subchains.remove(subchain);
    }

    /**
     * Adds a <code>DbRef</code> object to the <code>Chain</code> object.
     *
     * @param dbRef The <code>DbRef</code> object to be added.
     */
    public void addDbRef(DbRef dbRef) {
        dbRefs.add(dbRef);
    }

    /**
     * Description of the method.
     *
     * @return Description of the returned value.
     */
    public String toString() {
        String string = new String("Chain");
        if (id != INVALID_ID && id != ' ') {
            string += id;
        }
        if (getInitialResidue() != null) {
            if (isLigand()) {
                string = getInitialResidue().getTemplate().getName();
            }
        }
        if (compound != null) {
            string += "(" + compound.getMolecule() + ")";
        }

        // debug output
        //    string += getExceptionalResidues();
        //    string += " " + isLigand();
        return string;
    }

    /**
     * Updates the none transient data of the chain.
     */
    public void update() {
        super.update();

        // remove exceptional residues, that are not part of the chain.
        // add exceptional residues (like ACE at the start of the chain)
        updateExceptionalResidues();
        DbRefAnalyser dbRefAnalyser = new DbRefAnalyser();
        dbRefAnalyser.visit(this);
        if (chainFragments.isEmpty()) {
            ChainFragment chainFragment = new ChainFragment();
            chainFragment.setSerial(1);
            chainFragment.setInitialResidue(getInitialResidue());
            chainFragment.setEndResidue(getEndResidue());
            chainFragment.setId(id);
            chainFragment.getSubchains().addAll(subchains);
            chainFragments.add(chainFragment);
            chainFragment.setExceptionalResidues(getExceptionalResidues());
        }
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public ArrayList getChainFragments() {
        return chainFragments;
    }

    /**
     * Method description.
     */
    public void updateExceptionalResidues() {
        HashSet exceptionalResidues = new HashSet();
        Residue residue = getInitialResidue();
        Residue limit = getEndResidue();

        // ACE residues at the start are automatically classified as exceptional
        if (residue.getTemplate().getName().equals("ACE")) {
            getExceptionalResidues().add(residue);
        }
        if (limit != null) {
            limit = limit.getProceeding();
        }
        while (residue != null && residue != limit) {
            if (getExceptionalResidues().contains(residue)) {
                exceptionalResidues.add(residue);
            }
            residue = residue.getProceeding();
        }
        SetUtility.intersect(getExceptionalResidues(), exceptionalResidues);
    }

    /**
     * Description of the method.
     */
    public void cleanup() {
        super.cleanup();
        cleanup(dbRefs);
        dbRefs = null;
        cleanup(subchains);
        subchains = null;
        cleanup(chainFragments);
        chainFragments = null;
        compound = null;
    }

    /**
     * Method description.
     *
     * @param compound Parameter description.
     */
    public void setCompound(Compound compound) {
        this.compound = compound;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public Compound getCompound() {
        return compound;
    }

    /**
     * Method description.
     *
     * @param link Parameter description.
     */
    public void setLink(Link link) {
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public Link getLink() {
        Link link = new Link();
        Iterator iterator = dbRefs.iterator();
        DbRef dbRef;
        while (iterator.hasNext()) {
            dbRef = (DbRef) iterator.next();
            link.addLink(dbRef.getDbId(), dbRef.getDbAccession());
        }
        return link;
    }

    /**
     * Method description.
     */
    public void updateBonds() {
        boolean needsComputation = false;
        if (isLigand()) {
            if (!isWater()) {
                Residue residue = getInitialResidue();
                Residue limit = getEndResidue().getProceeding();
                while (!needsComputation && residue != null &&
                      residue != limit) {
                    if (residue.getBonds().isEmpty()) {
                        needsComputation = true;
                    }
                    residue = residue.getProceeding();
                }
            }
        } else {
            needsComputation = needsBondComputation();
        }
        if (needsComputation) {
            Collection bonds = computeBonds();
            Residue residue = getInitialResidue();
            Residue limit = getEndResidue().getProceeding();
            while (!bonds.isEmpty() && residue != null && residue != limit) {
                if (residue.getBonds().isEmpty()) {
                    residue.addBonds(bonds);
                }
                residue = residue.getProceeding();
            }
        }
    }

    // determines whether there is a residue with unsufficient atoms for
    // generating bonds with the normal backbone mode; true if a chain wide
    // bond generation is needed; only valid for non-ligands
    public boolean needsBondComputation() {
        Iterator iterator = getExceptionalResidues().iterator();
        Residue residue;
        boolean isNucleic = isNucleic();
        while (iterator.hasNext()) {
            residue = (Residue) iterator.next();
            if (isNucleic) {
                if (residue.refO3 == null || residue.refP == null) {
                    return true;
                }
            } else {
                if (residue.refN == null || residue.refC == null) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public Collection computeBonds() {
        BondCreator bondCreator = new BondCreator();
        bondCreator.mode = BondCreator.ALL;
        bondCreator.visit(this);
        return bondCreator.bonds;
    }
}
