package org.srs3d.viewer.j3d.behaviors;

public interface InteractiveZoom {

	/**
	 * Initializes the wakeup conditions for the behavior.
	 */
	public abstract void initialize();

	/**
	 * Processes the mouseEvent. This will directly result in a modification of
	 * the viewingPlatform in the activated <code>Context</code> , if the
	 * according conditions are met by the mouse event.
	 * 
	 * @param mouseEvent
	 *            Description of parameter.
	 */
	public abstract void processStimulus(int p_zoom);

}