/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.objects;

import java.util.Collection;
import java.util.HashSet;

import org.srs3d.viewer.objects.AbstractObject;

/**
 * @author Karsten Klein
 *
 * @created October 2, 2001
 */
public class Compound extends AbstractObject {
    public static final int INVALID_ID = -1;
    private String molecule = null;
    private String fragment = null;
    private String details = null;
    private int id = INVALID_ID;
    HashSet chainIds = new HashSet();
    boolean isComplete = false;

    /**
     * Sets the <code>name</code> attribute of the <code>Compound</code> object.
     *
     * @param name The new <code>name</code> value.
     */
    public void setMolecule(String molecule) {
        this.molecule = molecule;
    }

    /**
     * Method description.
     *
     * @param fragment Parameter description.
     */
    public void setFragment(String fragment) {
        this.fragment = fragment;
    }

    /**
     * Method description.
     *
     * @param details Parameter description.
     */
    public void setDetails(String details) {
        this.details = details;
    }

    /**
     * Gets the <code>name</code> attribute of the <code>Compound</code> object.
     *
     * @return The <code>name</code> value.
     */
    public String getMolecule() {
        return molecule;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public String getFragment() {
        return fragment;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public String getDetails() {
        return details;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public Collection getChainIds() {
        return chainIds;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public boolean isComplete() {
        return isComplete;
    }

    /**
     * Method description.
     *
     * @param isComplete Parameter description.
     */
    public void setComplete(boolean isComplete) {
        this.isComplete = isComplete;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public int getId() {
        return id;
    }

    /**
     * Method description.
     *
     * @param id Parameter description.
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public String toString() {
        return "Compound: " + getMolecule() + "; " + getFragment();
    }

    /**
     * Method description.
     */
    public void cleanup() {
        super.cleanup();
        cleanup(chainIds);
        chainIds = null;
    }
}
