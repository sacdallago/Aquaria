/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.annotation.creators;

import javax.media.j3d.Appearance;
import javax.media.j3d.BranchGroup;
import javax.media.j3d.PolygonAttributes;
import javax.media.j3d.Shape3D;
import javax.vecmath.Point3f;
import javax.vecmath.Tuple3f;
import javax.vecmath.Vector3f;

import org.srs3d.viewer.annotation.attributes.LayoutPosition;
import org.srs3d.viewer.j3d.AppearanceHelper;
import org.srs3d.viewer.j3d.ShapeManager;
import org.srs3d.viewer.j3d.creators.AbstractGeometryCreator;
import org.srs3d.viewer.j3d.geometry.primitive.Quad;
import org.srs3d.viewer.j3d.objects.Sensor;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.objects.State;

/**
 * Description of the class.
 *
 * @author Christian Zofka
 *
 * @created September 19, 2001
 */
public class SensorGeometryCreator extends AbstractGeometryCreator {

    /**
     * Description of the method.
     *
     * @param object Description of parameter.
     * @param branchGroup Description of parameter.
     */
    public void create(AbstractObject object, BranchGroup branchGroup) {
        create((Sensor) object, branchGroup);
    }

    /**
     * Description of the method.
     *
     * @param sensor Description of parameter.
     * @param branchGroup Description of parameter.
     */
    public void create(Sensor sensor, BranchGroup branchGroup) {
        State.Immutable state;
        LayoutPosition.Immutable layoutPosition;
        state = getContextData().getStateManager().getImmutableState(sensor);
        layoutPosition =
            (LayoutPosition.Immutable) state.getAttribute(LayoutPosition.class);
        Vector3f position = new Vector3f();
        if (layoutPosition != null) {
            position.set(layoutPosition.getPosition());
        }
        Shape3D shape =
            createQuad(0, sensor.getExtend().x, sensor.getExtend().y, position);
        ShapeManager.setCapabilities(shape, sensor);
        getContextData().getShapeManager().register(sensor, shape);
        Appearance appearance = new Appearance();
        AppearanceHelper.setDefaults(appearance);

        //    AppearanceHelper.modifyAppearance( appearance, new Color3f( 0, 0, 0 ) );
        PolygonAttributes pa = new PolygonAttributes();
        pa.setPolygonOffset(10);
        appearance.setPolygonAttributes(pa);
        shape.setAppearance(appearance);
        branchGroup.addChild(shape);
    }

    /**
     * Description of the method.
     *
     * @param start Description of parameter.
     * @param end Description of parameter.
     * @param height Description of parameter.
     * @param position Description of parameter.
     *
     * @return Description of the returned value.
     */
    private Shape3D createQuad(float start, float end, float height,
        Tuple3f position) {
        Shape3D shape = null;
        float width = end - start;
        Tuple3f offset = new Point3f(start + width / 2.0f, 0.0f, 0.0f);
        Quad quad = new Quad();
        quad.getCoordinates().scale(new Point3f(width, height, 1.0f));
        quad.getCoordinates().add(offset);
        quad.getCoordinates().add(position);
        shape = quad.getShape();
        return shape;
    }
}
