/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.modules;

import java.awt.event.ActionEvent;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;

import org.srs3d.viewer.bioatlas.objects.Annotation;
import org.srs3d.viewer.bioatlas.objects.Feature;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.objects.ObjectManager;
import org.srs3d.viewer.objects.Operation;

/**
 * <code>Module</code> implementation selecting a set of features
 *
 * @author Karsten Klein
 *
 * @created May 14, 2001
 */
public class SelectFeatureModule extends ProcessModule {

    /**
     * <code>SelectFeatureModule</code> constructor.
     *
     * @param name Description of parameter.
     * @param contextData Description of parameter.
     */
    public SelectFeatureModule(String name, ContextData contextData) {
        super(name, contextData);
    }

    /**
     * Gets the <code>moduleIdPrefix</code> attribute of the
     * <code>SelectFeatureModule</code> object.
     *
     * @return The <code>moduleIdPrefix</code> value.
     */
    public String getModuleIdPrefix() {
        return "SELECT-";
    }

    /**
     * Description of the method.
     *
     * @param e Description of parameter.
     */
    public void process(ActionEvent e) {
        ContextData contextData = getContextData();
        final HashSet set = new HashSet();
        ObjectManager.extract(contextData.getObjectContainer().getObjects(),
            set, Annotation.class);
        selectActiveAnnotations(set);
    }

    /**
     * Description of the method.
     *
     * @param annotations Description of parameter.
     */
    public void selectActiveAnnotations(Collection annotations) {
        Iterator iterator = annotations.iterator();
        Annotation annotation;
        Collection features = new HashSet();
        while (iterator.hasNext()) {
            annotation = (Annotation) iterator.next();
            if (AnnotationModule.isActiveAnnotation(getContextData(), annotation)) {
                features.addAll(annotation.getFeatures());
            }
        }
        selectActiveFeatures(features);
    }

    /**
     * Description of the method.
     *
     * @param features Description of parameter.
     */
    public void selectActiveFeatures(Collection features) {
        HashSet objects = new HashSet();
        Iterator iterator = features.iterator();
        while (iterator.hasNext()) {
            objects.addAll(((Feature) iterator.next()).getObjects());
        }
        Operation operation =
            new Operation(getContextData().getContext(), "TRANSFER_SELECTION",
                null);
        operation.setObjects(objects);
        operation.setSerializable(false);
        getContextData().getDispatcher().runDispatch(operation);
    }

    /**
     * Description of the method.
     */
    public void updateIntern() {
        Collection annotations = new HashSet();
        AnnotationModule.getActiveAnnotations(getContextData(), annotations);
        getComponent().setEnabled(!annotations.isEmpty());
    }
}
