/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.styles;

import org.srs3d.viewer.bioatlas.attributes.AtomRepresentation;
import org.srs3d.viewer.bioatlas.attributes.Representation;
import org.srs3d.viewer.bioatlas.attributes.ResidueRepresentation;
import org.srs3d.viewer.bioatlas.attributes.SubchainRepresentation;
import org.srs3d.viewer.bioatlas.colorschemes.CPKColorScheme;
import org.srs3d.viewer.bioatlas.objects.Atom;
import org.srs3d.viewer.bioatlas.objects.Coil;
import org.srs3d.viewer.bioatlas.objects.Helix;
import org.srs3d.viewer.bioatlas.objects.Layer;
import org.srs3d.viewer.bioatlas.objects.NucleicChain;
import org.srs3d.viewer.bioatlas.objects.Residue;
import org.srs3d.viewer.bioatlas.objects.Strand;
import org.srs3d.viewer.bioatlas.objects.Turn;
import org.srs3d.viewer.j3d.ColorSchemeBucket;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.attributes.Visible;
import org.srs3d.viewer.j3d.commands.ColorCommand;
import org.srs3d.viewer.j3d.commands.RemoveStateCommand;
import org.srs3d.viewer.objects.Attribute;
import org.srs3d.viewer.objects.State;

/**
 * <code>CompoundStyle</code> .
 *
 * @author Karsten Klein
 *
 * @created July 11, 2001
 */
public class CompoundStyle extends FirstImpressionStyle {

    /**
     * <code>FirstImpressionStyle</code> constructor.
     *
     * @param contextData Description of parameter.
     */
    public CompoundStyle(ContextData contextData) {
        super(contextData);
        CPKColorScheme colorScheme = new CPKColorScheme(contextData);
        colorScheme.setComplete(true);
        contextData.setProperty(CPKColorScheme.class, colorScheme);
    }

    protected void adaptStatePrototypes() {
        ContextData contextData = getContextData();
        State state;

        // subchain state prototype changed
        state = new State();
        state.setAttribute(Attribute.getInstance(Visible.class));
        SubchainRepresentation subchainRepresentation =
            (SubchainRepresentation) Attribute.getInstance(SubchainRepresentation.class);
        subchainRepresentation.setMode(Representation.REPRESENTATION_WIREFRAME);
        state.setAttribute(subchainRepresentation);
        contextData.getStatePrototypeManager().register(Helix.class, state);
        contextData.getStatePrototypeManager().register(Strand.class, state);
        contextData.getStatePrototypeManager().register(Turn.class, state);
        contextData.getStatePrototypeManager().register(Coil.class, state);
        contextData.getStatePrototypeManager().register(NucleicChain.class,
            state);

        // residue state prototype changed
        state = new State();
        state.setAttribute(Attribute.getInstance(Visible.class));
        ResidueRepresentation residueRepresentation =
            (ResidueRepresentation) Attribute.getInstance(ResidueRepresentation.class);
        residueRepresentation.setMode(Representation.REPRESENTATION_WIREFRAME);
        state.setAttribute(residueRepresentation);
        contextData.getStatePrototypeManager().register(Residue.class, state);

        // atom state prototype changed
        state = new State();
        state.setAttribute(Attribute.getInstance(Visible.class));
        AtomRepresentation atomRepresentation =
            (AtomRepresentation) Attribute.getInstance(AtomRepresentation.class);
        atomRepresentation.setMode(Representation.REPRESENTATION_WIREFRAME);
        state.setAttribute(atomRepresentation);
        contextData.getStatePrototypeManager().register(Atom.class, state.copy());
    }

    /**
     * Description of the method.
     *
     * @param layer Description of parameter.
     */
    public void applyColorScheme(Layer layer) {
        ColorSchemeBucket bucket = new ColorSchemeBucket();
        bucket.add(getColorScheme(CPKColorScheme.class));
        ColorCommand colorCommand = new ColorCommand(getContextData(), bucket);
        colorCommand.setForceRecoloring(true);
        colorCommand.propagate(layer);
        getContextData().setColorSchemeBucket(bucket);
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public String getName() {
        return "Compound";
    }

    /**
     * Method description.
     *
     * @param layer Parameter description.
     */
    public void applyStateChange(Layer layer) {
        adaptStatePrototypes();

        // remove all states:
        getContextData().getStrategyManager().propagate(layer,
            new RemoveStateCommand(getContextData()), null);
    }
}
