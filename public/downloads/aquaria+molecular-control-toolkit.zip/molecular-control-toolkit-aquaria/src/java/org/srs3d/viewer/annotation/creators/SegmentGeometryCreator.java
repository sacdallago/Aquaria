/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.annotation.creators;

import javax.media.j3d.BranchGroup;
import javax.media.j3d.Shape3D;
import javax.vecmath.Matrix3f;
import javax.vecmath.Point3f;
import javax.vecmath.TexCoord2f;
import javax.vecmath.Tuple3f;
import javax.vecmath.Vector3f;

import org.srs3d.viewer.annotation.attributes.LayoutPosition;
import org.srs3d.viewer.annotation.objects.Segment;
import org.srs3d.viewer.bioatlas.Parameter;
import org.srs3d.viewer.bioatlas.objects.Coil;
import org.srs3d.viewer.bioatlas.objects.Helix;
import org.srs3d.viewer.bioatlas.objects.Section;
import org.srs3d.viewer.bioatlas.objects.Strand;
import org.srs3d.viewer.bioatlas.objects.Turn;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.ShapeManager;
import org.srs3d.viewer.j3d.creators.AbstractGeometryCreator;
import org.srs3d.viewer.j3d.geometry.GeometryHelper;
import org.srs3d.viewer.j3d.geometry.primitive.Cylinder;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.objects.State;
import org.srs3d.viewer.vecmath.Constants;
import org.srs3d.viewer.vecmath.Contour;
import org.srs3d.viewer.vecmath.SweepingSurface;
import org.srs3d.viewer.vecmath.TexCoordArray2f;
import org.srs3d.viewer.vecmath.VectorArray3f;

/**
 * Description of the class
 *
 * @author Christian Zofka
 *
 * @created July 08, 2001
 */
public class SegmentGeometryCreator extends AbstractGeometryCreator {
    private static final Matrix3f rotation =
        new Matrix3f(0, 0, 1, 0, 1, 0, 1, 0, 0);
    private static final Matrix3f rotation90 =
        new Matrix3f(0, 0, 1, 0, 1, 0, 1, 0, 0);
    private Vector3f position = new Vector3f();
    private int segmentMode = Parameter.segmentCylinder;

    /**
     * Description of the method
     *
     * @param object Description of parameter
     * @param branchGroup Description of parameter
     */
    public void create(AbstractObject object, BranchGroup branchGroup) {
        create((Segment) object, branchGroup);
    }

    /**
     * Description of the method
     *
     * @param segment Description of parameter
     * @param branchGroup Description of parameter
     */
    public void create(Segment segment, BranchGroup branchGroup) {

        // perform explicit registration from subchain down to segment. Note that
        // this registration complies to the normal registration mechanism, but
        // is nevertheless the big difference from the annotation context to the
        // 3d or sequence context.
        if (segment.getSubchain() != null) {
            getContextData().getObjectManager().register(segment.getSubchain(),
                segment);
        }
        if ((segmentMode & Parameter.segmentCylinder) != 0) {
            createCylinderGeometry(segment, branchGroup);
        }
    }

    /**
     * Description of the method.
     *
     * @param object Description of parameter.
     * @param contextData Description of parameter.
     */
    public void modifyAttributes(ContextData contextData, AbstractObject object) {
        super.modifyAttributes(contextData, object);
        State.Immutable state =
            getContextData().getStateManager().getImmutableState(object);
        LayoutPosition.Immutable layoutPosition =
            (LayoutPosition.Immutable) state.getAttribute(LayoutPosition.class);
        if (layoutPosition != null) {
            position.set(layoutPosition.getPosition());
        }
    }

    /**
     * Description of the method
     *
     * @param segment Description of parameter
     * @param branchGroup Description of parameter
     */
    private void createCylinderGeometry(Segment segment, BranchGroup branchGroup) {
        Shape3D shape = null;
        int startIndex = segment.getStartIndex();
        int endIndex = segment.getEndIndex() + 1;
        if (startIndex < endIndex) {
            if (segment.getSubchain() != null) {
                if (segment.getSubchain().getCode() == Coil.CODE) {
                    shape = createCoil(segment);
                } else if (segment.getSubchain().getCode() == Strand.CODE) {
                    shape = createPlaneStrand(segment);
                } else if (segment.getSubchain().getCode() == Helix.CODE) {
                    shape =
                        createCylinder(segment, startIndex, endIndex,
                            Parameter.helixAnnotationSize, position);
                } else if (segment.getSubchain().getCode() == Section.CODE) {
                    shape =
                        createCylinder(segment, startIndex, endIndex,
                            Parameter.sectionAnnotationSize, position);
                } else if (segment.getSubchain().getCode() == Turn.CODE) {
                    shape = createTurn(segment);
                } else {
                    shape =
                        createCylinder(segment, startIndex, endIndex,
                            Parameter.coilAnnotationSize, position);
                }
                if (shape != null) {
                    ShapeManager.setCapabilities(shape, segment);
                    getContextData().getShapeManager().register(segment, shape);
                    branchGroup.addChild(shape);
                }
            }
        }
    }

    /**
     * Description of the method
     *
     * @param segment Description of parameter
     *
     * @return
     */
    private Shape3D createCoil(Segment segment) {
        Shape3D shape = new Shape3D();
        Shape3D tempShape = null;
        int startIndex = segment.getStartIndex();
        int endIndex = segment.getEndIndex() + 1;
        tempShape =
            createCylinder(segment, startIndex, endIndex,
                Parameter.coilAnnotationSize, position);
        shape.addGeometry(tempShape.getGeometry(1));
        return shape;
    }

    /**
     * Description of the method
     *
     * @param segment Description of parameter
     *
     * @return
     */
    private Shape3D createStrand(Segment segment) {
        Shape3D shape = null;
        int startIndex = segment.getStartIndex();
        int endIndex = segment.getEndIndex() + 1;
        int length = endIndex - startIndex;
        int coneSize = Parameter.maxConeSize;
        if (length == 1) {
            coneSize = 1;
            length = 0;
        } else if (length <= coneSize) {
            coneSize = length - 1;
        }
        endIndex -= coneSize;

        // Body
        if (length > 0) {
            shape =
                createCylinder(segment, startIndex, endIndex,
                    Parameter.strandAnnotationSize, position);
        }

        // Top
        if (coneSize > 0) {
            Cylinder cone = new Cylinder();
            cone.setDivisionY(Parameter.segmentDivision);
            cone.getCoordinates().setAt(0, new Point3f(endIndex, 0, 0));
            cone.getCoordinates().setAt(1,
                new Point3f(endIndex + coneSize, 0, 0));
            cone.setRadiusAt(0, 3.0f);
            cone.setRadiusAt(1, 0.5f);
            cone.getCoordinates().add(position);
            if (shape != null) {
                shape.addGeometry(cone.getShape().getGeometry(1));
                shape.addGeometry(cone.getShape().getGeometry(2));
            } else {
                shape = cone.getShape();
            }
        }
        return shape;
    }

    /**
     * Description of the method.
     *
     * @param segment Description of parameter.
     *
     * @return Description of the returned value.
     */
    private Shape3D createPlaneStrand(Segment segment) {
        if (segment.getEndResidue() == segment.getSubchain().getEndResidue()) {
            return createPlaneStrandPike(segment);
        }
        Shape3D shape = null;
        int startIndex = segment.getStartIndex();
        int endIndex = segment.getEndIndex() + 1;
        Contour contour = Contour.getRectangleContour();
        contour.setClosed(false);
        SweepingSurface sweepingSurface = new SweepingSurface(contour);
        sweepingSurface.setTextured(true);
        VectorArray3f scale = new VectorArray3f(2);
        scale.setAt(0, Parameter.strandAnnotationDepth,
            Parameter.strandAnnotationSize, 1);
        scale.setAt(1, Parameter.strandAnnotationDepth,
            Parameter.strandAnnotationSize, 1);
        VectorArray3f translation = new VectorArray3f(2);
        translation.setAt(0, startIndex, 0, 0);
        translation.setAt(1, endIndex, 0, 0);
        TexCoord2f textureCoordinate = new TexCoord2f();
        float width = endIndex - startIndex;
        float widthPowerOf2 =
            Constants.computeNextHigherPowerOf2(segment.getSubchain().getLength());
        float deltaTexture = 1.0f / widthPowerOf2;
        float offset =
            deltaTexture * segment.getSubchain().computeResidueIndex(segment.getInitialResidue());
        textureCoordinate.x = offset;
        translation.getAt(0).add(position);
        translation.getAt(1).add(position);
        sweepingSurface.addFrame(rotation90, translation.getAt(0),
            scale.getAt(0), false, textureCoordinate);
        textureCoordinate.x = offset + deltaTexture * width;
        sweepingSurface.addFrame(rotation90, translation.getAt(1),
            scale.getAt(1), false, textureCoordinate);
        shape = sweepingSurface.getFullGeometry(0, 1, false);
        return shape;
    }

    /**
     * Description of the method.
     *
     * @param segment Description of parameter.
     *
     * @return Description of the returned value.
     */
    private Shape3D createPlaneStrandPike(Segment segment) {
        Shape3D shape = null;
        int startIndex = segment.getStartIndex();
        int endIndex = segment.getEndIndex() + 1;
        int length = endIndex - startIndex;
        int coneSize = Parameter.maxConeSize;
        Contour contour = Contour.getRectangleContour();
        contour.setClosed(true);
        SweepingSurface sweepingSurface = new SweepingSurface(contour);
        int start = 0;
        float width = length;
        float widthPowerOf2 =
            Constants.computeNextHigherPowerOf2(segment.getSubchain().getLength());
        float deltaTexture = 1.0f / widthPowerOf2;
        float offset =
            deltaTexture * segment.getSubchain().computeResidueIndex(segment.getInitialResidue());
        if (length == 1) {
            coneSize = 1;
            length = 0;
            start = 2;
        } else if (length <= coneSize) {
            coneSize = length - 1;
        }
        endIndex -= coneSize;
        VectorArray3f scale = new VectorArray3f(4);
        scale.setAt(0, Parameter.strandAnnotationDepth,
            Parameter.strandAnnotationSize, 1);
        scale.setAt(1, Parameter.strandAnnotationDepth,
            Parameter.strandAnnotationSize, 1);
        scale.setAt(2, Parameter.strandAnnotationDepth,
            Parameter.strandAnnotationConeSize, 1);
        scale.setAt(3, Parameter.strandAnnotationDepth,
            Parameter.coilAnnotationSize, 1);
        VectorArray3f translation = new VectorArray3f(4);
        TexCoord2f textureCoordinate = new TexCoord2f();
        TexCoordArray2f textureCoordinates = new TexCoordArray2f(4);
        textureCoordinate.x = offset;
        textureCoordinates.setAt(0, textureCoordinate);
        textureCoordinate.x = offset + deltaTexture * (endIndex - startIndex);
        textureCoordinates.setAt(1, textureCoordinate);
        textureCoordinates.setAt(2, textureCoordinate);
        textureCoordinate.x =
            offset + deltaTexture * (endIndex - startIndex + coneSize);
        textureCoordinates.setAt(3, textureCoordinate);
        translation.setAt(0, startIndex, 0, 0);
        translation.setAt(1, endIndex, 0, 0);
        translation.setAt(2, endIndex, 0, 0);
        translation.setAt(3, endIndex + coneSize, 0, 0);
        sweepingSurface.setTextured(true);
        for (int i = start; i < 4; i++) {
            translation.getAt(i).add(position);
            sweepingSurface.addFrame(rotation90, translation.getAt(i),
                scale.getAt(i), true, textureCoordinates.getAt(i));
        }

        // normally we don't have to artifically destinguish the two cases, but
        // it seems that the getFullGeometry method does not work porperly and produdes
        // degenerated triangles.
        if (start == 2) {
            shape =
                sweepingSurface.getFullGeometry(0,
                    sweepingSurface.getFrameCount() - 1, true);
        } else {
            shape = sweepingSurface.getFullGeometry(0, 1, true);
            GeometryHelper.copyGeometry(sweepingSurface.getFullGeometry(2, 3,
                    true), shape);
        }
        return shape;
    }

    /**
     * Description of the method.
     *
     * @param segment Description of parameter.
     *
     * @return Description of the returned value.
     */
    private Shape3D createTurn(Segment segment) {
        int startIndex = segment.getStartIndex();
        int endIndex = segment.getEndIndex() + 1;
        int length = endIndex - startIndex;
        float border = 1.0f;
        if (length <= 3) {
            border = 0.6f;
            if (length == 1) {
                border = 0.2f;
            }
        }
        Contour contour = Contour.getCircleContour(6, (float) Math.PI, 4);
        contour.setClosed(false);
        SweepingSurface sweepingSurface = new SweepingSurface(contour);
        sweepingSurface.setTextured(true);
        TexCoord2f textureCoordinate = new TexCoord2f();
        float width = endIndex - startIndex;
        float widthPowerOf2 =
            Constants.computeNextHigherPowerOf2(segment.getSubchain().getLength());
        float deltaTexture = 1.0f / widthPowerOf2;
        float offset =
            segment.getSubchain().computeResidueIndex(segment.getInitialResidue());
        Point3f point = new Point3f(0, 0, 0);
        Vector3f scale = new Vector3f(1, 1, 1);
        point.set(position);
        point.x += startIndex;
        scale.y = 0.5f;
        textureCoordinate.x = offset;
        sweepingSurface.addFrame(rotation, point, scale, false,
            textureCoordinate);
        point.set(position);
        point.x += startIndex + border;
        scale.y = 1;
        textureCoordinate.x = offset + border * deltaTexture;
        sweepingSurface.addFrame(rotation, point, scale, false,
            textureCoordinate);
        point.set(position);
        point.x += endIndex - border;
        scale.y = 1;
        textureCoordinate.x = offset + (width - border) * deltaTexture;
        sweepingSurface.addFrame(rotation, point, scale, false,
            textureCoordinate);
        point.set(position);
        point.x += endIndex;
        scale.y = 0.5f;
        textureCoordinate.x = offset + width * deltaTexture;
        sweepingSurface.addFrame(rotation, point, scale, false,
            textureCoordinate);
        return sweepingSurface.getFullGeometry(0, 3, false);
    }

    /**
     * Draws the front part of a cylinder without bottom and top geometry. Texturing
     * coodrinates are set lineary approproate to the y position in (segment aligned) in
     * space;
     *
     * @param startIndex Description of parameter.
     * @param endIndex Description of parameter.
     * @param radius Description of parameter.
     * @param position Description of parameter.
     *
     * @return Description of the returned value.
     */
    public static Shape3D createCylinder(Segment segment, float startIndex,
        float endIndex, float radius, Tuple3f position) {
        Contour contour = Contour.getCircleContour(6, (float) Math.PI, 4);
        contour.setClosed(false);
        float width = endIndex - startIndex;
        float widthPowerOf2 =
            Constants.computeNextHigherPowerOf2(segment.getSubchain().getLength());
        float deltaTexture = 1.0f / widthPowerOf2;
        float offset =
            deltaTexture * segment.getSubchain().computeResidueIndex(segment.getInitialResidue());
        SweepingSurface sweepingSurface = new SweepingSurface(contour);
        sweepingSurface.setTextured(true);
        TexCoord2f textureCoordinate = new TexCoord2f(offset, 0);
        VectorArray3f scale = new VectorArray3f(2);
        scale.setAt(0, radius, radius, 1);
        scale.setAt(1, radius, radius, 1);
        VectorArray3f translation = new VectorArray3f(2);
        translation.setAt(0, startIndex, 0, 0);
        translation.setAt(1, endIndex, 0, 0);
        translation.getAt(0).add(position);
        sweepingSurface.addFrame(rotation, translation.getAt(0),
            scale.getAt(0), false, textureCoordinate);
        translation.getAt(1).add(position);

        // :NOTE: the endIndex has already been raised by 1
        textureCoordinate.x = offset + deltaTexture * width;
        sweepingSurface.addFrame(rotation, translation.getAt(1),
            scale.getAt(1), false, textureCoordinate);
        return sweepingSurface.getFullGeometry(0, 1, true);
    }
}
