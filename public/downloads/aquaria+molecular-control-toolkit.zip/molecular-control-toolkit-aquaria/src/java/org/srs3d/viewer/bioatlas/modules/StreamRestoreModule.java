/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.modules;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.Collection;
import java.util.Iterator;

import org.srs3d.viewer.bioatlas.views.CustomView;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.util.ExceptionHandler;
import org.srs3d.viewer.util.XmlTag;

/**
 * Abstract implentation of the abstract RestoreModule class handling input streams.
 *
 * @author Karsten Klein
 *
 * @created August 20, 2003
 */
public abstract class StreamRestoreModule extends RestoreModule {

    /**
     * <code>RestoreModule</code> constructor.
     *
     * @param name Description of parameter.
     * @param contextData Description of parameter.
     * @param id Description of parameter.
     */
    public StreamRestoreModule(String name, ContextData contextData, String id) {
        super(name, contextData, id);
    }

    /**
     * Description of the method.
     *
     * @param xmlTag Description of parameter.
     */
    protected void serialize(XmlTag xmlTag, OutputStream out) {
        try {
            out.write((xmlTag.toString() + "\r\n").getBytes());
        } catch (java.io.IOException e) {
            ExceptionHandler.handleException(e,
                ExceptionHandler.SILENT_IN_RELEASE, this);
        }
    }

    protected void read(InputStream in) {
        try {
            BufferedReader reader =
                new BufferedReader(new InputStreamReader(in));
            XmlTag xmlTag = XmlTag.deserialize(reader);
            xmlTag = xmlTag.findTag("project");
            Collection subtags = xmlTag.getSubtags();
            Iterator viewIterator = subtags.iterator();
            boolean hasViewTag = false;
            while (viewIterator.hasNext()) {

                // retrieve view tags
                xmlTag = (XmlTag) viewIterator.next();

                // create a view from view tag
                if (xmlTag != null) {
                    if (xmlTag.getName().equals(CustomView.VIEW_TAG)) {
                        CustomView view = new CustomView(xmlTag);
                        getViewManager().registerView(view);
                        hasViewTag = true;
                    } else {
                        if (xmlTag.getName().equals(ViewManager.DEFAULT_VIEW_TAG)) {
                            setInitialView(xmlTag.getAttribute(
                                    ViewManager.DEFAULT_VIEW_ATTRIBUTE));
                            hasViewTag = true;
                        }
                    }
                }
            }
            if (!hasViewTag) {

                // stream is an formatted in the old fashion (new view defined)
                String viewId = "default";

                // create a new view tag        
                XmlTag viewTag = new XmlTag(CustomView.VIEW_TAG);
                viewTag.setAttribute(CustomView.ID_ATTRIBUTE, viewId);
                viewTag.getSubtags().addAll(subtags);
                getViewManager().registerView(new CustomView(viewTag));
                setInitialView(viewId);
            }
        } catch (Exception e) {
            ExceptionHandler.handleException(e,
                ExceptionHandler.VISIBLE_IN_RELEASE, this);
        }
    }

    protected void write(OutputStream out) throws IOException {
        out.write("<?xml version=\"1.0\"?>\r\n".getBytes());
        out.write("<project id=\"srs3d\">\r\n".getBytes());
        Iterator iterator = getViewManager().getViewMap().values().iterator();
        CustomView view;
        while (iterator.hasNext()) {
            view = (CustomView) iterator.next();
            serialize(view.getXmlTag(), out);
        }
        String defaultViewId = getViewManager().getDefaultViewId();
        if (defaultViewId != null) {

            // add default view tag
            XmlTag tag = new XmlTag(ViewManager.DEFAULT_VIEW_TAG);
            tag.setAttribute(ViewManager.DEFAULT_VIEW_ATTRIBUTE, defaultViewId);
            serialize(tag, out);
        }
        out.write("</project>\r\n".getBytes());
    }
}
