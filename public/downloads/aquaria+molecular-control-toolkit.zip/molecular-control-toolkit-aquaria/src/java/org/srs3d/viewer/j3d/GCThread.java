/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d;


/**
 * Class description.
 *
 * @author Karsten Klein, LION bioscience AG
 */
public class GCThread extends Thread {

    // the automatic or application controller garbage collection can be switched
    // off via a system property
    private static boolean isActive =
        !"false".equals(System.getProperty("srs3d.gc"));
    private static final GCThread instance = new GCThread();
    private static boolean isVerbose = false;

    /**
     * Constructor description.
     */
    private GCThread() {
        setPriority(Thread.MIN_PRIORITY);
        setDaemon(true);
        setName(getClass().getName());
        start();
    }

    /**
     * Method description.
     */
    public void run() {
        try {
            while (true) {
                GCThread.runFinalization();
                GCThread.gc();
                try {
                    Thread.sleep(60000);
                } catch (InterruptedException e) {

                    // :SILENT EXCEPTION:
                }
            }
        } catch (Throwable e) {

            // continue execution
            run();

            // don't throw the throwable for further handling
        }
    }

    /**
     * Method description.
     */
    public static void initialize() {

        // empty method; side-effect: class loaded and initilized
    }

    /**
     * Method description.
     */
    public static void runFinalization() {
        if (isActive) {
            Runtime.getRuntime().runFinalization();
        }
    }

    /**
     * Method description.
     */
    public static void gc() {
        if (isActive) {
            System.gc();
        }
    }
}
