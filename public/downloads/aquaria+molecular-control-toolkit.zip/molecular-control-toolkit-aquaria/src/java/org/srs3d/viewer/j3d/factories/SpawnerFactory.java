/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.factories;

import java.util.HashSet;

import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.Contextual;
import org.srs3d.viewer.j3d.Spawner;
import org.srs3d.viewer.objects.AbstractObject;

/**
 * @author Karsten Klein
 *
 * @created April 03, 2001
 */
public class SpawnerFactory implements Contextual {
    private HashSet classRegistry = new HashSet();
    private ContextData contextData;

    /**
     * <code>SpawnerFactory</code> constructor.
     *
     * @param contextData Description of parameter.
     */
    public SpawnerFactory(ContextData contextData) {
        this.contextData = contextData;
    }

    /**
     * Gets the <code>Spawner</code> attribute of the <code>SpawnerFactory </code>object.
     * Note that object only receive a new spawner, when they are registered to the
     * factory.
     *
     * @param object Description of parameter.
     *
     * @return The <code>Spawner</code> value.
     */
    public Spawner getSpawner(AbstractObject object) {
        if (classRegistry.contains(object.getClass())) {
            Spawner spawner =
                getContextData().getSpawnerManager().getSpawner(object);
            if (spawner == null) {
                spawner = new Spawner(object);
                getContextData().getSpawnerManager().register(object, spawner);
            }
            return spawner;
        }
        return null;
    }

    /**
     * Gets the <code>contextData</code> attribute of the <code>SpawnerFactory</code>
     * object.
     *
     * @return The <code>contextData</code> value.
     */
    public final ContextData getContextData() {
        return contextData;
    }

    /**
     * Description of the method.
     *
     * @param objectClass Description of parameter.
     */
    public void register(Class objectClass) {
        classRegistry.add(objectClass);
    }

    /**
     * Description of the method.
     */
    public void clearRegistry() {
        classRegistry.clear();
    }
}
