/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.geometry.primitive;

import javax.media.j3d.Shape3D;

/**
 * The AbstractPrimitive interface simply unifies the specialized primitve types.
 *
 * @author Karsten Klein, 10/2000
 *
 * @since 1.0
 */
public interface AbstractPrimitive {

    /**
     * Retrieves a <code>Shape3D</code> object with the geometry inside. The user of the
     * shape can feel free to read the geometries out of the shape and compose them in
     * another way. This return value was chosen, due to the fact that primitives could
     * generate more than only one <code>Geometry</code> object. It's restricted by the
     * fact that only geometries of one specific type can be accumulated in a single
     * shape instance.
     *
     * @return <code>Shape3D</code> - the shape returned embeds the produced
     *         geometry/ies. Note that no <code>Appearance</code> is set by the
     *         primitive.
     */
    public abstract Shape3D getShape();
}
