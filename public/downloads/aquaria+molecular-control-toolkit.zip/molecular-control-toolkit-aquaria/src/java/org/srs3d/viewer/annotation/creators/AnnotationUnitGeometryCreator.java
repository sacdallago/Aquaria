/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.annotation.creators;

import java.util.Collection;
import java.util.Iterator;
import java.util.Vector;

import javax.media.j3d.Appearance;
import javax.media.j3d.BranchGroup;
import javax.media.j3d.ImageComponent2D;
import javax.media.j3d.LineArray;
import javax.media.j3d.RenderingAttributes;
import javax.media.j3d.Shape3D;
import javax.media.j3d.TransparencyAttributes;
import javax.vecmath.Color3f;
import javax.vecmath.Point3f;
import javax.vecmath.Tuple3f;
import javax.vecmath.Vector3f;

import org.srs3d.viewer.annotation.attributes.LayoutPosition;
import org.srs3d.viewer.annotation.objects.Alignment;
import org.srs3d.viewer.annotation.objects.AnnotationUnit;
import org.srs3d.viewer.annotation.objects.ChainAnnotation;
import org.srs3d.viewer.annotation.objects.FeatureUnit;
import org.srs3d.viewer.bioatlas.objects.Residue;
import org.srs3d.viewer.j3d.AppearanceHelper;
import org.srs3d.viewer.j3d.ShapeManager;
import org.srs3d.viewer.j3d.commands.RegisterCommand;
import org.srs3d.viewer.j3d.creators.AbstractGeometryCreator;
import org.srs3d.viewer.j3d.geometry.GeometryHelper;
import org.srs3d.viewer.j3d.geometry.primitive.Line;
import org.srs3d.viewer.j3d.objects.Sensor;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.objects.Attribute;
import org.srs3d.viewer.objects.ObjectManager;
import org.srs3d.viewer.objects.State;
import org.srs3d.viewer.util.Log;

/**
 * Creates lines that align to the sequence information of the corresponding sequence and
 * postitions a sensor for feature activation. The layout positions for the feature
 * units is produced.
 *
 * @author Karsten Klein
 *
 * @created September 19, 2001
 */
public class AnnotationUnitGeometryCreator extends AbstractGeometryCreator {
    private static final Log log = new Log(AnnotationUnitGeometryCreator.class);
    private static transient Appearance appearance = null;

    /**
     * Description of the method.
     *
     * @param object Description of parameter.
     * @param branchGroup Description of parameter.
     */
    public void create(AbstractObject object, BranchGroup branchGroup) {
        create((AnnotationUnit) object, branchGroup);
    }

    /**
     * Description of the method.
     *
     * @param branchGroup Description of parameter.
     * @param annotationUnit Description of parameter.
     */
    public void create(AnnotationUnit annotationUnit, BranchGroup branchGroup) {
        Iterator iterator;
        State state;
        State.Immutable immutableState;
        LayoutPosition.Immutable immutableLayoutPosition;
        LayoutPosition layoutPosition;
        immutableState =
            getContextData().getStateManager().getImmutableState(annotationUnit);
        immutableLayoutPosition =
            (LayoutPosition.Immutable) immutableState.getAttribute(LayoutPosition.class);
        Vector3f position = new Vector3f();
        if (immutableLayoutPosition != null) {
            position.set(immutableLayoutPosition.getPosition());
        }
        drawLabel(annotationUnit, position, branchGroup);
        position.y -= 0.5f * org.srs3d.viewer.bioatlas.Parameter.annotationUnitHeight;
        Sensor sensor = annotationUnit.getSensor();
        getContextData().getSensorManager().register(sensor,
            annotationUnit.getAnnotation());
        getContextData().getObjectManager().register(annotationUnit.getAnnotation(),
            annotationUnit);
        LayoutPosition sensorPosition = new LayoutPosition();
        sensorPosition.setPosition(new Vector3f(position));
        state = getContextData().getStateManager().getState(sensor);
        state.setAttribute(sensorPosition);
        getContextData().getStateManager().register(sensor, state);

        // find associated chain annotation
        Alignment alignment = null;
        ChainAnnotation chainAnnotation = null;
        Collection alignments = new Vector();
        getContextData().getObjectManager().getDirectUpAssociations(annotationUnit,
            alignments);
        ObjectManager.extract(alignments, Alignment.class);
        if (!alignments.isEmpty()) {
            alignment = (Alignment) alignments.iterator().next();
            chainAnnotation = alignment.findChainAnnotation(annotationUnit);
        }
        if (chainAnnotation != null) {

            // create shaped according to gap sequence
            Shape3D shape =
                createGeometry(annotationUnit,
                    chainAnnotation.getGapSequence(), position);
            ShapeManager.setCapabilities(shape, annotationUnit);
            getContextData().getShapeManager().register(annotationUnit, shape);
            shape.setPickable(false);
            branchGroup.addChild(shape);

            // the sensor is a little longer then the alignment; the user must
            // always be able to activate the annotation
            sensor.getExtend().x = alignment.getLength() + 10;
            sensor.getExtend().y =
                org.srs3d.viewer.bioatlas.Parameter.annotationUnitHeight;
        } else {
            log.error("no chain annotation found for '" + annotationUnit +
                "'.");
        }

        // iterate over segments annotations and do layout stuff
        iterator = annotationUnit.getFeatureUnits().iterator();
        FeatureUnit featureUnit;
        while (iterator.hasNext()) {
            featureUnit = (FeatureUnit) iterator.next();

            // modify layout position attribute of FeatureUnits state
            state = getContextData().getStateManager().getState(featureUnit);
            layoutPosition =
                (LayoutPosition) Attribute.getInstance(LayoutPosition.class);
            layoutPosition.setPosition(position);
            state.setAttribute(layoutPosition);
            getContextData().getStateManager().register(featureUnit, state);
        }
        RegisterCommand registerCommand = new RegisterCommand(getContextData());
        registerCommand.setMode(RegisterCommand.DOWN | RegisterCommand.UP);
        getContextData().getStrategyManager().propagate(annotationUnit.getAnnotation(),
            registerCommand, null);
    }

    /**
     * Description of the method.
     *
     * @param annotationUnit Description of parameter.
     * @param gapSequence Description of parameter.
     * @param offset Description of parameter.
     *
     * @return Description of the returned value.
     */
    private Shape3D createGeometry(AnnotationUnit annotationUnit,
        Vector gapSequence, Vector3f offset) {
        int offsetZ = 0;
        int index = -1;
        Residue residue;
        int i;
        Vector lines = new Vector();
        Line line;
        for (i = 0; i < gapSequence.size(); i++) {
            residue = (Residue) gapSequence.elementAt(i);
            if (residue == null) {
                if (index != -1) {

                    // create a line from startIndex to i - 1;
                    line = new Line();
                    line.getCoordinates().setAt(0,
                        new Point3f(index, 0, offsetZ));
                    line.getCoordinates().setAt(1, new Point3f(i, 0, offsetZ));
                    line.getCoordinates().add(offset);
                    lines.add(line);
                    index = -1;
                }
            } else if (index == -1) {
                index = i;
            }
        }
        if (index != -1) {
            line = new Line();
            line.getCoordinates().setAt(0, new Point3f(index, 0, offsetZ));
            line.getCoordinates().setAt(1, new Point3f(i, 0, offsetZ));
            line.getCoordinates().add(offset);
            lines.add(line);
        }
        if (!lines.isEmpty()) {
            LineArray lineArray =
                GeometryHelper.getDefaultLineArray(2 * lines.size(), 0);
            Iterator iterator = lines.iterator();
            index = 0;
            while (iterator.hasNext()) {
                line = (Line) iterator.next();
                line.insertInto(index++, lineArray);
            }
            Shape3D shape = new Shape3D(lineArray);
            return shape;
        }
        return null;
    }

    /**
     * Description of the method.
     *
     * @param annotationUnit Description of parameter.
     * @param position Description of parameter.
     * @param branchGroup Description of parameter.
     */
    private void drawLabel(AnnotationUnit annotationUnit, Tuple3f position,
        BranchGroup branchGroup) {
        String string = annotationUnit.getAnnotation().getName();
        if (string != null) {
            Color3f color =
                new Color3f(annotationUnit.getAnnotation().getColor());
            color.add(new Color3f(0.1f, 0.1f, 0.1f));
            ImageComponent2D image =
                getContextData().getLabelManager().getLabel(string,
                    org.srs3d.viewer.j3d.LabelManager.convertColor(color, 1));
            javax.media.j3d.Raster raster = new javax.media.j3d.Raster();
            raster.setImage(image);
            raster.setSize(image.getWidth(), image.getHeight());
            Point3f textPosition =
                new Point3f(position.x, position.y + 1.5f, 0.0f);
            raster.setPosition(textPosition);
            if (appearance == null) {
                appearance = new Appearance();
                AppearanceHelper.setDefaults(appearance);
                RenderingAttributes renderingAttributes =
                    new RenderingAttributes();
                renderingAttributes.setDepthBufferEnable(false);
                appearance.setRenderingAttributes(renderingAttributes);
                TransparencyAttributes transparencyAttributes =
                    new TransparencyAttributes(TransparencyAttributes.BLENDED,
                        0.0f);
                appearance.setTransparencyAttributes(transparencyAttributes);
            }
            Shape3D shape = new Shape3D(raster, appearance);
            shape.setPickable(false);
            branchGroup.addChild(shape);
        } else {

            // no label
        }
    }
}
