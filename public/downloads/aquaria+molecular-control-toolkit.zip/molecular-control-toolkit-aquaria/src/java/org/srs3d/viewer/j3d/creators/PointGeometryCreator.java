/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.creators;

import javax.media.j3d.BranchGroup;
import javax.media.j3d.LineArray;
import javax.media.j3d.PointArray;
import javax.media.j3d.Shape3D;
import javax.vecmath.Point3f;

import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.ShapeManager;
import org.srs3d.viewer.j3d.geometry.primitive.Sphere;
import org.srs3d.viewer.j3d.objects.Point;
import org.srs3d.viewer.objects.AbstractObject;

/**
 * Creates geometry of <code>Atom</code> objects.
 *
 * @author Karsten Klein
 *
 * @created March 20, 2001
 */
public class PointGeometryCreator extends AbstractGeometryCreator {
    public static int SPHERE = 1;
    public static int POINT = 2;
    public static int CROSS = 4;
    private int mode = 0;

    /**
     * <code>GeometryCreator</code> interface implementation.
     *
     * @param object Object to create geometry for.
     * @param branchGroup Roots to attach the geometry to.
     */
    public void create(AbstractObject object, BranchGroup branchGroup) {
        Point point = (Point) object;
        if ((mode & SPHERE) != 0) {
            createSphere(point, branchGroup);
        }
        if ((mode & POINT) != 0) {
            createPoint(point, branchGroup);
        }
        if ((mode & CROSS) != 0) {
            createCross(point, branchGroup);
        }
    }

    /**
     * Creates sphere geometry for the specified <code>Atom</code> .
     *
     * @param atom <code>Atom</code> to create geometry for.
     * @param branchGroup Roots to attach the geometry to.
     */
    public void createSphere(Point point, BranchGroup branchGroup) {

        // create sphere with the appropriate attributes
        Sphere sphere = new Sphere();
        sphere.getCoordinates().set(point.getCoordinate());
        sphere.setRadius(point.getRadius());
        int divisions = (int) (sphere.getRadius() * 6);
        divisions = Math.max(6, divisions);
        divisions = Math.min(10, divisions);
        sphere.setDivisions(divisions);

        // construct shape object
        Shape3D shape = sphere.getShape();
        ShapeManager.setCapabilities(shape, point);
        getContextData().getShapeManager().register(point, shape);
        branchGroup.addChild(shape);

        // release sphere
        sphere = null;
    }

    /**
     * Creates point geometry for the specified <code>Atom</code> .
     *
     * @param atom <code>Atom</code> to create geometry for.
     * @param branchGroup Roots to attach the geometry to.
     */
    public void createPoint(Point point, BranchGroup branchGroup) {

        // create sphere with the appropriate attributes
        PointArray pointArray = new PointArray(1, PointArray.COORDINATES);
        pointArray.setCoordinate(0, point.getCoordinate());
        Shape3D shape = new Shape3D(pointArray);
        ShapeManager.setCapabilities(shape, point);
        getContextData().getShapeManager().register(point, shape);
        branchGroup.addChild(shape);
    }

    /**
     * Creates point geometry for the specified <code>Atom</code> .
     *
     * @param atom <code>Atom</code> to create geometry for.
     * @param branchGroup Roots to attach the geometry to.
     */
    public void createCross(Point point, BranchGroup branchGroup) {

        // create sphere with the appropriate attributes
        LineArray lineArray = new LineArray(6, LineArray.COORDINATES);
        Point3f position = new Point3f(point.getCoordinate());
        position.x -= 0.5f;
        lineArray.setCoordinate(0, position);
        position.x += 1.0f;
        lineArray.setCoordinate(1, position);
        position.x -= 0.5f;
        position.y -= 0.5f;
        lineArray.setCoordinate(2, position);
        position.y += 1.0f;
        lineArray.setCoordinate(3, position);
        position.y -= 0.5f;
        position.z -= 0.5f;
        lineArray.setCoordinate(4, position);
        position.z += 1.0f;
        lineArray.setCoordinate(5, position);
        Shape3D shape = new Shape3D(lineArray);
        ShapeManager.setCapabilities(shape, point);
        getContextData().getShapeManager().register(point, shape);
        branchGroup.addChild(shape);
    }

    /**
     * Description of the method.
     *
     * @param object Description of parameter.
     * @param contextData Description of parameter.
     */
    public void modifyAttributes(ContextData contextData, AbstractObject object) {
        super.modifyAttributes(contextData, object);
        mode = POINT;
    }
}
