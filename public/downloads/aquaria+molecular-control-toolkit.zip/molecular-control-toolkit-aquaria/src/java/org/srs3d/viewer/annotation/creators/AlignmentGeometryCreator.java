/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.annotation.creators;

import javax.media.j3d.BranchGroup;
import javax.vecmath.Point3f;

import org.srs3d.viewer.annotation.attributes.AlignmentLayout;
import org.srs3d.viewer.annotation.attributes.LayoutPosition;
import org.srs3d.viewer.annotation.contexts.AnnotationContextData;
import org.srs3d.viewer.annotation.objects.Alignment;
import org.srs3d.viewer.annotation.visitors.AbstractAlignmentLayoutCreator;
import org.srs3d.viewer.annotation.visitors.AlignmentLayoutCreator;
import org.srs3d.viewer.j3d.commands.SpawnCommand;
import org.srs3d.viewer.j3d.creators.AbstractGeometryCreator;
import org.srs3d.viewer.j3d.objects.Rectangle;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.objects.Attribute;
import org.srs3d.viewer.objects.State;
import org.srs3d.viewer.objects.StateManager;
import org.srs3d.viewer.util.ExceptionHandler;

/**
 * The AlignmentGeometryCreator produces a layout for alignment objects.
 *
 * @author Christian Zofka
 *
 * @created July 4, 2001
 * @reviewed Karsten Fries, LION bioscience AG
 * @reviewed January 09, 2002
 */
public class AlignmentGeometryCreator extends AbstractGeometryCreator {
    private Point3f position;

    /**
     * Description of the method.
     *
     * @param object Description of parameter
     * @param branchGroup Description of parameter
     */
    public void create(AbstractObject object, BranchGroup branchGroup) {
        create((Alignment) object, branchGroup);
    }

    /**
     * Description of the method.
     *
     * @param alignment Description of parameter.
     * @param branchGroup Description of parameter.
     */
    public void create(Alignment alignment, BranchGroup branchGroup) {
        try {
            position = new Point3f();
            AnnotationContextData contextData =
                (AnnotationContextData) getContextData();
            StateManager stateManager = contextData.getStateManager();
            State state = stateManager.getState(alignment);

            // LayoutCreator: put annotationUnits, chains & rulers in order
            AbstractAlignmentLayoutCreator alignmentLayoutCreator =
                getAlignmentLayoutCreator(alignment);
            alignmentLayoutCreator.create();
            AlignmentLayout alignmentLayout =
                alignmentLayoutCreator.getAlignmentLayout();
            state.setAttribute(alignmentLayout);

            // get alignement layout information
            LayoutPosition layoutPosition =
                (LayoutPosition) state.getAttribute(LayoutPosition.class);
            if (layoutPosition != null) {
                position.set(layoutPosition.getPosition());
            }
            float yOffset = alignmentLayout.getHeight() / 2.0f;
            position.y = yOffset;
            layoutPosition.setPosition(position);
            stateManager.register(alignment, state);
            Object[] objects = alignmentLayout.getRows();
            float[] positions = alignmentLayout.getPositions();
            int length = objects.length;
            for (int i = 0; i < length; i++) {
                if (objects[i] != null) {
                    position.y = positions[i] + yOffset;

                    // modify layout position attribute of chain annotation state
                    state = stateManager.getState((AbstractObject) objects[i]);
                    layoutPosition =
                        (LayoutPosition) Attribute.getInstance(LayoutPosition.class);
                    layoutPosition.setPosition(position);
                    state.setAttribute(layoutPosition);
                    stateManager.register((AbstractObject) objects[i], state);
                }
            }
            if (contextData.getActiveBoxAlignment() == alignment) {
                adjustZoomBox(contextData, alignmentLayout);
            }
        } catch (Exception e) {
            ExceptionHandler.handleException(e);
        }
    }

    /**
     * Gets the <code>alignmentLayoutCreator</code> attribute of the
     * <code>AlignmentGeometryCreator</code> object.
     *
     * @param alignment Description of parameter.
     *
     * @return The <code>alignmentLayoutCreator</code> value.
     */
    protected AbstractAlignmentLayoutCreator getAlignmentLayoutCreator(
        Alignment alignment) {
        return new AlignmentLayoutCreator(alignment, 0.0f);
    }

    /**
     * note: method is overwritten by Sequence/AlignmnentGeometryCreator
     *
     * @param contextData Description of parameter.
     * @param alignmentLayout Description of parameter.
     */
    protected void adjustZoomBox(AnnotationContextData contextData,
        AlignmentLayout alignmentLayout) {
        Rectangle zoomBox = contextData.getZoomBox();
        if (zoomBox != null) {
            adjustYValue(alignmentLayout, zoomBox);

            // :FIXME: this is not the normal procedure of a geometry creator
            //   to issue a spawn command!
            SpawnCommand spawn = new SpawnCommand(contextData);
            contextData.getStrategyManager().execute(zoomBox, spawn);
        }
    }

    /**
     * Updates and sets the y-coordinate of the zoomBox
     *
     * @param alignmentLayout to determine the position of zoomBox
     * @param zoomBox zoomBox object
     */
    public static void adjustYValue(AlignmentLayout alignmentLayout,
        Rectangle zoomBox) {
        Point3f boxPosition = (Point3f) zoomBox.getCoordinate();
        float startPosition = alignmentLayout.getStartChainPosition();
        boxPosition.y =
            0.5f * alignmentLayout.getHeight() + startPosition -
            0.5f * (startPosition - alignmentLayout.getEndChainPosition());
        zoomBox.setCoordinate(boxPosition);
    }
}
