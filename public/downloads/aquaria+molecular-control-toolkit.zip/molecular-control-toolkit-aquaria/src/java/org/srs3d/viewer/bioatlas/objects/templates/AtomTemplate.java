/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.objects.templates;

import java.util.Hashtable;
import java.util.Map;
import java.util.StringTokenizer;

import javax.vecmath.Color3f;

/**
 * Shared properies of atoms of a common element, remoteness and branch.
 *
 * @author Karsten Klein
 *
 * @created March 20, 2001
 */
public final class AtomTemplate {

    /** Invalid element number */
    public static final int INVALID_ELEMENT = -1;
    private static Map elementMap = new Hashtable();

    /** The type hashtable maps pdb identifiers to type identifiers */
    private static final Hashtable typeHash = new Hashtable();

    /** The element hashtable maps type indentifiers to the atom element */
    private static final Hashtable elementHash = new Hashtable();
    private static final String[] elements =
    {
        
        // element number | element string | 2 character id | van-der-waals | covalent | electronegativity | color
        "1 hydrogen       H   120 0.37  2.1  1    1    1",
        "2 helium         He  122 0.37  0    1    0.78 0.78",
        "3 lithium        Li  182 1.23  1    0.65 0.16 0.16",
        "4 beryllium      Be  140 0.89  1.5  1    0.08 0.58",
        "5 boron          B   208 0.88  2    0    1    0",
        "6 carbon         C   185 0.77  2.5  0.7  0.7  0.7",
        "7 nitrogen       N   154 0.7   3    0.5  0.5  1",
        "8 oxygen         O   140 0.66  3.5  0.9  0.1  0.1",
        "9 fluorine       F   135 0.64  4    0.78 0.65 0.09",
        "10 neon          Ne  160 0.7   0    1    0.08 0.58",
        "11 sodium        Na  231 1.57  0.9  0    0    1",
        "12 magnesium     Mg  173 1.36  1.2  0.16 0.5  0.16",
        "13 aluminium     Al  273 1.25  1.5  0.5  0.5  0.56",
        "14 silicon       Si  200 1.17  1.8  0.78 0.65 0.09",
        "15 phosphorus    P   190 1.1   2.1  1    0.65 0",
        "16 sulfur        S   185 1.04  2.5  1    0.78 0.2",
        "17 chlorine      Cl  181 0.99  3    0    1    0",
        "18 argon         Ar  191 1.1   0", "19 potassium     K   231 2.03  0.8",
        "20 calcium       Ca  223 1.74  1    0.5  0.5  0.56",
        "21 scandium      Sc  180 1.44  1.3",
        "22 titanium      Ti  200 1.32  1.5  0.5  0.5  0.56",
        "23 vanadium      V   190 1.22  1.6",
        "24 chromium      Cr  185 1.17  1.6  0.5  0.5  0.56",
        "25 manganese     Mn  179 1.17  1.5  0.5  0.5  0.56",
        

        //      "26 iron          Fe  172 1.17  1.8  1    0.65 0",
        "26 iron          Fe  170 1.0  1.8  1    0.65 0",
        "27 cobalt        Co  172 1.16  1.8",
        "28 nickel        Ni  163 1.15  1.8  0.65 0.16 0.16",
        "29 copper        Cu  140 1.17  1.9  0.65 0.16 0.16",
        "30 zinc          Zn  139 1.25  1.6  0.65 0.16 0.16",
        "31 gallium       Ga  187 1.25  1.6",
        "32 germanium     Ge  190 1.22  1.8", "33 arsenic       As  185 1.21  2",
        "34 selenium      Se  200 1.17  2.4",
        "35 bromine       Br  185 1.14  2.8  0.65 0.16 0.16",
        "36 krypton       Kr  198 1.89  3", "37 rubidium      Rb  244 2.16  0.8",
        "38 strontium     Sr  200 1.92  1", "39 yttrium       Y   180 1.62  1.2",
        "40 zirconium     Zr  170 1.45  1.4",
        "41 niobium       Nb  180 1.34  1.6",
        "42 molybdenum    Mo  200 1.29  1.8",
        "43 technetium    Tc  200 1.29  1.9",
        "44 ruthenium     Ru  160 1.24  2.2",
        "45 rhodium       Rh  139 1.25  2.2",
        "46 palladium     Pd  163 1.28  2.2",
        "47 silver        Ag  172 1.34  1.9  0.5 0.5 0.56",
        "48 cadmium       Cd  158 1.41  1.7",
        "49 indium        In  193 1.5   1.7",
        "50 tin           Sn  217 1.4   1.8",
        "51 antimony      Sb  218 1.41  1.9",
        "52 tellurium     Te  220 1.37  2.1",
        "53 iodine        I   198 1.33  2.5  0.56 0.56 1",
        "54 xenon         Xe  216 2.09  2.6",
        "55 caesium       Cs  262 2.64  0.7",
        "56 barium        Ba  278 1.98  0.9  1    0.65 0",
        "57 lanthanum     La  180 1.69  1.1",
        "58 cerium        Ce  185 1.65  1.1", "59 praseodymium  Pr",
        "60 neodymium     Nd", "61 promethium    Pm", "62 samarium      Sm",
        "63 europium      Eu", "64 gadolinium    Gd", "65 terbium       Tb",
        "66 dysprosium    Dy", "67 holmium       Ho", "68 erbium        Er",
        "69 thulium       Tm", "70 ytterbium     Yb", "71 lutetium      Lu",
        "72 hafnium       Hf", "73 tantalum      Ta", "74 tungsten      W",
        "75 rhenium       Re", "76 osmium        Os", "77 iridium       Ir",
        "78 platinum      Pt  175 1.29  2.2",
        "79 gold          Au  166 1.34  2.4  0.78 0.65 0.09",
        "80 mercury       Hg  155 1.44  1.9",
        "81 thallium      Tl  196 1.55  1.8",
        "82 lead          Pb  202 1.54  1.8", "83 bismuth       Bi",
        "84 polonium      Po", "85 astatine      At", "86 radon         Rn",
        

        //    "87 francium      Fr",
        //    "88 radium        Ra",
        //    "89 actinium      Ac",
        "90 thorium       Th", 
        //    "91 protactinium  Pa",
        "92 uranium       U   186 1.34  1.7"
    };
    private String templateName = null;
    private String fullElementName = null;
    private String elementName = null;
    private Color3f color = new Color3f();
    private float vanDerWaalsRadius = 1.85f;
    private float covalentRadius = 0.77f;
    private float electronegativity = 0;
    private int elementNumber = INVALID_ELEMENT;
    private char remotenessIndicator = ' ';
    private char branchDesignator = ' ';

    /**
     * <code>AtomTemplate</code> contructor.
     *
     * @param pdbAtomName Description of parameter
     */
    public AtomTemplate(String pdbAtomName) {
        templateName = pdbAtomName;
        create(pdbAtomName);
    }

    /**
     * Sets the <code>VanDerWaalsRadius</code> attribute of the <code>AtomTemplate</code>
     * object.
     *
     * @param vanDerWaalsRadius The new <code>VanDerWaalsRadius</code> value.
     */
    public void setVanDerWaalsRadius(float vanDerWaalsRadius) {
        this.vanDerWaalsRadius = vanDerWaalsRadius;
    }

    /**
     * Sets the <code>CovalentRadius</code> attribute of the <code>AtomTemplate
     * </code>object.
     *
     * @param covalentRadius The new <code>CovalentRadius</code> value.
     */
    public void setCovalentRadius(float covalentRadius) {
        this.covalentRadius = covalentRadius;
    }

    /**
     * Sets the <code>Electronegativity</code> attribute of the <code>AtomTemplate</code>
     * object.
     *
     * @param electronegativity The new <code>Electronegativity</code> value.
     */
    public void setElectronegativity(float electronegativity) {
        this.electronegativity = electronegativity;
    }

    /**
     * Sets the <code>Color</code> attribute of the <code>AtomTemplate</code> object
     *
     * @param color The new <code>Color</code> value
     */
    public void setColor(Color3f color) {
        this.color.set(color);
    }

    /**
     * Gets the <code>Id</code> attribute of the <code>AtomTemplate</code> object
     *
     * @return The <code>Id</code> value
     */
    public String getId() {
        return elementName + remotenessIndicator + branchDesignator;
    }

    /**
     * Gets the <code>vanDerWaalsRadius</code> attribute of the <code>AtomTemplate</code>
     * object.
     *
     * @return The <code>vanDerWaalsRadius</code> value.
     */
    public float getVanDerWaalsRadius() {
        return vanDerWaalsRadius;
    }

    /**
     * Gets the <code>covalentRadius</code> attribute of the <code>AtomTemplate </code>
     * object.
     *
     * @return The <code>covalentRadius</code> value.
     */
    public float getCovalentRadius() {
        return covalentRadius;
    }

    /**
     * Gets the <code>electronegativity</code> attribute of the <code>AtomTemplate</code>
     * object.
     *
     * @return The <code>electronegativity</code> value.
     */
    public float getElectronegativity() {
        return electronegativity;
    }

    /**
     * Gets the <code>Color</code> attribute of the <code>AtomTemplate</code> object
     *
     * @return The <code>Color</code> value
     */
    public Color3f getColor() {
        return color;
    }

    /**
     * Gets the <code>RemotenessIndicator</code> attribute of the
     * <code>AtomTemplate</code> object
     *
     * @return The <code>RemotenessIndicator</code> value
     */
    public char getRemotenessIndicator() {
        return remotenessIndicator;
    }

    /**
     * Gets the <code>BranchDesignator</code> attribute of the <code>AtomTemplate
     * </code>object
     *
     * @return The <code>BranchDesignator</code> value
     */
    public char getBranchDesignator() {
        return branchDesignator;
    }

    /**
     * Gets the <code>Element</code> attribute of the <code>AtomTemplate</code> object
     *
     * @param string Description of parameter
     *
     * @return The <code>Element</code> value
     */
    public boolean isElement(String string) {
        String composition = elementName;
        composition = composition.trim();
        return composition.equalsIgnoreCase(string);
    }

    /**
     * Description of the method
     *
     * @param string Description of parameter
     *
     * @return Description of the returned value
     */
    public boolean is(String string) {
        return templateName.substring(0, string.length()).equalsIgnoreCase(string);
    }

    /**
     * Gets the <code>element</code> attribute of the <code>AtomTemplate</code> object.
     *
     * @return The <code>element</code> value.
     */
    public String getElement() {
        return elementName;
    }

    /**
     * Gets the <code>elementName</code> attribute of the <code>AtomTemplate</code>
     * object.
     *
     * @return The <code>elementName</code> value.
     */
    public String getElementName() {
        return fullElementName;
    }

    /**
     * Method description.
     */
    public final void setDefaults() {

        // unknown element; set defaults
        color.x = 0.58f;
        color.y = 0.08f;
        color.z = 0.58f;

        // :NOTE: the negative covalent radius is meant to prohibit
        //   bonds to unknown atoms;
        // :EXAMPLE: 1gpx
        vanDerWaalsRadius = 1.0f;
        covalentRadius = 0.77f;
        electronegativity = 0;
    }

    /**
     * Method description.
     */
    public final void setInvalidDefaults() {

        // unknown element; set defaults
        color.x = 0.58f;
        color.y = 0.08f;
        color.z = 0.58f;

        // :NOTE: the negative covalent radius is meant to prohibit
        //   bonds to unknown atoms;
        // :EXAMPLE: 1gpx
        vanDerWaalsRadius = 1.0f;
        covalentRadius = -Float.MAX_VALUE;
        electronegativity = 0;
    }

    /**
     * Creates the template from a pdb atom name string. The string contains 4
     * characters. The first two a designated to the chemical symbol, the third is the
     * remoteness indicator and the last is the branch designator.
     *
     * @param pdbAtomName the pdb atom name to use for the template creation
     */
    public static final AtomTemplate getInstance(String pdbAtomName) {
        return new AtomTemplate(pdbAtomName);
    }

    /**
     * Method description.
     *
     * @param pdbAtomName Parameter description.
     */
    public void create(String pdbAtomName) {
        setDefaults();
        char first = pdbAtomName.charAt(0);
        if ((first >= '0' && first <= '9') || first == ' ') {
            elementName = pdbAtomName.substring(1, 2);
        } else {
            elementName = pdbAtomName.substring(0, 2);
        }
        remotenessIndicator = pdbAtomName.charAt(2);
        branchDesignator = pdbAtomName.charAt(3);
        mapNameToElement(elementName);
    }

    private void mapNameToElement(String elementName) {
        boolean found = mapNameToElementEx(elementName);
        if (!found) {
            mapNameToElementEx(elementName.substring(1));
        }
    }

    /**
     * Maps the element name to the appropriate setting. The fields of the instance are
     * set appropriately.
     *
     * @param elementName Name of the element with branch designator and alternate
     *        location
     *
     * @return Description of the returned value
     */
    private boolean mapNameToElementEx(String elementName) {
        StringTokenizer tokenizer;
        String token;
        String delimiter = " ";
        boolean found = false;
        int i;
        Integer cachedIndex = (Integer) elementMap.get(elementName);
        if (cachedIndex != null) {
            i = cachedIndex.intValue();
        } else {
            i = 0;
        }
        while (!found && i < elements.length) {
            tokenizer = new StringTokenizer(elements[i], delimiter);
            token = tokenizer.nextToken();
            elementNumber = Integer.parseInt(token);

            // the full element name
            fullElementName = tokenizer.nextToken();

            // the element abreviation
            token = tokenizer.nextToken();
            if (elementName.equalsIgnoreCase(token)) {
                elementName = token;
                found = true;
            }
            if (found) {
                if (tokenizer.hasMoreTokens()) {
                    vanDerWaalsRadius = Float.parseFloat(tokenizer.nextToken());
                    vanDerWaalsRadius /= 100;
                } else {
                    vanDerWaalsRadius = 1.2f;
                }
                if (tokenizer.hasMoreTokens()) {
                    covalentRadius = Float.parseFloat(tokenizer.nextToken());
                } else {
                    covalentRadius = 0.37f;
                }
                if (tokenizer.hasMoreTokens()) {
                    electronegativity = Float.parseFloat(tokenizer.nextToken());
                } else {
                    electronegativity = 0;
                }
                if (tokenizer.hasMoreTokens()) {
                    color.x = Float.parseFloat(tokenizer.nextToken());
                    color.y = Float.parseFloat(tokenizer.nextToken());
                    color.z = Float.parseFloat(tokenizer.nextToken());
                } else {
                    color.x = 0.58f;
                    color.y = 0.08f;
                    color.z = 0.58f;
                }
                elementMap.put(elementName, new Integer(i));
            } else {
                i++;
            }
        }
        if (!found) {
            elementNumber = INVALID_ELEMENT;
            setInvalidDefaults();
        }
        return found;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public boolean isInvalid() {
        return elementNumber == INVALID_ELEMENT;
    }
}
