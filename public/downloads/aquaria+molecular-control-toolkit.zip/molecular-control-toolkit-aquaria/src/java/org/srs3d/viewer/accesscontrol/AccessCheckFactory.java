/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.accesscontrol;

import org.srs3d.viewer.accesscontrol.checks.InputCheck;
import org.srs3d.viewer.accesscontrol.checks.ServerClientCheck;
import org.srs3d.viewer.accesscontrol.checks.ServerClientIPCheck;

/**
 * Provides instances according to a given id. The id will be stored with the license key
 * file to map back on the AccessCheck class.
 *
 * @author Karsten Klein
 *
 * @created August 23, 2002
 */
public class AccessCheckFactory {

    /**
     * Creates an appropriate AccessCheck instance for the given id.
     *
     * @param id Id to get the AccessCheck instance for.
     *
     * @return <code>AccessCheck</code> instance.
     */
    public static AccessCheck getInstance(int id) {
        AccessCheck accessCheck;
        switch (id) {

            case 0:
                accessCheck = new ServerClientCheck();
                break;

            case 1:
                accessCheck = new ServerClientIPCheck();
                break;

            case 2:
                accessCheck = new InputCheck();
                break;

            default:
                accessCheck = new ServerClientCheck();
        }
        return accessCheck;
    }

    /**
     * Gets the <code>id</code> attribute of the <code>AccessCheckFactory</code> class.
     *
     * @param accessCheck AccessCheck instance to retrieve the id for.
     *
     * @return The <code>id</code> value.
     */
    public static int getId(AccessCheck accessCheck) {
        if (accessCheck == null) {
            return 0;
        }
        if (accessCheck.getClass() == ServerClientCheck.class) {
            return 0;
        }
        if (accessCheck.getClass() == ServerClientIPCheck.class) {
            return 1;
        }
        if (accessCheck.getClass() == InputCheck.class) {
            return 2;
        }

        // default to ServerClientCheck
        return 0;
    }
}
