/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.annotation.modules;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;

import javax.swing.JCheckBoxMenuItem;

import org.srs3d.viewer.annotation.contexts.AnnotationContextData;
import org.srs3d.viewer.annotation.objects.Alignment;
import org.srs3d.viewer.annotation.objects.AnnotationContainer;
import org.srs3d.viewer.bioatlas.modules.ProcessModule;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.commands.SpawnCommand;
import org.srs3d.viewer.objects.ObjectManager;
import org.srs3d.viewer.objects.filters.ObjectClassFilter;
import org.srs3d.viewer.objects.visitors.ObjectCollector;

/**
 * Menu module for executing <code>Command</code> s on the current selection.
 *
 * @author Karsten Klein
 *
 * @created May 14, 2001
 */
public class AnnotationLayoutModule extends ProcessModule {
    private JCheckBoxMenuItem component = null;
    private int checkResult = 0;
    private int layout = Alignment.FLIPPED;
    private ContextData sequenceContextData = null;

    /**
     * Constructor description.
     *
     * @param name Parameter description.
     * @param contextData Parameter description.
     * @param layout Parameter description.
     */
    public AnnotationLayoutModule(String name, ContextData contextData,
        int layout) {
        super(name, contextData);
        this.layout = layout;
    }

    /**
     * Constructor description.
     *
     * @param name Parameter description.
     * @param contextData Parameter description.
     * @param sequenceContextData Parameter description.
     * @param layout Parameter description.
     */
    public AnnotationLayoutModule(String name, ContextData contextData,
        ContextData sequenceContextData, int layout) {
        super(name, contextData);
        this.layout = layout;
        this.sequenceContextData = sequenceContextData;
    }

    /**
     * Description of the method.
     *
     * @param e Description of parameter.
     */
    public void process(ActionEvent e) {
        final ContextData contextData = getContextData();
        final ObjectManager objectManager = contextData.getObjectManager();
        ObjectCollector objectCollector =
            new ObjectCollector(new ObjectClassFilter(Alignment.class));
        AnnotationContainer annotationContainer =
            ((AnnotationContextData) getContextData()).getAnnotationContainer();
        objectCollector.visit(annotationContainer);
        Collection alignments = objectCollector.getObjects();
        ObjectManager.extract(alignments, Alignment.class);
        Iterator iterator = alignments.iterator();
        while (iterator.hasNext()) {
            ((Alignment) iterator.next()).setLayoutMode(layout);
        }
        final HashSet spawners = new HashSet();
        spawners.add(annotationContainer);
        SpawnCommand.searchSpawners(contextData, spawners);
        contextData.getContext().addUpdateCallback(new org.srs3d.viewer.j3d.behaviors.UpdateBehavior.Callback() {
                public void execute() {
                    contextData.getStrategyManager().execute(spawners,
                        new SpawnCommand(contextData));
                }
            });

        final HashSet sequenceSpawners = new HashSet();
        sequenceSpawners.add(annotationContainer);
        SpawnCommand.searchSpawners(sequenceContextData, sequenceSpawners);
        sequenceContextData.getContext().addUpdateCallback(new org.srs3d.viewer.j3d.behaviors.UpdateBehavior.Callback() {
                public void execute() {
                    contextData.getStrategyManager().execute(sequenceSpawners,
                        new SpawnCommand(sequenceContextData));
                }
            });
    }

    /**
     * Description of the method.
     */
    public void cleanup() {
        super.cleanup();
    }

    /**
     * Gets the <code>component</code> attribute of the <code>SolidRenderingModule</code>
     * object.
     *
     * @return The <code>component</code> value.
     */
    public Component getComponent() {
        update();
        return component;
    }

    /**
     * Description of the method.
     */
    public void updateIntern() {
        if (component == null) {
            component = new JCheckBoxMenuItem(getName(), false);
            component.addActionListener(this);
        }
        Alignment alignment =
            ((AnnotationContextData) getContextData()).getActiveBoxAlignment();
        component.setEnabled(alignment != null);
        if (alignment != null && component != null) {
            component.setState(alignment.getLayoutMode() == layout);
        }
    }
}
