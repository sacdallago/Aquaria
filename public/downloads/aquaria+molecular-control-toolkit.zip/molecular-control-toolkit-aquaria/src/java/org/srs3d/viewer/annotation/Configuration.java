/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.annotation;

import org.srs3d.viewer.annotation.creators.AlignmentGeometryCreator;
import org.srs3d.viewer.annotation.creators.AnnotationContainerGeometryCreator;
import org.srs3d.viewer.annotation.creators.AnnotationUnitGeometryCreator;
import org.srs3d.viewer.annotation.creators.ChainAnnotationGeometryCreator;
import org.srs3d.viewer.annotation.creators.FeatureUnitGeometryCreator;
import org.srs3d.viewer.annotation.creators.RulerGeometryCreator;
import org.srs3d.viewer.annotation.creators.SegmentGeometryCreator;
import org.srs3d.viewer.annotation.creators.SensorGeometryCreator;
import org.srs3d.viewer.annotation.objects.Alignment;
import org.srs3d.viewer.annotation.objects.AnnotationContainer;
import org.srs3d.viewer.annotation.objects.AnnotationUnit;
import org.srs3d.viewer.annotation.objects.ChainAnnotation;
import org.srs3d.viewer.annotation.objects.FeatureUnit;
import org.srs3d.viewer.annotation.objects.Ruler;
import org.srs3d.viewer.annotation.objects.Segment;
import org.srs3d.viewer.annotation.objects.strategies.AnnotationContainerStrategy;
import org.srs3d.viewer.annotation.objects.strategies.AnnotationUnitStrategy;
import org.srs3d.viewer.annotation.objects.strategies.FeatureUnitStrategy;
import org.srs3d.viewer.annotation.objects.strategies.SegmentStrategy;
import org.srs3d.viewer.annotation.objects.strategies.ZoomBoxStrategy;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.attributes.Expanded;
import org.srs3d.viewer.j3d.attributes.Visible;
import org.srs3d.viewer.j3d.creators.LabelGeometryCreator;
import org.srs3d.viewer.j3d.creators.RectangleGeometryCreator;
import org.srs3d.viewer.j3d.factories.GeometryCreatorFactory;
import org.srs3d.viewer.j3d.factories.SpawnerFactory;
import org.srs3d.viewer.j3d.objects.Sensor;
import org.srs3d.viewer.j3d.objects.strategies.LabelStrategy;
import org.srs3d.viewer.j3d.objects.strategies.SensorStrategy;
import org.srs3d.viewer.objects.Attribute;
import org.srs3d.viewer.objects.ObjectContainer;
import org.srs3d.viewer.objects.State;
import org.srs3d.viewer.objects.StatePrototypeManager;
import org.srs3d.viewer.objects.StrategyManager;

/**
 * Description of the class.
 *
 * @author Karsten Klein
 *
 * @created March 22, 2001
 */
public class Configuration {

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     */
    public static void registerGeometryCreators(ContextData contextData) {
        GeometryCreatorFactory factory =
            contextData.getGeometryCreatorFactory();
        factory.register(org.srs3d.viewer.j3d.objects.Rectangle.class,
            RectangleGeometryCreator.class);
        factory.register(org.srs3d.viewer.j3d.objects.Label.class,
            LabelGeometryCreator.class);
        factory.register(org.srs3d.viewer.j3d.objects.Sensor.class,
            SensorGeometryCreator.class);
        factory.register(AnnotationContainer.class,
            AnnotationContainerGeometryCreator.class);
        factory.register(Alignment.class, AlignmentGeometryCreator.class);
        factory.register(ChainAnnotation.class,
            ChainAnnotationGeometryCreator.class);
        factory.register(Segment.class, SegmentGeometryCreator.class);
        factory.register(AnnotationUnit.class,
            AnnotationUnitGeometryCreator.class);
        factory.register(FeatureUnit.class, FeatureUnitGeometryCreator.class);
        factory.register(Ruler.class, RulerGeometryCreator.class);
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     */
    public static void registerSpawners(ContextData contextData) {
        SpawnerFactory factory = contextData.getSpawnerFactory();
        factory.register(ObjectContainer.class);
        factory.register(AnnotationContainer.class);
        factory.register(Alignment.class);
        factory.register(org.srs3d.viewer.j3d.objects.Rectangle.class);
        factory.register(org.srs3d.viewer.j3d.objects.Label.class);
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     */
    public static void registerStrategies(ContextData contextData) {
        StrategyManager manager = contextData.getStrategyManager();
        manager.register(org.srs3d.viewer.j3d.objects.Label.class,
            new LabelStrategy());
        manager.register(org.srs3d.viewer.j3d.objects.Rectangle.class,
            new ZoomBoxStrategy());
        manager.register(org.srs3d.viewer.j3d.objects.Sensor.class,
            new SensorStrategy());
        manager.register(AnnotationContainer.class,
            new AnnotationContainerStrategy());

        //    manager.register( Alignment.class, new SegmentStrategy() );
        //    manager.register( ChainAnnotation.class, new SegmentStrategy() );
        manager.register(Segment.class, new SegmentStrategy());
        manager.register(FeatureUnit.class, new FeatureUnitStrategy());
        manager.register(AnnotationUnit.class, new AnnotationUnitStrategy());
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     */
    public static void registerPrototypes(ContextData contextData) {
        State visibleState = new State();
        visibleState.setAttribute(Attribute.getInstance(Visible.class));
        State expandedState = new State();
        expandedState.setAttribute(Attribute.getInstance(Visible.class));
        expandedState.setAttribute(Attribute.getInstance(Expanded.class));
        StatePrototypeManager manager = contextData.getStatePrototypeManager();
        manager.register(Ruler.class, visibleState);
        manager.register(Sensor.class, visibleState);
        manager.register(ObjectContainer.class, expandedState);
        manager.register(AnnotationContainer.class, expandedState);
        manager.register(Alignment.class, expandedState);
        manager.register(ChainAnnotation.class, expandedState);
        manager.register(AnnotationUnit.class, expandedState);
        manager.register(org.srs3d.viewer.bioatlas.objects.Annotation.class,
            expandedState);
        manager.register(org.srs3d.viewer.j3d.objects.Rectangle.class,
            visibleState);
        manager.register(Segment.class, visibleState);
        manager.register(FeatureUnit.class, visibleState);
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     */
    public static void configure(ContextData contextData) {
        registerGeometryCreators(contextData);
        registerSpawners(contextData);
        registerPrototypes(contextData);
        registerStrategies(contextData);
    }
}
