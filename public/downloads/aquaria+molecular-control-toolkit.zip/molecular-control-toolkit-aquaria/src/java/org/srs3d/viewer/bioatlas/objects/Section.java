/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.objects;


/**
 * Special <code>AbstractObject</code> implementation defining a <code>Tile </code>. The
 * implementation contains only the intrinsic data of the object.
 *
 * @author Karsten Klein
 *
 * @created March 28, 2001
 */
public final class Section extends Subchain {

    /** Description of the field. */
    public static final char CODE = 'Z';

    /**
     * Gets the <code>Code</code> attribute of the <code>Coil</code> object.
     *
     * @return The <code>Code</code> value.
     */
    public char getCode() {
        return CODE;
    }

    /**
     * Description of the method.
     *
     * @return Description of the returned value.
     */
    public String toString() {
        String string = new String("Section");
        string += super.toString();
        return string;
    }
}
