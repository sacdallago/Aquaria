/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.visitors;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;

import javax.vecmath.Vector3f;

import org.srs3d.viewer.bioatlas.filters.BackboneAtomFilter;
import org.srs3d.viewer.bioatlas.objects.Chain;
import org.srs3d.viewer.bioatlas.objects.ChainFragment;
import org.srs3d.viewer.bioatlas.objects.Compound;
import org.srs3d.viewer.bioatlas.objects.Residue;
import org.srs3d.viewer.bioatlas.objects.Site;
import org.srs3d.viewer.bioatlas.objects.templates.ResidueTemplate;
import org.srs3d.viewer.objects.ObjectContainer;
import org.srs3d.viewer.objects.ObjectFilter;
import org.srs3d.viewer.objects.ObjectManager;

/**
 * This class checks all chains of an <code>ObjectContainer</code> . Chemical criteria,
 * such as distance measures and ligand/nucleic acid/amino acid classifications is used
 * to split chains.
 *
 * @author Karsten Klein
 *
 * @created March 28, 2001
 */
public class ChainAnalyser {
    private static final float MAX_NUCELIC_ACID_RESIDUE_DISTANCE = 8.0f;
    private static final float MAX_AMINO_ACID_RESIDUE_DISTANCE = 4.2f;

    /**
     * Extracts all the chains from the container and calls visit( Chain ).
     *
     * @param objectContainer ObjectContainter to visit.
     */
    public void visit(ObjectContainer objectContainer) {
        Collection chains = new ArrayList();
        Collection newChains = new ArrayList();
        HashSet compounds = new HashSet();
        ObjectManager.extract(objectContainer.getObjects(), chains, Chain.class);
        ObjectManager.extract(objectContainer.getObjects(), compounds,
            Compound.class);
        Iterator iterator = chains.iterator();
        while (iterator.hasNext()) {
            visit((Chain) iterator.next(), objectContainer);
        }

        // update chain list
        chains = new ArrayList();
        ObjectManager.extract(objectContainer.getObjects(), chains, Chain.class);

        // after the splitting we assign the compound records
        iterator = chains.iterator();
        Iterator compoundIterator;
        Chain chain;
        Compound compound;
        while (iterator.hasNext()) {
            chain = (Chain) iterator.next();

            // we need to do that here for appropriate isLigandCheck()
            // :FIXME: isLigand() should be dependent on updateExceptionalResidues()
            chain.updateExceptionalResidues();
            if (chain.isLigand()) {
                chain.setCompound(null);
            } else {
                compoundIterator = compounds.iterator();
                while (compoundIterator.hasNext()) {
                    compound = (Compound) compoundIterator.next();
                    if (compound.getChainIds().contains("" + chain.getId())) {
                        chain.setCompound(compound);
                    }
                }
            }
            chain.updateBonds();
        }
    }

    /**
     * Description of the method.
     *
     * @param chain Description of parameter.
     * @param container Description of parameter.
     */
    public void visit(Chain chain, ObjectContainer container) {
        Residue residue = chain.getInitialResidue();
        Residue proceeding;
        Residue limit = chain.getEndResidue().getProceeding();
        boolean split = false;
        chain.update();
        ChainFragment chainFragment =
            (ChainFragment) chain.getChainFragments().get(0);
        Collection subchains = new ArrayList(chain.getSubchains());
        while (residue != null && residue != limit) {
            proceeding = residue.getProceeding();
            if (proceeding != null) {
                if (!isConnected(residue, proceeding, chain)) {
                    if (chain.containsLigandResidues()) {

                        // create subsequent chain
                        Chain newChain = new Chain();
                        newChain.setId(chain.getId());
                        newChain.setInitialResidue(proceeding);
                        newChain.setEndResidue(chainFragment.getEndResidue());

                        // forward additional attributes to the new chain
                        newChain.setExceptionalResidues(new HashSet(
                                chain.getExceptionalResidues()));
                        newChain.addSubchains(subchains);
                        chainFragment.setEndResidue(residue);
                        chain.setEndResidue(residue);
                        newChain.update();
                        container.addObject(newChain);
                        chain.getEndResidue().setProceeding(null);
                        newChain.getInitialResidue().setPreceeding(null);

                        // proceed analysis with new chain
                        chain = newChain;
                        chainFragment =
                            (ChainFragment) chain.getChainFragments().get(0);
                    } else {
                        ChainFragment newChainFragment = new ChainFragment();
                        newChainFragment.setExceptionalResidues(chain.getExceptionalResidues());
                        newChainFragment.setId(chain.getId());
                        newChainFragment.setSerial(chainFragment.getSerial() +
                            1);
                        newChainFragment.setInitialResidue(proceeding);
                        newChainFragment.setEndResidue(chain.getEndResidue());
                        chainFragment.setEndResidue(residue);

                        // forward additional attributes to the new chain
                        // copy full secondary structure annotation
                        newChainFragment.getSubchains().addAll(subchains);
                        newChainFragment.update();
                        chain.getChainFragments().add(newChainFragment);

                        // we do some additional stuff in this block, to highlight this
                        // particular residue
                        if (chainFragment.getLength() == 1 &&
                              !chainFragment.getInitialResidue().isLigand()) {

                            // create a site to assure residue expansion
                            Site site = new Site();
                            site.setContentType(Site.EXCEPTIONAL_RESIDUES);
                            site.setName("Exceptional");
                            site.setId(1);
                            site.addResidue(chainFragment.getInitialResidue());
                            site.update();
                            container.addObject(site);
                        }

                        // proceed analysis with new chain
                        chainFragment = newChainFragment;
                    }
                }
            }
            residue = proceeding;
        }
    }

    /**
     * Checks the connection criteria between two residues. The distance citerai is as
     * follows: 1) if one of the two residues is exceptional or a ligand residue, we
     * return true if both residues are water residues (ligand case) or if they have two
     * atoms (one each) with overlapping covalent radii. 2) if none of the two residue
     * is ligand residue or marked as exceptional we use a CA or rather a P distance
     * criteria for connectivity determination. Note that the getCoordinate() method of
     * the residue prioritizes in the order CA/P, avaraged coordinate (eg. in case no CA
     * is available the weighted center of the residue will be used).
     *
     * @param residue First residue.
     * @param proceeding Second residue.
     * @param chain Chain of the residues. The chain is needed to determine exceptional
     *        residues.
     *
     * @return <code>true</code> if the residues are connected.
     */
    public static final boolean isConnected(Residue residueA, Residue residueB,
        Chain chain) {
        if (residueA.isLigand() || residueB.isLigand() ||
              chain.isExceptionalResidue(residueA) ||
              chain.isExceptionalResidue(residueB)) {
            if (residueA.getTemplate() == residueB.getTemplate()) {

                // water is stored in one chain; therefore it always gives true
                if (residueA.getTemplate().isWater()) {
                    return true;
                }
            } else {
                if (residueB.getTemplate().isWater() ||
                      residueA.getTemplate().isWater()) {
                    return false;
                }
            }
            return isCovalentlyConnected(residueA, residueB);
        } else {
            return isConnected(residueA, residueB);
        }
    }

    /**
     * Method description.
     *
     * @param residueA Parameter description.
     * @param residueB Parameter description.
     *
     * @return Return description.
     */
    public static final boolean isCovalentlyConnected(Residue residueA,
        Residue residueB) {
        return BondCreator.isConnected(residueA.getAtoms(), residueB.getAtoms());
    }

    /**
     * Method description.
     *
     * @param residueA Parameter description.
     * @param residueB Parameter description.
     *
     * @return Return description.
     */
    public static final boolean isBackboneCovalentlyConnected(
        Residue residueA, Residue residueB) {
        ObjectFilter filter = new BackboneAtomFilter();
        AtomCollector atomCollectorA = new AtomCollector(filter);
        atomCollectorA.visit(residueA);
        return BondCreator.isConnected(atomCollectorA.getObjects(),
            residueB.getAtoms());
    }

    /**
     * Gets the <code>connected</code> attribute of the <code>ChainAnalyser</code> class.
     *
     * @param residue Description of parameter.
     * @param proceeding Description of parameter.
     *
     * @return The <code>connected</code> value.
     */
    public static final boolean isConnected(Residue residueA, Residue residueB) {
        if (residueA != null && residueB != null) {
            ResidueTemplate templateA = residueA.getTemplate();
            ResidueTemplate templateB = residueB.getTemplate();
            Vector3f vector = new Vector3f();

            // check distance criteria
            if (templateA.isAminoAcid() && templateB.isAminoAcid()) {
                vector.set(residueA.getCoordinate());
                vector.sub(residueB.getCoordinate());

                // we use 8 angstroem for amino acid distance
                return vector.lengthSquared() < MAX_AMINO_ACID_RESIDUE_DISTANCE * MAX_AMINO_ACID_RESIDUE_DISTANCE;
            } else {
                if (templateA.isNucleicAcid() && templateB.isNucleicAcid()) {
                    vector.set(residueA.getCoordinate());
                    vector.sub(residueB.getCoordinate());

                    // we use 4.2 angstroem for nucleic acid distance
                    return vector.lengthSquared() < MAX_NUCELIC_ACID_RESIDUE_DISTANCE * MAX_NUCELIC_ACID_RESIDUE_DISTANCE;
                }
            }
            return isBackboneCovalentlyConnected(residueA, residueB);
        }
        return false;
    }
}
