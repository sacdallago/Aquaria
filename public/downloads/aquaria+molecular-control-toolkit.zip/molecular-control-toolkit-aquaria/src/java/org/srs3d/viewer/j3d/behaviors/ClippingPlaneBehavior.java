/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.behaviors;

import java.awt.event.MouseEvent;

import javax.media.j3d.ModelClip;
import javax.media.j3d.WakeupOnAWTEvent;
import javax.media.j3d.WakeupOr;
import javax.vecmath.Vector4d;

import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.objects.Box;

/**
 * The class <code>ClippingPlaneBehavior</code> represents a specialized
 * <code>MouseBehavior</code> that manipulates planes.
 *
 * @author Karsten Klein
 *
 * @created November 20, 2000
 */
public class ClippingPlaneBehavior extends MouseBehavior {

    /** Description of the field */
    public static final int HORIZONTAL = 0;

    /** Description of the field */
    public static final int VERTICAL = 1;

    /** Description of the field */
    private ClippingPlaneBehaviorCallback callback = null;

    /** Description of the field */
    private ModelClip modelClip = null;

    /** Description of the field */
    private int planeIndex = -1;

    /** Description of the field */
    private float direction = 1;

    /** Description of the field */
    private Box boundingBox = null;

    /** Description of the field */
    private int mouseButtonMask = MouseEvent.BUTTON1_MASK;

    /** Description of the field */
    private int mode = 0;

    /** Integers used for saving the mouse positions */
    private int lastX;

    /** Integers used for saving the mouse positions */
    private int x;

    /** Description of the field */
    private int lastY;

    /** Description of the field */
    private int y;

    /**
     * <code>ClippingPlaneBehavior</code> contructor.
     *
     * @param contextData Description of parameter.
     */
    public ClippingPlaneBehavior(ContextData contextData) {
        super(contextData);
    }

    /**
     * Sets the <code>PlaneIndex</code> attribute of the
     * <code>ClippingPlaneBehavior</code> object.
     *
     * @param planeIndex The new <code>PlaneIndex</code> value.
     */
    public void setPlaneIndex(int planeIndex) {
        this.planeIndex = planeIndex;
    }

    /**
     * Sets the <code>Mode</code> attribute of the <code>ClippingPlaneBehavior
     * </code>object.
     *
     * @param mode The new <code>Mode</code> value.
     */
    public void setMode(int mode) {
        this.mode = mode;
    }

    /**
     * Sets the <code>ModelClip</code> attribute of the
     * <code>ClippingPlaneBehavior</code> object.
     *
     * @param modelClip The new <code>ModelClip</code> value.
     */
    public void setModelClip(ModelClip modelClip) {
        this.modelClip = modelClip;
    }

    /**
     * Sets the <code>Direction</code> attribute of the
     * <code>ClippingPlaneBehavior</code> object.
     *
     * @param direction The new <code>Direction</code> value.
     */
    public void setDirection(float direction) {
        this.direction = direction;
    }

    /**
     * Sets the <code>MouseButtonMask</code> attribute of the
     * <code>ClippingPlaneBehavior</code> object.
     *
     * @param mouseButtonMask The new <code>MouseButtonMask</code> value.
     */
    public void setMouseButtonMask(int mouseButtonMask) {
        this.mouseButtonMask = mouseButtonMask;
    }

    /**
     * Sets the <code>Callback</code> attribute of the <code>ClippingPlaneBehavior</code>
     * object.
     *
     * @param callback The new <code>Callback</code> value.
     */
    public void setCallback(ClippingPlaneBehaviorCallback callback) {
        this.callback = callback;
    }

    /**
     * Initializes the wakeup conditions for the behavior.
     */
    public void initialize() {
        WakeupOnAWTEvent[] conditions = new WakeupOnAWTEvent[2];

        // set wakeup condition (waiting for further dragging events)
        conditions[0] = new WakeupOnAWTEvent(MouseEvent.MOUSE_DRAGGED);
        conditions[1] = new WakeupOnAWTEvent(MouseEvent.MOUSE_PRESSED);
        wakeupOn(new WakeupOr(conditions));
    }

    /**
     * Processes the mouseEvent. This will directly result in a modification of the
     * viewingPlatform in the activated <code>Context</code> , if the according
     * conditions are met by the mouse event.
     *
     * @param mouseEvent Description of parameter.
     */
    public void processStimulus(MouseEvent mouseEvent) {
        lastX = x;
        lastY = y;
        x = mouseEvent.getX();
        y = mouseEvent.getY();
        if (checkCriteria(mouseEvent) && modelClip != null) {

            // modify appropriate plane of the modelClip instance
            Vector4d plane = new Vector4d();
            modelClip.getPlane(planeIndex, plane);
            if (mode == HORIZONTAL) {
                plane.w += direction * (lastX - x);
            } else if (mode == VERTICAL) {
                plane.w += direction * (lastY - y);
            } else {
                plane.w += direction * (lastX - x);
                plane.w += direction * (lastY - y);
            }
            modelClip.setPlane(planeIndex, plane);
            if (callback != null) {
                callback.clippingPlaneChanged();
            }
        }
    }

    /**
     * This method checks the mouseEvent (fail early, fail fast)
     *
     * @param mouseEvent the mouse event to validate.
     *
     * @return <code>true</code> if the mouse event is meant to adjust the clipping
     *         plane.
     */
    protected boolean checkCriteria(MouseEvent mouseEvent) {
        if (mouseEvent.getID() == MouseEvent.MOUSE_DRAGGED) {
            if (mouseEvent.isShiftDown()) {
                if (mouseEvent.isControlDown()) {
                    if ((mouseEvent.getModifiers() & mouseButtonMask) != 0) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    /**
     * Description of the class.
     *
     * @author Karsten Klein
     *
     * @created March 30, 2001
     */
    public interface ClippingPlaneBehaviorCallback {

        /**
         * Description of the method.
         */
        public void clippingPlaneChanged();
    }
}
