/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Vector;

import javax.media.j3d.Appearance;

import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.util.Log;

/**
 * A <code>ColorSchemeBucket</code> if defined by a list of colorschemes. Rather than
 * applying a set of colorschemes to an object you can create a ColorSchemeBucket and
 * modify the appearance of an object by applying the ColorSchemeBucket. Moreover the
 * ColorSchemeBucket extends several methods of the colorscheme class. The information
 * of the colorschemes are combined in a certain manner. The colorschemes in the bucket
 * are managed efectively in terms of optimizing the correnct assignment of colors (e.g.
 * no double assignment of the same colorscheme).
 *
 * @author Karsten Klein
 *
 * @created July 30, 2001
 */
public class ColorSchemeBucket extends Vector {
    private static final Log log = new Log(ColorSchemeBucket.class);

    /** If true the colorschemes are cleared once a complete one is added. */
    private boolean canClear = true;
    private boolean isLocked = false;

    /**
     * <code>ColorSchemeBucket</code> constructor.
     *
     * @param colorScheme Description of parameter.
     */
    public ColorSchemeBucket(ColorScheme colorScheme) {
        if (colorScheme != null) {
            extend(colorScheme);
        }
    }

    /**
     * <code>ColorSchemeBucket</code> constructor.
     *
     * @param colorSchemeBucket Description of parameter.
     */
    public ColorSchemeBucket(ColorSchemeBucket colorSchemeBucket) {
        if (colorSchemeBucket != null) {
            extend(colorSchemeBucket);
        }
    }

    /**
     * <code>ColorSchemeBucket</code> constructor.
     */
    public ColorSchemeBucket() {
    }

    /**
     * Sets the <code>removing</code> attribute of the <code>ColorSchemeBucket</code>
     * object.
     *
     * @param canClear The new <code>removing</code> value.
     */
    public void setRemoving(boolean canClear) {
        this.canClear = canClear;
    }

    /**
     * Gets the <code>complete</code> attribute of the <code>ColorSchemeBucket</code>
     * object.
     *
     * @return The <code>complete</code> value.
     */
    public boolean isComplete() {
        if (!isEmpty()) {
            if (firstElement() != null) {
                return ((ColorScheme) firstElement()).isComplete();
            }
        }
        return false;
    }

    /**
     * Gets the <code>vertexBased</code> attribute of the <code>ColorSchemeBucket</code>
     * object.
     *
     * @return The <code>vertexBased</code> value.
     */
    public boolean isVertexBased() {
        int size = size();
        if (size > 0) {
            for (int i = 0; i < size; i++) {
                if (((ColorScheme) elementAt(i)).isVertexBased()) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Gets the <code>information</code> attribute of the <code>ColorSchemeBucket</code>
     * object.
     *
     * @param map Description of parameter.
     *
     * @return The <code>information</code> value.
     */
    public Map getInformation(Map map) {
        Vector composedOrder = null;
        Vector order;
        String composedName = new String();
        String name;
        if (map == null) {
            map = new HashMap();
        }
        composedOrder = (Vector) map.get("ORDER");
        if (composedOrder == null) {
            composedOrder = new Vector();
        }
        int size = size();
        ColorScheme colorScheme;
        for (int i = 0; i < size; i++) {
            colorScheme = ((ColorScheme) elementAt(i));
            if (colorScheme.hasInformation()) {
                map = colorScheme.getInformation(map);
                name = (String) map.get("NAME");
                if (name != null) {
                    if (composedName.length() > 0) {
                        composedName += "/";
                    }
                    composedName += name;
                }
                order = (Vector) map.get("ORDER");
                if (order != null) {
                    composedOrder.removeAll(order);
                    composedOrder.addAll(order);
                }
            }
        }
        map.put("ORDER", composedOrder);
        map.put("NAME", composedName);
        return map;
    }

    /**
     * Gets the <code>baseColorScheme</code> attribute of the
     * <code>ColorSchemeBucket</code> object.
     *
     * @return The <code>baseColorScheme</code> value.
     */
    public ColorScheme getBaseColorScheme() {
        if (size() > 0) {
            return (ColorScheme) firstElement();
        } else {
            return null;
        }
    }

    /**
     * Description of the method.
     *
     * @param object Description of parameter.
     * @param appearance Description of parameter.
     *
     * @return Description of the returned value.
     */
    public boolean modify(AbstractObject object, Appearance appearance) {
        ColorScheme colorScheme;
        boolean isModified = false;
        int size = size();
        for (int i = 0; i < size; i++) {
            colorScheme = (ColorScheme) elementAt(i);
            isModified |= colorScheme.modify(object, appearance);
        }
        return isModified;
    }

    /**
     * Description of the method.
     *
     * @param colorScheme Description of parameter.
     */
    public void extend(ColorScheme colorScheme) {
        if (!isLocked) {
            if (colorScheme.isComplete() && canClear) {
                clear();
            }
            if (!isEmpty()) {
                if (lastElement() != colorScheme) {
                    remove(colorScheme);
                    add(colorScheme);
                }
            } else {
                add(colorScheme);
            }
        } else {
            log.debug("trying to extend locked color scheme bucket.");
        }
    }

    /**
     * Method description.
     *
     * @param bucket Parameter description.
     */
    public void remove(ColorSchemeBucket bucket) {
        if (!isLocked) {
            Iterator iterator = bucket.iterator();
            Object object;
            while (iterator.hasNext()) {
                object = iterator.next();
                remove(object);
            }
        } else {
            log.debug("trying to remove from locked color scheme bucket.");
        }
    }

    /**
     * Description of the method.
     *
     * @param colorSchemeBucket Description of parameter.
     */
    public void extend(ColorSchemeBucket colorSchemeBucket) {
        if (!isLocked) {
            if (colorSchemeBucket != null) {
                if (colorSchemeBucket.isComplete() && canClear) {
                    clear();
                    addAll(colorSchemeBucket);
                } else {
                    for (int i = 0; i < colorSchemeBucket.size(); i++) {
                        extend((ColorScheme) colorSchemeBucket.elementAt(i));
                    }
                }
            }
        } else {
            log.debug("trying to extend locked color scheme bucket.");
        }
    }

    /**
     * Method description.
     *
     * @param isLocked Parameter description.
     */
    public void setLocked(boolean isLocked) {
        this.isLocked = isLocked;
    }
}
