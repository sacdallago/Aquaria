/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.annotation.visitors;

import org.srs3d.viewer.annotation.objects.Segment;
import org.srs3d.viewer.bioatlas.objects.Subchain;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.objects.ObjectContainer;
import org.srs3d.viewer.objects.visitors.AbstractVisitor;

/**
 * This class provides the methods to create the <code>Segment</code> instances from an
 * <code>Chain</code> . The segments represent the secondary structure e.g.
 *
 * @author Christian Zofka, 06/2001
 *
 * @created July 08, 2001
 */
public class SegmentCreator extends AbstractVisitor {

    /** Description of the field. */
    private Segment segment = null;

    /**
     * Gets the <code>segment</code> attribute of the <code>SegmentCreator</code> object.
     *
     * @return The <code>segment</code> value.
     */
    public Segment getSegment() {
        return segment;
    }

    /**
     * Description of the method.
     *
     * @param object Description of parameter.
     */
    public void visit(ObjectContainer object) {
        super.visit((ObjectContainer) object);
    }

    /**
     * Description of the method.
     *
     * @param object Description of parameter.
     */
    public void visit(AbstractObject object) {
        if (object instanceof Subchain) {
            visit((Subchain) object);
        }
        if (object instanceof ObjectContainer) {
            visit((ObjectContainer) object);
        }
    }

    /**
     * Visits a chain. Automatically creates segments for <code>Subchain</code>
     * instances.
     *
     * @param subchain Description of parameter.
     */
    public void visit(Subchain subchain) {
        segment = new Segment(subchain);
    }
}
