/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.modules;

import java.awt.event.ActionEvent;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;

import javax.swing.JMenuItem;
import javax.vecmath.Point3f;
import javax.vecmath.Vector3f;

import org.srs3d.viewer.bioatlas.objects.Atom;
import org.srs3d.viewer.bioatlas.objects.Layer;
import org.srs3d.viewer.bioatlas.visitors.AtomCollector;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.Selection;
import org.srs3d.viewer.j3d.commands.ColorCommand;
import org.srs3d.viewer.j3d.commands.ComputeCenterCommand;
import org.srs3d.viewer.j3d.commands.ExpandCommand;
import org.srs3d.viewer.j3d.commands.SpawnCommand;
import org.srs3d.viewer.j3d.commands.VisibleCommand;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.objects.ObjectManager;
import org.srs3d.viewer.objects.Operation;
import org.srs3d.viewer.objects.StrategyManager;
import org.srs3d.viewer.objects.visitors.ObjectLocalizer;
import org.srs3d.viewer.visualization.AtomVolume;
import org.srs3d.viewer.visualization.Cuboid;
import org.srs3d.viewer.visualization.Sphere;
import org.srs3d.viewer.visualization.Subspace;

/**
 * <code>Module</code> implementation expanding and selecting the proximity of the
 * current selection.
 *
 * @author Karsten Klein
 *
 * @created May 14, 2001
 */
public class ProximityModule extends ProcessModule {
    private float radius;

    /**
     * <code>ProximityModule</code> constructor.
     *
     * @param name Description of parameter.
     * @param radius Description of parameter.
     * @param contextData Description of parameter.
     */
    public ProximityModule(String name, ContextData contextData, float radius) {
        super(name, contextData, true, true);
        this.radius = radius;
    }

    /**
     * Description of the method.
     *
     * @param e Description of parameter.
     */
    public void process(ActionEvent e) {
        final ContextData contextData = getContextData();
        getContextData().getContext().addUpdateCallback(new org.srs3d.viewer.j3d.behaviors.UpdateBehavior.Callback() {
                public void execute() {
                    Selection selection =
                        contextData.getSelectionManager().getSelection();
                    getComputation().setDescription("Computing atom proximity...");
                    Collection atoms =
                        computeAtomProximity(contextData, selection, radius);
                    getComputation().setDescription("Creating geometry...");
                    getComputation().setProgress(20);
                    expandAtomProximity(contextData, atoms, true);

                    // select atoms in the proximity
                    selection.clear();
                    getComputation().setDescription("Updating selection...");
                    getComputation().setProgress(80);
                    Operation operation =
                        new Operation(contextData.getContext(),
                            "TRANSFER_SELECTION", null);
                    operation.setSerializable(false);
                    operation.setObjects(atoms);
                    contextData.getDispatcher().runDispatch(operation);
                }
            });
    }

    /**
     * Description of the method.
     */
    public void updateIntern() {
        Selection selection =
            getContextData().getSelectionManager().getSelection();
        JMenuItem menuItem = (JMenuItem) getComponent();
        if (selection != null) {
            menuItem.setEnabled(!selection.isEmpty());
        } else {
            menuItem.setEnabled(false);
        }
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     * @param objects Description of parameter.
     * @param radius Description of parameter.
     *
     * @return Description of the returned value.
     */
    public static Collection computeAtomProximity(ContextData contextData,
        Collection objects, float radius) {
        Collection filteredAtoms = new HashSet();
        ObjectManager objectManager = contextData.getObjectManager();
        AtomCollector atomCollector = new AtomCollector();
        atomCollector.visit(objects);
        Collection subset = atomCollector.getObjects();
        if (subset.size() > 0) {
            AtomCollector globalAtomCollector = new AtomCollector();
            globalAtomCollector.visit((AbstractObject) contextData.getObjectContainer());
            Collection atoms = globalAtomCollector.getObjects();
            Point3f center = atomCollector.getCenter();
            Vector3f extend = atomCollector.getExtend();
            extend.add(new Point3f(3 + radius, 3 + radius, 3 + radius));
            Cuboid cuboid = new Cuboid();
            cuboid.setCoordinate(center);
            cuboid.setExtend(extend.length() * 0.866f); // sqrt( 3 ) / 2
            Subspace subspace = new Subspace(cuboid);
            Subspace bufferSubspace = new Subspace(cuboid);
            int counter = 0;
            Iterator iterator = atoms.iterator();
            AtomVolume atomVolume;
            Atom atom;
            while (iterator.hasNext()) {
                atom = (Atom) iterator.next();
                if (!subset.contains(atom)) {
                    atomVolume = new AtomVolume(atom, 0);
                    subspace.addElement(atomVolume);
                    counter++;
                }
            }
            subspace.subdivide(7);
            Collection proximityVolumes = new HashSet();
            iterator = subset.iterator();
            Atom candidate;
            float distance;
            float dummy;
            Vector3f vector = new Vector3f();
            while (iterator.hasNext()) {
                atom = (Atom) iterator.next();
                atomVolume = new AtomVolume(atom, radius);
                proximityVolumes.clear();
                subspace.collectCandidates(atomVolume, proximityVolumes);
                Iterator volumeIterator = proximityVolumes.iterator();
                Iterator subsetIterator;
                while (volumeIterator.hasNext()) {
                    candidate =
                        (Atom) ((AtomVolume) volumeIterator.next()).getAtom();
                    distance = Float.MAX_VALUE;
                    vector.set(atom.getCoordinate());
                    vector.sub(candidate.getCoordinate());
                    distance = vector.length();
                    if (distance <= radius) {
                        filteredAtoms.add(candidate);
                    }
                }
            }
        } else {
            ComputeCenterCommand command =
                new ComputeCenterCommand(contextData);
            contextData.getStrategyManager().execute(objects, command);
            Point3f center = command.getCenter();

            //      Vector3f extend = command.getExtend();
            //      float size = Math.max( extend.x, Math.max( extend.y, extend.z ) );
            Sphere volume = new Sphere();
            volume.setCoordinate(center);
            volume.setRadius(radius);
            AtomCollector globalAtomCollector = new AtomCollector();
            globalAtomCollector.visit((AbstractObject) contextData.getObjectContainer());
            Iterator iterator = globalAtomCollector.getObjects().iterator();
            Atom atom;
            while (iterator.hasNext()) {
                atom = (Atom) iterator.next();
                if (volume.intersects(atom.getCoordinate(), 0)) {
                    filteredAtoms.add(atom);
                }
            }
        }
        return filteredAtoms;
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     * @param atoms Description of parameter.
     *
     * @return Description of the returned value.
     */
    public static Collection computeRelatedObjects(ContextData contextData,
        Collection atoms) {
        ObjectManager objectManager = contextData.getObjectManager();
        Collection objects = null;
        if (atoms.size() != 0) {
            Collection layers = new HashSet();
            ObjectManager.extract(contextData.getObjectContainer().getObjects(),
                layers, Layer.class);
            StructureModule.filterSequenceLayers(layers);
            AtomCollector globalAtomCollector = new AtomCollector();
            globalAtomCollector.visit(layers);
            ObjectLocalizer objectLocalizer = new ObjectLocalizer();
            objectLocalizer.setObjects(new HashSet());

            // the objectLocalizer accumulates all the objects related to the
            // proximity atoms (upward direction)
            objectLocalizer.localize(atoms, layers);
            objects = objectLocalizer.getObjects();
        }
        return objects;
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     * @param atoms Description of parameter.
     */
    public static void expandAtomProximity(ContextData contextData,
        Collection atoms, boolean asBallAndStick) {
        ObjectManager objectManager = contextData.getObjectManager();
        StrategyManager strategyManager = contextData.getStrategyManager();
        Collection relatedObjects = computeRelatedObjects(contextData, atoms);
        if (relatedObjects != null && !relatedObjects.isEmpty()) {
            HashSet modifiedObjects = new HashSet();

            // expand parents
            ExpandCommand expandCommand =
                new ExpandCommand(contextData, true, true);
            VisibleCommand visibleCommand =
                new VisibleCommand(contextData, true);
            expandCommand.setModifiedObjects(modifiedObjects);
            visibleCommand.setModifiedObjects(modifiedObjects);
            strategyManager.execute(relatedObjects, expandCommand);
            strategyManager.execute(relatedObjects, visibleCommand);
            if (!modifiedObjects.isEmpty()) {

                // spawn the geometry
                SpawnCommand.searchSpawners(contextData, modifiedObjects);
                SpawnCommand spawn = new SpawnCommand(contextData);
                strategyManager.execute(modifiedObjects, spawn);

                // color all expanded; searchSpawers collapsed relatedObjects!
                ColorCommand colorCommand = new ColorCommand(contextData);
                colorCommand.propagate(modifiedObjects, false);
            }
        }
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public String getModuleIdPrefix() {
        return "EXECUTE-";
    }
}
