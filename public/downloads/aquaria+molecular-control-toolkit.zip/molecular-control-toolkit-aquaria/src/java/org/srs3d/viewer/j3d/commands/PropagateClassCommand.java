/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.commands;

import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.objects.Command;

/**
 * Show command.
 *
 * @author Karsten Klein
 *
 * @created April 03, 2001
 */
public class PropagateClassCommand extends PropagateCommand {
    private Class objectClass = null;

    /**
     * Constructor description.
     *
     * @param contextData Parameter description.
     * @param command Parameter description.
     * @param objectClass Parameter description.
     */
    public PropagateClassCommand(ContextData contextData, Command command,
        Class objectClass) {
        super(contextData, command);
        this.objectClass = objectClass;
    }

    /**
     * Method description.
     */
    public void execute() {
        getContextData().getStrategyManager().propagate(getObject(),
            getCommand(), objectClass);
    }
}
