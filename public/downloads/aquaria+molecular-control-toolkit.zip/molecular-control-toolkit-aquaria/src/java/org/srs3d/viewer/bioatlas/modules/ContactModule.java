/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.modules;

import java.awt.event.ActionEvent;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;

import javax.vecmath.Point3f;
import javax.vecmath.Vector3f;

import org.srs3d.viewer.bioatlas.colorschemes.MonochromeColorScheme;
import org.srs3d.viewer.bioatlas.objects.Atom;
import org.srs3d.viewer.bioatlas.visitors.AtomCollector;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.Selection;
import org.srs3d.viewer.j3d.commands.ColorCommand;
import org.srs3d.viewer.j3d.commands.RegisterCommand;
import org.srs3d.viewer.j3d.commands.SpawnCommand;
import org.srs3d.viewer.objects.ObjectContainer;
import org.srs3d.viewer.objects.ObjectManager;
import org.srs3d.viewer.objects.StrategyManager;
import org.srs3d.viewer.util.Log;
import org.srs3d.viewer.visualization.AtomVolume;
import org.srs3d.viewer.visualization.Cuboid;
import org.srs3d.viewer.visualization.Subspace;

/**
 * @author Karsten Klein
 *
 * @created May 14, 2001
 */
public class ContactModule extends ProcessModule {
    private static final Log log = new Log(ContactModule.class);
    public static final float THRESHOLD = 2.5f;
    public static final float COVALENT_THRESHOLD = 1.2f;
    public static final float VANDERWAALS_THRESHOLD = -0.2f;

    /**
     * <code>DistanceModule</code> constructor.
     *
     * @param name Description of parameter.
     * @param contextData Description of parameter.
     */
    public ContactModule(String name, ContextData contextData) {
        super(name, contextData, true, true);
    }

    /**
     * Description of the method.
     *
     * @param e Description of parameter.
     */
    public void process(ActionEvent e) {
        final ContextData contextData = getContextData();
        Selection selection = contextData.getSelectionManager().getSelection();
        HashSet atoms = new HashSet();
        HashSet bufferAtoms = new HashSet();
        extractContactCandidates(contextData, selection, atoms, bufferAtoms);
        bufferAtoms.removeAll(atoms);
        if (!atoms.isEmpty()) {
            getComputation().setDescription("Identifying Atoms");
            ObjectManager objectManager = contextData.getObjectManager();
            final StrategyManager strategyManager =
                contextData.getStrategyManager();
            Collection set = new HashSet(selection.size());
            objectManager.collapseUp(selection, set);
            Collection roots = new HashSet(set);
            objectManager.getUpAssociations(set, roots);
            ObjectManager.extract(roots, ObjectContainer.class);
            if (!roots.isEmpty()) {
                final ObjectContainer root =
                    (ObjectContainer) roots.iterator().next();
                if (!atoms.isEmpty()) {
                    if (!bufferAtoms.isEmpty()) {
                        Iterator atomIterator = atoms.iterator();
                        Iterator bufferAtomIterator;
                        Atom atomA;
                        Atom atomB;
                        Vector3f vector = new Vector3f();
                        float distance;
                        float covalentDistance;
                        float vdwDistance;
                        final Collection createdContainers = new HashSet();
                        final Collection contactAtoms = new HashSet();
                        getComputation().setDescription("Searching Contacts");
                        float progress = 0;
                        float deltaProgress = 100.0f / atoms.size();
                        while (atomIterator.hasNext()) {
                            getComputation().setProgress((int) progress);
                            progress += deltaProgress;
                            atomA = (Atom) atomIterator.next();
                            bufferAtomIterator = bufferAtoms.iterator();
                            while (bufferAtomIterator.hasNext()) {
                                atomB = (Atom) bufferAtomIterator.next();
                                vector.set(atomA.getCoordinate());
                                vector.sub(atomB.getCoordinate());
                                distance = vector.length();

                                //                covalentDistance = distance - atomA.getCovalentRadius();
                                //                covalentDistance -= atomB.getCovalentRadius();
                                vdwDistance =
                                    distance - atomA.getVanDerWaalsRadius();
                                vdwDistance -= atomB.getVanDerWaalsRadius();

                                //                if ( covalentDistance < COVALENT_THRESHOLD ) {
                                //                if ( distance < THRESHOLD ) {
                                if (vdwDistance < VANDERWAALS_THRESHOLD) {
                                    Point3f center =
                                        new Point3f(atomA.getCoordinate());
                                    center.add(atomB.getCoordinate());
                                    center.scale(0.5f);

                                    // 2 decimals accurarcy
                                    distance = ((float) ((int) (distance * 100)) / 100);
                                    ObjectContainer distanceContainer =
                                        new ObjectContainer();
                                    distanceContainer.setName("Distance " +
                                        atomA.getTemplate().getElement() + "-" +
                                        atomB.getTemplate().getElement() + "(" +
                                        distance + ")");
                                    createdContainers.add(distanceContainer);
                                    org.srs3d.viewer.j3d.objects.Label label =
                                        new org.srs3d.viewer.j3d.objects.Label();
                                    label.setString("" + distance + " �");
                                    label.getCoordinate().set(center);
                                    label.setAlignment(new Vector3f(0, 0, 0));
                                    org.srs3d.viewer.j3d.objects.Line line =
                                        new org.srs3d.viewer.j3d.objects.Line();
                                    line.getCoordinates().setAt(0,
                                        atomA.getCoordinate());
                                    line.getCoordinates().setAt(1,
                                        atomB.getCoordinate());
                                    distanceContainer.addObject(label);
                                    distanceContainer.addObject(line);
                                    root.addObject(distanceContainer);
                                    contactAtoms.add(atomA);
                                    contactAtoms.add(atomB);
                                }
                            }
                        }
                        getComputation().setProgress(0);
                        getComputation().setComputation(contextData.getStrategyManager());

                        // draw distances
                        contextData.getContext().addUpdateCallback(new org.srs3d.viewer.j3d.behaviors.UpdateBehavior.Callback() {
                                public void execute() {
                                    SpawnCommand spawnCommand =
                                        new SpawnCommand(contextData);
                                    spawnCommand.setParent(root);
                                    strategyManager.execute(createdContainers,
                                        spawnCommand);
                                    RegisterCommand registerCommand =
                                        new RegisterCommand(contextData);
                                    registerCommand.setParent(root);
                                    strategyManager.propagate(createdContainers,
                                        registerCommand, false);
                                    ColorCommand colorCommand =
                                        new ColorCommand(contextData,
                                            new MonochromeColorScheme(
                                                contextData));
                                    strategyManager.propagate(createdContainers,
                                        colorCommand, false);
                                    ProximityModule.expandAtomProximity(contextData,
                                        contactAtoms, true);
                                    org.srs3d.viewer.bioatlas.Capture.updateSelections(contextData,
                                        true);
                                    contextData.getStrategyManager()
                                               .resetComputation();
                                    getComputation().setComputation(null);
                                }
                            });
                    }
                }
            } else {
                log.error("no rooting container found. Cannot create geometry.");
            }
        }
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     * @param objects Parameter description.
     * @param atoms Parameter description.
     * @param bufferAtoms Parameter description.
     */
    public void extractContactCandidates(ContextData contextData,
        Collection objects, Collection atoms, Collection bufferAtoms) {
        AtomCollector atomCollector = new AtomCollector();
        atomCollector.setObjects(atoms);
        atomCollector.visit(objects);
        if (atomCollector.hasObjects()) {
            Point3f center = atomCollector.getCenter();
            Vector3f extend = atomCollector.getExtend();
            extend.add(new Point3f(THRESHOLD, THRESHOLD, THRESHOLD));
            Vector3f modifiedExtend = new Vector3f(extend);
            Point3f modifiedCenter = new Point3f(center);
            modifiedExtend.scale(0.5f);
            modifiedCenter.sub(modifiedExtend);
            modifiedExtend.scale(2);
            AtomCollector bufferAtomCollector = new AtomCollector();
            bufferAtomCollector.setObjects(bufferAtoms);
            bufferAtomCollector.visit(contextData.getObjectContainer()
                                                 .getObjects());
            log.info("found " + bufferAtomCollector.getObjects().size() +
                " buffer atoms.");
            Cuboid cuboid = new Cuboid();
            cuboid.setCoordinate(center);
            cuboid.setExtend(extend.length() * 0.866f); // sqrt( 3 ) /2
            Subspace subspace = new Subspace(cuboid);
            Subspace bufferSubspace = new Subspace(cuboid);
            Iterator iterator = bufferAtomCollector.getObjects().iterator();
            Atom atom;
            AtomVolume atomVolume;
            int counter = 0;
            while (iterator.hasNext()) {
                atom = (Atom) iterator.next();
                atomVolume = new AtomVolume(atom, 0f);
                if (!atomVolume.intersects(cuboid)) {
                    iterator.remove();
                } else {
                    if (!atomCollector.getObjects().contains(atom)) {
                        bufferSubspace.addElement(atomVolume);
                        counter++;
                    }
                }
            }
            log.debug("found " + bufferAtomCollector.getObjects().size() + "(" +
                counter + ") final buffer atoms!");
        }
    }

    /**
     * Description of the method.
     */
    public void updateIntern() {
        super.updateIntern();
        ContextData contextData = getContextData();
        Selection selection = contextData.getSelectionManager().getSelection();
        if (selection.isEmpty()) {
            getComponent().setEnabled(false);
        } else {
            getComponent().setEnabled(!selection.isEmpty());
        }
    }
}
