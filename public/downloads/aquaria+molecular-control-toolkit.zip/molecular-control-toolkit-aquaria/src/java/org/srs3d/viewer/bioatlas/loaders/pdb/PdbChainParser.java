/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.loaders.pdb;

import java.util.Collection;
import java.util.Iterator;
import java.util.Vector;

import org.srs3d.viewer.bioatlas.objects.Chain;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.objects.ObjectContainer;
import org.srs3d.viewer.util.Log;

/**
 * This class is base class for all parsers that operate on one chain.
 *
 * @author Karsten Klein
 *
 * @created January 28, 2001
 */
public abstract class PdbChainParser extends AbstractPdbParser {
    private static final Log log = new Log(PdbChainParser.class);

    /** The chain identifier of the chain */
    public char chainId = Chain.INVALID_ID;
    private transient Collection pendingChains = new Vector();

    /**
     * Default implementation visiting all objects contained in the specified
     * <code>ObjectContainer</code> instance. If no chain is encountered in the
     * container with the according identifier a new <code>Chain</code> will be created
     * and added to the container. Entry point for all subclasses is visit( Chain chain
     * ). After successful reading and adding the data the subclass is supposed to
     * setSuccess( true );
     *
     * @param ObjectContainer the <code>ObjectContainer</code> instance to visit
     */
    public void visit(ObjectContainer objectContainer) {

        // optimization
        Iterator iterator = objectContainer.getIterator();
        AbstractObject object = null;
        Chain chain;

        // examine all chains until the data was added successfully
        while (!isSuccess() && iterator.hasNext()) {
            object = (AbstractObject) iterator.next();
            if (object instanceof Chain) {
                chain = (Chain) object;

                // visit chains with appropriate id
                if (chain.getId() == chainId) {
                    visit(chain);
                    if (!isSuccess()) {
                        chain.setTerminated(true);
                    }
                }
            }
        }

        // terminate the rest of all open chains
        if (isSuccess()) {
            while (iterator.hasNext()) {
                object = (AbstractObject) iterator.next();
                if (object instanceof Chain) {
                    chain = (Chain) object;
                    chain.setTerminated(true);
                }
            }
        }

        // if there was no chain found, we create a new one
        if (!isSuccess()) {

            // supplement the missing chain
            chain = new Chain();
            visit(chain);

            // in case of success, add the new chain
            if (isSuccess()) {
                objectContainer.addObject(chain);
            } else {
                if (PdbParser.isVerbose()) {
                    log.error("no hosting chain found for parsed data for " +
                        chainId);
                }
                chain = null;
            }
        }
    }

    /**
     * Clears all attributes of the parser.
     */
    public void clear() {
        super.clear();
        chainId = Chain.INVALID_ID;
    }

    /**
     * Visits a chain. Since this class is abtract the success flag will no be set
     *
     * @param chain Chain to visit.
     */
    public void visit(Chain chain) {
        chain.setId(chainId);
    }
}
