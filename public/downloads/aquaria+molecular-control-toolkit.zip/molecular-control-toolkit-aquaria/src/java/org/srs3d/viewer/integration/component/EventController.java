/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.integration.component;

import java.util.Collection;

/**
 * EventController interface. A simultanously defines the interface between components
 * and other EventControllers. A concrete event controller should be understood as
 * listener and publisher for a particular type of events. Thus implementations of an
 * specialized EventController (e.g. for communicating selections) is written once and
 * can be shared by all the client components.
 *
 * @author Karsten Klein
 *
 * @created September 23, 2002
 */
public interface EventController extends ComponentEventListener,
    ComponentEventPublisher {

    /**
     * Add a component event listener to the controller. When calling publish(...) these
     * listeners will receive the event.
     *
     * @param listener The <code>ComponentEventListener</code> to be added.
     */
    public void addComponentEventListener(ComponentEventListener listener);

    /**
     * This method is intended to collect all event controllers in a event controller
     * hierarchy. A normal instance of the event controller returns a collection that
     * just included itself. An event controller that propagates the events to one or
     * more other event controllers has to propagate this method.
     *
     * @return The event controllers controlled by this event controller.
     */
    public Collection getEventControllers();
}
