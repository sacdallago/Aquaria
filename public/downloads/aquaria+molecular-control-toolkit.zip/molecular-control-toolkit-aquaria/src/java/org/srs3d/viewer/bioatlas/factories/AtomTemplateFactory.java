/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.factories;

import java.util.HashMap;

import org.srs3d.viewer.bioatlas.objects.templates.AtomTemplate;

/**
 * The class <code>AtomTemplateFactory</code> produces/manages all
 * <code>AtomTemplates</code> needed/available.
 *
 * @author Karsten Klein
 *
 * @created January 13, 2001
 */
public final class AtomTemplateFactory {

    /**
     * The static instance is the only instance that is available of the
     * <code>AtomTemplateFactory</code> class. Note that the class implements the
     * singleton design pattern. The interface aims for transparancy concering the
     * static instance, that means there is no method getInstance() available and that
     * all public operations are redirected automatically
     */
    private static final AtomTemplateFactory atomTemplateFactory =
        new AtomTemplateFactory();

    /**
     * The <code>AtomTemplate</code> instances are kept in a HashMap to ensure fast
     * access
     */
    private HashMap atomTemplates = new HashMap();

    /**
     * Constructor description.
     */
    private AtomTemplateFactory() {
    }

    /**
     * Private redirected version of getTemplate()
     *
     * @param string Strign identifying the template.
     *
     * @return The <code>atomTemplate</code> value.
     */
    private final AtomTemplate getAtomTemplate(String string) {
        AtomTemplate atomTemplate = (AtomTemplate) atomTemplates.get(string);
        if (atomTemplate == null) {

            // get appropriate instance from the AtomTemplate class
            atomTemplate = AtomTemplate.getInstance(string);
            atomTemplates.put(string, atomTemplate);
        }
        return atomTemplate;
    }

    /**
     * This method inquires an <code>AtomTemplate</code> by the specifeid identifying
     * string. If such a template doesn't exist yet, it will be allocated and stored
     * with the other templates for further accessing.
     *
     * @param string Description of parameter.
     * @param string specifies the template to retrieve
     *
     * @return The appropriate <code>AtomTemplate</code>
     */
    public static final AtomTemplate getTemplate(String string) {
        return atomTemplateFactory.getAtomTemplate(string);
    }
}
