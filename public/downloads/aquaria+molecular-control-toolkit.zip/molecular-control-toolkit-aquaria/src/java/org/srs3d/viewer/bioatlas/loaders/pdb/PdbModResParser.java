/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.loaders.pdb;

import org.srs3d.viewer.bioatlas.objects.Chain;
import org.srs3d.viewer.bioatlas.objects.Residue;

/**
 * This class parses strings for pdb MODRES tags and tranfers/builts the appropriate
 * datastructure in a <code>ObjectContainer</code> .
 *
 * @author Karsten Klein, 01/2001
 *
 * @created May 18, 2001
 * @since 1.0
 */
public class PdbModResParser extends PdbResidueParser {

    /** Description of the field. */
    public static final String TAG = new String("MODRES");

    /** Description of the field. */
    private String comment = null;

    /**
     * Gets the <code>retained</code> attribute of the <code>PdbModResParser </code>
     * object.
     *
     * @return The <code>retained</code> value.
     */
    public boolean isRetained() {
        return true;
    }

    /**
     * Parses the formated pdb string for MODRES data. The data is stored locally and no
     * object is created.
     *
     * @param string Description of parameter.
     */
    public void create(String string) {
        clear();

        // :NOTE: the standard residue name is not read!
        residueName = extractString(string, 12, 15);
        chainId = extractChar(string, 16);
        residueId = extractInt(string, 18, 22);
        residueICode = extractChar(string, 22);
        comment = extractString(string, 29, 70, true);
    }

    /**
     * Method description.
     *
     * @param chain Parameter description.
     */
    public void visit(Chain chain) {
        Residue residue =
            chain.getResidue(residueName, residueId, residueICode);
        if (residue != null) {
            chain.markExceptionalResidue(residue);
            setSuccess(true);
        }
    }

    /**
     * Description of the method.
     */
    public void clear() {
        super.clear();
        comment = null;
    }
}
