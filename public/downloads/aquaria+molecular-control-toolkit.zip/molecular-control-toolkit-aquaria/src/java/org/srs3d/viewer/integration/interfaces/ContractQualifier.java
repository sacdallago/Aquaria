/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.integration.interfaces;


/**
 * A contract qualifier is a contract on key basis. The qualifier contains all
 * information associated with a key, but no the real object.
 *
 * @author Karsten Klein
 *
 * @created September 11, 2002
 */
public interface ContractQualifier {

    /**
     * Check whether a key value pair matches the contract.
     *
     * @param key Key to check for (only needed for informative output).
     * @param object Object to check the contract qualification for.
     *
     * @return <code>true</code> if the contract qualifier is valid for the provided key
     *         value pair..
     */
    public boolean check(Object key, Object object);

    /**
     * Description of the method.
     *
     * @param attributeClass Parameter description.
     *
     * @return Return parameter description.
     */
    public boolean hasAttribute(Class attributeClass);

    /**
     * Description of the method.
     *
     * @param attributeClass Parameter description.
     *
     * @return Return parameter description.
     */
    public ContractAttribute getAttribute(Class attributeClass);
}
