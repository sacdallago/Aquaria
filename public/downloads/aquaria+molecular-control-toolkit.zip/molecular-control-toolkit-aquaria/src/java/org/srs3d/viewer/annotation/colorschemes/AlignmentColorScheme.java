/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.annotation.colorschemes;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.Vector;

import javax.media.j3d.Appearance;
import javax.vecmath.Color3f;

import org.srs3d.viewer.annotation.objects.AnnotationContainer;
import org.srs3d.viewer.bioatlas.colorschemes.CPKColorScheme;
import org.srs3d.viewer.bioatlas.objects.Atom;
import org.srs3d.viewer.bioatlas.objects.Residue;
import org.srs3d.viewer.bioatlas.objects.templates.ResidueTemplate;
import org.srs3d.viewer.j3d.AbstractColorScheme;
import org.srs3d.viewer.j3d.AppearanceHelper;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.objects.ObjectManager;
import org.srs3d.viewer.vecmath.CubicBezierCurve3f;

/**
 * This <code>ColorScheme</code> colors residues by conservation. It uses the
 * conservation matrix that can be found in the ResidueTemplate class. Residue
 * subobjects are mapped to the residue and a avarage computation is performed for
 * higher level objects that include residues.
 *
 * @author Karsten Klein
 *
 * @created March 20, 2001
 */
public abstract class AlignmentColorScheme extends AbstractColorScheme {

    // contains a context to annotation mapping
    private static Map contextAnnotationMap = new Hashtable();
    private static final float NO_ALIGNMENT = -100;
    private static final float MIN_CONSERVATION = -3.5f;
    private static final float MAX_CONSERVATION = 1.0f;
    private static final float IDENTICAL = 10f;
    private static final float DELTA_CONSERVATION =
        MAX_CONSERVATION - MIN_CONSERVATION;

    /** a cubic bezier curve is used for the color interpolation. */
    private CubicBezierCurve3f colorCurve = null;
    private CPKColorScheme cpkColorScheme = null;

    /**
     * Constructor description.
     *
     * @param contextData Parameter description.
     */
    public AlignmentColorScheme(ContextData contextData) {
        super(contextData);

        // non-aligned atoms are colored with a darkened cpk color scheme
        cpkColorScheme = new CPKColorScheme(contextData);
        cpkColorScheme.setColorScale(0.5f);
    }

    protected void initialize() {
        colorCurve = new CubicBezierCurve3f();
        ArrayList colors = new ArrayList(2);
        colors.add(getConservedColor());
        colors.add(getUnconservedColor());
        colorCurve.setCoordinates(colors);
    }

    /**
     * Colors the annotation objects as their counterparts in the molecule view.
     *
     * @param object Description of Parameter
     * @param appearance Description of parameter.
     *
     * @return Description of the returned value.
     */
    public boolean modify(AbstractObject object, Appearance appearance) {

        // color max deviation
        Color3f color = getMaxDeviationColor();
        if (isApplicable(object)) {
            if (object instanceof Residue) {
                float conservation = computeConservation((Residue) object);
                if (conservation == IDENTICAL) {
                    color = getIdenticalColor();
                } else if (conservation == NO_ALIGNMENT) {
                    color = getMaxDeviationColor();
                } else {
                    color = computeColor(conservation);
                }
            } else {

                // it's an atom
                Collection residues = new HashSet();
                getContextData().getObjectManager().getUpAssociations(object,
                    residues);
                ObjectManager.extract(residues, Residue.class);
                if (residues.size() > 0) {
                    Iterator iterator = residues.iterator();
                    float conservation = 0;
                    while (iterator.hasNext()) {
                        conservation += computeConservation((Residue) iterator.next());
                    }
                    conservation /= residues.size();
                    if (conservation == IDENTICAL) {
                        color = getIdenticalColor();
                    } else if (conservation == NO_ALIGNMENT) {
                        color = getMaxDeviationColor();
                        AppearanceHelper.enableVertexColors(appearance,
                            object.getClass() != Atom.class);
                        AppearanceHelper.modifyAppearance(appearance, color);
                        cpkColorScheme.modify(object, appearance);
                        return true;
                    } else {
                        color = computeColor(conservation);
                    }
                }
            }
            AppearanceHelper.enableVertexColors(appearance,
                object.getClass() != Atom.class);
            AppearanceHelper.modifyAppearance(appearance, color);
            return true;
        }
        return false;
    }

    /**
     * Maps the residue pair to a certain color.
     *
     * @param conservation Description of parameter.
     *
     * @return <code>Color3f</code> - the color mapped to the specified temperature.
     */
    private Color3f computeColor(float conservation) {
        float map = (conservation - MIN_CONSERVATION) / DELTA_CONSERVATION;
        if (map < 0) {
            map = 0;
        }
        if (map > 1) {
            map = 1;
        }
        Color3f color = new Color3f();
        color.set(colorCurve.computePoint(1 - map));
        return color;
    }

    /**
     * Gets the <code>information</code> attribute of the
     * <code>HomologyColorScheme</code> object.
     *
     * @param map Description of parameter.
     *
     * @return The <code>information</code> value.
     */
    public Map getInformation(Map map) {
        map = super.getInformation(map);
        map.put("identical", getIdenticalColor());
        map.put("unaligned", getMaxDeviationColor());
        map.put("conserved", getConservedColor());
        map.put("non-conserved", getUnconservedColor());
        map.put("GRADIENT", colorCurve);
        map.put("GRADIENT_START", "conserved");
        map.put("GRADIENT_END", "unconserved");
        Vector vector = new Vector();
        vector.add("identical");
        vector.add("GRADIENT_START");
        vector.add("conserved");
        vector.add("non-conserved");
        vector.add("GRADIENT_END");
        vector.add("unaligned");
        map.put("ORDER", vector);
        return map;
    }

    /**
     * Description of the method.
     *
     * @param residueA Description of parameter.
     *
     * @return Description of the returned value.
     */
    private float computeConservation(Residue residueA) {
        ResidueTemplate templateA = residueA.getTemplate();
        AnnotationContainer annotationContainer =
            (AnnotationContainer) contextAnnotationMap.get(getContextData());
        if (!templateA.isLigand() && annotationContainer != null) {
            Collection residues = annotationContainer.mapResidues(residueA);
            if (residues != null) {
                Iterator iterator = residues.iterator();
                Residue residueB;
                float conservation = 0;
                int count = 0;
                boolean isIdentical = true;
                while (iterator.hasNext()) {
                    residueB = (Residue) iterator.next();
                    if (residueB != residueA) {
                        ResidueTemplate templateB = residueB.getTemplate();
                        if (templateA != templateB) {
                            isIdentical = false;
                        }
                        conservation += (float) ResidueTemplate.getConservation(templateA,
                            templateB);
                        count++;
                    }
                }
                if (count == 0) {
                    return NO_ALIGNMENT;
                } else {
                    if (isIdentical) {
                        return IDENTICAL;
                    }
                    if (count > 1) {
                        return conservation / count;
                    }
                    return conservation;
                }
            }
        }
        return NO_ALIGNMENT;
    }

    /**
     * Gets the <code>homologyMap</code> attribute of the
     * <code>HomologyColorScheme</code> class.
     *
     * @param contextData Description of parameter.
     *
     * @return The <code>homologyMap</code> value.
     */
    public static AnnotationContainer getAnnotation(ContextData contextData) {
        return (AnnotationContainer) contextAnnotationMap.get(contextData);
    }

    /**
     * Registers <code>ContextData</code> objects to alignment maps. The alignment map
     * maps <code>Residue </code> instances of a structure to <code>Residue</code>
     * instances of another (template) structure.
     *
     * @param contextData Description of parameter.
     * @param annotationContainer Description of parameter.
     */
    public static void register(ContextData contextData,
        AnnotationContainer annotationContainer) {
        contextAnnotationMap.put(contextData, annotationContainer);
    }

    private boolean isApplicable(AbstractObject object) {
        if (object.getClass() == Residue.class) {
            return true;
        }
        if (object.getClass() == Atom.class) {
            return true;
        }
        return false;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public abstract Color3f getConservedColor();

    /**
     * Method description.
     *
     * @return Return description.
     */
    public abstract Color3f getIdenticalColor();

    /**
     * Method description.
     *
     * @return Return description.
     */
    public abstract Color3f getMaxDeviationColor();

    /**
     * Method description.
     *
     * @return Return description.
     */
    public abstract Color3f getUnconservedColor();
}
