/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.geometry.primitive;

import java.util.Hashtable;
import java.util.Map;

import javax.media.j3d.GeometryArray;
import javax.media.j3d.Shape3D;
import javax.media.j3d.TriangleFanArray;
import javax.vecmath.Matrix3f;
import javax.vecmath.Point3f;
import javax.vecmath.Vector3f;

import org.srs3d.viewer.j3d.geometry.GeometryHelper;
import org.srs3d.viewer.vecmath.Contour;
import org.srs3d.viewer.vecmath.PointArray3f;
import org.srs3d.viewer.vecmath.SweepingSurface;

/**
 * The <code>Sphere</code> class provides the ability to construct spherical geometric
 * primitives as Shape3D objects. The class doesn't use the sun utility class
 * <code>Sphere</code> to create the geometrical representation, anymore. The
 * implementation was replaced by our own sphere creation procedure.
 *
 * @author Karsten Klein, 10/2000
 *
 * @created March 20, 2001
 */
public class Sphere implements AbstractPrimitive {

    // :FIXME: create a constants class
    private static final Matrix3f matrix =
        new Matrix3f(1, 0, 0, 0, 1, 0, 0, 0, 1);

    /** Maps division integers to unit spheres */
    private static final Map sphereMap = new Hashtable();

    /** Array of coordinates (array of one in this case) */
    private PointArray3f coordinates = null;

    /** Radius of the sphere */
    private float radius = 1.0f;

    /** Number of divisions along the diameter of the sphere */
    private int divisions = 12;

    /**
     * <code>Sphere</code> contructor.
     */
    public Sphere() {
        coordinates = new PointArray3f(1);
    }

    /**
     * Sets the <code>Divisions</code> attribute of the <code>Sphere</code> object
     *
     * @param divisions The new <code>Divisions</code> value
     */
    public void setDivisions(int divisions) {
        this.divisions = divisions;
    }

    /**
     * Sets the <code>Radius</code> attribute of the <code>Sphere</code> object
     *
     * @param radius The new <code>Radius</code> value
     */
    public void setRadius(float radius) {
        this.radius = radius;
    }

    /**
     * Gets the <code>Coordinates</code> attribute of the <code>Sphere</code> object
     *
     * @return The <code>Coordinates</code> value
     */
    public PointArray3f getCoordinates() {
        return coordinates;
    }

    /**
     * Gets the <code>Divisions</code> attribute of the <code>Sphere</code> object
     *
     * @return The <code>Divisions</code> value
     */
    public int getDivisions() {
        return divisions;
    }

    /**
     * Gets the <code>Radius</code> attribute of the <code>Sphere</code> object
     *
     * @return The <code>Radius</code> value
     */
    public float getRadius() {
        return radius;
    }

    /**
     * Gets the <code>shape</code> attribute of the <code>Sphere</code> object.
     *
     * @return The <code>shape</code> value.
     */
    public Shape3D getShape() {
        Shape3D shape = (Shape3D) sphereMap.get(new Integer(divisions));
        Shape3D copy = new Shape3D();
        if (shape == null) {
            shape = getUnitSphere();
            sphereMap.put(new Integer(divisions), shape);
        }
        GeometryHelper.copyGeometry(shape, copy);
        return copy;
    }

    /**
     * Gets the <code>shape</code> attribute of the <code>Sphere</code> object. Generates
     * a unit sphere with the appropriate divisions.
     *
     * @return Unit sphere geometry.
     */
    public final Shape3D getUnitSphere() {

        // create a sphere using the sweeping surface implementation
        // create half circular contour (not closed)
        int size = divisions + 1;
        Contour contour = new Contour(size - 2);
        Point3f coordinate = new Point3f();
        Vector3f normal = new Vector3f();
        final float radius = 1;
        float dAngle = ((float) Math.PI) / divisions;
        float angle;
        for (int i = 1; i < size - 1; i++) {
            angle = dAngle * i;
            normal.x = -(float) Math.cos(angle);
            normal.y = (float) Math.sin(angle);
            coordinate.x = normal.x;
            coordinate.y = normal.y;
            contour.getCoordinates().setAt(i - 1, coordinate);
            contour.getNormals().setAt(i - 1, normal);
            contour.getNormals().setAt(size - 2 + i - 1, normal);
        }
        contour.setClosed(false);

        // create sweeping surface
        final Point3f translation = new Point3f();
        final Vector3f scale = new Vector3f(1, 1, 1);
        SweepingSurface sweepingSurface = new SweepingSurface(contour);
        float dFullAngle = (float) (Math.PI * 2.0f) / divisions;
        for (int i = 0; i < size; i++) {
            matrix.rotX(i * dFullAngle);
            sweepingSurface.addFrame(matrix, translation, scale, false);
        }
        Shape3D shape = sweepingSurface.getFullGeometry(0, divisions, false);

        // still need bottom and top geometry
        int[] stripVertexCounts = { size + 1 };
        TriangleFanArray triangleFanArray =
            new TriangleFanArray(size + 1,
                GeometryArray.COORDINATES | GeometryArray.NORMALS,
                stripVertexCounts);
        coordinate.set(translation);
        coordinate.x -= radius;
        triangleFanArray.setCoordinate(0, coordinate);
        triangleFanArray.setNormal(0, new Vector3f(-1, 0, 0));
        for (int i = 0; i < size; i++) {
            normal.x = -(float) Math.cos(dAngle);
            normal.y = (float) Math.sin(dAngle);
            normal.z = 0;
            coordinate.x = radius * normal.x;
            coordinate.y = radius * normal.y;
            coordinate.z = 0;
            matrix.rotX(-i * dFullAngle);
            matrix.transform(coordinate);
            matrix.transform(normal);
            coordinate.add(translation);
            triangleFanArray.setCoordinate(i + 1, coordinate);
            triangleFanArray.setNormal(i + 1, normal);
        }
        shape.addGeometry(triangleFanArray);
        triangleFanArray =
            new TriangleFanArray(size + 1,
                GeometryArray.COORDINATES | GeometryArray.NORMALS,
                stripVertexCounts);
        coordinate.set(translation);
        coordinate.x += radius;
        triangleFanArray.setCoordinate(0, coordinate);
        triangleFanArray.setNormal(0, new Vector3f(1, 0, 0));
        for (int i = 0; i < size; i++) {
            normal.x = -(float) Math.cos((float) Math.PI - dAngle);
            normal.y = (float) Math.sin((float) Math.PI - dAngle);
            normal.z = 0;
            coordinate.x = radius * normal.x;
            coordinate.y = radius * normal.y;
            coordinate.z = 0;
            matrix.rotX(i * dFullAngle);
            matrix.transform(coordinate);
            matrix.transform(normal);
            coordinate.add(translation);
            triangleFanArray.setCoordinate(i + 1, coordinate);
            triangleFanArray.setNormal(i + 1, normal);
        }
        shape.addGeometry(triangleFanArray);
        return shape;
    }
}
