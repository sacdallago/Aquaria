/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.objects.strategies;

import java.util.ArrayList;

import javax.media.j3d.Appearance;

import org.srs3d.viewer.bioatlas.colorschemes.NoCullColorScheme;
import org.srs3d.viewer.j3d.AppearanceHelper;
import org.srs3d.viewer.j3d.ColorScheme;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.Reaction;
import org.srs3d.viewer.j3d.commands.ColorCommand;
import org.srs3d.viewer.j3d.commands.ComputeCenterCommand;
import org.srs3d.viewer.j3d.commands.ExpandCommand;
import org.srs3d.viewer.j3d.commands.IdentificationCommand;
import org.srs3d.viewer.j3d.objects.Surface;
import org.srs3d.viewer.j3d.objects.strategies.reactions.EmptyReaction;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.objects.Command;
import org.srs3d.viewer.objects.ObjectContainer;
import org.srs3d.viewer.objects.ObjectManager;

/**
 * @author Karsten Klein
 *
 * @created April 03, 2001
 */
public class SurfaceStrategy extends AbstractStrategy {
    private ColorScheme colorScheme = null;

    /**
     * Constructor description.
     */
    public SurfaceStrategy() {
        register(ComputeCenterCommand.class, new ComputeCenterReaction());
        register(ColorCommand.class, new ColorReaction());
        register(IdentificationCommand.class, new IdentificationReaction());
        register(ExpandCommand.class, EmptyReaction.getSharedInstance());
    }

    private ColorScheme getColorScheme(ContextData contextData) {
        if (colorScheme == null) {
            colorScheme = new NoCullColorScheme(contextData);
        }
        return colorScheme;
    }

    /**
     * Class description.
     *
     * @author Karsten Klein, LION bioscience AG
     */
    public class ColorReaction implements Reaction {

        /**
         * Method description.
         *
         * @param command Parameter description.
         */
        public void execute(Command command) {
            command.execute();
            ContextData contextData = ((ColorCommand) command).getContextData();
            Appearance appearance =
                contextData.getAppearanceManager().getAppearance(command.getObject());
            getColorScheme(contextData).modify(command.getObject(), appearance);
            AppearanceHelper.enableAlternateTransparency(appearance);
            ColorCommand.apply(contextData, command.getObject(), appearance);
        }
    }

    /**
     * Class description.
     *
     * @author Karsten Klein, LION bioscience AG
     */
    public class ComputeCenterReaction implements Reaction {

        /**
         * Method description.
         *
         * @param command Parameter description.
         */
        public void execute(Command command) {
            ComputeCenterCommand computeCenterCommand =
                (ComputeCenterCommand) command;
            Surface surface = (Surface) computeCenterCommand.getObject();
            computeCenterCommand.modifyCenter(surface.getCenter(),
                surface.getExtend());
        }
    }

    /**
     * Reaction for retrieving the object identification.
     *
     * @author Karsten Klein
     *
     * @created March 26, 2002
     */
    public static class IdentificationReaction implements Reaction {

        /**
         * Execute implementation of the reaction interface.
         *
         * @param command Command to react to.
         */
        public void execute(Command command) {
            IdentificationCommand idCommand = (IdentificationCommand) command;
            AbstractObject object = command.getObject();
            ArrayList parents = new ArrayList();
            ObjectManager.extract(idCommand.getObjects(), parents,
                ObjectContainer.class);
            if (!parents.isEmpty()) {
                ObjectContainer parent = (ObjectContainer) parents.get(0);
                ArrayList surfaces = new ArrayList();
                ObjectManager.extract(parent.getObjects(), surfaces,
                    Surface.class);
                idCommand.setObjectId("SURFACE:#" + surfaces.indexOf(object));
                idCommand.execute();
            }
        }
    }
}
