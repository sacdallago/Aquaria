/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.accesscontrol.checks;

import java.applet.AppletStub;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Map;

import org.srs3d.viewer.accesscontrol.AccessCheck;
import org.srs3d.viewer.accesscontrol.AccessCheckFactory;
import org.srs3d.viewer.util.XmlTag;

/**
 * AccessCheck implementation that checks the license creaation and expiration dates.
 *
 * @author Karsten Klein
 *
 * @created August 23, 2002
 */
public class ExpirationCheck implements AccessCheck {
    private transient long expirationDate;
    private transient long creationDate;

    /**
     * Gets the <code>name</code> attribute of the <code>ExpirationCheck</code> object.
     *
     * @return The <code>name</code> value.
     */
    public String getName() {
        return "ExpirationCheck-1.0";
    }

    /**
     * Description of the method.
     *
     * @param appletStub Description of parameter.
     *
     * @return Description of the returned value.
     */
    public boolean check(AppletStub appletStub) {
        if (System.currentTimeMillis() > creationDate) {
            if (System.currentTimeMillis() < expirationDate) {
                return true;
            }
        }
        return false;
    }

    /**
     * Description of the method.
     *
     * @param object Description of parameter.
     */
    public void read(Object object) {
        Map map = (Map) object;

        // read dates
        expirationDate = ((Long) map.get("ExpirationDate")).longValue();
        creationDate = ((Long) map.get("CreationDate")).longValue();
    }

    /**
     * Description of the method.
     *
     * @param object Description of parameter.
     */
    public void write(Object object) {
        Map map = (Map) object;

        // write dates
        map.put("ExpirationDate", new Long(expirationDate));
        map.put("CreationDate", new Long(creationDate));
    }

    /**
     * Description of the method.
     *
     * @return Description of the returned value.
     */
    public XmlTag createXmlTag() {
        XmlTag xmlTag = new XmlTag("check");
        xmlTag.setAttribute("type", "" + AccessCheckFactory.getId(this));
        Date date = new Date(expirationDate);
        GregorianCalendar calendar = new GregorianCalendar();
        calendar.setTime(date);
        xmlTag.setAttribute("expire",
            "" + calendar.get(Calendar.YEAR) + "/" +
            (calendar.get(Calendar.MONTH) + 1) + "/" +
            calendar.get(Calendar.DAY_OF_MONTH));
        return xmlTag;
    }
}
