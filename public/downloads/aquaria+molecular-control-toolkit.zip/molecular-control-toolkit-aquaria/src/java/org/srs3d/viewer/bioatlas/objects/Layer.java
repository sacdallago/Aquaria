/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.objects;

import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;

import javax.vecmath.Matrix4f;
import javax.vecmath.Point3f;
import javax.vecmath.Tuple3f;
import javax.vecmath.Vector3f;

import org.srs3d.viewer.bioatlas.factories.ResidueTemplateFactory;
import org.srs3d.viewer.bioatlas.filters.ResidueTemplateFilter;
import org.srs3d.viewer.bioatlas.objects.templates.ResidueTemplate;
import org.srs3d.viewer.bioatlas.visitors.AtomCollector;
import org.srs3d.viewer.bioatlas.visitors.BondCreator;
import org.srs3d.viewer.j3d.Linkable;
import org.srs3d.viewer.j3d.objects.Link;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.objects.ObjectContainer;
import org.srs3d.viewer.objects.ObjectManager;
import org.srs3d.viewer.objects.visitors.ObjectCollector;
import org.srs3d.viewer.objects.visitors.ObjectLocalizer;

/**
 * Special <code>AbstractObject</code> implementation defining a <code>Layer </code>. The
 * implementation contains only the intrinsic data of the object.
 *
 * @author Karsten Klein
 *
 * @created March 22, 2001
 */
public final class Layer extends ObjectContainer implements Linkable {

    /** Description of the field. */
    public static String INVALID_ID = null;
    private String id = null;
    private Link link = null;
    private String compartment = null;
    private String classification = null;
    private Vector3f orientation = null;

    /** offet of the layer in the display */
    private Point3f coordinate = null;

    /** center of all atoms */
    private Point3f center = new Point3f();
    private Vector3f extend = new Vector3f(50, 50, 50);
    private int dimension = 3;
    private String description = null;
    private boolean isTemplate = false;
    private boolean isSequenceLayer = false;
    private boolean isMergeable = false;
    private boolean isImposed = false;
    private boolean isMaster = false;
    private boolean isCentered = false;
    private Matrix4f superpositionOperator = null;

    /**
     * <code>Layer</code> contructor.
     */
    public Layer() {
        orientation = new Vector3f(1, 0, 0);
        coordinate = new Point3f();
        description = new String("");
    }

    /**
     * Sets the <code>sequenceLayer</code> attribute of the <code>Layer</code> object.
     *
     * @param isSequenceLayer The new <code>sequenceLayer</code> value.
     */
    public void setSequenceLayer(boolean isSequenceLayer) {
        this.isSequenceLayer = isSequenceLayer;
    }

    /**
     * Sets the <code>Dimension</code> attribute of the <code>Layer</code> object.
     *
     * @param dimension The new <code>Dimension</code> value.
     */
    public void setDimension(int dimension) {
        this.dimension = dimension;
    }

    /**
     * Sets the <code>Classification</code> attribute of the <code>Layer </code> object.
     *
     * @param classification The new <code>Classification</code> value.
     */
    public void setClassification(String classification) {
        this.classification = new String(classification);
    }

    /**
     * Sets the <code>Compartment</code> attribute of the <code>Layer</code> object.
     *
     * @param compartment The new <code>Compartment</code> value.
     */
    public void setCompartment(String compartment) {
        this.compartment = new String(compartment);
    }

    /**
     * Sets the <code>Coordinate</code> attribute of the <code>Layer</code> object.
     *
     * @param coordinate The new <code>Coordinate</code> value.
     */
    public void setCoordinate(Tuple3f coordinate) {
        this.coordinate.set(coordinate);
    }

    /**
     * Sets the <code>center</code> attribute of the <code>Layer</code> object.
     *
     * @param center The new <code>center</code> value.
     */
    public void setCenter(Tuple3f center) {
        this.center.set(center);
        isCentered = true;
    }

    /**
     * Sets the <code>Orientation</code> attribute of the <code>Layer</code> object.
     *
     * @param orientation The new <code>Orientation</code> value.
     */
    public void setOrientation(Tuple3f orientation) {
        this.orientation.set(orientation);
    }

    /**
     * Sets the <code>description</code> attribute of the <code>Layer</code> object.
     *
     * @param description The new <code>description</code> value.
     */
    public void setDescription(String description) {
        if (description != null) {
            this.description = new String(description);
        } else {
            description = new String();
        }
    }

    /**
     * Sets the <code>template</code> attribute of the <code>Layer</code> object.
     *
     * @param isTemplate The new <code>template</code> value.
     */
    public void setTemplate(boolean isTemplate) {
        this.isTemplate = isTemplate;
    }

    /**
     * Sets the <code>mergeable</code> attribute of the <code>Layer</code> object.
     *
     * @param merge The new <code>mergeable</code> value.
     */
    public void setMergeable(boolean merge) {
        isMergeable = merge;
    }

    /**
     * Sets the <code>extend</code> attribute of the <code>Layer</code> object.
     *
     * @param extend The new <code>extend</code> value.
     */
    public void setExtend(Tuple3f extend) {
        this.extend.set(extend);
    }

    /**
     * Sets the <code>link</code> attribute of the <code>Layer</code> object.
     *
     * @param link The new <code>link</code> value.
     */
    public void setLink(Link link) {
        throw new RuntimeException("Not Implemented!!!");
    }

    /**
     * Sets the <code>superpositionOperator</code> attribute of the <code>Layer</code>
     * object.
     *
     * @param superpositionOperator The new <code>superpositionOperator</code> value.
     */
    public void setSuperpositionOperator(Matrix4f superpositionOperator) {
        this.superpositionOperator = superpositionOperator;
    }

    /**
     * Gets the <code>sequenceLayer</code> attribute of the <code>Layer</code> object.
     *
     * @return The <code>sequenceLayer</code> value.
     */
    public boolean isSequenceLayer() {
        return isSequenceLayer;
    }

    /**
     * Gets the <code>mergeable</code> attribute of the <code>Layer</code> object.
     *
     * @return The <code>mergeable</code> value.
     */
    public boolean isMergeable() {
        return isMergeable;
    }

    /**
     * Gets the <code>Id</code> attribute of the <code>Layer</code> object. Gets the
     * <code>Dimension</code> attribute of the <code>Layer</code> object.
     *
     * @return The <code>Dimension</code> value.
     */
    public int getDimension() {
        return dimension;
    }

    /**
     * Gets the <code>Compartment</code> attribute of the <code>Layer</code> object.
     *
     * @return The <code>Compartment</code> value.
     */
    public String getCompartment() {
        return new String(compartment);
    }

    /**
     * Gets the <code>Classification</code> attribute of the <code>Layer </code>object.
     *
     * @return The <code>Classification</code> value.
     */
    public String getClassification() {
        return new String(classification);
    }

    /**
     * Gets the <code>Coordinate</code> attribute of the <code>Layer</code> object.
     *
     * @return The <code>Coordinate</code> value.
     */
    public Point3f getCoordinate() {
        return new Point3f(coordinate);
    }

    /**
     * Gets the <code>center</code> attribute of the <code>Layer</code> object.
     *
     * @return The <code>center</code> value.
     */
    public Point3f getCenter() {
        return new Point3f(center);
    }

    /**
     * Gets the <code>Orientation</code> attribute of the <code>Layer</code> object.
     *
     * @return The <code>Orientation</code> value.
     */
    public Vector3f getOrientation() {
        return orientation;
    }

    /**
     * Gets the <code>Id</code> attribute of the <code>Layer</code> object.
     *
     * @param databaseId Description of parameter.
     *
     * @return The <code>Id</code> value.
     */
    public String getId(String databaseId) {
        if (link != null) {
            return link.getLink(databaseId);
        }
        return null;
    }

    /**
     * Gets the <code>description</code> attribute of the <code>Layer</code> object.
     *
     * @return The <code>description</code> value.
     */
    public String getDescription() {
        return new String(description);
    }

    /**
     * Gets the <code>template</code> attribute of the <code>Layer</code> object.
     *
     * @return The <code>template</code> value.
     */
    public boolean isTemplate() {
        return isTemplate;
    }

    /**
     * Gets the <code>extend</code> attribute of the <code>Layer</code> object.
     *
     * @return The <code>extend</code> value.
     */
    public Vector3f getExtend() {
        return extend;
    }

    /**
     * Gets the <code>link</code> attribute of the <code>Layer</code> object.
     *
     * @return The <code>link</code> value.
     */
    public Link getLink() {
        return link;
    }

    /**
     * Adds a feature to the <code>Id</code> attribute of the <code>Layer </code>object.
     *
     * @param databaseIdentifier The feature to be added to the <code>Id</code>
     *        attribute.
     * @param id The feature to be added to the <code>Id</code> attribute.
     */
    public void addId(String databaseIdentifier, String id) {
        createLink();
        link.addLink(databaseIdentifier, id);
    }

    /**
     * Description of the method.
     *
     * @return Description of the returned value.
     */
    public String toString() {
        return description;
    }

    /**
     * Description of the method.
     */
    public void cleanup() {
        super.cleanup();
        link = null;
        compartment = null;
        classification = null;
        orientation = null;
        coordinate = null;
        center = null;
        extend = null;
        superpositionOperator = null;
    }

    /**
     * Description of the method.
     */
    public void update() {
        super.update();

        // :FIXME: move this out off here, again. The bond should be created on
        //    demand.
        ResidueTemplate template = ResidueTemplateFactory.getTemplate("CYS");
        ObjectCollector cysteinCollector =
            new ObjectCollector(new ResidueTemplateFilter(template));
        cysteinCollector.visit((AbstractObject) this);

        // search for disulfide bonds
        BondCreator bondCreator = new BondCreator();
        bondCreator.mode = BondCreator.DISULFIDE;
        bondCreator.visit(cysteinCollector.getObjects());
        Collection residues = new HashSet();
        if (!bondCreator.bonds.isEmpty()) {

            // :FIXME: create a special object that takes care of the residues and the
            //  additional bond.
            Site site;
            Iterator iterator = bondCreator.bonds.iterator();
            Bond bond;
            while (iterator.hasNext()) {
                site = new Site();
                site.setContentType(Site.DISULFIDEBOND_RESIDUES);
                site.setName("Disulfide Bridge");
                bond = (Bond) iterator.next();
                ObjectLocalizer objectLocalizer = new ObjectLocalizer();
                objectLocalizer.setSearchObject(bond.getAtom0());
                objectLocalizer.visit(cysteinCollector.getObjects());
                ObjectManager.extract(objectLocalizer.getObjects(),
                    Residue.class);
                Residue residue0 =
                    (Residue) objectLocalizer.getObjects().iterator().next();
                objectLocalizer.getObjects().clear();
                objectLocalizer.setSearchObject(bond.getAtom1());
                objectLocalizer.visit((AbstractObject) this);
                ObjectManager.extract(objectLocalizer.getObjects(),
                    Residue.class);
                Residue residue1 =
                    (Residue) objectLocalizer.getObjects().iterator().next();
                site.getResidues().add(residue0);
                site.getResidues().add(residue1);
                residue0.getBonds().addAll(residue0.computeBonds());
                residue0.addBond(bond);
                if (!residues.contains(residue0)) {
                    addObject(site);
                    site.update();
                    residues.add(residue0);
                    residues.add(residue1);
                }
            }
        }
        updateCenter();
    }

    /**
     * Description of the method.
     */
    public void updateCenter() {

        // cache center and extend
        AtomCollector atomCollector = new AtomCollector();
        atomCollector.visit((AbstractObject) this);
        if (!atomCollector.getObjects().isEmpty()) {
            setCenter(atomCollector.getCenter());
            setExtend(atomCollector.getExtend());
        }
    }

    /**
     * Description of the method.
     */
    public void superimpose() {
        if (superpositionOperator != null) {
            AtomCollector atomCollector = new AtomCollector();
            atomCollector.visit((AbstractObject) this);
            atomCollector.transformAtoms(superpositionOperator);
            superpositionOperator.transform(center);
        }
    }

    /**
     * Description of the method.
     */
    private void createLink() {
        if (link == null) {
            link = new Link();
            HashSet objects = new HashSet();
            objects.add(this);
            link.setObjects(objects);
        }
    }

    /**
     * Method description.
     *
     * @param isImposed Parameter description.
     */
    public void setImposed(boolean isImposed) {
        this.isImposed = isImposed;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public boolean isImposed() {
        return isImposed;
    }

    /**
     * Method description.
     *
     * @param isMaster Parameter description.
     */
    public void setMaster(boolean isMaster) {
        this.isMaster = isMaster;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public boolean isMaster() {
        return isMaster;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public String getId() {
        return id;
    }

    /**
     * Method description.
     *
     * @param id Parameter description.
     */
    public void setId(String id) {
        this.id = id;
    }
}
