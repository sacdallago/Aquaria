/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.accesscontrol.checks;

import java.net.InetAddress;

import org.srs3d.viewer.util.ExceptionHandler;
import org.srs3d.viewer.util.Log;

/**
 * @author Karsten Klein
 *
 * @created March 22, 2002
 */
public class ServerClientIPCheck extends ServerClientCheck {
    private static final Log log = new Log(ServerClientIPCheck.class);

    /**
     * Method description.
     *
     * @return Return description.
     */
    public String getName() {
        return "ServerClientIPCheck-1.0";
    }

    /**
     * Method description.
     *
     * @param serverHost Parameter description.
     *
     * @return Return description.
     */
    public boolean checkServer(String serverHost) {
        boolean isSuccess = false;
        if (serverHost.trim().length() == 0) {
            serverHost = "localhost";
        }
        try {

            // the server has to be fully qualified in this check, since the client
            // is only checked by ip (which might be huge ranges)
            if (serverHost.equalsIgnoreCase("localhost")) {
                isSuccess = false;
            } else {
                InetAddress ip = InetAddress.getByName(serverHost);
                String machineName = ip.getHostName();
                int index = machineName.indexOf(".");
                if (machineName.indexOf(".") != -1) {
                    machineName = machineName.substring(0, index);
                }
                log.info("Checking " + machineName + " " + ip.getHostAddress());
                isSuccess = contains(machineName, ip.getHostAddress());
            }
        } catch (java.net.UnknownHostException e) {
            log.error("Cannot resolve server host " + serverHost);
            isSuccess = contains(serverHost);
            if (!isSuccess) {
                log.error("Server name " + serverHost +
                    " has no access permission!");
            }
            ExceptionHandler.handleException(e,
                ExceptionHandler.SILENT_IN_RELEASE, this);
        }
        return isSuccess;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public boolean checkClient() {
        boolean isSuccess = false;
        try {
            InetAddress ip = InetAddress.getLocalHost();
            if (!ip.getHostName().equalsIgnoreCase("localhost")) {
                log.info("Checking " + ip.getHostName() + " " +
                    ip.getHostAddress());

                // checking IP only, not the name
                isSuccess = containsIP(ip.getHostAddress());
            } else {
                isSuccess = false;
                log.error("Client host invalid.");
            }
        } catch (java.net.UnknownHostException e) {
            log.error("Cannot resolve local host!");
            ExceptionHandler.handleException(e,
                ExceptionHandler.SILENT_IN_DEBUG, this);
        }
        return isSuccess;
    }
}
