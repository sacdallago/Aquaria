/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.geometry.primitive;

import javax.media.j3d.GeometryArray;
import javax.media.j3d.LineArray;
import javax.media.j3d.Shape3D;
import javax.vecmath.Matrix3f;
import javax.vecmath.Vector3f;

import org.srs3d.viewer.vecmath.ColorArray4f;
import org.srs3d.viewer.vecmath.PointArray3f;

/**
 * The <code>Line</code> class can be used to generate a <code>LineArray </code>instance.
 * The class provides all data of the line. The method <code>insertInto(...)</code> can
 * be used to accumulate lines.
 *
 * @author Karsten Klein, 10/2000
 *
 * @created March 20, 2001
 * @since 1.0
 */
public class Line implements AbstractPrimitive {

    /** Array with the line coordinates */
    private PointArray3f coordinates = null;

    /** Array with per vertex colors */
    private ColorArray4f colors = null;

    /**
     * <code>Line</code> contructor.
     */
    public Line() {
        coordinates = new PointArray3f(2);
        colors = new ColorArray4f(2);
    }

    /**
     * Gets the <code>Coordinates</code> attribute of the <code>Line</code> object
     *
     * @return The <code>Coordinates</code> value
     */
    public PointArray3f getCoordinates() {
        return coordinates;
    }

    /**
     * Gets the <code>Colors</code> attribute of the <code>Line</code> object
     *
     * @return The <code>Colors</code> value
     */
    public ColorArray4f getColors() {
        return colors;
    }

    /**
     * Use this method to create a shape that represents a single line.
     *
     * @return <code>Shape3D</code> - the shape including the line geometry.
     *
     * @see AbstractPrimitive
     */
    public Shape3D getShape() {
        LineArray lineArray = new LineArray(2, GeometryArray.COORDINATES);
        insertInto(0, lineArray);
        Shape3D shape = new Shape3D(lineArray);
        return shape;
    }

    /**
     * Computes the connecting vector of the points defining the line.
     *
     * @return <code>Vector3f</code> - the vector conntecting the start with the end
     *         point of the line. The directional vector is NOT normalized.
     */
    public Vector3f computeAxis() {
        Vector3f connect = new Vector3f(coordinates.getAt(1));
        connect.sub(coordinates.getAt(0));
        return connect;
    }

    /**
     * Computes the length of the line.
     *
     * @return <code>float</code> - the euclidean length of the line
     */
    public float computeLength() {
        Vector3f connect = new Vector3f(coordinates.getAt(1));
        connect.sub(coordinates.getAt(0));
        return connect.length();
    }

    /**
     * This methods inserts the information from this line instance at the given index
     * into the triangle array.
     *
     * @param index index of the line in the line array. Note that this is the index of
     *        the line and not of the point.
     * @param lineArray the according line array.
     */
    public void insertInto(int index, LineArray lineArray) {
        int format = lineArray.getVertexFormat();
        if ((format & LineArray.COORDINATES) != 0) {
            lineArray.setCoordinates(index * 2, coordinates.getBuffer());
        }
        if ((format & LineArray.COLOR_4) != 0) {
            lineArray.setColors(index * 2, colors.getBuffer());
        }
        if ((format & LineArray.NORMALS) != 0) {
            Vector3f normal = new Vector3f(0, 0, 0);
            lineArray.setNormal(index * 2, normal);
            lineArray.setNormal(index * 2 + 1, normal);
        }
    }

    /**
     * This method computes the rotation the line would need to be transformed with to
     * end up in the current orientation. It is assumed that the 'original' line was
     * generated with its long axis in the y-axis of the default coordinate system.
     *
     * @param rotation the computed rotation matrix.
     */
    public void computeRotation(Matrix3f rotation) {

        // compute transformational components
        Vector3f basisz = computeAxis();
        basisz.normalize();

        // create orthonormal basis from basisy
        Vector3f basisx = new Vector3f(basisz);
        if (basisx.x > 0.3 || basisx.x < -0.3) {
            basisx.y = basisx.x / Math.abs(basisx.x);
            basisx.x = 0;
        } else {
            if (basisx.y > 0.3 || basisx.y < -0.3) {
                basisx.x = basisx.y / Math.abs(basisx.y);
                basisx.y = 0;
            } else if (basisx.z > 0.3 || basisx.z < -0.3) {
                basisx.x = basisx.z / Math.abs(basisx.z);
                basisx.z = 0;
            }
        }
        basisx.normalize();
        Vector3f basisy = new Vector3f();
        basisy.cross(basisz, basisx);
        basisy.normalize();
        basisx.cross(basisy, basisz);
        basisy.negate();
        rotation.setColumn(0, basisx);
        rotation.setColumn(1, basisy);
        rotation.setColumn(2, basisz);
    }
}
