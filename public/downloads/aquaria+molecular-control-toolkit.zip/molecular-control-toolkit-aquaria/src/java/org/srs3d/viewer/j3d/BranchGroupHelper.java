/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d;

import java.util.Enumeration;

import javax.media.j3d.BranchGroup;
import javax.media.j3d.CapabilityNotSetException;
import javax.media.j3d.Group;
import javax.media.j3d.RestrictedAccessException;
import javax.media.j3d.SceneGraphObject;
import javax.media.j3d.Shape3D;

import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.util.ExceptionHandler;
import org.srs3d.viewer.util.Log;

/**
 * BranchGroup extension class. Provides static methods for branch group set up and
 * control.
 *
 * @author Karsten Klein, 02/2001
 *
 * @created February 25, 2002
 */
public class BranchGroupHelper {
    private static final Log log = new Log(BranchGroupHelper.class);

    /**
     * Applies the default capability setting to the provided BranchGroup. The default
     * capbilities currenlty are dependent on the clean up process privided with the
     * detach() method for subscenegraph removal. ALLOW_CHILDREN_WRITE and _EXTEND are
     * always set. As well as the ALLOW_DETACH. To ensure ALLOW_CHILDREN_READ is set,
     * set it explicitly after calling the method.
     *
     * @param branchGroup The BranchGroup for setting the defaults.
     */
    public static void setDefaultCapabilities(BranchGroup branchGroup) {
        branchGroup.setCapability(BranchGroup.ALLOW_DETACH);
        branchGroup.setCapability(Group.ALLOW_CHILDREN_EXTEND);
        branchGroup.setCapability(Group.ALLOW_CHILDREN_READ);
        branchGroup.setCapability(Group.ALLOW_CHILDREN_WRITE);
    }

    /**
     * Applies the default capability setting to the provided Group. The default
     * capbilities currenlty are dependent on the clean up process privided with the
     * detach() method for subscenegraph removal. ALLOW_CHILDREN_WRITE and _EXTEND are
     * always set. To ensure ALLOW_CHILDREN_READ is set, set it explicitly after calling
     * the method.
     *
     * @param group The Group for setting the defaults.
     */
    public static void setDefaultCapabilities(Group group) {
        group.setCapability(Group.ALLOW_CHILDREN_EXTEND);
        group.setCapability(Group.ALLOW_CHILDREN_READ);
        group.setCapability(Group.ALLOW_CHILDREN_WRITE);
    }

    /**
     * Description of the method.
     *
     * @param branchGroup Description of parameter.
     * @param contextData Description of parameter.
     */
    public static final void detach(ContextData contextData,
        BranchGroup branchGroup) {
        SceneGraphObject obj;
        try {

            // detach all spawner childs
            for (Enumeration enumer = branchGroup.getAllChildren();
            		enumer.hasMoreElements();) {
                obj = (SceneGraphObject) enumer.nextElement();
                if (obj != null) {
                    if (obj instanceof Shape3D) {
                        try {
                            AbstractObject object =
                                (AbstractObject) obj.getUserData();
                            if (object != null) {
                                contextData.getShapeManager().remove(object);
                            }
                        } catch (ClassCastException e) {

                            // :SILENT:
                            ExceptionHandler.handleException(e,
                                ExceptionHandler.SILENT_IN_RELEASE);
                        }
                    }
                    obj.setUserData(null);
                    if (obj instanceof Spawner) {

                        // the spawner cares about all detaching and even more
                        ((Spawner) obj).cleanup(contextData);
                    } else if (obj instanceof BranchGroup) {
                        try {
                            detach(contextData, (BranchGroup) obj);
                            ((BranchGroup) obj).detach();
                        } catch (CapabilityNotSetException e) {

                            // do nothing: capability may not be set or something else
                            log.debug(e, e);
                        }
                    }
                }
            }

            // make sure all (removeable) children where removed
            int index = 0;
            while (branchGroup.numChildren() > index) {
                try {
                    branchGroup.removeChild(index);
                } catch (RestrictedAccessException e) {

                    // do nothing: capability may not be set or something else
                    index++;
                } catch (Exception e) {
                    index++;
                    ExceptionHandler.handleException(e,
                        ExceptionHandler.SILENT_IN_RELEASE);
                }
            }
        } catch (Exception e) {

            // can't do anything about the branchgroup
            ExceptionHandler.handleException(e,
                ExceptionHandler.SILENT_IN_RELEASE);
        }
    }
}
