/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.styles;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Vector;

import org.srs3d.viewer.bioatlas.attributes.AtomRepresentation;
import org.srs3d.viewer.bioatlas.attributes.Representation;
import org.srs3d.viewer.bioatlas.attributes.ResidueRepresentation;
import org.srs3d.viewer.bioatlas.attributes.SubchainRepresentation;
import org.srs3d.viewer.bioatlas.colorschemes.CPKColorScheme;
import org.srs3d.viewer.bioatlas.colorschemes.ChainColorScheme;
import org.srs3d.viewer.bioatlas.colorschemes.FirstImpressionColorScheme;
import org.srs3d.viewer.bioatlas.colorschemes.MoleculeColorScheme;
import org.srs3d.viewer.bioatlas.colorschemes.SecondaryStructureColorScheme;
import org.srs3d.viewer.bioatlas.filters.LigandFilter;
import org.srs3d.viewer.bioatlas.filters.SecondaryStructureFilter;
import org.srs3d.viewer.bioatlas.filters.SubchainFilter;
import org.srs3d.viewer.bioatlas.filters.WaterFilter;
import org.srs3d.viewer.bioatlas.modules.AnnotationToggleModule;
import org.srs3d.viewer.bioatlas.modules.BallAndStickCheck;
import org.srs3d.viewer.bioatlas.modules.VanDerWaalsCheck;
import org.srs3d.viewer.bioatlas.modules.WireframeCheck;
import org.srs3d.viewer.bioatlas.objects.Atom;
import org.srs3d.viewer.bioatlas.objects.Bond;
import org.srs3d.viewer.bioatlas.objects.Chain;
import org.srs3d.viewer.bioatlas.objects.Coil;
import org.srs3d.viewer.bioatlas.objects.Helix;
import org.srs3d.viewer.bioatlas.objects.Layer;
import org.srs3d.viewer.bioatlas.objects.NucleicChain;
import org.srs3d.viewer.bioatlas.objects.Residue;
import org.srs3d.viewer.bioatlas.objects.Site;
import org.srs3d.viewer.bioatlas.objects.Strand;
import org.srs3d.viewer.bioatlas.objects.Turn;
import org.srs3d.viewer.bioatlas.visitors.AtomCollector;
import org.srs3d.viewer.j3d.ColorScheme;
import org.srs3d.viewer.j3d.ColorSchemeBucket;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.attributes.Visible;
import org.srs3d.viewer.j3d.commands.ColorCommand;
import org.srs3d.viewer.j3d.commands.ExpandCommand;
import org.srs3d.viewer.j3d.commands.RemoveStateCommand;
import org.srs3d.viewer.j3d.commands.VisibleCommand;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.objects.Attribute;
import org.srs3d.viewer.objects.Command;
import org.srs3d.viewer.objects.ObjectManager;
import org.srs3d.viewer.objects.State;
import org.srs3d.viewer.objects.StrategyManager;
import org.srs3d.viewer.objects.filters.ObjectClassFilter;
import org.srs3d.viewer.objects.visitors.ObjectCollector;
import org.srs3d.viewer.objects.visitors.ObjectLocalizer;

/**
 * <code>FirstImpressionStyle</code> . This <code>Style</code> implementation is meant to
 * highlight things in a <code>Layer</code> objects that should be intermediate visible
 * to biologists.
 *
 * @author Karsten Klein
 *
 * @created July 11, 2001
 */
public class FirstImpressionStyle extends AbstractStyle {
    private boolean hasSecondaryStructure = true;
    private boolean hasMultipleChains = true;
    private boolean hasMultipleMolecules = true;
    private boolean hasLigands = true;

    /**
     * <code>FirstImpressionStyle</code> constructor.
     *
     * @param contextData Description of parameter.
     */
    public FirstImpressionStyle(ContextData contextData) {
        super(contextData);
    }

    private void createColorScheme() {
        if (getContextData().getProperty(FirstImpressionColorScheme.class) == null) {
            ContextData contextData = getContextData();
            Collection layers = new HashSet();
            ObjectManager.extract(contextData.getObjectContainer().getObjects(),
                layers, Layer.class);
            Iterator iterator = layers.iterator();
            while (iterator.hasNext()) {
                if (((Layer) iterator.next()).isSequenceLayer()) {
                    iterator.remove();
                }
            }
            ObjectCollector objectCollector =
                new ObjectCollector(new ObjectClassFilter(Chain.class));
            objectCollector.visit(layers);
            iterator = objectCollector.getObjects().iterator();
            while (iterator.hasNext()) {
                if (((Chain) iterator.next()).isLigand()) {
                    iterator.remove();
                }
            }

            //      ObjectCollector ligandCollector =
            //        new ObjectCollector( new LigandFilter() );
            //      ligandCollector.visit( objectCollector.getObjects() );
            FirstImpressionColorScheme colorScheme =
                new FirstImpressionColorScheme(contextData);
            getContextData().setProperty(FirstImpressionColorScheme.class,
                colorScheme);
            int difference = objectCollector.getObjects().size();

            //      int difference = objectCollector.getObjects().size() -
            //        ligandCollector.getObjects().size();
            if (difference > 1) {

                // more than 1 chain
                // keep defaults
                iterator = objectCollector.getObjects().iterator();
                Chain chain;
                HashSet identifiers = new HashSet();
                Object identifier;
                while (iterator.hasNext()) {
                    chain = (Chain) iterator.next();
                    identifier =
                        MoleculeColorScheme.computeIdentifier(contextData, chain);
                    identifiers.add(identifier);
                }
                if (identifiers.size() < 2) {
                    hasMultipleMolecules = false;
                }
            } else {

                // only one chain
                hasMultipleMolecules = false;
                hasMultipleChains = false;
            }
            float colorScale = hasLigands ? 0.65f : 1.0f;
            if (!hasMultipleMolecules) {

                // determine SecondaryStructure availablility
                ObjectCollector collector =
                    new ObjectCollector(new SecondaryStructureFilter());
                collector.setMode(ObjectCollector.COLLECT_ONE);
                collector.visit(objectCollector.getObjects());
                hasSecondaryStructure = !collector.getObjects().isEmpty();
            }
            if (hasMultipleMolecules) {

                // create molecule coloring
                MoleculeColorScheme baseColorScheme =
                    new MoleculeColorScheme(contextData);
                baseColorScheme.setColorScale(colorScale);
                colorScheme.setBaseColorScheme(baseColorScheme);
            } else if (hasMultipleChains || !hasSecondaryStructure) {

                // chain coloring
                ChainColorScheme baseColorScheme =
                    new ChainColorScheme(contextData);
                baseColorScheme.setColorScale(colorScale);
                colorScheme.setBaseColorScheme(baseColorScheme);
            } else {

                // SecondaryStructureColorScheme
                SecondaryStructureColorScheme baseColorScheme =
                    new SecondaryStructureColorScheme(contextData);
                baseColorScheme.setColorScale(colorScale);
                colorScheme.setBaseColorScheme(baseColorScheme);
            }
        }
    }

    /**
     * Method description.
     *
     * @param layer Parameter description.
     *
     * @return Return description.
     */
    public boolean applyLargeScaleState(Layer layer) {

        //    ContextData contextData = getContextData();
        //    StrategyManager strategyManager = contextData.getStrategyManager();
        //
        //    Collection commands = new ArrayList();
        //    WireframeCheck.sharedInstance.getAllOnCommands( contextData, commands );
        //    strategyManager.execute( layer,
        //      new CommandCollection( contextData, commands ) );
        return false;
    }

    /**
     * Description of the method.
     *
     * @param layer Description of parameter.
     */
    public void applyStateChange(Layer layer) {
        adaptStatePrototypes();
        processSubchains(layer);
        processResidues(layer);
        processSites(layer);
        processLigands(layer);
    }

    /**
     * Method description.
     *
     * @param layer Parameter description.
     */
    public void processResidues(Layer layer) {
    }

    /**
     * Description of the method.
     *
     * @param layer Description of parameter.
     */
    public void applyColorScheme(Layer layer) {
        createColorScheme();
        ColorSchemeBucket bucket = new ColorSchemeBucket();
        CPKColorScheme cpkColorScheme = new CPKColorScheme(getContextData());
        cpkColorScheme.setComplete(true);
        cpkColorScheme.setInformation(false);
        bucket.extend(cpkColorScheme);
        bucket.extend(getColorScheme(FirstImpressionColorScheme.class));
        ColorCommand colorCommand = new ColorCommand(getContextData(), bucket);
        colorCommand.setForceRecoloring(true);
        colorCommand.setRespawning(false);
        colorCommand.setExpanding(false);
        colorCommand.propagate(layer);
        getContextData().setColorSchemeBucket(bucket);
        AnnotationToggleModule.updateColoring(getContextData(), bucket);
    }

    /**
     * Set the subchain mode.
     *
     * @param layer Description of parameter.
     */
    public void processSubchains(Layer layer) {
        ContextData contextData = getContextData();
        ObjectCollector objectCollector =
            new ObjectCollector(new SubchainFilter());
        objectCollector.visit((AbstractObject) layer);
        if (!layer.isSequenceLayer()) {
            if (objectCollector.getObjects().isEmpty()) {
                hasSecondaryStructure = false;
            } else {

                // count residues
                int residues = countResidues(objectCollector.getObjects());
                Collection commands = new Vector();
                if (residues > 4000) {
                    adaptStatePrototypesCATrace();
                }
                StrategyManager strategyManager =
                    contextData.getStrategyManager();
                strategyManager.propagate(objectCollector.getObjects(),
                    new RemoveStateCommand(contextData), null);

                // all objects default to their prototype (default) state
            }
        } else {
            if (!objectCollector.getObjects().isEmpty()) {
                StrategyManager strategyManager =
                    contextData.getStrategyManager();
                strategyManager.execute(objectCollector.getObjects(),
                    new ExpandCommand(contextData, true, false));
            }
            hasSecondaryStructure = false;
        }
    }

    /**
     * Method description.
     *
     * @param collection Parameter description.
     *
     * @return Return description.
     */
    public int countResidues(Collection collection) {
        ObjectCollector objectCollector =
            new ObjectCollector(new ObjectClassFilter(Residue.class));
        objectCollector.visit(collection);
        return objectCollector.getObjects().size();
    }

    protected void adaptStatePrototypes() {
        ContextData contextData = getContextData();
        State state;
        state = new State();
        state.setAttribute(Attribute.getInstance(Visible.class));
        AtomRepresentation atomRepresentation =
            (AtomRepresentation) Attribute.getInstance(AtomRepresentation.class);
        atomRepresentation.setMode(Representation.REPRESENTATION_BALL_AND_STICK);
        state.setAttribute(atomRepresentation);
        contextData.getStatePrototypeManager().register(Atom.class, state.copy());
        adaptStatePrototypesRibbon();
    }

    /**
     * Method description.
     */
    public void adaptStatePrototypesCATrace() {
        ContextData contextData = getContextData();
        State state;

        // subchain state prototype changed
        state = new State();
        state.setAttribute(Attribute.getInstance(Visible.class));
        SubchainRepresentation subchainRepresentation =
            (SubchainRepresentation) Attribute.getInstance(SubchainRepresentation.class);
        subchainRepresentation.setMode(Representation.REPRESENTATION_CATRACE);
        state.setAttribute(subchainRepresentation);
        contextData.getStatePrototypeManager().register(Helix.class, state);
        contextData.getStatePrototypeManager().register(Strand.class, state);
        contextData.getStatePrototypeManager().register(Turn.class, state);
        contextData.getStatePrototypeManager().register(Coil.class, state);
        contextData.getStatePrototypeManager().register(NucleicChain.class,
            state);

        // residue state prototype changed
        state = new State();
        state.setAttribute(Attribute.getInstance(Visible.class));
        ResidueRepresentation residueRepresentation =
            (ResidueRepresentation) Attribute.getInstance(ResidueRepresentation.class);
        residueRepresentation.setMode(Representation.REPRESENTATION_CATRACE);
        state.setAttribute(residueRepresentation);
        contextData.getStatePrototypeManager().register(Residue.class, state);
    }

    /**
     * Method description.
     */
    public void adaptStatePrototypesRibbon() {
        ContextData contextData = getContextData();
        State state;

        // subchain state prototype changed
        state = new State();
        state.setAttribute(Attribute.getInstance(Visible.class));
        SubchainRepresentation subchainRepresentation =
            (SubchainRepresentation) Attribute.getInstance(SubchainRepresentation.class);
        subchainRepresentation.setMode(Representation.REPRESENTATION_RIBBON);
        state.setAttribute(subchainRepresentation);
        contextData.getStatePrototypeManager().register(Helix.class, state);
        contextData.getStatePrototypeManager().register(Strand.class, state);
        contextData.getStatePrototypeManager().register(Turn.class, state);
        contextData.getStatePrototypeManager().register(Coil.class, state);
        contextData.getStatePrototypeManager().register(NucleicChain.class,
            state);

        // residue state prototype changed
        state = new State();
        state.setAttribute(Attribute.getInstance(Visible.class));
        ResidueRepresentation residueRepresentation =
            (ResidueRepresentation) Attribute.getInstance(ResidueRepresentation.class);
        residueRepresentation.setMode(Representation.REPRESENTATION_RIBBON);
        state.setAttribute(residueRepresentation);
        contextData.getStatePrototypeManager().register(Residue.class, state);
    }

    /**
     * Method description.
     *
     * @param layer Parameter description.
     */
    public void processLigands(Layer layer) {
        if (!layer.isSequenceLayer()) {
            boolean isWireframe = false;
            processWaters(layer);
            ContextData contextData = getContextData();
            StrategyManager strategyManager = contextData.getStrategyManager();

            // collect all ligands, except waters
            ObjectCollector objectCollector =
                new ObjectCollector(new LigandFilter(true));
            objectCollector.visit((AbstractObject) layer);
            if (!objectCollector.getObjects().isEmpty()) {

                // count the atoms that will become visible
                AtomCollector atomCollector = new AtomCollector();
                atomCollector.visit(objectCollector.getObjects());
                Vector commands = new Vector();
                if (atomCollector.getObjects().size() > 1000) {

                    // apply wireframe
                    WireframeCheck.sharedInstance.getAllOnCommands(contextData,
                        commands);
                    isWireframe = true;
                } else {

                    // apply van der waals
                    VanDerWaalsCheck.sharedInstance.getAllOnCommands(contextData,
                        commands);
                }
                commands.add(new VisibleCommand(contextData, true));
                strategyManager.propagate(objectCollector.getObjects(),
                    new RemoveStateCommand(contextData), null);
                if (!isWireframe) {
                    strategyManager.propagate(objectCollector.getObjects(),
                        new ExpandCommand(contextData, true, false),
                        Residue.class);
                } else {
                    strategyManager.propagate(objectCollector.getObjects(),
                        new ExpandCommand(contextData, false), Residue.class);
                    strategyManager.execute(objectCollector.getObjects(),
                        new ExpandCommand(contextData, true, false));
                }
                strategyManager.execute(objectCollector.getObjects(), commands);
                hasLigands = true;
            } else {
                hasLigands = false;
            }
        }
    }

    /**
     * Method description.
     *
     * @param layer Parameter description.
     */
    public void processSites(Layer layer) {
        if (!layer.isSequenceLayer()) {
            ContextData contextData = getContextData();
            StrategyManager strategyManager = contextData.getStrategyManager();
            Collection sites = new HashSet();
            ObjectManager.extract(layer.getObjects(), sites, Site.class);
            Iterator siteIterator = sites.iterator();
            Site site;

            // apply ball and stick
            Vector ballAndStickCommands = new Vector();
            BallAndStickCheck.sharedInstance.getAllOnCommands(contextData,
                ballAndStickCommands);
            VisibleCommand hideCommand = new VisibleCommand(contextData, false);
            Iterator atomIterator;
            Iterator bondIterator;
            Atom atom;
            Bond bond;

            // show sites in ball&stick
            while (siteIterator.hasNext()) {
                site = (Site) siteIterator.next();
                if (site.getContentType() == Site.DISULFIDEBOND_RESIDUES) {

                    // assure secondary structure elements are expanded
                    HashSet set = new HashSet();
                    set.addAll(site.getResidues());
                    ObjectLocalizer objectLocalizer = new ObjectLocalizer();
                    objectLocalizer.setSearchMode(ObjectLocalizer.SEARCH_ALL);
                    objectLocalizer.visit(layer, set);
                    contextData.getStrategyManager().execute(objectLocalizer.getObjects(),
                        new ExpandCommand(contextData));

                    // hide all but CA CB SG
                    AtomCollector atomCollector = new AtomCollector();
                    atomCollector.visit(set);
                    atomIterator = atomCollector.getObjects().iterator();
                    while (atomIterator.hasNext()) {
                        atom = (Atom) atomIterator.next();
                        if (!atom.getTemplate().is(" CA")) {
                            if (!atom.getTemplate().is(" CB")) {
                                if (!atom.getTemplate().is(" SG")) {
                                    strategyManager.execute(atom, hideCommand);
                                }
                            }
                        }
                    }
                }

                // apply ball & stick to all sites but ACTIVE_SITEs
                if (site.getContentType() != Site.ACTIVE_SITE) {
                    strategyManager.execute(site, ballAndStickCommands);
                }
            }
        }
    }

    /**
     * Method description.
     *
     * @param layer Parameter description.
     */
    public void processWaters(Layer layer) {
        if (!layer.isSequenceLayer()) {
            ContextData contextData = getContextData();
            StrategyManager strategyManager = contextData.getStrategyManager();
            ObjectCollector objectCollector =
                new ObjectCollector(new WaterFilter());
            objectCollector.visit((AbstractObject) layer);
            if (!objectCollector.getObjects().isEmpty()) {

                // apply ball and stick
                ArrayList commands = new ArrayList();
                WireframeCheck.sharedInstance.getAllOnCommands(contextData,
                    commands);
                strategyManager.execute(objectCollector.getObjects(), commands);
                Command visibleCommand = new VisibleCommand(contextData, false);
                strategyManager.propagate(objectCollector.getObjects(),
                    visibleCommand, null);
                strategyManager.propagate(objectCollector.getObjects(),
                    new ExpandCommand(contextData, false), Residue.class);
            }
        }
    }

    /**
     * Method description.
     *
     * @param colorSchemeClass Parameter description.
     *
     * @return Return description.
     */
    public ColorScheme getColorScheme(Class colorSchemeClass) {
        return (ColorScheme) getContextData().getProperty(colorSchemeClass);
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public String getName() {
        return "First Impression";
    }
}
