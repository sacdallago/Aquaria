/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.objects;

import java.util.Collection;

import org.srs3d.viewer.objects.AbstractObject;

/**
 * Bond class.
 *
 * @author Karsten Klein
 *
 * @created January 28, 2001
 */
public class Bond extends AbstractObject {
    public static final int SINGLE = 1;
    public static final int DOUBLE = 2;
    public static final int TRIPLE = 3;
    public static final int DELOCALIZED = 1 + 7;
    public static final int DELOCALIZED_BOTH = 1 + 8;
    private Atom atom0 = null;
    private Atom atom1 = null;
    private int type = SINGLE;

    /**
     * Sets the <code>Atom0</code> attribute of the <code>Bond</code> object.
     *
     * @param atom The new <code>Atom0</code> value.
     */
    public void setAtom0(Atom atom) {
        this.atom0 = atom;
    }

    /**
     * Sets the <code>Atom1</code> attribute of the <code>Bond</code> object.
     *
     * @param atom The new <code>Atom1</code> value.
     */
    public void setAtom1(Atom atom) {
        this.atom1 = atom;
    }

    /**
     * Gets the <code>Atom0</code> attribute of the <code>Bond</code> object.
     *
     * @return The <code>Atom0</code> value.
     */
    public Atom getAtom0() {
        return atom0;
    }

    /**
     * Gets the <code>Atom1</code> attribute of the <code>Bond</code> object.
     *
     * @return The <code>Atom1</code> value.
     */
    public Atom getAtom1() {
        return atom1;
    }

    /**
     * Gets the <code>allObjects</code> attribute of the <code>Bond</code> object.
     *
     * @param collection Description of parameter.
     */
    public void getAllObjects(Collection collection) {
    }

    /**
     * Description of the method.
     */
    public void cleanup() {
        super.cleanup();
        atom0 = null;
        atom1 = null;
    }

    /**
     * Description of the method.
     *
     * @return Description of the returned value.
     */
    public String toString() {
        String string = "Bond";
        if (atom0 != null && atom1 != null) {
            string += "(" + atom0.getTemplate().getElement() + "-" +
            atom1.getTemplate().getElement() + ")";
        }
        return string;
    }

    /**
     * Method description.
     *
     * @param type Parameter description.
     */
    public void setType(int type) {
        this.type = type;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public int getType() {
        return type;
    }
}
