/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.dispatcher;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Vector;

import javax.vecmath.Matrix4f;
import javax.vecmath.Point3f;
import javax.vecmath.Vector3f;

import org.srs3d.viewer.bioatlas.objects.Atom;
import org.srs3d.viewer.bioatlas.objects.Chain;
import org.srs3d.viewer.bioatlas.objects.ChainFragment;
import org.srs3d.viewer.bioatlas.objects.Layer;
import org.srs3d.viewer.bioatlas.objects.Residue;
import org.srs3d.viewer.bioatlas.objects.Subchain;
import org.srs3d.viewer.bioatlas.visitors.AtomCollector;
import org.srs3d.viewer.j3d.Context;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.DispatchManager;
import org.srs3d.viewer.j3d.Transform;
import org.srs3d.viewer.j3d.TransformManager;
import org.srs3d.viewer.j3d.behaviors.KeyHandler;
import org.srs3d.viewer.j3d.behaviors.dispatcher.AbstractDispatcher;
import org.srs3d.viewer.j3d.behaviors.dispatcher.DispatchThread;
import org.srs3d.viewer.j3d.commands.ComputeCenterCommand;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.objects.ObjectManager;
import org.srs3d.viewer.objects.Operation;
import org.srs3d.viewer.objects.StrategyManager;
import org.srs3d.viewer.util.ExceptionHandler;

/**
 * @author Karsten Klein, 11/2000
 *
 * @created March 20, 2001
 * @since 1.0
 */
public abstract class ThreadedDispatcher extends AbstractDispatcher {
    public static final int TIME_TO_SHOW_WAIT_CURSOR = 500;
    private transient String lastStatus;
    private transient long lastStatusTimestamp;

    /**
     * Method description.
     *
     * @param operation Parameter description.
     */
    public void dispatch(Operation operation) {
        DispatchThread.schedule(this, operation);
    }

    /**
     * Description of the method
     *
     * @param operation Description of parameter
     * @param object Description of parameter
     */
    public void runDispatch(Operation operation) {
        final Context context = DispatchManager.getContext(this);
        final Collection set = new Vector();

        // process the operation
        if (context != null) {
            Thread thread =
                new Thread(new Runnable() {
                        public void run() {
                            try {
                                Thread.sleep(TIME_TO_SHOW_WAIT_CURSOR);
                            } catch (InterruptedException e) {

                                // :SILENT EXCEPTION:
                            }
                            synchronized (set) {
                                if (set.isEmpty()) {
                                    KeyHandler.getKeyHandler(context.getContextData())
                                              .setWaitCursor();
                                }
                            }
                        }
                    });
            thread.start();
            try {
                process(context, operation);
            } catch (Exception e) {
                ExceptionHandler.handleException(e,
                    ExceptionHandler.TRACE_IN_RELEASE, this);
            } finally {
                synchronized (set) {
                    set.add(context);
                    KeyHandler.getKeyHandler(context.getContextData())
                              .restoreCursor();
                }
            }
        }
    }

    /**
     * Method description.
     *
     * @param context Parameter description.
     * @param operation Parameter description.
     */
    public abstract void process(Context context, Operation operation);

    /**
     * Displays the hierarchy of the objects in the selection. Assumes that the selection
     * is collapsed up the hierarchy
     *
     * @param objects Description of parameter.
     */
    public void showSelectionMessage(ContextData contextData, Collection objects) {
        if (objects != null && !objects.isEmpty()) {
            Collection collection = new HashSet();
            Collection filteredCollection = new ArrayList();
            String string = new String();
            contextData.getObjectManager().getUpAssociations(objects, collection);
            collection.addAll(objects);
            filteredCollection.clear();
            ObjectManager.extract(collection, filteredCollection, Layer.class);
            if (!filteredCollection.isEmpty()) {
                string += filteredCollection;
            }
            filteredCollection.clear();
            ObjectManager.extract(collection, filteredCollection, Chain.class);
            if (!filteredCollection.isEmpty()) {
                string += filteredCollection;
            }
            filteredCollection.clear();
            ObjectManager.extract(collection, filteredCollection,
                ChainFragment.class);
            if (!filteredCollection.isEmpty()) {
                string += filteredCollection;
            }
            filteredCollection.clear();
            ObjectManager.extract(collection, filteredCollection, Subchain.class);
            if (!filteredCollection.isEmpty()) {
                string += filteredCollection;
            }
            if (string.length() < 80) {
                filteredCollection.clear();
                ObjectManager.extract(collection, filteredCollection,
                    Residue.class);
                if (!filteredCollection.isEmpty()) {
                    string += filteredCollection;
                }
            }
            if (string.length() < 80) {
                filteredCollection.clear();
                ObjectManager.extract(collection, filteredCollection, Atom.class);
                if (!filteredCollection.isEmpty()) {
                    string += filteredCollection;
                }
            }

            // fromm the collection toString method
            string = string.replace('[', ' ');
            string = string.replace(']', ' ');
            string = string.trim();
            if (string.length() > 80) {
                string += "...";
            }
            showStatus(contextData, string);
        } else {
            showStatus(contextData, "");
        }
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     * @param objects Parameter description.
     * @param center Parameter description.
     * @param extend Parameter description.
     *
     * @return Return description.
     */
    public static boolean computeCenter(ContextData contextData,
        Collection objects, Point3f center, Vector3f extend) {
        center.set(0, 0, 0);
        extend.set(0, 0, 0);
        if (!objects.isEmpty()) {
            ObjectManager objectManager = contextData.getObjectManager();
            TransformManager transformManager =
                contextData.getTransformManager();
            StrategyManager strategyManager = contextData.getStrategyManager();
            int counter = 0;
            Matrix4f matrix = new Matrix4f();
            Vector3f min =
                new Vector3f(Float.MAX_VALUE, Float.MAX_VALUE, Float.MAX_VALUE);
            Vector3f max =
                new Vector3f(-Float.MAX_VALUE, -Float.MAX_VALUE,
                    -Float.MAX_VALUE);

            // collapse object set first
            Collection collapsed = new HashSet(objects.size());
            objectManager.collapseUp(objects, collapsed);

            // search for layers
            Collection layers = new HashSet(objects.size());
            objectManager.getUpAssociations(objects, layers);
            layers.addAll(collapsed);
            ObjectManager.extract(layers, Layer.class);
            org.srs3d.viewer.bioatlas.modules.StructureModule.filterSequenceLayers(layers);
            Vector3f translation = new Vector3f();
            int size = layers.size();
            if (size > 0) {
                AtomCollector atomCollector;
                Transform transform;
                Layer layer;
                Collection layerObjects = new HashSet();
                Collection set = new HashSet();
                AbstractObject object;
                Iterator layerIterator = layers.iterator();
                Iterator iterator;
                Point3f tempCenter = new Point3f();
                Vector3f tempExtend = new Vector3f();
                ComputeCenterCommand computeCenterCommand =
                    new ComputeCenterCommand(contextData);
                while (layerIterator.hasNext()) {
                    layer = (Layer) layerIterator.next();

                    // we can save the distingtion, if there is only one layer
                    if (size > 1) {
                        if (collapsed.contains(layer)) {

                            // the full layer is contained in the selection
                            tempCenter.set(layer.getCenter());
                            tempExtend.set(layer.getExtend());
                        } else {

                            // we have to compute the center and extend ourself
                            // :OPTIMIZE: this can be optimized; the implementation is not
                            // very speedy especially for many layers.
                            // extract those objects in the selection that belong to the layer
                            iterator = collapsed.iterator();
                            layerObjects.clear();
                            while (iterator.hasNext()) {
                                object = (AbstractObject) iterator.next();
                                set.clear();
                                objectManager.getUpAssociations(object, set);
                                if (set.contains(layer)) {
                                    layerObjects.add(object);
                                    iterator.remove();
                                }
                            }
                            computeCenterCommand =
                                new ComputeCenterCommand(contextData);
                            strategyManager.execute(layerObjects,
                                computeCenterCommand);
                            tempCenter.set(computeCenterCommand.getCenter());
                            tempExtend.set(computeCenterCommand.getExtend());
                        }
                    } else {
                        computeCenterCommand =
                            new ComputeCenterCommand(contextData);
                        strategyManager.execute(collapsed, computeCenterCommand);
                        tempCenter.set(computeCenterCommand.getCenter());
                        tempExtend.set(computeCenterCommand.getExtend());
                    }
                    transform = transformManager.getTransform(layer);
                    if (transform != null) {
                        transform.getTransform().get(matrix);
                        matrix.transform(tempCenter);
                    }
                    if (!Float.isInfinite(tempCenter.x) &&
                          !Float.isNaN(tempCenter.x)) {
                        center.add(tempCenter);
                        counter++;

                        // merge extends
                        tempExtend.scale(0.5f);
                        tempCenter.sub(tempExtend);
                        if (tempCenter.x < min.x) {
                            min.x = tempCenter.x;
                        }
                        if (tempCenter.y < min.y) {
                            min.y = tempCenter.y;
                        }
                        if (tempCenter.z < min.z) {
                            min.z = tempCenter.z;
                        }
                        tempCenter.add(tempExtend);
                        tempCenter.add(tempExtend);
                        if (tempCenter.x > max.x) {
                            max.x = tempCenter.x;
                        }
                        if (tempCenter.y > max.y) {
                            max.y = tempCenter.y;
                        }
                        if (tempCenter.z > max.z) {
                            max.z = tempCenter.z;
                        }
                    }
                }
                if (counter != 0) {
                    center.scale(1.0f / counter);
                    extend.set(max);
                    extend.sub(min);
                    return true;
                }
            } else {
                ComputeCenterCommand computeCenterCommand =
                    new ComputeCenterCommand(contextData);
                strategyManager.execute(objects, computeCenterCommand);
                center.set(computeCenterCommand.getCenter());
                extend.set(computeCenterCommand.getExtend());
                return true;
            }
        }
        return false;
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     * @param string Description of parameter.
     */
    public void showStatus(ContextData contextData, String string) {
        boolean update = !string.equals(lastStatus);
        if (!update) {
            update |= (System.currentTimeMillis() - lastStatusTimestamp) > 5000;
        }
        if (update) {
            contextData.getAppletStub().getAppletContext().showStatus(string);
            lastStatus = string;
            lastStatusTimestamp = System.currentTimeMillis();
        }
    }
}
