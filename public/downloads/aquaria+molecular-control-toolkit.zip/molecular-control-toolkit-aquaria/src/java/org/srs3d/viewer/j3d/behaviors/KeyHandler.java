/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.behaviors;

import java.awt.Component;
import java.awt.Cursor;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Iterator;
import java.util.Vector;

import org.srs3d.viewer.j3d.Context;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.operations.InputOperation;
import org.srs3d.viewer.swing.CursorManager;
import org.srs3d.viewer.util.Log;

/**
 * Description of the class.
 *
 * @author Christian Zofka
 * @author Karsten Klein
 *
 * @created August 16, 2001
 * @modified September 19, 2001
 */
public class KeyHandler implements KeyListener {
    private static final Log log = new Log(KeyHandler.class);
    private static String lastCursorName = "";
    private static int keyCode = 0;
    private ContextData contextData = null;
    private Vector components = new Vector();
    private InputEvent lastKeyEvent = null;

    /**
     * <code>KeyHandler</code> constructor.
     *
     * @param context Description of parameter.
     */
    public KeyHandler(ContextData contextData) {
        this.contextData = contextData;
    }

    /**
     * Description of the method.
     *
     * @param e Description of parameter.
     */
    public void keyPressed(KeyEvent e) {
        lastKeyEvent = e;
        if (!e.isConsumed()) {
            InputOperation operation = null;
            operation =
                new InputOperation(getContextData().getContext(), "KEY_INPUT",
                    null);
            operation.setInputEvent(e);
            getContextData().getDispatcher().dispatch(operation);
            keyCode = e.getKeyCode();
            e.consume();
        }
        setCursor(getContextData().getContext(), e, 0);
    }

    /**
     * Method description.
     *
     * @param context Parameter description.
     */
    public static void requestFocus(Context context) {
        if (context.getContextData() != null &&
              context.getContextData().isValid()) {
            context.requestFocus();
        }
    }

    /**
     * Description of the method.
     *
     * @param e Description of parameter.
     */
    public void keyReleased(KeyEvent e) {
        if (e.getModifiers() == 0) {
            lastKeyEvent = null;
        }
        setCursor(getContextData().getContext(), e, 0);
        if (!e.isConsumed()) {
            keyCode = 0;
        }
        e.consume();
    }

    /**
     * Description of the method.
     *
     * @param e Description of parameter.
     */
    public void keyTyped(KeyEvent e) {
    }

    /**
     * Method description.
     *
     * @param e Parameter description.
     *
     * @return Return description.
     */
    public String getCursorModifier(InputEvent e) {
        String cursorModifier = "";
        if (lastKeyEvent != null) {
            e = lastKeyEvent;
            if (e.isControlDown()) {
                if (e.isShiftDown()) {
                    cursorModifier = "Minus";
                } else {
                    if (e.isAltDown()) {
                        cursorModifier = "AddAll";
                    } else {
                        cursorModifier = "Add";
                    }
                }
            } else {
                if (e.isShiftDown()) {
                    cursorModifier = "Range";
                } else {
                    if (e.isAltDown()) {
                        cursorModifier = "All";
                    }
                }
            }
        }
        return cursorModifier;
    }

    /**
     * Sets the <code>cursor</code> attribute of the <code>KeyHandler</code> class.
     *
     * @param e The new <code>cursor</code> value.
     */
    public void setCursor(Context context, InputEvent e, int flags) {
        Cursor current = context.getCursor();
        Cursor cursor;
        InputEvent storedEvent = e;
        boolean isSet = false;
        String cursorName = flags == 0 ? "Select" : "Activate";
        if (lastCursorName != null) {
            cursorName = lastCursorName;
        }
        if (lastKeyEvent != null) {
            if (e != null) {
                lastKeyEvent = e;
            }
        }
        String cursorModifier = getCursorModifier(lastKeyEvent);
        setCursor(contextData.getContext(), cursorName, cursorModifier);
        lastCursorName = cursorName;
    }

    /**
     * Method description.
     *
     * @param context Parameter description.
     */
    public void setDefaultCursor(Context context) {
        setDefaultCursor(context, true);
    }

    /**
     * Method description.
     *
     * @param context Parameter description.
     * @param isSet Parameter description.
     */
    public void setDefaultCursor(Context context, boolean isSet) {
        lastCursorName = null;
        if (isSet) {
            setCursor(context,
                org.srs3d.viewer.swing.CursorManager.getCursor("Select"));
        }
    }

    /**
     * Gets the <code>context</code> attribute of the <code>KeyHandler</code> object.
     *
     * @return The <code>context</code> value.
     */
    public ContextData getContextData() {
        return contextData;
    }

    /**
     * Method description.
     *
     * @param cursor Parameter description.
     */
    public void setCursor(Cursor cursor) {
        Iterator iterator = components.iterator();
        Component component;
        while (iterator.hasNext()) {
            component = (Component) iterator.next();
            CursorManager.setCursor(component, cursor);
        }
    }

    /**
     * Method description.
     *
     * @param context Parameter description.
     * @param cursor Parameter description.
     */
    public void setCursor(Context context, Cursor cursor) {
        setCursor(cursor);
        lastCursorName = null;
    }

    /**
     * Method description.
     *
     * @param component Parameter description.
     */
    public void registerComponent(Component component) {
        components.add(component);
    }

    /**
     * Method description.
     *
     * @param context Parameter description.
     * @param cursorName Parameter description.
     * @param cursorModifier Parameter description.
     */
    public void setCursor(Context context, String cursorName,
        String cursorModifier) {
        Cursor cursor =
            org.srs3d.viewer.swing.CursorManager.getCursor(cursorName +
                cursorModifier);
        if (cursor == null) {
            cursor = org.srs3d.viewer.swing.CursorManager.getCursor(cursorName);
        }
        setCursor(cursor);
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     * @param cursorName Parameter description.
     * @param isVolatile Parameter description.
     */
    public static void setCursor(ContextData contextData, String cursorName,
        boolean isVolatile) {
        KeyHandler keyHandler =
            (KeyHandler) contextData.getProperty("KeyHandler");
        if (keyHandler != null) {
            String cursorModifier =
                keyHandler.getCursorModifier(keyHandler.lastKeyEvent);
            keyHandler.setCursor(contextData.getContext(), cursorName,
                cursorModifier);
            KeyHandler.lastCursorName = cursorName;
        } else {
            log.error("no keyhandler for " + contextData.getContext());
        }
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     * @param e Parameter description.
     * @param flags Parameter description.
     */
    public static void setCursor(ContextData contextData, InputEvent e,
        int flags) {
        KeyHandler keyHandler =
            (KeyHandler) contextData.getProperty("KeyHandler");
        if (keyHandler != null) {
            keyHandler.setCursor(contextData.getContext(), e, flags);
        } else {
            log.error("no keyhandler for " + contextData.getContext());
        }
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     * @param cursor Parameter description.
     */
    public static void setCursor(ContextData contextData, Cursor cursor) {
        KeyHandler keyHandler =
            (KeyHandler) contextData.getProperty("KeyHandler");
        keyHandler.setCursor(cursor);
        KeyHandler.lastCursorName = null;
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     *
     * @return Return description.
     */
    public static KeyHandler getKeyHandler(ContextData contextData) {
        return (KeyHandler) contextData.getProperty("KeyHandler");
    }

    /**
     * Method description.
     */
    public void reset() {
        lastCursorName = null;
        lastKeyEvent = null;
    }

    /**
     * Method description.
     */
    public void setWaitCursor() {
        Iterator iterator = components.iterator();
        Component component;
        while (iterator.hasNext()) {
            component = (Component) iterator.next();
            CursorManager.setWaitCursor(component);
        }
    }

    /**
     * Method description.
     */
    public void restoreCursor() {
        Iterator iterator = components.iterator();
        Component component;
        while (iterator.hasNext()) {
            component = (Component) iterator.next();
            CursorManager.restoreCursor(component);
        }
    }
}
