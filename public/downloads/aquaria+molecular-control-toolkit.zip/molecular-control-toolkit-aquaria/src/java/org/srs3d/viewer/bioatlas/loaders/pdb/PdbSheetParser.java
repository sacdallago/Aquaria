/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.loaders.pdb;

import org.srs3d.viewer.bioatlas.objects.Chain;
import org.srs3d.viewer.bioatlas.objects.Strand;

/**
 * This class parses strings for pdb SHEET tags and tranfers/builts the appropriate
 * datastructure in a <code>ObjectContainer</code> . Note that this parser is executed
 * as retained parser.
 *
 * @author Karsten Klein, 01/2001
 *
 * @created May 21, 2001
 * @since 1.0
 */
public class PdbSheetParser extends PdbSubchainParser {

    /** Description of the field. */
    public static final String TAG = new String("SHEET ");

    /** Description of the field. */
    private String sheetId = null;

    /** Description of the field. */
    private int strandSerial = Strand.INVALID_SERIAL;

    /** Description of the field. */
    private int strandSense = 1;

    /**
     * Parses the formated pdb string for helix data. The data is stored locally.
     *
     * @param string Description of parameter.
     */
    public void create(String string) {
        clear();
        sheetId = extractString(string, 11, 14, true);
        strandSerial = extractInt(string, 7, 10);
        strandSense = extractInt(string, 38, 40);
        chainId = extractChar(string, 21);
        initialResidueName = extractString(string, 17, 20);
        initialResidueId = extractInt(string, 22, 26);
        initialResidueICode = extractChar(string, 26);
        endResidueName = extractString(string, 28, 31);
        endResidueId = extractInt(string, 33, 37);
        endResidueICode = extractChar(string, 37);
    }

    /**
     * Visits a chain. This method adds a new strand subchain to the chain if the strand
     * is defacto part of the chain.
     *
     * @param chain Description of parameter.
     */
    public void visit(Chain chain) {
        super.visit(chain);
        Strand strand = new Strand();
        visit(strand, chain);
    }

    /**
     * Visits the strand and the chain. This method adds a helix subchain to the chain if
     * the strand is defacto part of the chain.
     *
     * @param strand Description of parameter.
     * @param chain Description of parameter.
     */
    public void visit(Strand strand, Chain chain) {

        // :NOTE: as strand identifier we siply use the sheet identifier. This
        //   enables us to identify the sheet from the strand.
        strand.setId(sheetId);
        strand.setSerial(strandSerial);
        strand.setSense(strandSense);
        super.visit(strand, chain);
    }

    /**
     * Description of the method.
     */
    public void clear() {
        super.clear();
        sheetId = null;
        strandSerial = Strand.INVALID_SERIAL;
        strandSense = 1;
    }
}
