/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas;

import org.srs3d.viewer.bioatlas.objects.Atom;
import org.srs3d.viewer.bioatlas.objects.Bond;
import org.srs3d.viewer.bioatlas.objects.Chain;
import org.srs3d.viewer.bioatlas.objects.ChainFragment;
import org.srs3d.viewer.bioatlas.objects.Coil;
import org.srs3d.viewer.bioatlas.objects.Helix;
import org.srs3d.viewer.bioatlas.objects.Layer;
import org.srs3d.viewer.bioatlas.objects.NucleicChain;
import org.srs3d.viewer.bioatlas.objects.Residue;
import org.srs3d.viewer.bioatlas.objects.Site;
import org.srs3d.viewer.bioatlas.objects.Strand;
import org.srs3d.viewer.bioatlas.objects.Turn;
import org.srs3d.viewer.bioatlas.objects.strategies.AtomStrategy;
import org.srs3d.viewer.bioatlas.objects.strategies.BondStrategy;
import org.srs3d.viewer.bioatlas.objects.strategies.ChainFragmentStrategy;
import org.srs3d.viewer.bioatlas.objects.strategies.ChainSelectionStrategy;
import org.srs3d.viewer.bioatlas.objects.strategies.LayerStrategy;
import org.srs3d.viewer.bioatlas.objects.strategies.ResidueStrategy;
import org.srs3d.viewer.bioatlas.objects.strategies.SiteStrategy;
import org.srs3d.viewer.bioatlas.objects.strategies.SubchainStrategy;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.attributes.Expanded;
import org.srs3d.viewer.j3d.attributes.Visible;
import org.srs3d.viewer.j3d.objects.strategies.LabelStrategy;
import org.srs3d.viewer.j3d.objects.strategies.LineStrategy;
import org.srs3d.viewer.j3d.objects.strategies.SurfaceStrategy;
import org.srs3d.viewer.objects.Attribute;
import org.srs3d.viewer.objects.State;
import org.srs3d.viewer.objects.StrategyManager;

/**
 * Description of the class.
 *
 * @author Karsten Klein
 *
 * @created March 22, 2001
 */
public class CellConfiguration extends Configuration {

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     */
    public static void registerStrategies(ContextData contextData) {
        StrategyManager manager = contextData.getStrategyManager();
        manager.register(Layer.class, new LayerStrategy());
        manager.register(Chain.class, new ChainSelectionStrategy());
        manager.register(ChainFragment.class, new ChainFragmentStrategy());
        manager.register(Site.class, new SiteStrategy());
        manager.register(Residue.class, new ResidueStrategy());
        manager.register(Helix.class, new SubchainStrategy());
        manager.register(Turn.class, new SubchainStrategy());
        manager.register(Strand.class, new SubchainStrategy());
        manager.register(Coil.class, new SubchainStrategy());
        manager.register(NucleicChain.class, new SubchainStrategy());
        manager.register(Atom.class, new AtomStrategy());
        manager.register(Bond.class, new BondStrategy());
        manager.register(org.srs3d.viewer.j3d.objects.Line.class,
            new LineStrategy());
        manager.register(org.srs3d.viewer.j3d.objects.Label.class,
            new LabelStrategy());
        manager.register(org.srs3d.viewer.j3d.objects.Surface.class,
            new SurfaceStrategy());
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     */
    public static void configure(ContextData contextData) {
        registerGeometryCreators(contextData);
        registerSpawners(contextData);
        registerPrototypes(contextData);
        registerStrategies(contextData);

        // additional stuff
        State expandedState = new State();
        expandedState.setAttribute(Attribute.getInstance(Visible.class));
        expandedState.setAttribute(Attribute.getInstance(Expanded.class));
        contextData.getStatePrototypeManager().register(Layer.class,
            expandedState);
    }
}
