/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.commands;

import java.awt.Point;

import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.objects.AbstractObject;

import com.sun.j3d.utils.picking.PickResult;

/**
 * Description of the class.
 *
 * @author Karsten Klein
 *
 * @created February 11, 2002
 */
public class IntersectCommand extends ObjectCommand {
    public static final int MODE_NORMAL = 1;
    public static final int MODE_TOPLEVEL = 2;
    private Point coordinate = new Point();
    private PickResult pickResult = null;
    private int mode = MODE_NORMAL;

    /**
     * <code>IntersectCommand</code> constructor.
     *
     * @param contextData Description of parameter.
     */
    public IntersectCommand(ContextData contextData) {
        super(contextData);
    }

    /**
     * Sets the <code>coordinate</code> attribute of the <code>IntersectCommand</code>
     * object.
     *
     * @param coordinate The new <code>coordinate</code> value.
     */
    public void setCoordinate(Point coordinate) {
        this.coordinate.setLocation(coordinate);
    }

    /**
     * Sets the <code>pickResult</code> attribute of the <code>IntersectCommand</code>
     * object.
     *
     * @param pickResult The new <code>pickResult</code> value.
     */
    public void setPickResult(PickResult pickResult) {
        this.pickResult = pickResult;
    }

    /**
     * Gets the <code>coordinate</code> attribute of the <code>IntersectCommand</code>
     * object.
     *
     * @return The <code>coordinate</code> value.
     */
    public Point getCoordinate() {
        return coordinate;
    }

    /**
     * Gets the <code>pickResult</code> attribute of the <code>IntersectCommand</code>
     * object.
     *
     * @return The <code>pickResult</code> value.
     */
    public PickResult getPickResult() {
        return pickResult;
    }

    /**
     * Description of the method.
     */
    public void execute() {
    }

    /**
     * Description of the method.
     *
     * @return Description of the returned value.
     */
    public AbstractObject intersect() {
        PickResult pickResult =
            getContextData().getIntersectionManager().pickClosest(coordinate.x,
                coordinate.y);
        AbstractObject object = null;
        if (pickResult != null) {
            javax.media.j3d.Node node = pickResult.getObject();
            if (node != null) {
                object = (AbstractObject) node.getUserData();
                setPickResult(pickResult);
            }
        }
        return object;
    }

    /**
     * Method description.
     *
     * @param mode Parameter description.
     */
    public void setMode(int mode) {
        this.mode = mode;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public int getMode() {
        return mode;
    }
}
