/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.annotation.dispatcher;

import java.util.Vector;

import org.srs3d.viewer.j3d.Context;
import org.srs3d.viewer.j3d.DispatchManager;
import org.srs3d.viewer.objects.Operation;
import org.srs3d.viewer.util.ExceptionHandler;

/**
 * ZoomBox thread
 *
 * @author Karsten Klein
 *
 * @created August 27, 2001
 *
 * @todo implementation with notify might be cleaner
 */
public class ZoomBoxThread implements Runnable {
    private Vector operationQueue = new Vector();
    private Vector contextQueue = new Vector();
    private boolean isVerbose = false;
    private Thread thread = null;
    private boolean isTerminated = false;

    /**
     * <code>ZoomBoxThread</code> constructor.
     */
    public ZoomBoxThread() {
        thread = new Thread(this, ZoomBoxThread.class.toString());
        thread.start();
    }

    /**
     * Description of the method.
     *
     * @param context Description of parameter.
     * @param operation Description of parameter.
     */
    public void schedule(Context context, Operation operation) {
        addOperation(context, operation);
        try {
            thread.interrupt();
        } catch (Exception e) {

            // restart thread
            thread = new Thread(this, ZoomBoxThread.class.toString());
            ExceptionHandler.handleException(e,
                ExceptionHandler.SILENT_IN_DEBUG, this);
        }
    }

    /**
     * Main processing method for the <code>ZoomBoxThread</code> object.
     */
    public void run() {
        Operation operation;
        Context context;
        Operation lastOperation = null;
        Context lastContext = null;

        // stay referenced till death of JVM
        Thread thread = this.thread;
        while (true && !isTerminated) {
            while (!operationQueue.isEmpty() && !isTerminated) {
                operation = (Operation) operationQueue.remove(0);
                context = (Context) contextQueue.remove(0);
                if (operation != null) {
                    try {
                        context.waitForUpdate();
                        DispatchManager.runDispatch(context, operation);
                    } catch (Exception e) {
                        ExceptionHandler.handleException(e,
                            ExceptionHandler.SILENT_IN_DEBUG, this);
                    }
                }
                if (operation != null) {
                    if (operation.getId().equalsIgnoreCase("SWITCH_ALIGNMENT")) {
                        if (lastOperation != null) {
                            if (!lastOperation.getId().equalsIgnoreCase("SWITCH_ALIGNMENT")) {
                                try {
                                    lastContext.waitForUpdate();

                                    // fire last move (last one before switch)
                                    DispatchManager.runDispatch(lastContext,
                                        lastOperation);
                                } catch (Exception e) {
                                    ExceptionHandler.handleException(e,
                                        ExceptionHandler.SILENT_IN_DEBUG, this);
                                }
                            }
                        }
                    } else {
                        lastOperation = operation;
                        lastContext = context;
                    }
                }
                try {
                    Thread.sleep(org.srs3d.viewer.bioatlas.Parameter.zoomBoxUpdateDelay);
                } catch (InterruptedException e) {

                    // :SILENT EXCEPTION:
                }
            }

            // keep thread stack clear
            operation = null;
            context = null;
            lastOperation = null;
            lastContext = null;
            try {
                Thread.sleep(10000);
            } catch (InterruptedException e) {

                // :SILENT EXCEPTION:
            }
        }
    }

    /**
     * Description of the method.
     */
    public void terminate() {
        isTerminated = true;
        operationQueue.clear();
        contextQueue.clear();
    }

    /**
     * Description of the method.
     *
     * @param context Description of parameter.
     * @param operation Description of parameter.
     */
    private void addOperation(Context context, Operation operation) {
        Operation op;
        Operation lastSwitchAlignment = null;
        Context lastSwitchAlignmentContext = null;
        if (operation.getId().equalsIgnoreCase("SWITCH_ALIGNMENT")) {
            for (int i = 0; i < operationQueue.size(); i++) {
                op = (Operation) operationQueue.elementAt(i);
                if (op != null && op.is("SWITCH_ALIGNMENT")) {
                    operationQueue.setElementAt(null, i);
                }
            }
            addNullOperations(30);
        } else {
            addNullOperations(5);
        }
        operationQueue.add(operation);
        contextQueue.add(context);
    }

    /**
     * Method description.
     *
     * @param count Parameter description.
     */
    public void addNullOperations(int count) {
        for (int i = 0; i < count; i++) {
            operationQueue.add(null);
            contextQueue.add(null);
        }
    }
}
