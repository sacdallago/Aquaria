/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.attributes;

import org.srs3d.viewer.objects.Attribute;

/**
 * Representation attribute.
 *
 * @author Karsten Klein
 *
 * @created April 03, 2001
 */
public abstract class Representation extends Attribute {
    public static final int REPRESENTATION_WIREFRAME = 1;
    public static final int REPRESENTATION_RIBBON = 2;
    public static final int REPRESENTATION_COIL = 4;
    public static final int REPRESENTATION_CATRACE = 8;
    public static final int REPRESENTATION_BACKBONE = 16;
    public static final int REPRESENTATION_SOAPFILM = 32;
    public static final int REPRESENTATION_BALL_AND_STICK = 64;
    public static final int REPRESENTATION_VAN_DER_WAALS = 128;
    public static final int REPRESENTATION_ATOM_MODE =
        REPRESENTATION_BALL_AND_STICK | REPRESENTATION_WIREFRAME |
        REPRESENTATION_VAN_DER_WAALS;
    private int mode = 0;

    /**
     * Gets the <code>targetClass</code> attribute of the <code>Representation</code>
     * object.
     *
     * @return The <code>targetClass</code> value.
     */
    public abstract Class getTargetClass();

    /**
     * Gets the <code>equal</code> attribute of the <code>Representation</code> object.
     *
     * @param representation Description of parameter.
     *
     * @return The <code>equal</code> value.
     */
    public boolean isEqual(Attribute attribute) {
        if (attribute instanceof Representation) {
            Representation representation = (Representation) attribute;
            return getMode() == representation.getMode();
        }
        return false;
    }

    /**
     * Description of the method.
     *
     * @return Description of the returned value.
     */
    public Attribute copy() {
        Representation representation = (Representation) super.copy();
        representation.setMode(getMode());
        return representation;
    }

    /**
     * Sets the <code>mode</code> attribute of the <code>Representation</code> object.
     *
     * @param mode The new <code>mode</code> value.
     */
    public final void setMode(int mode) {
        this.mode = mode;
    }

    /**
     * Gets the <code>mode</code> attribute of the <code>Representation</code> object.
     *
     * @return The <code>mode</code> value.
     */
    public final int getMode() {
        return mode;
    }

    /**
     * Method description.
     *
     * @param representation Parameter description.
     */
    public void merge(Representation representation) {
        this.mode |= representation.getMode();
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public String toString() {
        return getClass().getName() + "(" + mode + ")";
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public Attribute.Immutable getImmutable() {
        return new Immutable();
    }

    /**
     * Class description.
     *
     * @author Karsten Klein, LION bioscience AG
     */
    public class Immutable extends Attribute.Immutable {

        /**
         * Method description.
         *
         * @return Return description.
         */
        public final int getMode() {
            return Representation.this.getMode();
        }
    }
}
