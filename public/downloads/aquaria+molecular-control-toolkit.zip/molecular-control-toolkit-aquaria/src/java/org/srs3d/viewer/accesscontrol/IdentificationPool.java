/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.accesscontrol;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

import org.srs3d.viewer.util.XmlTag;

/**
 * An IdentificationPool consists of a NamePool and an IP pool. Tuples of names and IPs
 * can be checked agains an IdentificationPool. Note that a computer might have several
 * names (e.g. with and without domain).
 *
 * @author Karsten Klein
 *
 * @created March 22, 2002
 */
public class IdentificationPool {
    private IPPool ipPool;
    private NamePool namePool;

    /**
     * <code>IdentificationPool</code> constructor.
     */
    public IdentificationPool(Object object) {
        Iterator iterator = ((Collection) object).iterator();
        ipPool = new IPPool(iterator.next());
        namePool = new NamePool(iterator.next());
    }

    /**
     * <code>IdentificationPool</code> constructor.
     *
     * @param namePool NamePool for this instance.
     * @param ipPool IPPool for this instance.
     */
    public IdentificationPool(NamePool namePool, IPPool ipPool) {
        this.ipPool = ipPool;
        this.namePool = namePool;
    }

    /**
     * Checks whether the specified tuple can be found in the pool.
     *
     * @param name Name of the computer.
     * @param ip IP of the computer.
     *
     * @return <code>true</code> if tuple contained in the pool.
     */
    public boolean contains(String name, String ip) {
        if (namePool.contains(name)) {
            if (ipPool.contains(ip)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Method description.
     *
     * @param name Parameter description.
     *
     * @return Return description.
     */
    public boolean contains(String name) {
        if (namePool.contains(name)) {
            return true;
        }
        return false;
    }

    /**
     * Method description.
     *
     * @param ip Parameter description.
     *
     * @return Return description.
     */
    public boolean containsIP(String ip) {
        if (ipPool.contains(ip)) {
            return true;
        }
        return false;
    }

    /**
     * Method for flattening the pool representation.
     *
     * @return Flattened data structure.
     */
    public Object flatten() {
        Collection collection = new ArrayList(2);
        collection.add(ipPool.flatten());
        collection.add(namePool.flatten());
        return collection;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public XmlTag createXmlTag() {
        XmlTag xmlTag = new XmlTag("pool");
        xmlTag.setAttribute("ip", ipPool.dump());
        if (!namePool.isEmpty()) {
            xmlTag.setAttribute("name", namePool.dump());
        }
        return xmlTag;
    }
}
