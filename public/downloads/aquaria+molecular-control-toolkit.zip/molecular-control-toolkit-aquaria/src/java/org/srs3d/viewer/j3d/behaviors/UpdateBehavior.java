/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.behaviors;

import java.util.Enumeration;
import java.util.Vector;

import javax.media.j3d.WakeupOnBehaviorPost;

import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.util.Chronometer;
import org.srs3d.viewer.util.ExceptionHandler;

/**
 * This class implements the <code>Constrainable</code> and <code>Behavior
 * </code>interface for all subsequent subclasses.
 *
 * @author Karsten Klein
 *
 * @created November 29, 2000
 */
public class UpdateBehavior extends AbstractBehavior {
    public static final int UPDATE_POST_ID = 42;
    private final Chronometer chronometer =
        Chronometer.getChronometer("UpdateBehavior");
    private transient Thread executionThread = null;
    private Vector callbacks = new Vector();
    private Callback runningCallback = null;
    private boolean isVerbose = false;
    private boolean isInitialized = false;

    /**
     * Constructor description.
     *
     * @param contextData Parameter description.
     */
    public UpdateBehavior(ContextData contextData) {
        setContextData(contextData);
    }

    /**
     * Gets the <code>executingThread</code> attribute of the <code>UpdateBehavior</code>
     * object.
     *
     * @param thread Description of parameter.
     *
     * @return The <code>executingThread</code> value.
     */
    public boolean isExecutingThread(Thread thread) {
        return thread == executionThread;
    }

    /**
     * Gets the <code>executingThreadRunning</code> attribute of the
     * <code>UpdateBehavior</code> object.
     *
     * @return The <code>executingThreadRunning</code> value.
     */
    public boolean isExecutingThreadRunning() {
        if (executionThread != null) {
            return executionThread.isAlive();
        }
        return false;
    }

    /**
     * Description of the method.
     *
     * @param enumeration Description of parameter.
     */
    public void processStimulus(Enumeration enumeration) {
        Callback callback;
        boolean isSubqueue = true;
        isInitialized = true;
        while (isSubqueue && !callbacks.isEmpty() &&
              getContextData().isValid()) {
            callback = (Callback) callbacks.elementAt(0);
            runningCallback = callback;
            if (callback == null) {
                isSubqueue = false;
            } else {
                try {
                    executionThread = Thread.currentThread();
                    chronometer.start();
                    callback.execute();
                    chronometer.stop(callback.getClass().toString());
                    executionThread = null;
                } catch (Exception e) {
                    ExceptionHandler.handleException(e,
                        ExceptionHandler.VISIBLE_IN_RELEASE, this);
                } catch (OutOfMemoryError e) {
                    ExceptionHandler.handleException(e,
                        ExceptionHandler.VISIBLE_IN_RELEASE, this);
                    getContextData().setProperty("EXCEPTION", e);

                    //          GCThread.runFinalization();
                    //          GCThread.gc();
                }
            }
            try {
                callbacks.remove(0);
            } catch (Exception e) {
                ExceptionHandler.handleException(e,
                    ExceptionHandler.SILENT_IN_RELEASE, this);
            }
            runningCallback = null;
        }
        initialize();
        if (!isSubqueue) {
            postId(UPDATE_POST_ID);
        }
    }

    /**
     * Description of the method.
     */
    public void initialize() {
        wakeupOn(new WakeupOnBehaviorPost(this, UPDATE_POST_ID));
    }

    /**
     * Adds a <code>Callback</code> object to the <code>UpdateBehavior</code> object.
     *
     * @param callback The <code>Callback</code> object to be added.
     */
    public void addCallback(Callback callback) {
        callbacks.add(callback);
        postId(UPDATE_POST_ID);
    }

    /**
     * Description of the method.
     *
     * @return Description of the returned value.
     */
    public boolean hasCallbacks() {
        return !callbacks.isEmpty();
    }

    /**
     * Description of the method.
     *
     * @param callback Description of parameter.
     *
     * @return Description of the returned value.
     */
    public boolean hasCallback(Callback callback) {
        return callbacks.contains(callback);
    }

    /**
     * Description of the method.
     */
    public void terminateCallbacks() {
        callbacks.clear();
    }

    /**
     * Description of the method.
     */
    public void runAllCallbacks() {
        Callback callback;
        while (!callbacks.isEmpty()) {
            callback = (Callback) callbacks.elementAt(0);
            if (callback != null) {
                try {
                    callback.execute();
                } catch (Exception e) {
                    ExceptionHandler.handleException(e,
                        ExceptionHandler.SILENT_IN_RELEASE, this);
                }
                callbacks.remove(callback);
            }
        }
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public boolean isInitialized() {
        return isInitialized;
    }

    /**
     * Description of the class.
     *
     * @author Karsten Klein
     *
     * @created January 7, 2002
     */
    public static interface Callback {

        /**
         * Description of the method.
         */
        public void execute();
    }
}
