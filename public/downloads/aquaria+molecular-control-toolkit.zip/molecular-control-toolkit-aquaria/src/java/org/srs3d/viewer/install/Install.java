/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.install;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Properties;

import javax.swing.ImageIcon;
import javax.swing.JApplet;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;

import org.srs3d.viewer.swing.SwingSettings;
import org.srs3d.viewer.util.Log;

/**
 * Applet implementation for BioAtlas applications. Checks for availability of the Java3D
 * API and guides the user to an appropriate setup procedure if not Java3D is installed.
 *
 * @author Karsten Klein
 *
 * @created July 18, 2001
 */
public class Install extends JApplet {
    private static final Log log = new Log(Install.class);
    private static final String fileSeparator =
        System.getProperty("file.separator");
    private static final String lineSeparator =
        System.getProperty("line.separator");

    // recognized plugin versions
    private static final int JAVA_PLUGIN_VERSION_13 = 1;
    private static final int JAVA_PLUGIN_VERSION_14 = 2;

    // recognized jre versions
    private static final int JRE_VERSION_13 = 1;
    private static final int JRE_VERSION_14 = 2;

    // recognized java3d versions
    private static final int J3D_VERSION_13 = 1;
    private static final int INVALID = -1;

    // IO access failure encoding
    private static final int IO_SUCCESS = 0;
    private static final int IO_NO_PERMISSION = 1;
    private static final int IO_CANNOT_OVERWRITE = 2;

    // install image
    private static final String IMAGE_NAME =
        "/org/srs3d/viewer/install/series000.jpg";
    private static final Image image =
        new ImageIcon(Install.class.getResource(IMAGE_NAME)).getImage();

    // component stuff
    private JTextArea textComponent = null;
    private JScrollPane scrollPane = null;
    private JSplitPane jSplitPane = null;
    private JButton jButton = null;

    /**
     * Sets the <code>message</code> attribute of the <code>Install</code> object.
     *
     * @param message The new <code>message</code> value.
     */
    public void setMessage(final String message) {
        SwingUtilities.invokeLater(new Runnable() {
                public void run() {
                    if (textComponent != null) {
                        textComponent.append(message + lineSeparator);
                        scrollPane.getVerticalScrollBar().setValue(scrollPane.getVerticalScrollBar()
                                                                             .getMaximum());
                    } else {
                        log.debug(message);
                    }
                }
            });
    }

    /**
     * Gets the <code>propertiesFilename</code> attribute of the <code>Install</code>
     * object.
     *
     * @return The <code>propertiesFilename</code> value.
     */
    public String getPropertiesFilename() {
        String fileName = getAlternatePropertiesFilename();
        if (System.getProperty("javaplugin.nodotversion") != null) {
            fileName += System.getProperty("javaplugin.nodotversion");
        }
        return fileName;
    }

    /**
     * Gets the <code>alternatePropertiesFilename</code> attribute of the
     * <code>Install</code> object.
     *
     * @return The <code>alternatePropertiesFilename</code> value.
     */
    public String getAlternatePropertiesFilename() {
        return System.getProperty("user.home") + fileSeparator + ".java" +
        fileSeparator + "properties";
    }

    /**
     * Gets the <code>customPath</code> attribute of the <code>Install</code> object.
     *
     * @return The <code>customPath</code> value.
     */
    public String getCustomPath(String initialFolder) {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        fileChooser.setDialogTitle("Choose a folder (NO TEMPORARY FOLDER!)");
        fileChooser.setCurrentDirectory(new File(initialFolder));
        int result = fileChooser.showDialog(null, "OK");
        if (result != JFileChooser.CANCEL_OPTION &&
              fileChooser.getSelectedFile() != null) {
            String pathname = fileChooser.getSelectedFile().getAbsolutePath();
            File file = new File(pathname);
            file.mkdirs();
            return pathname;
        }
        return null;
    }

    /**
     * Method description.
     *
     * @param installJREVersion Parameter description.
     *
     * @return Return description.
     */
    public int getJava3DVersion(int installJREVersion) {
        return J3D_VERSION_13;
    }

    /**
     * Method description.
     *
     * @param javaPluginVersion Parameter description.
     *
     * @return Return description.
     */
    public int getJREVersion(int javaPluginVersion) {
        if (javaPluginVersion == JAVA_PLUGIN_VERSION_14) {
            return JRE_VERSION_14;
        } else {
            return JRE_VERSION_13;
        }
    }

    /**
     * Gets the <code>java3DString</code> attribute of the <code>Install</code> object.
     *
     * @return The <code>java3DString</code> value.
     */
    public String getJava3DString(int installJ3DVersion) {
        if (isWindowsOS()) {
            if (installJ3DVersion == J3D_VERSION_13) {
                return "Java3D13";
            }

            // this is the current default
            return "Java3D13";
        } else {

            // this is the current linux default
            return "Java3D13-linux";
        }
    }

    /**
     * Gets the <code>parameterString</code> attribute of the <code>Install</code>
     * object.
     *
     * @return The <code>parameterString</code> value.
     */
    public String getParameterString(int installJ3DVersion) {
        String parameter = getParameter("vmParameter");
        return parameter;
    }

    /**
     * Gets the <code>pluginPath</code> attribute of the <code>Install</code> object.
     *
     * @param properties Description of parameter.
     *
     * @return The <code>pluginPath</code> value.
     */
    public String getPluginPath(Properties properties) {
        String path = properties.getProperty("javaplugin.jre.path");
        if (path.equalsIgnoreCase("default")) {
            log.debug("alternate plugin path retrieval");
            path = System.getProperty("java.home");
        }
        return path;
    }

    /**
     * Gets the <code>downloadPath</code> attribute of the <code>Install</code> object.
     *
     * @return The <code>downloadPath</code> value.
     */
    public String getDownloadPath() {
        String path = getDocumentBase().toString();
        int index = path.lastIndexOf("/");
        path = path.substring(0, index + 1);
        return path;
    }

    /**
     * Description of the method
     */
    public void init() {
        super.init();
        SwingSettings.setLookAndFeel(
            "com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
        SwingSettings.update();
    }

    /**
     * Method description.
     */
    public void start() {
        super.start();
        SwingSettings.update();
        Font font = new Font("Arial", Font.PLAIN, 11);
        textComponent = new JTextArea("");
        textComponent.setFont(font);
        textComponent.setEditable(false);
        textComponent.setOpaque(false);
        scrollPane = new JScrollPane(textComponent);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());
        panel.add(scrollPane, "Center");
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new BorderLayout());
        panel.add(buttonPanel, "South");
        JButton jDetailsButton = new JButton("Setup Details");
        buttonPanel.add(jDetailsButton, "West");
        jButton = new JButton("Start Setup");
        buttonPanel.add(jButton, "East");
        jButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    new Thread(new Runnable() {
                            public void run() {
                                jButton.setEnabled(false);
                                startSetup();
                                jButton.setEnabled(true);
                                jButton.requestFocus();
                            }
                        }).start();
                }
            });
        jDetailsButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    showSetupDetails(true);
                }
            });

        JPanel imagePanel =
            new JPanel() {
                public void paint(Graphics g) {
                    super.paint(g);
                    int x = (getWidth() - image.getWidth(null)) / 2;
                    int y = (getHeight() - image.getHeight(null)) / 2;
                    g.drawImage(image, x, y, null);
                }

                public void update(Graphics g) {
                    paint(g);
                }
            };
        jSplitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
        jSplitPane.setTopComponent(imagePanel);
        jSplitPane.setBottomComponent(panel);
        jSplitPane.setContinuousLayout(false);
        jSplitPane.setDividerSize(1);
        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(jSplitPane, BorderLayout.CENTER);
        jSplitPane.setDividerLocation(image.getHeight(null));
        setMessage("Welcome to the SRS 3D Client Setup");
        setMessage("Setup version: 1.3");
        setMessage("");
        setMessage("Click 'Start Setup' to proceed");
    }

    /**
     * Description of the method
     */
    public void startSetup() {
        new Thread(new Runnable() {
                public void run() {
                    runSetup();
                }
            }).start();
    }

    /**
     * Method description.
     */
    public void runSetup() {
        boolean isSuccess = false;
        Object[] options = { "Proceed", "Cancel" };
        String setupPath = null;
        String jrePath = null;
        String modifiedJrePath = null;
        int installJ3DVersion = INVALID;
        int result =
            JOptionPane.showOptionDialog(this,
                "We recommend contacting your System Administrator\n" +
                "before proceeding with the setup.",
                "Contact System Administrator", JOptionPane.YES_NO_OPTION,
                JOptionPane.INFORMATION_MESSAGE, null, options, null);
        String propertiesFilename = null;
        if (result == 0) {
            int currentJavaPluginVersion = getJavaPluginVersion();
            if (result == 0) {

                // read properties file
                propertiesFilename = getPropertiesFilename();

                // try to open "properties + version" file
                Properties properties =
                    readPluginProperties(propertiesFilename);
                if (properties == null) {

                    // try to open "properties" file
                    propertiesFilename = getAlternatePropertiesFilename();
                    properties =
                        readPluginProperties(getAlternatePropertiesFilename());
                }

                // copy default properties file and open this one
                if (properties == null) {
                    propertiesFilename = getPropertiesFilename();
                    copyFile(getClass().getResource("/org/srs3d/viewer/install/default.properties"),
                        propertiesFilename);
                    properties = readPluginProperties(propertiesFilename);
                }
                if (properties != null) {
                    setupPath = getSetupPath(properties);
                    if (setupPath != null) {
                        int currentJREVersion = getCurrentJREVersion();
                        int installJREVersion =
                            getJREVersion(currentJavaPluginVersion);
                        installJ3DVersion = getJava3DVersion(installJREVersion);
                        String java3DString =
                            getJava3DString(installJ3DVersion);
                        if (installJ3DVersion != INVALID) {

                            // try to install the appropriate Java3D version to the existing jre
                            jrePath = getPluginPath(properties);
                            String zipUrl =
                                getDownloadPath() + java3DString + ".zip";

                            // try to install Java3D binaries
                            result = installZipped(zipUrl, jrePath);
                            if (result == IO_SUCCESS) {

                                // done; modification of the plugin path not needed
                                isSuccess = true;
                            } else {
                                if (result == IO_CANNOT_OVERWRITE) {

                                    // it seems we cannot extend the jre (write protection).
                                    JOptionPane.showMessageDialog(this,
                                        "The JRE is currently in use. Close your browser \n" +
                                        "and any Java application and restart the setup.",
                                        "Cannot overwrite existing files.",
                                        JOptionPane.INFORMATION_MESSAGE);
                                    setMessage(
                                        "Close all running applications and restart the setup.");
                                } else {

                                    // in this case we have to trigger a new JRE install
                                    result = JOptionPane.OK_OPTION;
                                    modifiedJrePath =
                                        setupPath + fileSeparator + "jre";
                                    File path = new File(modifiedJrePath);
                                    path.mkdirs();
                                    setMessage("Creating new JRE instance in " +
                                        modifiedJrePath);
                                    if (copyDirectory(jrePath, modifiedJrePath)) {

                                        // try to install Java3D binaries, again
                                        result =
                                            installZipped(zipUrl,
                                                modifiedJrePath);
                                        if (result == IO_SUCCESS) {

                                            // done; modification of the plugin path not needed
                                            isSuccess = true;
                                        }
                                    }
                                    if (!isSuccess) {
                                        setMessage(
                                            "Unable to create JRE instance! Check access permissions and disk space.");
                                    }
                                }
                            }

                            // copy the "properties" to "properties + version"
                            if (!propertiesFilename.equalsIgnoreCase(
                                      getPropertiesFilename())) {
                                try {
                                    copyFile(new URL("file", null,
                                            propertiesFilename),
                                        getPropertiesFilename());
                                } catch (Exception e) {
                                    setMessage("WARNING: cannot copy " +
                                        propertiesFilename + " to " +
                                        getPropertiesFilename());
                                }
                            }
                            if (!propertiesFilename.equalsIgnoreCase(
                                      getAlternatePropertiesFilename())) {
                                try {
                                    copyFile(new URL("file", null,
                                            propertiesFilename),
                                        getAlternatePropertiesFilename());
                                } catch (Exception e) {
                                    setMessage("WARNING: cannot copy " +
                                        propertiesFilename + " to " +
                                        getAlternatePropertiesFilename());
                                }
                            }
                        }
                    }
                }
            }
        }
        if (isSuccess) {
            if (propertiesFilename != null) {

                // adapt properties file
                // set the parameters in the property file correctly
                if (modifyPluginProperties(modifiedJrePath,
                          getParameterString(installJ3DVersion),
                          propertiesFilename, setupPath)) {
                    setMessage("Successfully adapted plugin parameters");
                }
            }
            if (modifiedJrePath != null) {
                installLocalFiles(setupPath, modifiedJrePath, installJ3DVersion);
            } else {
                installLocalFiles(setupPath, jrePath, installJ3DVersion);
            }
        }
        if (isSuccess) {
            setMessage("Setup completed successfully.");
            setMessage(
                "Close all browser windows (including Netscape Messenger if you are using Netscape Navigator) to apply the changes.");
            setMessage("");
            JOptionPane.showMessageDialog(this,
                "The SRS Client Setup is complete! Before using SRS 3D we highly recommend\n" +
                "that your System Administrator installs an up-to-date graphics card driver.\n\n" +
                "You have to restart your browser to apply the changes.",
                "SRS Client Setup complete", JOptionPane.INFORMATION_MESSAGE);
        } else {
            setMessage("Setup canceled!");
        }
        setMessage("-------------------------------------");
    }

    /**
     * Description of the method
     */
    public void stop() {
        super.stop();
    }

    /**
     * Description of the method
     */
    public void destroy() {
        super.destroy();
    }

    /**
     * Description of the method.
     *
     * @param url Description of parameter.
     * @param destination Description of parameter.
     *
     * @return Description of the returned value.
     */
    public boolean copyFile(URL url, String destination) {
        setMessage("COPYING FILE: " + url + " to " + destination);
        try {
            InputStream in = url.openStream();
            File file = new File(destination);
            OutputStream out = new FileOutputStream(file);
            copy(in, out);
            out.close();
            in.close();
        } catch (Exception e) {
            log.debug(e, e);
            setMessage("WARNING: failed to copy " + url + " to " + destination);
            return false;
        }
        return true;
    }

    /**
     * Method description.
     *
     * @param inputFile Parameter description.
     * @param destination Parameter description.
     *
     * @return Return description.
     */
    public boolean copyFile(File inputFile, String destination) {
        setMessage("COPYING FILE: " + inputFile + " to " + destination);
        try {
            InputStream in = new FileInputStream(inputFile);
            File file = new File(destination);
            OutputStream out = new FileOutputStream(file);
            copy(in, out);
            out.close();
            in.close();
        } catch (Exception e) {
            log.debug(e, e);
            setMessage("WARNING: failed to copy " + inputFile + " to " +
                destination);
            return false;
        }
        return true;
    }

    /**
     * Description of the method.
     *
     * @param url Description of parameter.
     * @param destination Description of parameter.
     *
     * @return Description of the returned value.
     */
    public int unzipFile(URL url, String destination) {
        try {
            File file = new File(destination);
            log.debug("destination: " + destination);
            String localFile =
                destination + "temp" + System.currentTimeMillis();
            String fileName;
            setMessage("CREATING TEMPORARY FILE: " + localFile);

            // create local copy
            if (copyFile(url, localFile)) {
                if (isWindowsOS()) {
                    java.util.zip.ZipFile zipFile =
                        new java.util.zip.ZipFile(localFile);
                    java.util.Enumeration enumer = zipFile.entries();
                    java.util.zip.ZipEntry entry;
                    while (enumer.hasMoreElements()) {
                        entry = (java.util.zip.ZipEntry) enumer.nextElement();
                        setMessage("INFLATING: " + entry);
                        fileName = destination + entry.toString();
                        file = new File(fileName);
                        file.setLastModified(entry.getTime());
                        if (!entry.isDirectory()) {
                            copy(zipFile.getInputStream(entry),
                                new FileOutputStream(file));
                        } else {
                            file.mkdirs();
                        }
                    }
                    zipFile.close();
                } else {
                    String exec =
                        "unzip -u -o " + localFile + " -d " + destination;
                    setMessage("EXECUTING: " + exec);
                    Runtime.getRuntime().exec(exec).waitFor();
                }
                new File(localFile).delete();
                setMessage("DELETING TEMPORARY FILE: " + localFile);
            } else {
                return IO_NO_PERMISSION;
            }
        } catch (Exception e) {
            log.debug(e, e);
            return IO_CANNOT_OVERWRITE;
        }
        return IO_SUCCESS;
    }

    /**
     * Description of the method.
     *
     * @param filename Description of parameter.
     *
     * @return Description of the returned value.
     */
    public Properties readPluginProperties(String filename) {
        setMessage("READING: " + filename);
        Properties properties = null;
        try {
            properties = new Properties();
            properties.load(new FileInputStream(filename));
        } catch (Exception e) {
            setMessage("WARNING: cannot read property file " + filename);
            properties = null;
            log.debug(e, e);
        }
        return properties;
    }

    /**
     * Description of the method.
     *
     * @param path Description of parameter.
     * @param parameters Description of parameter.
     * @param filename Description of parameter.
     *
     * @return Description of the returned value.
     */
    public boolean modifyPluginProperties(String path, String parameters,
        String filename, String setupPath) {
        setMessage("MODIFYING PROPERTY FILE: " + filename);
        try {
            Properties p = readPluginProperties(filename);
            p.store(new FileOutputStream(filename + ".bak" +
                    System.currentTimeMillis()), null);
            if (path != null) {
                p.setProperty("javaplugin.jre.path", path);
                p.setProperty("javaplugin.jre.type", "Other");
            }
            if (parameters != null) {
                p.setProperty("javaplugin.jre.params", parameters);
            }
            if (setupPath != null) {
                p.setProperty("org.srs3d.viewer.srs3d.setup.path", setupPath);
            }
            p.store(new FileOutputStream(filename), null);
        } catch (Exception e) {
            log.debug(e, e);
            setMessage("WARNING: unable to modify " + filename);
            return false;
        }
        return true;
    }

    /**
     * Description of the method.
     *
     * @param zipUrl Description of parameter.
     * @param destinationPath Description of parameter.
     *
     * @return Description of the returned value.
     */
    public int installZipped(String zipUrl, String destinationPath) {
        try {
            URL url = new URL(zipUrl);
            return unzipFile(url, destinationPath + fileSeparator);
        } catch (Exception e) {
            setMessage("WARNING: unable to install " + zipUrl + " to " +
                destinationPath);
            log.debug(e, e);
        }
        return IO_NO_PERMISSION;
    }

    /**
     * Description of the method.
     *
     * @param in Description of parameter.
     * @param out Description of parameter.
     *
     * @exception IOException Description of exception.
     */
    private void copy(InputStream in, OutputStream out) throws IOException {
        byte[] buffer = new byte[1000000];
        int bytesRead;
        while ((bytesRead = in.read(buffer)) > 0) {
            out.write(buffer, 0, bytesRead);
        }
        out.close();
        in.close();
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public int getCurrentJREVersion() {
        String version = System.getProperty("java.version");
        setMessage("Current JRE version: " + version);
        if (version != null) {
            if (version.startsWith("1.3")) {
                return JRE_VERSION_13;
            }
            if (version.startsWith("1.4")) {
                return JRE_VERSION_14;
            }
        }

        // as default we assume its a 1.4 version or newer
        return JRE_VERSION_14;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public int getJavaPluginVersion() {
        String version = System.getProperty("javaplugin.version");
        setMessage("Java Plug-in version: " + version);
        if (version != null) {
            if (version.startsWith("1.3")) {
                return JAVA_PLUGIN_VERSION_13;
            }
            if (version.startsWith("1.4")) {
                return JAVA_PLUGIN_VERSION_14;
            }
        }

        // default is 1.4
        return JAVA_PLUGIN_VERSION_14;
    }

    /**
     * Method description.
     */
    public void showSunJ3D() {
        try {
            getAppletContext().showDocument(new URL(
                    "http://java.sun.com/products/java-media/3D/"));
        } catch (Exception e) {
        }
    }

    /**
     * Method description.
     *
     * @param useNewFrame Parameter description.
     */
    public void showSetupDetails(boolean useNewFrame) {
        log.debug("opening setup details page.");
        try {
            URL url =
                new URL(getCodeBase().toString() + "install_details.html");
            if (useNewFrame) {
                getAppletContext().showDocument(url, "Install_Details");
            } else {
                getAppletContext().showDocument(url);
            }
        } catch (Exception ex) {
            log.debug(ex, ex);
        }
    }

    /**
     * Method description.
     *
     * @param setupPath Parameter description.
     * @param jrePath Parameter description.
     * @param installJ3DVersion Parameter description.
     */
    public void installLocalFiles(String setupPath, String jrePath,
        int installJ3DVersion) {
        writeBatchFile(setupPath, jrePath, installJ3DVersion);
        try {
            URL url = new URL(getDownloadPath() + "capture.jar");
            if (!copyFile(url, setupPath + fileSeparator + "capture.jar")) {
                url = new URL(stepUpPath(getDownloadPath()) + "capture.jar");
                copyFile(url, setupPath + fileSeparator + "capture.jar");
            }
            url = new URL(getDownloadPath() + "license.key");
            if (!copyFile(url, setupPath + fileSeparator + "license.key")) {
                url = new URL(stepUpPath(getDownloadPath()) + "license.key");
                copyFile(url, setupPath + fileSeparator + "license.key");
            }
        } catch (MalformedURLException e) {
            log.debug(e, e);
        }
    }

    /**
     * Method description.
     *
     * @param setupPath Parameter description.
     * @param jrePath Parameter description.
     * @param installJ3DVersion Parameter description.
     */
    public void writeBatchFile(String setupPath, String jrePath,
        int installJ3DVersion) {
        try {
            String filename = isWindowsOS() ? "SRS3D.bat" : "srs3d.sh";
            File outFile = new File(setupPath + fileSeparator + filename);
            FileWriter writer = new FileWriter(outFile);
            if (isWindowsOS()) {
                writer.write("set SRS3D_JRE_PATH=" + jrePath + lineSeparator);
                writer.write("set SRS3D_LOCAL_PATH=" + setupPath +
                    lineSeparator);
                writer.write(
                    "set SRS3D_LICENSE_KEY_LOCATION=\"file:///%SRS3D_LOCAL_PATH%/license.key\"" +
                    lineSeparator);
                writer.write(
                    "set SRS3D_JAR_LOCATION=\"%SRS3D_LOCAL_PATH%/capture.jar\"" +
                    lineSeparator);
                writer.write(
                    "set SRS3D_CODEBASE=\"file:///%SRS3D_LOCAL_PATH%/\"" +
                    lineSeparator);
                writer.write("\"%SRS3D_JRE_PATH%" + fileSeparator + "bin" +
                    fileSeparator + "java\"" + " " +
                    getParameterString(installJ3DVersion) + " " +
                    "-cp %SRS3D_JAR_LOCATION% CaptureApplication " +
                    "structures=structures{,file:///%1,REFERENCE,} " +
                    "sequenceView=on annotationView=on expertMode=on statusbar=on applicationMode=application" +
                    " codeBaseUrl=%SRS3D_CODEBASE% licenseKey=%SRS3D_LICENSE_KEY_LOCATION% " +
                    "instanceId=%1 " + lineSeparator);
            } else {
                writer.write("#!/bin/csh -f" + lineSeparator);
                writer.write("setenv SRS3D_JRE_PATH " + jrePath +
                    lineSeparator);
                writer.write("setenv SRS3D_LOCAL_PATH " + setupPath +
                    lineSeparator);
                writer.write(
                    "setenv SRS3D_LICENSE_KEY_LOCATION file:///$SRS3D_LOCAL_PATH/license.key" +
                    lineSeparator);
                writer.write(
                    "setenv SRS3D_JAR_LOCATION $SRS3D_LOCAL_PATH/capture.jar" +
                    lineSeparator);
                writer.write("setenv SRS3D_CODEBASE file:///$SRS3D_LOCAL_PATH" +
                    lineSeparator);
                writer.write("$SRS3D_JRE_PATH/bin/java " + " " +
                    getParameterString(installJ3DVersion) + " " +
                    "-cp $SRS3D_JAR_LOCATION CaptureApplication " +
                    " \"structures=structures{,file:///$1,REFERENCE,}\" " +
                    "sequenceView=on annotationView=on expertMode=on statusbar=on applicationMode=application" +
                    " codeBaseUrl=$SRS3D_CODEBASE licenseKey=$SRS3D_LICENSE_KEY_LOCATION " +
                    "instanceId=$1" + lineSeparator);
            }
            writer.flush();
            writer.close();
            if (!isWindowsOS()) {
                String exec = "chmod +x " + outFile.getAbsolutePath();
                setMessage("EXECUTING: " + exec);
                Runtime.getRuntime().exec(exec);
            }
        } catch (IOException e) {
            log.debug(e, e);
        }
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public boolean isWindowsOS() {
        String osName = System.getProperty("os.name");
        if (osName != null) {
            osName = osName.toLowerCase();
            if (osName.indexOf("win") == -1) {
                return false;
            }
        }
        return true;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public String getDefaultSetupPath() {
        String defaultPath = System.getProperty("user.home");
        if (isWindowsOS()) {
            int index = defaultPath.indexOf(":");
            if (index != -1) {
                defaultPath = defaultPath.substring(0, index);
                String proposal =
                    defaultPath + ":" + fileSeparator + "Program Files";
                File file = new File(proposal);
                if (!file.isDirectory()) {
                    proposal = defaultPath + fileSeparator + "Programme";
                    file = new File(proposal);
                    if (!file.isDirectory()) {

                        // keep the english version as default
                        proposal =
                            defaultPath + fileSeparator + "Program Files";
                    }
                }
                defaultPath = proposal;
            }
        }
        defaultPath += fileSeparator + "SRS3D";
        return defaultPath;
    }

    /**
     * Method description.
     *
     * @param properties Parameter description.
     *
     * @return Return description.
     */
    public String getSetupPath(Properties properties) {
        Object[] options = { "Yes", "Choose other" };
        String setupPath = getDefaultSetupPath(properties);
        int result =
            JOptionPane.showOptionDialog(this,
                "The setup directory defaults to " + setupPath + ".\n" +
                "Do you want to install the SRS 3D Client to this directory?",
                "Setup Directory", JOptionPane.YES_NO_OPTION,
                JOptionPane.INFORMATION_MESSAGE, null, options, null);
        if (result == 1) {
            setupPath = getCustomPath(getDefaultSetupPath(properties));
        }
        if (setupPath != null && result != -1) {
            File file = new File(setupPath);
            while (file != null && !file.isDirectory() && !file.mkdirs()) {
                setMessage("Cannot create directory " + setupPath);
                setupPath = getCustomPath("C:\\Program Files\\");
                if (setupPath != null) {
                    file = new File(setupPath);
                } else {
                    file = null;
                }
            }
        } else {
            setupPath = null;
        }
        return setupPath;
    }

    /**
     * Method description.
     *
     * @param properties Parameter description.
     *
     * @return Return description.
     */
    public String getDefaultSetupPath(Properties properties) {

        // try to read path from properties file (setup was executed before)
        String defaultSetupPath =
            properties.getProperty("org.srs3d.viewer.srs3d.setup.path");

        // else use parameter if valid
        if (defaultSetupPath == null) {
            defaultSetupPath =
                isWindowsOS() ? getParameter("winSetupPath")
                              : getParameter("linuxSetupPath");
            log.debug("default setup path: " + defaultSetupPath);
            if (defaultSetupPath != null) {
                defaultSetupPath.trim();

                // invalid path
                if (defaultSetupPath.length() == 0) {
                    defaultSetupPath = null;
                }
            }
        }

        // just infer one from the data we have
        if (defaultSetupPath == null) {
            defaultSetupPath = getDefaultSetupPath();
        }
        return defaultSetupPath;
    }

    /**
     * Method description.
     *
     * @param path Parameter description.
     *
     * @return Return description.
     */
    public String stepUpPath(String path) {
        path = path.substring(0, path.length() - 1);
        int index = path.lastIndexOf("/");
        if (index != -1) {
            path = path.substring(0, index + 1);
        }
        log.debug("new path " + path);
        return path;
    }

    /**
     * Method description.
     *
     * @param sourcePath Parameter description.
     * @param destPath Parameter description.
     *
     * @return Return description.
     */
    public boolean copyDirectory(String sourcePath, String destPath) {
        File sourcePathFile = new File(sourcePath);
        File[] files = sourcePathFile.listFiles();
        File destPathFile;
        boolean isSuccess = true;
        destPathFile = new File(destPath);
        destPathFile.mkdirs();
        if (files != null) {
            for (int i = 0; i < files.length; i++) {
                if (files[i].isDirectory()) {
                    destPathFile =
                        new File(destPath + fileSeparator + files[i].getName());
                    destPathFile.mkdirs();
                    isSuccess &= copyDirectory(files[i].getAbsolutePath(),
                        destPathFile.getAbsolutePath());
                } else {
                    isSuccess &= copyFile(files[i],
                        destPath + fileSeparator + files[i].getName());
                }
            }
        }
        return true;
    }

    /**
     * Method description.
     *
     * @param args Parameter description.
     */
    public static void main(String[] args) {
        Install install = new Install();
        String sourcePath = "C:\\Program Files\\java\\j2re1.4.1_03";
        String destPath = "d:\\tempcopy";
        if (install.copyDirectory(sourcePath, destPath)) {
            log.debug("success");
        } else {
            log.debug("failed");
        }
    }
}
