/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.loaders.sdf;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.InterruptedIOException;
import java.util.ArrayList;
import java.util.StringTokenizer;

import javax.vecmath.Point3f;

import org.srs3d.viewer.bioatlas.loaders.AbstractParser;
import org.srs3d.viewer.bioatlas.objects.Atom;
import org.srs3d.viewer.bioatlas.objects.Bond;
import org.srs3d.viewer.bioatlas.objects.Chain;
import org.srs3d.viewer.bioatlas.objects.Residue;
import org.srs3d.viewer.bioatlas.visitors.ChainAnalyser;
import org.srs3d.viewer.objects.ObjectContainer;
import org.srs3d.viewer.objects.visitors.ObjectUpdater;
import org.srs3d.viewer.util.Chronometer;
import org.srs3d.viewer.util.ExceptionHandler;
import org.srs3d.viewer.util.Log;

/**
 * This class implements a parser reading sdf files/urls. The method <code>parse</code>
 * files all extracted data in a database.
 *
 * @author Karsten Klein
 *
 * @created July 16, 2002
 */
public class SdfParser extends BufferedReader implements AbstractParser {
    private static final Log log = new Log(SdfParser.class);
    private static final boolean isVerbose = false;
    private Object parameterObject = null;

    /**
     * <code>SdfParser</code> constructor.
     *
     * @param filename Description of parameter.
     *
     * @exception FileNotFoundException Description of exception.
     */
    public SdfParser(String filename) throws FileNotFoundException {
        super(new FileReader(filename));
    }

    /**
     * <code>PdbParser</code> contructor.
     *
     * @param inputStream Description of parameter.
     */
    public SdfParser(InputStream inputStream) {
        super(new InputStreamReader(inputStream));
    }

    /**
     * Sets the <code>parameterObject</code> attribute of the <code>SdfParser</code>
     * object.
     *
     * @param parameterObject The new <code>parameterObject</code> value.
     */
    public void setParameterObject(Object parameterObject) {
        this.parameterObject = parameterObject;
    }

    /**
     * Description of the method.
     *
     * @return Description of the returned value.
     */
    public ObjectContainer parse() {
        Chronometer c = Chronometer.getChronometer("PdbParser");
        c.start();
        ObjectContainer objectContainer = new ObjectContainer();
        String line;
        ArrayList atoms = null;
        ArrayList bonds = null;
        String name = null;
        float scaleFactor = 1.0f;
        String moleculeId = null;
        int startLineIndex = 0;
        int nameLineIndex = 0;
        int lineIndex = 0;
        String alternativeName = "structure";
        try {

            // parse information from parameter object
            if (parameterObject != null) {
                String parameterString = parameterObject.toString();
                if (parameterString.indexOf("ID:") != -1) {
                    moleculeId =
                        parameterString.substring(parameterString.indexOf("ID:") +
                            3);
                    if (moleculeId.indexOf("|") != -1) {
                        moleculeId =
                            moleculeId.substring(0, moleculeId.indexOf("|"));
                    }
                }
                if (parameterString.indexOf("SF:") != -1) {
                    String factor =
                        parameterString.substring(parameterString.indexOf("SF:") +
                            3);
                    try {
                        scaleFactor = Float.parseFloat(factor);
                    } catch (NumberFormatException e) {
                        log.error("scale factor not a number.", e);
                        log.debug(parameterObject);
                    }
                }
                if (parameterString.indexOf("NAME:") != -1) {
                    alternativeName =
                        parameterString.substring(parameterString.indexOf(
                                "NAME:") + 5);
                    if (alternativeName.indexOf("|") != -1) {
                        alternativeName =
                            alternativeName.substring(0,
                                alternativeName.indexOf("|"));
                    }
                }
            }
            atoms = new ArrayList();
            bonds = new ArrayList();
            do {
                line = null;
                line = readLine();
                if (line != null) {
                    try {
                        StringTokenizer tokenizer = new StringTokenizer(line);
                        int tokenCount = tokenizer.countTokens();
                        switch (tokenCount) {

                            case 4:
                            case 11:

                                // atom table start
                                // ignored (only contains number of atoms and number of bonds)
                                break;

                            case 7:
                            case 6:
                            case 5: // atom colums might have been merged
                                if (atoms != null) {

                                    // bonds
                                    Bond bond = new Bond();

                                    // index numbers have been merged (second one exceeds 99)
                                    bond.setAtom0((Atom) atoms.get(Integer.parseInt(
                                                line.substring(0, 3).trim()) -
                                            1));
                                    bond.setAtom1((Atom) atoms.get(Integer.parseInt(
                                                line.substring(3, 6).trim()) -
                                            1));
                                    bond.setType(Integer.parseInt(
                                            line.substring(6, 9).trim()));
                                    bonds.add(bond);
                                    Bond bond1 = new Bond();
                                    bond1.setAtom1(bond.getAtom0());
                                    bond1.setAtom0(bond.getAtom1());
                                    bond1.setType(bond.getType());
                                    bonds.add(bond1);
                                }
                                break;

                            case 2:
                                break;

                            case 1:

                                // compound name (or something else)
                                if (name == null) {
                                    if (line.indexOf("$$$$") != -1) {
                                        atoms.clear();
                                        bonds.clear();
                                    } else {
                                        if (moleculeId == null ||
                                              line.indexOf(moleculeId) != -1) {
                                            if (moleculeId == null) {
                                                moleculeId = alternativeName;
                                            }
                                            name = moleculeId;
                                            if (!atoms.isEmpty()) {
                                                line = null;
                                            }
                                        }
                                    }
                                } else {
                                    if (line.indexOf("$$$$") != -1) {

                                        // stop parsing
                                        line = null;
                                    }
                                }
                                break;

                            default:
                                try {
                                    if (atoms != null) {
                                        Atom atom = new Atom();
                                        atom.setCoordinate(new Point3f(
                                                Float.parseFloat(
                                                    tokenizer.nextToken()),
                                                Float.parseFloat(
                                                    tokenizer.nextToken()),
                                                Float.parseFloat(
                                                    tokenizer.nextToken())));
                                        atom.getCoordinate().scale(scaleFactor);
                                        String template = tokenizer.nextToken();
                                        if (template.length() == 1) {
                                            template = " " + template;
                                        }
                                        while (template.length() < 4) {
                                            template += " ";
                                        }
                                        atom.setTemplate(org.srs3d.viewer.bioatlas.factories.AtomTemplateFactory.getTemplate(
                                                template));
                                        atoms.add(atom);
                                    }
                                } catch (Exception e) {
                                    ExceptionHandler.handleException(e,
                                        ExceptionHandler.SILENT_IN_DEBUG, this);
                                }

                                // atom line
                                break;
                        }
                    } catch (Exception e) {
                        ExceptionHandler.handleException(e,
                            ExceptionHandler.SILENT_IN_RELEASE);
                    }
                }
            } while (line != null);
            close();
        } catch (Exception e) {
            log.error(e, e);
        }

        // convert current atom and bond list into appropraite data structure
        if (atoms != null) {
            if (!atoms.isEmpty()) {
                if (name == null) {
                    name = alternativeName;
                }
                Residue residue = new Residue();
                residue.setTemplate(org.srs3d.viewer.bioatlas.factories.ResidueTemplateFactory.getTemplate(
                        name));
                residue.getAtoms().addAll(atoms);
                residue.getBonds().addAll(bonds);
                Chain chain = new Chain();
                chain.addResidue(residue);
                chain.getExceptionalResidues().add(residue);
                objectContainer.setName(name);
                objectContainer.addObject(chain);
                line = null;
            }
        }
        c.start();

        // run chain split
        ChainAnalyser chainAnalyser = new ChainAnalyser();
        chainAnalyser.visit(objectContainer);
        c.stop("chain analyser");
        c.start();

        // run object update (deep)
        ObjectUpdater objectUpdater = new ObjectUpdater();
        objectUpdater.visit(objectContainer);
        c.stop("update");
        c.stop();
        return objectContainer;
    }

    /**
     * Description of the method.
     *
     * @return Description of the returned value.
     *
     * @exception java.io.IOException Description of exception.
     */
    public String readLine() throws java.io.IOException {
        try {
            return super.readLine();
        } catch (InterruptedIOException e) {

            // :NOTE: SOLARIS specific exception handling
            return readLine();
        }
    }

    /**
     * Gets the <code>verbose</code> attribute of the <code>SdfParser</code> class.
     *
     * @return The <code>verbose</code> value.
     */
    public static final boolean isVerbose() {
        return isVerbose;
    }
}
