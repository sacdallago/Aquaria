/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.accesscontrol;

import java.applet.AppletStub;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.srs3d.viewer.accesscontrol.checks.GeneralCheck;
import org.srs3d.viewer.util.ExceptionHandler;
import org.srs3d.viewer.util.XmlTag;

/**
 * Main class for performing the access control check. Contains static load and save
 * methods for reading and writing files. The AccessControl class consists of a list of
 * IdenticationPools to implement the accessability check. Note that for writing the
 * data structure can be collapsed to exclude all accesscontrol package classes. This
 * enables proper obfuscation and ensures compatibility to key files generated with
 * different jar files.
 *
 * @author Karsten Klein
 *
 * @created March 22, 2002
 */
public class AccessControl {
    private static boolean isVerbose = false;
    private AccessCheck accessCheck = new GeneralCheck();

    /**
     * <code>AccessControl</code> constructor.
     *
     * @param object Description of parameter.
     */
    public AccessControl(Object object) {
        try {
            Map map = (Map) object;
            accessCheck.read(map);
        } catch (ClassCastException e) {

            // :COMPATIBILITY: legacy code for reading old license files
            // potentially an old license file
            Collection set = (Collection) object;
            Iterator iterator = set.iterator();
            Map localMap = new HashMap();
            localMap.put("ExpirationDate", new Long(iterator.next().toString()));
            Collection IdentificationPools = new ArrayList();
            IdentificationPool identicationPool;
            localMap.put("IdentificationPools", IdentificationPools);
            while (iterator.hasNext()) {
                object = iterator.next();
                IdentificationPools.add(object);
            }
            localMap.put("CreationDate", new Long(System.currentTimeMillis()));
            localMap.put("AccessCheck", new Integer(0));
            ArrayList checks = new ArrayList();
            checks.add(localMap);
            localMap.put("EmbeddedAccessChecks", checks);
            accessCheck.read(localMap);
            ExceptionHandler.handleException(e,
                ExceptionHandler.SILENT_IN_DEBUG, this);
        }
    }

    /**
     * <code>AccessControl</code> constructor.
     */
    protected AccessControl() {
    }

    /**
     * Converts the AccessControl representation to a more primitve representation only
     * relying on JDK classes and primitive data types. This mechanism enables
     * obfuscation of the hole accesscontrol package.
     *
     * @return The <code>outputStructure</code> value.
     */
    private Object flatten() {
        Map map = new HashMap();
        accessCheck.write(map);
        return map;
    }

    /**
     * Method for saving the AccessControl instance to a file. This method should not be
     * available in the shipped version of this class.
     *
     * @param accessControl The AccessControl object to save.
     * @param filename Filename.
     */
    public static void save(AccessControl accessControl, String filename) {
        try {
            FileOutputStream stream = new FileOutputStream(filename);

            // insert header
            byte[] header = new byte[42];
            header[0] = 'L';
            header[1] = 'I';
            header[2] = 'O';
            header[3] = 'N';
            for (int i = 4; i < 42; i++) {
                header[i] = (byte) (Math.random() * 255);
            }
            stream.write(header);
            stream.flush();

            // insert identification pools in compressed form
            java.util.zip.GZIPOutputStream zippedStream =
                new java.util.zip.GZIPOutputStream(stream);
            ObjectOutputStream p = new ObjectOutputStream(zippedStream);
            p.writeObject(accessControl.flatten());
            p.flush();
            p.close();
            zippedStream.flush();
            zippedStream.close();
            stream.flush();
            stream.close();
        } catch (Exception e) {
            ExceptionHandler.handleException(e);
        }
    }

    /**
     * Loads a AccessControl file from a given URL.
     *
     * @param url URL of the access control file.
     *
     * @return Read AccessControl instance; null if any error occured.
     */
    public static AccessControl load(URL url) {
        AccessControl accessControl = null;
        try {

            // attempt to read a not cached file
            URLConnection urlConnection = url.openConnection();
            urlConnection.setUseCaches(false);
            urlConnection.connect();
            InputStream stream = null;
            try {
                stream = urlConnection.getInputStream();

                // read header (skip the header bytes)
                byte[] header = new byte[42];
                stream.read(header, 0, 42);

                // read compressed representation
                stream = new java.util.zip.GZIPInputStream(stream);
            } catch (Exception e) {

                // open stream directly without disabling caching
                stream = url.openStream();

                // read header (skip the header bytes)
                byte[] header = new byte[42];
                stream.read(header, 0, 42);

                // read compressed representation
                stream = new java.util.zip.GZIPInputStream(stream);
                ExceptionHandler.handleException(e,
                    ExceptionHandler.SILENT_IN_RELEASE, accessControl);
            }
            ObjectInputStream p = new ObjectInputStream(stream);
            accessControl = new AccessControl(p.readObject());
            stream.close();
        } catch (Exception e) {

            // catch silently; otherwise we would potiential cheaters the direct hint
            // to this class/method
            ExceptionHandler.handleException(e,
                ExceptionHandler.SILENT_IN_RELEASE, accessControl);
        }
        return accessControl;
    }

    /**
     * Method description.
     *
     * @param appletStub Parameter description.
     *
     * @return Return description.
     */
    public boolean check(AppletStub appletStub) {
        try {
            return accessCheck.check(appletStub);
        } catch (Exception e) {

            // catch silent
            ExceptionHandler.handleException(e,
                ExceptionHandler.SILENT_IN_DEBUG, this);
        }
        return false;
    }

    protected void dump() {
        XmlTag xmlTag = accessCheck.createXmlTag();
        xmlTag.setName("license");
        xmlTag.removeAttribute("type");
        System.out.println(xmlTag);
    }
}
