/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.visitors;

import java.util.Iterator;

import org.srs3d.viewer.bioatlas.objects.Chain;
import org.srs3d.viewer.bioatlas.objects.DbRef;
import org.srs3d.viewer.bioatlas.objects.Residue;

/**
 * This class checks the <code>DbRef</code>s of a splitted chain. Those
 * <code>DbRef</code>s, which have no overlap with the chain are removed from the chains
 * <code>DbRef</code> list.
 *
 * @author Karsten Klein, 01/2001
 *
 * @created June 19, 2001
 */
public class DbRefAnalyser {

    /**
     * Checks the chain associated subchains for multiple annotation.
     *
     * @param chain the chain to visit
     */
    public void visit(Chain chain) {
        if (chain.containsLigandResidues()) {
            chain.getDbRefs().clear();
        } else {
            Iterator iterator = chain.getDbRefs().iterator();
            DbRef dbRef;
            Residue residue;
            Residue limit;
            boolean foundOne;
            while (iterator.hasNext()) {
                dbRef = (DbRef) iterator.next();
                residue = dbRef.getInitialResidue();
                limit = dbRef.getEndResidue().getProceeding();
                foundOne = false;
                while (!foundOne && residue != limit && residue != null) {
                    if (chain.getResidue(residue.getTemplate().getName(),
                              residue.getId(), residue.getICode()) != null) {
                        foundOne = true;
                    }
                    residue = residue.getProceeding();
                }
                if (!foundOne) {
                    iterator.remove();
                }
            }
        }
    }
}
