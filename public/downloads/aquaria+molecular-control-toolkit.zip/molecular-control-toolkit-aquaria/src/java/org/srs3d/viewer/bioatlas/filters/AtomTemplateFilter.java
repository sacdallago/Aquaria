/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.filters;

import org.srs3d.viewer.bioatlas.objects.Atom;
import org.srs3d.viewer.bioatlas.objects.templates.AtomTemplate;
import org.srs3d.viewer.objects.AbstractObject;

/**
 * <code>ObjectFilter</code> implementation. Filters <code>Atoms</code> s with specified
 * <code>AtomTemplate</code> .
 *
 * @author Karsten Feies, LION bioscience AG
 *
 * @created May 14, 2001
 */
public final class AtomTemplateFilter extends BaseObjectFilter {
    private AtomTemplate atomTemplate = null;

    /**
     * <code>AtomTemplateFilter</code> constructor.
     *
     * @param atomTemplate Description of parameter.
     */
    public AtomTemplateFilter(AtomTemplate atomTemplate) {
        super(Atom.class);
        setAtomTemplate(atomTemplate);
    }

    /**
     * Sets the <code>atomTemplate</code> attribute of the
     * <code>AtomTemplateFilter</code> object.
     *
     * @param atomTemplate The new <code>atomTemplate</code> value.
     */
    public void setAtomTemplate(AtomTemplate atomTemplate) {
        this.atomTemplate = atomTemplate;
    }

    /**
     * Description of the method.
     *
     * @param object Description of parameter.
     *
     * @return Description of the returned value.
     */
    public boolean filter(AbstractObject object) {
        if (super.filter(object)) {
            if (((Atom) object).getTemplate() == atomTemplate) {
                return true;
            }
        }
        return false;
    }
}
