/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.views;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

import javax.media.j3d.Transform3D;
import javax.vecmath.Matrix4f;
import javax.vecmath.Point3f;
import javax.vecmath.Tuple3f;

import org.srs3d.viewer.bioatlas.modules.AnnotationModule;
import org.srs3d.viewer.bioatlas.modules.StructureModule;
import org.srs3d.viewer.bioatlas.modules.ViewAnalysis;
import org.srs3d.viewer.j3d.Context;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.behaviors.UpdateBehavior;
import org.srs3d.viewer.j3d.behaviors.dispatcher.DispatchThread;
import org.srs3d.viewer.objects.Operation;
import org.srs3d.viewer.util.Log;
import org.srs3d.viewer.util.XmlTag;

/**
 * Abstract View implementation.
 *
 * @author Karsten Klein
 */
public class CustomView extends AbstractView {
    private static final Log log = new Log(CustomView.class);
    public static final String OPERATION_TAG = "operation";
    public static final String ORIENTATION_TAG = "orientation";
    public static final String MATRIX_ATTRIBUTE = "matrix";
    public static final String CENTER_ATTRIBUTE = "center";
    public static final String VIEW_TAG = "view";
    public static final String ID_ATTRIBUTE = "id";
    private XmlTag viewTag = null;

    /**
     * Constructor description.
     *
     * @param name Parameter description.
     */
    public CustomView(XmlTag viewTag) {
        super(viewTag.getAttribute(ID_ATTRIBUTE));
        this.viewTag = viewTag;
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     */
    public void apply(final ContextData contextData) {
        Collection xmlTags = XmlTag.copy(viewTag).getSubtags();
        int tries = 0;
        Iterator tagIterator = xmlTags.iterator();
        XmlTag xmlTag;
        ArrayList operationTagList = new ArrayList();
        while (tagIterator.hasNext()) {
            xmlTag = (XmlTag) tagIterator.next();
            if (xmlTag.getName().equals(OPERATION_TAG)) {
                operationTagList.add(xmlTag);
            } else if (xmlTag.getName().equals(ORIENTATION_TAG)) {

                // the orientation tag is interpreted directly
                String value = xmlTag.getAttribute(MATRIX_ATTRIBUTE);
                if (value != null) {
                    final Matrix4f matrix = StructureModule.readMatrix(value);
                    if (matrix != null) {
                        final Context context = contextData.getContext();
                        context.addUpdateCallback(new UpdateBehavior.Callback() {
                                public void execute() {
                                    Transform3D transform =
                                        context.getViewingPlatformTransform();
                                    transform.set(matrix);
                                    context.setViewingPlatformTransform(transform);
                                }
                            });
                    }
                }
                value = xmlTag.getAttribute(CENTER_ATTRIBUTE);
                if (value != null) {
                    Point3f center = new Point3f();
                    AnnotationModule.readTuple(value, center);
                    contextData.getContext().setCenterOfRotation(center);
                }
            } else {
                log.debug("Unknown tag: " + xmlTag.getName());
            }
        }
        if (!operationTagList.isEmpty()) {
            log.debug("Analysing operations");
            log.debug("Pre analysis operation number: " +
                operationTagList.size());
            new ViewAnalysis().analyze(contextData, operationTagList);
            log.debug("Post analysis operation number: " +
                operationTagList.size());
            Iterator iterator = operationTagList.iterator();
            while (iterator.hasNext()) {
                scheduleOperation(contextData, (XmlTag) iterator.next());
            }
        }
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public XmlTag getXmlTag() {
        return viewTag;
    }

    private void scheduleOperation(final ContextData contextData,
        XmlTag operationTag) {
        final Collection operations =
            Operation.deserialize(contextData, operationTag);
        contextData.getContext().addUpdateCallback(new UpdateBehavior.Callback() {
                public void execute() {
                    Iterator iterator = operations.iterator();
                    while (iterator.hasNext()) {
                        contextData.getDispatcher().runDispatch((Operation) iterator.next());
                    }

                    // BF 010702
                    // this is needed for unexpanded atom geometry
                    if (org.srs3d.viewer.bioatlas.dispatcher.NavigateUpDispatcher.processSelectionExpand(
                              contextData,
                              contextData.getSelectionManager().getSelection())) {
                        org.srs3d.viewer.bioatlas.Capture.updateSelections(contextData,
                            true);
                    }
                }
            });
        contextData.getContext().waitForUpdate();
        DispatchThread.waitForEmptyQueue();
        contextData.getContext().waitForUpdate();
        DispatchThread.waitForEmptyQueue();
        Thread.yield();
    }

    /**
     * Method description.
     */
    public void delete() {
        getXmlTag().getSubtags().clear();
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     */
    public void updateOrientationData(ContextData contextData) {
        Context context = contextData.getContext();
        Matrix4f matrix = new Matrix4f();
        context.getViewingPlatformTransform().get(matrix);
        XmlTag tag = new XmlTag(ORIENTATION_TAG);
        tag.setAttribute(MATRIX_ATTRIBUTE, convertMatrix(matrix));
        Point3f center = context.getCenterOfRotation();
        tag.setAttribute(CENTER_ATTRIBUTE, convertTuple(center));
        getXmlTag().getSubtags().add(tag);
    }

    /**
     * Description of the method.
     *
     * @param matrix Description of parameter.
     *
     * @return Description of the returned value.
     */
    public static String convertMatrix(Matrix4f matrix) {
        String matrixString;
        matrixString = Float.toString(matrix.m00) + ":";
        matrixString += Float.toString(matrix.m01) + ":";
        matrixString += Float.toString(matrix.m02) + ":";
        matrixString += Float.toString(matrix.m03) + ":";
        matrixString += Float.toString(matrix.m10) + ":";
        matrixString += Float.toString(matrix.m11) + ":";
        matrixString += Float.toString(matrix.m12) + ":";
        matrixString += Float.toString(matrix.m13) + ":";
        matrixString += Float.toString(matrix.m20) + ":";
        matrixString += Float.toString(matrix.m21) + ":";
        matrixString += Float.toString(matrix.m22) + ":";
        matrixString += Float.toString(matrix.m23);
        return matrixString;
    }

    /**
     * Method description.
     *
     * @param tuple Parameter description.
     *
     * @return Return description.
     */
    public static String convertTuple(Tuple3f tuple) {
        String string = Float.toString(tuple.x) + ":";
        string += Float.toString(tuple.y) + ":";
        string += Float.toString(tuple.z);
        return string;
    }
}
