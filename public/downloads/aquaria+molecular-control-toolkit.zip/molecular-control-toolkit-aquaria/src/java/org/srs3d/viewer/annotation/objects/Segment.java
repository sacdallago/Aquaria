/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.annotation.objects;

import java.util.Iterator;
import java.util.Vector;

import org.srs3d.viewer.bioatlas.objects.AbstractChain;
import org.srs3d.viewer.bioatlas.objects.Residue;
import org.srs3d.viewer.bioatlas.objects.Subchain;
import org.srs3d.viewer.objects.AbstractObject;

/**
 * Description of the class.
 *
 * @author Karsten Klein
 * @author Christian Zofka
 *
 * @created March 28, 2001
 * @modified June 26, 2001
 */
public final class Segment extends AbstractChain implements Referenceable {
    private Subchain subchain = null;
    private int startIndex = 0;
    private int endIndex = -1;
    private Vector gaps = null;

    /**
     * <code>Segment</code> contructor.
     *
     * @param subchain Description of parameter.
     */
    public Segment(Subchain subchain) {
        this.subchain = subchain;
        if (subchain != null) {
            setInitialResidue(subchain.getInitialResidue());
            setEndResidue(subchain.getEndResidue());
        }
    }

    /**
     * Sets the <code>StartIndex</code> attribute of the <code>Segment</code> object.
     *
     * @param startIndex The new <code>StartIndex</code> value.
     */
    public void setStartIndex(int startIndex) {
        this.startIndex = startIndex;
        invalidate();
    }

    /**
     * Sets the <code>EndIndex</code> attribute of the <code>Segment</code> object.
     *
     * @param endIndex The new <code>EndIndex</code> value.
     */
    public void setEndIndex(int endIndex) {
        this.endIndex = endIndex;
        invalidate();
    }

    /**
     * Gets the <code>StartIndex</code> attribute of the <code>Segment</code> object.
     *
     * @return The <code>StartIndex</code> value.
     */
    public int getStartIndex() {
        return startIndex;
    }

    /**
     * Gets the <code>EndIndex</code> attribute of the <code>Segment</code> object.
     *
     * @return The <code>EndIndex</code> value.
     */
    public int getEndIndex() {
        return endIndex;
    }

    /**
     * Gets the <code>subchain</code> attribute of the <code>Segment</code> object.
     *
     * @return The <code>subchain</code> value.
     */
    public Subchain getSubchain() {
        return subchain;
    }

    /**
     * Gets the <code>reference</code> attribute of the <code>Segment</code> object.
     *
     * @return The <code>reference</code> value.
     */
    public AbstractObject getReference() {
        return (AbstractObject) subchain;
    }

    /**
     * Gets the <code>gaps</code> attribute of the <code>Segment</code> object.
     *
     * @return The <code>gaps</code> value.
     */
    public Vector getGaps() {
        if (gaps == null) {
            gaps = new Vector();
        }
        return gaps;
    }

    /**
     * Gets the <code>gapsSize</code> attribute of the <code>Segment</code> object.
     *
     * @return The <code>gapsSize</code> value.
     */
    public int getGapsSize() {
        if (gaps != null) {
            int size = 0;
            Gap gap = null;
            Iterator iterator = getGaps().iterator();
            while (iterator.hasNext()) {
                gap = (Gap) iterator.next();
                size += gap.getLength();
            }
            return size;
        }
        return 0;
    }

    /**
     * Adds a <code>Gap</code> object to the <code>Segment</code> object.
     *
     * @param gap The <code>Gap</code> object to be added.
     */
    public void addGap(Gap gap) {
        invalidate();
        getGaps().add(gap);
    }

    /**
     * Description of the method.
     *
     * @param gap Description of parameter.
     */
    public void removeGap(Gap gap) {
        invalidate();
        getGaps().remove(gap);
    }

    /**
     * Determines the length of the chain by counting the residues.
     *
     * @return Length of the chain.
     */
    public int computeLength() {
        int length = getEndIndex() - getStartIndex() + 1;

        //    length += getGapsSize();
        return length;
    }

    /**
     * Description of the method.
     *
     * @return Description of the returned value.
     */
    public String toString() {
        String string = new String("[Segment(");
        if (getSubchain() != null) {
            string += "[" + getSubchain().getCode();
            if (getInitialResidue() != null && getEndResidue() != null) {
                if (getInitialResidue().getTemplate() != null) {
                    String description =
                        getInitialResidue().getTemplate().getName();
                    description += getInitialResidue().getId() + "-";
                    description += getEndResidue().getTemplate().getName();
                    description += getEndResidue().getId();
                }
                string += "(" + getInitialResidue() + "-" + getEndResidue() +
                ")";
            }
            string += "]";
        } else {
            string += new String("Gap");
        }
        string += new String(")]");
        return string;
    }

    /**
     * Description of the method.
     */
    public void update() {
        invalidate();
    }

    /**
     * splits this segment in 2 parts; 1. part will be cutted and have all gaps, 2. part
     * will be a new created segment; notice the indizies will be updated and the
     * subchain reference will be set for the new segment
     *
     * @param residue endresidue of the 1. part
     *
     * @return newly created 2. part of the segment
     */
    public Segment split(Residue residue) {
        if (residue != null) {
            Segment newSegment = new Segment(getSubchain());
            newSegment.setInitialResidue(residue.getProceeding());
            newSegment.setEndResidue(getEndResidue());
            newSegment.setEndIndex(getEndIndex());
            setEndResidue(residue);
            setEndIndex(getStartIndex() + computeResidueIndex(residue));
            newSegment.setStartIndex(getEndIndex() + 1);
            newSegment.setEndIndex(newSegment.getStartIndex() +
                newSegment.computeResidueIndex(newSegment.getEndResidue()));
            return newSegment;
        } else {
            return null;
        }
    }

    /**
     * Description of the method.
     */
    public void cleanup() {
        super.cleanup();
        subchain = null;
        cleanup(gaps);
        gaps = null;
    }
}
