/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.loaders.rdb;

import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.Vector;

/**
 * This class parses a rdb line for high level protein data and tranfers/builts the
 * extracted information into a <code>ObjectContainer</code> .
 *
 * @author Karsten Klein
 *
 * @created January 20, 2001
 */
public class RdbFieldParser {
    private Vector fieldOrder = null;

    /**
     * Sets the <code>fieldOrder</code> attribute of the <code>RdbFieldParser</code>
     * object.
     *
     * @param e Collection giving the appropriate order of the fields in the rdb file.
     */
    public void setFieldOrder(Vector fieldOrder) {
        this.fieldOrder = fieldOrder;
    }

    /**
     * Create from rdb string. The current implementations format is "PDB NAME X Y Z"
     *
     * @param string Description of parameter.
     *
     * @return Description of the returned value.
     */
    public Map create(String string) {
        Map fieldMap = new HashMap();
        if (fieldOrder != null) {
            StringTokenizer tokenizer = new StringTokenizer(string, "\t");
            String token;
            int index = 0;
            while (tokenizer.hasMoreTokens()) {
                token = tokenizer.nextToken().trim();
                fieldMap.put(fieldOrder.elementAt(index), token);
                index++;
            }
            tokenizer = null;
            token = null;
        }
        return fieldMap;
    }
}
