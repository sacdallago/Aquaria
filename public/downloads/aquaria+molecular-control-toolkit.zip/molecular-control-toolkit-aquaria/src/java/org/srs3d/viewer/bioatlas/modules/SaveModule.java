/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.modules;

import java.awt.Component;
import java.awt.event.ActionEvent;

import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.objects.Operation;

/**
 * @author Karsten Klein
 *
 * @created February 06, 2002
 */
public class SaveModule extends ProcessModule {

    /**
     * <code>RestoreModule</code> constructor.
     *
     * @param name Description of parameter.
     * @param contextData Description of parameter.
     * @param filename Description of parameter.
     */
    public SaveModule(String name, ContextData contextData) {
        super(name, contextData, false, false);
        setOperationSerializeable(false);
    }

    /**
     * Description of the method.
     *
     * @param e Description of parameter.
     */
    public void process(ActionEvent e) {
        String viewId = (String) getContextData().getProperty("VIEW");
        if (viewId != null) {
            Operation operation =
                new Operation(getContextData().getContext(),
                    RestoreModule.SAVE_OPERATION, null);
            operation.setSerializable(false);
            getContextData().getDispatcher().runDispatch(operation);
        } else {
            Operation operation =
                new Operation(getContextData().getContext(),
                    SaveAsModule.SAVE_AS_OPERATION, null);
            operation.setSerializable(false);
            getContextData().getDispatcher().runDispatch(operation);
        }
    }

    /**
     * Method description.
     */
    public void updateIntern() {
        Component component = getComponent();
        RestoreModule restoreModule =
            (RestoreModule) getContextData().getProperty("RESTORE_MODULE");
        if (restoreModule != null) {
            if (restoreModule.canSave()) {
                component.setEnabled(true);
            } else {
                component.setEnabled(false);
            }
        }
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public boolean checkVisible() {
        RestoreModule restoreModule =
            (RestoreModule) getContextData().getProperty("RESTORE_MODULE");
        if (restoreModule == null) {
            return false;
        }
        return super.checkVisible();
    }
}
