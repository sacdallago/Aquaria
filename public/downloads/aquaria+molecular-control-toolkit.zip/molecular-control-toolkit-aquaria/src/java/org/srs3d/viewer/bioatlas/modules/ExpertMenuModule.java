/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.modules;

import java.awt.event.ActionEvent;

import org.srs3d.viewer.j3d.ContextData;

/**
 * Menu module enabling to switch between the epxert menu mode and the reduced menu.
 *
 * @author Karsten Klein
 *
 * @created May 14, 2001
 */
public class ExpertMenuModule extends CheckModule {

    /**
     * Constructor description.
     *
     * @param name Parameter description.
     * @param contextData Parameter description.
     */
    public ExpertMenuModule(String name, ContextData contextData) {
        super(name, contextData);
    }

    /**
     * Description of the method.
     */
    public void updateIntern() {
        if (getCheckComponent() != null) {
            getCheckComponent().setState(getContextData().isExpertContext());
        }
    }

    /**
     * Description of the method.
     *
     * @param e Description of parameter.
     */
    public void react(ActionEvent e) {
        getContextData().setExpertContext(!getContextData().isExpertContext());
    }
}
