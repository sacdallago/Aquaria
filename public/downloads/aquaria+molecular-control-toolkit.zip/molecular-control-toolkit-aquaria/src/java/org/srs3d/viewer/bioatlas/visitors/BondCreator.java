/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.visitors;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.Vector;

import javax.vecmath.Vector3f;

import org.srs3d.viewer.bioatlas.Parameter;
import org.srs3d.viewer.bioatlas.factories.AtomTemplateFactory;
import org.srs3d.viewer.bioatlas.factories.ResidueTemplateFactory;
import org.srs3d.viewer.bioatlas.filters.AtomTemplateFilter;
import org.srs3d.viewer.bioatlas.filters.ResidueTemplateFilter;
import org.srs3d.viewer.bioatlas.objects.Atom;
import org.srs3d.viewer.bioatlas.objects.Bond;
import org.srs3d.viewer.bioatlas.objects.Chain;
import org.srs3d.viewer.bioatlas.objects.Residue;
import org.srs3d.viewer.bioatlas.objects.templates.AtomTemplate;
import org.srs3d.viewer.bioatlas.objects.templates.ResidueTemplate;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.objects.ObjectContainer;
import org.srs3d.viewer.objects.visitors.ObjectCollector;

/**
 * This class provides the methods to create the <code>Bonds</code> instances from an
 * <code>AbstractObject</code> .
 *
 * @author Karsten Klein
 *
 * @created January 20, 2001
 */
public class BondCreator {

    /** Description of the field */
    public static final int BACKBONE = 1;

    /** Description of the field */
    public static final int DISULFIDE = 2;

    /** Description of the field */
    public static final int ALL = 4;

    /** Description of the field */
    public int mode = ALL;

    /** Description of the field */
    public Vector bonds = new Vector();

    /**
     * Description of the method.
     *
     * @param objectContainer Description of parameter.
     */
    public void visit(ObjectContainer objectContainer) {
        if (mode == DISULFIDE) {
            ResidueTemplate template =
                ResidueTemplateFactory.getTemplate("CYS");
            ResidueTemplateFilter cysfilter =
                new ResidueTemplateFilter(template);
            ObjectCollector cysCollector = new ObjectCollector(cysfilter);
            cysCollector.setObjects(new ArrayList());
            cysCollector.visit((AbstractObject) objectContainer);
            AtomTemplate sulfidTemplate =
                AtomTemplateFactory.getTemplate(" SG ");
            AtomTemplateFilter sulfidFilter =
                new AtomTemplateFilter(sulfidTemplate);
            ObjectCollector sulfidCollector = new ObjectCollector(sulfidFilter);
            sulfidCollector.setObjects(new ArrayList());
            sulfidCollector.visit(cysCollector.getObjects());
            visitAtoms(sulfidCollector.getObjects());
        } else {
            Iterator iterator = objectContainer.getIterator();
            while (iterator.hasNext()) {
                visit(((AbstractObject) iterator.next()));
            }
        }
    }

    /**
     * Description of the method.
     *
     * @param object Description of parameter.
     */
    public void visit(AbstractObject object) {
        if (object instanceof Residue) {
            visit((Residue) object);
        } else if (object instanceof Chain) {
            visit((Chain) object);
        } else if (object instanceof ObjectContainer) {
            visit((ObjectContainer) object);
        }
    }

    /**
     * Method description.
     *
     * @param objects Parameter description.
     */
    public void visit(Collection objects) {
        Iterator iterator = objects.iterator();
        if (mode == DISULFIDE) {
            AtomTemplate sulfidTemplate =
                AtomTemplateFactory.getTemplate(" SG ");
            AtomTemplateFilter sulfidFilter =
                new AtomTemplateFilter(sulfidTemplate);
            ObjectCollector sulfidCollector = new ObjectCollector(sulfidFilter);
            sulfidCollector.setObjects(new ArrayList());
            sulfidCollector.visit(objects);
            visitAtoms(sulfidCollector.getObjects());
        } else {
            while (iterator.hasNext()) {
                visit((AbstractObject) iterator.next());
            }
        }
    }

    /**
     * Visits the atoms of a chain.
     *
     * @param chain the chain to visit.
     */
    public void visit(Chain chain) {
        if (mode == ALL) {
            ArrayList atoms = new ArrayList();
            AtomCollector atomCollector = new AtomCollector();
            atomCollector.setObjects(atoms);
            atomCollector.visit(chain);
            for (int i = 0; i < atoms.size(); i++) {
                for (int j = 0; j < atoms.size(); j++) {
                    createBond((Atom) atoms.get(i), (Atom) atoms.get(j));
                }
            }
        } else {
            Residue residue = chain.getInitialResidue();
            while (residue != null) {
                visit(residue);
                residue = residue.getProceeding();
            }
        }
    }

    /**
     * Visits a residue.
     *
     * @param residue the residue to visit.
     */
    public void visit(Residue residue) {
        Bond bond;
        if (mode == BACKBONE) {
            createBond(residue.refN, residue.refCA);
            createBond(residue.refCA, residue.refN);
            createBond(residue.refCA, residue.refC);
            createBond(residue.refC, residue.refCA);
        } else if (mode == ALL) {
            Collection atoms = residue.getAtoms();

            // create bonds in between all the atoms of the residue
            visitAtoms(atoms);
            atoms = null;
        }
        if (!residue.getTemplate().isWater()) {
            if (residue.getProceeding() != null) {
                createBond(residue.refC, residue.getProceeding().refN);

                // for dna/rna we connect the 3' oxygen with the phosphor
                createBond(residue.refO3, residue.getProceeding().refP);
            }
            if (residue.getPreceeding() != null) {
                createBond(residue.refN, residue.getPreceeding().refC);

                // for dna/rna we connect the 3' oxygen with the phosphor
                createBond(residue.refP, residue.getPreceeding().refO3);
            }
        }
    }

    /**
     * Description of the method.
     *
     * @param atom0 Description of parameter.
     * @param atom1 Description of parameter.
     */
    private void createBond(Atom atom0, Atom atom1) {
        if (atom0 != null && atom1 != null) {
            if (isConnected(atom0, atom1)) {
                Bond bond = new Bond();
                bond.setAtom0(atom0);
                bond.setAtom1(atom1);
                bonds.addElement(bond);
            }
        }
    }

    /**
     * Description of the method.
     *
     * @param atoms Description of parameter.
     */
    private void visitAtoms(Collection atoms) {
        Vector vector = new Vector();
        vector.addAll(atoms);
        visitAtoms(vector);
    }

    /**
     * Description of the method.
     *
     * @param atoms Description of parameter.
     */
    private void visitAtoms(Vector atoms) {
        int i;
        int j;
        int count = atoms.size();
        Atom atomi;
        Atom atomj;
        for (i = 0; i < count; i++) {
            atomi = (Atom) atoms.elementAt(i);
            for (j = i + 1; j < count; j++) {
                atomj = (Atom) atoms.elementAt(j);
                if (isConnected(atomi, atomj)) {
                    createBond(atomi, atomj);
                    createBond(atomj, atomi);
                }
            }
        }
    }

    /**
     * Checks whether there is a connection between the two offered atoms.
     *
     * @param atom0 First atom.
     * @param atom1 Second atom.
     *
     * @return <code>true</code> the two atoms shounld be connected by a bond.
     */
    public static boolean isConnected(Atom atom0, Atom atom1) {
        Vector3f connect;
        float maxDistance = atom0.getTemplate().getCovalentRadius();
        maxDistance += atom1.getTemplate().getCovalentRadius();
        maxDistance += Parameter.bondLengthTolerance;
        char aLocation0 = atom0.getAlternateLocation();
        char aLocation1 = atom1.getAlternateLocation();
        if (aLocation0 == ' ' || aLocation1 == ' ' || aLocation0 == aLocation1) {
            connect = new Vector3f(atom1.getCoordinate());
            connect.sub(atom0.getCoordinate());
            if (connect.length() < maxDistance &&
                  connect.length() > Float.MIN_VALUE) {
                return true;
            }
        }
        return false;
    }

    /**
     * Searches for atoms that might connect one collection with the other.
     *
     * @param atoms0 First collection.
     * @param atoms1 Second collection.
     *
     * @return <code>true</code> if a connection criteria met.
     */
    public static boolean isConnected(Collection atoms0, Collection atoms1) {
        Iterator iterator0 = atoms0.iterator();
        Iterator iterator1;
        Atom atom0;
        while (iterator0.hasNext()) {
            atom0 = (Atom) iterator0.next();
            iterator1 = atoms1.iterator();
            while (iterator1.hasNext()) {
                if (isConnected(atom0, (Atom) iterator1.next())) {
                    return true;
                }
            }
        }
        return false;
    }
}
