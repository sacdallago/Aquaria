/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.modules;

import java.util.ArrayList;
import java.util.HashSet;

import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.util.XmlTag;

/**
 * Module that enables saving and restoring views. All reset operations will act on a
 * default view, only.
 *
 * @author Karsten Klein
 *
 * @created February 06, 2002
 */
public class ViewAnalysis {

    /**
     * Description of the method.
     *
     * @param xmlTags Description of parameter.
     */
    private void analyzeAnnotations(ArrayList xmlTags) {

        // strategy:
        // 1) step through the tags from start to end and 'simulate' the activations
        // of annotations; keep in mind that some might be active from the beginning
        // 2) use the result of the analysis when stepping through the tags
        // end to start and remove redundant activations
        boolean removeTag = false;
        HashSet annotations = new HashSet();
        String annotation;
        XmlTag xmlTag;
        String id;
        for (int i = 0; i < xmlTags.size(); i++) {
            removeTag = false;
            xmlTag = (XmlTag) xmlTags.get(i);
            id = xmlTag.getAttribute("id");

            // :FIXME: crude implementation
            if (id.equalsIgnoreCase("SELECT-ACTIVE_ANNOTATION")) {

                // this operation is based on the history of activation till
                // this point. the current implementation does NOT cover this
                // case. therefore we keep the operations as they are and
                // do NOT remove any tags.
                return;
            }
            boolean isToggle = id.equalsIgnoreCase("TOGGLE_ACTIVATION");
            boolean isToggleEx = id.equalsIgnoreCase("TOGGLE_ACTIVATION_EX");
            if (isToggle || isToggleEx) {
                annotation = xmlTag.getAttribute("object");
                if (annotations.contains(annotation)) {
                    if (isToggleEx) {
                        annotations.clear();
                    } else {
                        annotations.remove(annotation);
                    }
                } else {
                    if (isToggleEx) {
                        annotations.clear();
                    }
                    annotations.add(annotation);
                }
            }
        }

        // now we have a list of annotations that need a manipulation
        for (int i = xmlTags.size() - 1; i >= 0; i--) {
            removeTag = false;
            xmlTag = (XmlTag) xmlTags.get(i);
            id = xmlTag.getAttribute("id");
            boolean isToggle =
                id.equalsIgnoreCase("TOGGLE_ACTIVATION") ||
                id.equalsIgnoreCase("TOGGLE_ACTIVATION_EX");
            if (isToggle) {
                annotation = xmlTag.getAttribute("object");
                if (annotations.contains(annotation)) {
                    annotations.remove(annotation);

                    // manipulate xmlTag
                    xmlTag.setAttribute("id", "TOGGLE_ACTIVATION");
                } else {
                    removeTag = true;
                }
            }
            if (removeTag) {
                xmlTags.remove(i);
            }
        }
    }

    /**
     * Description of the method.
     *
     * @param xmlTags Description of parameter.
     */
    private void analyze(ArrayList xmlTags) {

        // remove invalid operation plus invalidated operations
        analyzeCanceled(xmlTags);
        analyzeInvalid(xmlTags);
        analyzeSwitches(xmlTags);
        analyzeRemoveAll(xmlTags);
        boolean removeStyleFlag = false;
        boolean removeSelectFlag = false;
        boolean removeOperation = false;
        XmlTag xmlTag;
        String id;
        for (int i = xmlTags.size() - 1; i >= 0; i--) {
            removeOperation = false;
            xmlTag = (XmlTag) xmlTags.get(i);
            id = xmlTag.getAttribute("id");
            boolean absolutSelection =
                id.equalsIgnoreCase("SELECT") ||
                id.equalsIgnoreCase("REQUEST_SELECTION") ||
                id.equalsIgnoreCase("SELECT-ALL") ||
                id.equalsIgnoreCase("SELECT-LIGANDS") ||
                id.equalsIgnoreCase("SELECT-WATER") ||
                id.equalsIgnoreCase("SELECT_FEATURES") ||
                id.equalsIgnoreCase("SELECT_ALT");
            boolean selection =
                absolutSelection || id.startsWith("SELECT_") ||
                id.startsWith("SELECT-") || id.startsWith("DESELECT_");
            if (selection || absolutSelection) {

                // filter all selections, directly following an absolut selection
                if (removeSelectFlag) {
                    removeOperation = true;
                }
                if (absolutSelection) {
                    removeSelectFlag = true;
                }
            } else {

                // selection independent operations don't affect the removeSelectFlag
                if (!id.startsWith("TOGGLE_ACTIVATION") &&
                      !id.startsWith("SWITCH-") && !id.startsWith("STYLE-")) {
                    removeSelectFlag = false;
                }
            }
            if (id.indexOf("STYLE-") != -1) {

                // remove all but the last style operation
                if (removeStyleFlag) {
                    removeOperation = true;
                }
                removeStyleFlag = true;
            } else if (id.indexOf("COLOR-") != -1 ||
                  id.indexOf("REPRESENT-") != -1) {

                // remove all redundant colorings and representations
                if (removeStyleFlag) {
                    removeOperation = true;
                }
            }
            if (removeOperation) {
                xmlTags.remove(i);
            }
        }
        analyzeAnnotations(xmlTags);
    }

    private void analyzeInvalid(ArrayList xmlTags) {
        boolean removeTag = false;
        XmlTag xmlTag;
        String id;
        boolean exceptionTag = false;
        boolean isRecoverOperation = false;
        for (int i = 0; i < xmlTags.size(); i++) {
            removeTag = false;
            xmlTag = (XmlTag) xmlTags.get(i);
            id = xmlTag.getAttribute("id");
            if (id.equalsIgnoreCase("invalid")) {
                exceptionTag = true;
                isRecoverOperation = false;
                removeTag = true;
            } else {
                if (exceptionTag) {
                    isRecoverOperation =
                        id.equals("SELECT") || id.equals("SELECT_ALT") ||
                        id.startsWith("SELECT-") ||
                        id.equals("REQUEST_SELECTION");
                    removeTag =
                        isRecoverOperation || id.startsWith("STYLE-") ||
                        id.startsWith("TOGGLE_ACTIVATION");
                    removeTag = !removeTag;
                }
            }
            if (removeTag) {
                xmlTags.remove(i);
                i--;
            } else {
                if (isRecoverOperation) {
                    exceptionTag = false;
                }
            }
        }
    }

    private void analyzeRemoveAll(ArrayList xmlTags) {
        boolean removeTag = false;
        HashSet removeSet = new HashSet();
        XmlTag xmlTag;
        String id;
        String removeString;
        int index;
        for (int i = xmlTags.size() - 1; i >= 0; i--) {
            removeTag = false;
            xmlTag = (XmlTag) xmlTags.get(i);
            id = xmlTag.getAttribute("id");
            if (id.startsWith("REMOVE_ALL_")) {
                index = id.lastIndexOf("_");
                removeString = id.substring(index + 1);
                removeTag = true;
                removeSet.add(removeString);
            } else {
                if (id.startsWith("SURFACE-")) {
                    if (removeSet.contains("SURFACES")) {
                        removeTag = true;
                    }
                } else if (id.startsWith("LABEL-")) {
                    if (removeSet.contains("LABELS")) {
                        removeTag = true;
                    }
                } else if (id.equalsIgnoreCase("PROCESS-DISTANCE") ||
                      id.equalsIgnoreCase("PROCESS-CONTACTS")) {
                    if (removeSet.contains("DISTANCES")) {
                        removeTag = true;
                    }
                }
            }
            if (removeTag) {
                xmlTags.remove(i);
            }
        }
    }

    private void analyzeSwitches(ArrayList xmlTags) {
        HashSet removeSet = new HashSet();
        XmlTag xmlTag;
        String id;
        String removeString;
        int index;

        // populate remove set
        for (int i = xmlTags.size() - 1; i >= 0; i--) {
            xmlTag = (XmlTag) xmlTags.get(i);
            id = xmlTag.getAttribute("id");
            if (id.startsWith("SWITCH-")) {
                index = id.lastIndexOf("-");
                removeString = id.substring(index + 1);
                if (removeSet.contains(removeString)) {
                    removeSet.remove(removeString);
                } else {
                    removeSet.add(removeString);
                }
            }
        }

        // strategy: only keep the last one
        for (int i = xmlTags.size() - 1; i >= 0; i--) {
            xmlTag = (XmlTag) xmlTags.get(i);
            id = xmlTag.getAttribute("id");
            if (id.startsWith("SWITCH-")) {
                index = id.lastIndexOf("-");
                removeString = id.substring(index + 1);
                if (!removeSet.contains(removeString)) {
                    xmlTags.remove(i);
                } else {
                    removeSet.remove(removeString);
                }
            }
        }
    }

    private void analyzeCanceled(ArrayList xmlTags) {
        boolean removeTag = false;
        boolean isCanceled = false;
        HashSet removeSet = new HashSet();
        XmlTag xmlTag;
        String id;
        String removeString;
        int index;

        // populate remove set
        for (int i = xmlTags.size() - 1; i >= 0; i--) {
            xmlTag = (XmlTag) xmlTags.get(i);
            id = xmlTag.getAttribute("id");
            removeTag = false;
            if (id.equalsIgnoreCase("CANCEL")) {
                removeTag = true;
                isCanceled = true;
            } else {
                if (isCanceled) {
                    removeTag = true;
                    isCanceled = false;
                }
            }
            if (removeTag) {
                xmlTags.remove(i);
            }
        }
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     * @param operationXmlTags Parameter description.
     */
    public void analyze(ContextData contextData, ArrayList operationXmlTags) {

        // now we have a list of operation tags
        if (contextData.getProperty("RuntimeTestMode") == null) {

            // analyze operation tag list and remove redundant tags
            analyze(operationXmlTags);
        } else {
            System.out.println(this + ": not removing redundant tags");
        }
    }
}
