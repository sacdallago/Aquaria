/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.loaders.raster3d;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.StringTokenizer;
import java.util.Vector;

import javax.media.j3d.BranchGroup;

import org.srs3d.viewer.util.Log;

/**
 * Class description.
 *
 * @author Karsten Klein, LION bioscience AG
 */
public class TextfileParser extends BufferedReader {
    private static final Log log = new Log(TextfileParser.class);

    /**
     * Constructor description.
     *
     * @param fileName Parameter description.
     *
     * @throws FileNotFoundException Exception description
     */
    public TextfileParser(String fileName) throws FileNotFoundException {
        super(new FileReader(fileName));
    }

    /**
     * Constructor description.
     *
     * @param inputStream Parameter description.
     *
     * @throws FileNotFoundException Exception description
     * @throws IOException Exception description
     */
    public TextfileParser(InputStream inputStream)
        throws FileNotFoundException, IOException {
        super(new InputStreamReader(inputStream));
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public BranchGroup readSceneGraph() {
        AbstractRaster3DPrimitive currentPrimitive = null;
        String token = null;
        String line = null;
        BranchGroup branch = new BranchGroup();
        org.srs3d.viewer.j3d.BranchGroupHelper.setDefaultCapabilities(branch);
        Vector triangles = new Vector();
        Vector lines = new Vector();
        try {
            do {
                line = readLine();
                if (line != null) {
                    StringTokenizer tokenizer = new StringTokenizer(line);
                    if (tokenizer.countTokens() == 1) {
                        token = tokenizer.nextToken();
                        currentPrimitive =
                            PrimitiveFactory.create(Integer.parseInt(token));
                        if (currentPrimitive != null) {
                            line = readLine();
                            if (line != null && currentPrimitive.create(line)) {

                                // primitive info parsing was successfull
                                // let it contribute to the existing data
                                currentPrimitive.supply(lines, triangles, branch);
                            }
                        }
                    }
                }
            } while (line != null);
        } catch (IOException e) {
            log.debug(e, e);
        }
        Raster3DLine.supply(lines, branch);
        Raster3DTriangle.supply(triangles, branch);
        return branch;
    }
}
