/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.objects;

import javax.vecmath.Point3f;
import javax.vecmath.Tuple3f;

import org.srs3d.viewer.objects.AbstractObject;

/**
 * Instances of this class describe a rectangle that can be displayed in 3d. It is always
 * parallel to the xy plane.
 *
 * @author Karsten Klein
 *
 * @created March 20, 2001
 */
public class Rectangle extends AbstractObject {
    private float width = 50;
    private float height = 50;
    private float minimumExtend = 250;
    private Tuple3f coordinate = new Point3f();

    /**
     * Sets the <code>Width</code> attribute of the <code>Rectangle</code> object.
     *
     * @param width The new <code>Width</code> value.
     */
    public void setWidth(float width) {
        this.width = width;
    }

    /**
     * Sets the <code>Height</code> attribute of the <code>Rectangle</code> object.
     *
     * @param height The new <code>Height</code> value.
     */
    public void setHeight(float height) {
        this.height = height;
    }

    /**
     * Sets the <code>MinimumExtend</code> attribute of the <code>Rectangle
     * </code>object.
     *
     * @param minimumExtend The new <code>MinimumExtend</code> value.
     */
    public void setMinimumExtend(float minimumExtend) {
        this.minimumExtend = minimumExtend;
    }

    /**
     * Sets the <code>Coordinate</code> attribute of the <code>Rectangle</code> object.
     *
     * @param coordinate The new <code>Coordinate</code> value.
     */
    public void setCoordinate(Tuple3f coordinate) {
        this.coordinate.set(coordinate);
    }

    /**
     * Gets the <code>Width</code> attribute of the <code>Rectangle</code> object.
     *
     * @return The <code>Width</code> value.
     */
    public float getWidth() {
        return width;
    }

    /**
     * Gets the <code>Height</code> attribute of the <code>Rectangle</code> object.
     *
     * @return The <code>Height</code> value.
     */
    public float getHeight() {
        return height;
    }

    /**
     * Gets the <code>MinimumExtend</code> attribute of the <code>Rectangle
     * </code>object.
     *
     * @return The <code>MinimumExtend</code> value.
     */
    public float getMinimumExtend() {
        return minimumExtend;
    }

    /**
     * Gets the <code>Coordinate</code> attribute of the <code>Rectangle</code> object.
     *
     * @return The <code>Coordinate</code> value.
     */
    public Tuple3f getCoordinate() {
        return coordinate;
    }

    /**
     * Description of the method.
     */
    public void cleanup() {
        super.cleanup();
        coordinate = null;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public String toString() {
        return "Focus Rectangle";
    }
}
