/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.loaders.raster3d;

import java.util.StringTokenizer;
import java.util.Vector;

import javax.media.j3d.BranchGroup;
import javax.vecmath.Vector3f;

import org.srs3d.viewer.vecmath.VectorArray3f;

/**
 * The TriangleNormals are a very special primitive object. Its purpose is to supply
 * triangle primitives with special normal settings. The class does not quite fit in the
 * row of the other AbstractPrimitive objects, because there is no visual
 * respresentation associated with it (at least only for debugging purposes).
 */
public class Raster3DNormals implements AbstractRaster3DPrimitive {
    private VectorArray3f normals = null;

    /**
     * Constructor description.
     */
    public Raster3DNormals() {
        super();
        normals = new VectorArray3f(3);
    }

    /**
     * create the normals from a raster3D string. The format reads as follows: "u1 v1 w1
     * u2 v2 w2 u3 v3 w3"
     */
    public boolean create(String string) {
        StringTokenizer tokenizer = new StringTokenizer(string);
        float f;

        // a triangle has 3x3 ordinates and 1x3 color attributes (RGB)
        if (tokenizer.countTokens() == 9) {
            Vector3f[] normals = this.normals.getBuffer();
            for (int index = 0; index < 9; index++) {
                f = Float.parseFloat(tokenizer.nextToken());
                switch (index) {

                    case 0:
                        normals[0].x = f;
                        break;

                    case 1:
                        normals[0].y = f;
                        break;

                    case 2:
                        normals[0].z = f;
                        break;

                    case 3:
                        normals[1].x = f;
                        break;

                    case 4:
                        normals[1].y = f;
                        break;

                    case 5:
                        normals[1].z = f;
                        break;

                    case 6:
                        normals[2].x = f;
                        break;

                    case 7:
                        normals[2].y = f;
                        break;

                    case 8:
                        normals[2].z = f;
                        break;
                }
            }
            return true;
        } else {
            return false;
        }
    }

    /**
     * The supply method implements part of the AbstractPrimitive interface. In the
     * TriangleNormals case the last triangle in the triangles vector is modified. Note
     * that no geometry is supplied by instances of this class.
     */
    public void supply(Vector lines, Vector triangles, BranchGroup branch) {
        if (triangles.size() > 0) {
            Raster3DTriangle triangle =
                (Raster3DTriangle) triangles.lastElement();
            if (triangle != null) {
                triangle.getNormals().set(normals.getAt(0), normals.getAt(1),
                    normals.getAt(2));
            }
        }
    }
}
