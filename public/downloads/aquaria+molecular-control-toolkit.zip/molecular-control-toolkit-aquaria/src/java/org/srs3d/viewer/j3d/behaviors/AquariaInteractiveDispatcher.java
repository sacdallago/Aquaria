package org.srs3d.viewer.j3d.behaviors;

import java.awt.AWTException;
import java.awt.Container;
import java.awt.Point;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.util.Collection;
import java.util.HashSet;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.JApplet;
import javax.swing.JFrame;

import org.odonoghuelab.molecularcontroltoolkit.MolecularControlListener;
import org.srs3d.viewer.bioatlas.filters.LigandFilter;
import org.srs3d.viewer.bioatlas.modules.AbstractModule;
import org.srs3d.viewer.bioatlas.modules.AnimationModule;
import org.srs3d.viewer.bioatlas.modules.OperationModule;
import org.srs3d.viewer.bioatlas.modules.ProcessModule;
import org.srs3d.viewer.bioatlas.modules.ProximityModule;
import org.srs3d.viewer.bioatlas.modules.SelectModule;
import org.srs3d.viewer.bioatlas.objects.Chain;
import org.srs3d.viewer.bioatlas.objects.Layer;
import org.srs3d.viewer.bioatlas.objects.Subchain;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.Selection;
import org.srs3d.viewer.j3d.operations.InputOperation;
import org.srs3d.viewer.objects.ObjectManager;
import org.srs3d.viewer.objects.Operation;
import org.srs3d.viewer.objects.StrategyManager;
import org.srs3d.viewer.objects.filters.ObjectClassFilter;

public class AquariaInteractiveDispatcher implements MolecularControlListener {

	ContextData contextData;
	static LigandFilter m_ligandFilter = null;

	
	static InteractiveZoom zoomBehaviour;
	static InteractivePan panBehaviour;
	static InteractiveRotate rotateBehaviour;
 	Container container;
	Robot robot = null;
	boolean disablePointer = false;
	
 	public void initialise(ContextData data) {
 		contextData = data;
		container = data.getContext().getParent();
		contextData.setProperty("mousePressed", new Runnable() {
			
			@Override
			public void run() {
				disablePointer = true;
				
			}
		});
		contextData.setProperty("mouseReleased", new Runnable() {
			
			@Override
			public void run() {
				disablePointer = false;
				
			}
		});
		while (!(container instanceof JFrame) && !(container instanceof JApplet)) {
			container = container.getParent();
		}
		if (container == null) {
			System.err.println("Parent container is not found, aborting pointing.");

			return;
		}

		try {
			robot = new Robot();
		} catch (AWTException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
 	}


	public  InteractivePan getPan() {
		return panBehaviour;
	}
	
	public static void setPan(InteractivePan p_pan) {
		panBehaviour = p_pan;
	}
		
	public static void setZoom(InteractiveZoom zoom) {
		zoomBehaviour = zoom;
	}

	public static void setRotate(InteractiveRotate rotateBehavior) {
		rotateBehaviour = rotateBehavior;
	}

	public InteractiveZoom getZoom() {
		return zoomBehaviour;
	}
	
	@Override
	public void point(float x, float y) {
		if (!disablePointer) {
			
			Point topLeft = container.getLocationOnScreen();
			int width = container.getWidth();
			int height = container.getHeight();
	    	robot.mouseMove((int)(topLeft.x + width*x), (int)(topLeft.y + ((height) * -1 * (y - 1))));
		}
	}

	
	@Override
	public void selectMouseCursor() {
    	robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
    	robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);

	}

//	private static void blankShader(AbstractObject abObj) {
//		((ShaderAppearance)getCurrentInteractivity().contextData.getAppearanceManager().getAppearance(abObj)).setShaderProgram(null);
//		System.out.println("SETTING OBJ PROGRAM TO NULL: " + abObj);
//		List list = new ArrayList();
//		abObj.getAllObjects(list);
//		for (Object l : list) {
//			blankShader((AbstractObject)l);
//		}
//	}



	public void triggerRotate(int rotateX, int rotateY, int rotateZ)
	{
		if (rotateBehaviour != null)
		{
			// kinect only needs the scale for X & Y
			rotateBehaviour.processStimulus(rotateX, rotateY, rotateZ);
		}
	}
	
	public boolean isPannable() {
		return Toolkit.getDefaultToolkit().getLockingKeyState (KeyEvent.VK_CAPS_LOCK );
	}

	public void triggerPan(int panX, int panY) {
		if (panBehaviour != null && isPannable())
		{
			panBehaviour.processStimulus(panX, panY);
		}

	}

	@Override
	public void triggerZoom(int zoom)
	{
		if (zoomBehaviour != null && isPannable())
		{
			zoomBehaviour.processStimulus(zoom);
		}
	}

	
	@Override
	public void zoomToSelection() {
		System.out.println("zooming: ");
        Operation operation =
                new Operation(contextData.getContext(),
                    "ZOOM", null);
		dispatch(operation);
	}
	
	@Override
	public void triggerSpeech(int speechEvent)
	{
		System.out.println("Got speech: " + speechEvent);
	}


	@Override
	public void reset()
	{
		System.out.println("resetting: ");
        Operation operation =
                new Operation(contextData.getContext(),
                    "ZOOM_OUT", null);
		dispatch(operation);
	}

	public void dispatch(Operation op) {
		contextData.getDispatcher().runDispatch(op);
	}

	@Override
	public void search(char searchTerm)
	{
		System.out.println("Searching: " + searchTerm);
	}

	@Override
	public void color(String type)
	{
//		if (voiceEnabled)  {
//			System.out.println("color something: " + type);
//			Class colorSchemeClass = null;
//			String moduleName = null;
//			if ("SequenceSimilarity".equals(type))
//			{
//				AbstractColorScheme colorScheme =
//		                (AbstractColorScheme) contextData.getProperty(colorSchemeClass);
//	            colorScheme.setComplete(true);
//	            ColorSchemeBucket colorSchemeBucket = new ColorSchemeBucket(colorScheme);
//				colorSchemeClass = HomologyColorScheme.class;
//				moduleName = "Sequence Similarity";
//			}
//			else if ("SecondaryStructure".equals(type))
//			{
//		        CPKColorScheme cpkColorScheme = new CPKColorScheme(contextData);
//		        cpkColorScheme.setComplete(true);
//		        cpkColorScheme.setInformation(false);
//
//		        colorSchemeBucket = new ColorSchemeBucket(cpkColorScheme);
//		        colorSchemeBucket.extend(new SecondaryStructureColorScheme(contextData));
//
//		        colorSchemeClass = HomologyColorScheme.class;
//				moduleName = "Sequence Similarity";
//			}
//			else if ("Structure".equals(type))
//			{
//				colorSchemeClass = HomologyColorScheme.class;
//				moduleName = "Sequence Similarity";
//			}
//			else if ("Displacement".equals(type))
//			{
//				colorSchemeClass = HomologyColorScheme.class;
//				moduleName = "Sequence Similarity";
//			}
//			if (colorSchemeClass != null) 
//			{
//		            ColorSchemeModule module = new ColorSchemeModule(moduleName, contextData,
//		                    colorSchemeBucket);
//					module.updateIntern();
//					module.react(null);
//
//			}
//		}
	}
	
	@Override
	public void spin(boolean goCrazy)
	{
		System.out.println("Spin: ");
		
		String name = "Spin";
		if (goCrazy) {
			name = "GoCrazy";
		}
		AbstractModule module = new AnimationModule(name, contextData);
		module.updateIntern();
		module.react(null);

	}
	
	@Override
	public void copy() {
        Operation operation = new Operation(contextData.getContext(), "COPY", null);
        operation.setSerializable(false);
		AbstractModule module = new OperationModule("Copy", contextData, operation);
		module.updateIntern();
		module.react(null);
		
	}
	@Override
	public void paste() {
        Operation operation = new Operation(contextData.getContext(), "PASTE", null);
        operation.setSerializable(false);
		AbstractModule module = new OperationModule("Paste", contextData, operation);
		module.updateIntern();
		module.react(null);
	}
	
	@Override
	public void selectAll()
	{
		System.out.println("selecting all: ");
		
		ProcessModule module = new SelectModule("All", contextData,
                new ObjectClassFilter(Layer.class));
		
		module.run();
	}

	@Override
	public void select(String value)
	{
		System.out.println("selecting something: " + value);
		
		if ("Ligand".equals(value) || (m_ligandFilter == null && "NextLigand".equals(value))){
			m_ligandFilter = new LigandFilter(true, true);
			ProcessModule module = new SelectModule("Ligands", contextData,
					m_ligandFilter);
			module.updateIntern();
			module.run();
		}
		else if ("AllLigands".equals(value)){
			LigandFilter ligandFilter = new LigandFilter(true, false);
			ProcessModule module = new SelectModule("Ligands", contextData,
					ligandFilter);
			module.updateIntern();
			module.run();
		}
		else if ("NextLigand".equals(value)){
			m_ligandFilter.prepareForNext();
			ProcessModule module = new SelectModule("Ligands", contextData,
					m_ligandFilter);
			module.updateIntern();
			module.run();
		}
		else if  ("All".equals(value)){
			ProcessModule module = new SelectModule("All", contextData,
	                new ObjectClassFilter(Layer.class));
			
			module.updateIntern();
			module.run();
		}
		else if  ("Proximity".equals(value)){
			ProcessModule module = new ProximityModule("Proximity 4 �", contextData, 4);
			
			module.updateIntern();
			module.run();
		}
		else if  ("Residue".equals(value)){
			selectMouseCursor();
			delayedSelection();
		}
		else if  ("Chain".equals(value)){
			selectTypeAndZoom(Chain.class);
		}
		else if  ("SubChain".equals(value)){
			selectTypeAndZoom(Subchain.class);

		}
		else if  ("None".equals(value)){
			ProcessModule module = new SelectModule("None", contextData,
	                null);
			
			module.run();
		}
		else if  ("Up".equals(value)){
	        InputOperation operation = null;
	        operation =
	            new InputOperation(contextData.getContext(), "KEY_INPUT",
	                null);
	        
	        KeyEvent ke = new KeyEvent(contextData.getContext(), KeyEvent.KEY_PRESSED, 0, 0, KeyEvent.VK_UP, (char)KeyEvent.VK_UP);
	        operation.setInputEvent(ke);
	        contextData.getDispatcher().dispatch(operation);
		}		
	}


	private void selectTypeAndZoom(final Class type) {
//		selectMouseCursor();
//		Timer timer = new Timer();
//		// add a delay so the app can process the mouse clicks.
//		timer.schedule(new TimerTask() {
//			
//			@Override
//			public void run() {
        Selection selection = contextData.getSelectionManager().getSelection();
        if (!selection.isEmpty()) {
            ObjectManager objectManager = contextData.getObjectManager();
            final StrategyManager strategyManager =
                contextData.getStrategyManager();
            final Collection set = new HashSet(selection.size());
//			            objectManager.collapseUp(selection, set);
            Collection chains = new HashSet(selection);
            objectManager.getUpAssociations(selection, chains);
            ObjectManager.extract(chains, type);
//			            selection.clear();
//			            selection.addAll(chains);
            Operation operation =
                    new Operation(contextData.getContext(), "TRANSFER_SELECTION",
                        null);
            operation.setObjects(chains);
            operation.setSerializable(false);
            contextData.getDispatcher().runDispatch(operation);
        }
		
		
		
		delayedSelection();
	}


	private void delayedSelection() {
		Timer timer = new Timer();
		// add a delay so the app can process the mouse clicks.
		timer.schedule(new TimerTask() {
			
			@Override
			public void run() {
				zoomToSelection();
			}
		}, 100);
	}
}
