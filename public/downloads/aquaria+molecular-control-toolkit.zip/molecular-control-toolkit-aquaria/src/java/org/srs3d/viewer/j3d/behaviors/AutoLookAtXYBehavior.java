/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.behaviors;

import javax.media.j3d.Alpha;
import javax.media.j3d.WakeupCriterion;
import javax.media.j3d.WakeupOnElapsedFrames;

import org.srs3d.viewer.j3d.ContextData;

/**
 * The class <code>LookAtXYBehavior</code> represents a specialized
 * <code>MouseBehavior</code>. It acts on the current viewport of the context
 *
 * @author Karsten Klein
 *
 * @created November 20, 2000
 */
public class AutoLookAtXYBehavior extends AutonomicBehavior {

    /** Description of the field */
    private float speedX = 5.0f / 180;
    private float speedY = 5.0f / 180;
    private float speedZ = 5.0f / 180;

    /**
     * <code>RotateBehavior</code> contructor.
     *
     * @param context Description of parameter.
     * @param branchGroup Description of parameter.
     * @param transformGroup Description of parameter.
     */
    public AutoLookAtXYBehavior(ContextData contextData) {
        setContextData(contextData);
    }

    /**
     * Sets the speed of the behavior. The speed is measured in readians per pixel of
     * mouse the movement.
     *
     * @param speed The new <code>Speed</code> value.
     */
    public void setSpeed(float speedX, float speedY, float speedZ) {
        this.speedX = speedX;
        this.speedY = speedY;
        this.speedZ = speedZ;
    }

    /**
     * Initializes the wakeup conditions for the behavior.
     */
    public void initialize() {
        WakeupCriterion criterion;
        criterion = new WakeupOnElapsedFrames(1);
        wakeupOn(criterion);
    }

    /**
     * Processes the mouseEvent. This will directly result in a modification of the
     * viewingPlatform in the activated <code>Context</code> , if the according
     * conditions are met by the mouse event.
     *
     * @param mouseEvent Description of parameter.
     */
    public void processStimulus(java.util.Enumeration enumeration) {
        Alpha alpha = getAlpha();
        if (alpha != null) {
            if (!alpha.finished()) {
                LookAtXYBehavior.rotate(getContextData(),
                    speedX * LookAtXYBehavior.deltaX,
                    speedY * LookAtXYBehavior.deltaY);
                LookAtBehavior.rotate(getContextData(),
                    speedZ * LookAtBehavior.deltaZ);
            } else {
                setEnable(false);
            }
        }
        dumpImage(getContextData());

        // reset wakeup condition
        initialize();
    }
}
