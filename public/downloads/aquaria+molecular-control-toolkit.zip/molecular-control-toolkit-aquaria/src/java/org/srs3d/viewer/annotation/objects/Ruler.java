/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.annotation.objects;

import java.util.Collection;
import java.util.HashSet;

import javax.vecmath.Vector3f;

import org.srs3d.viewer.objects.AbstractObject;

/**
 * Class representing a ruler.
 *
 * @author Christian Zofka
 *
 * @created October 17, 2001
 * @rewritten Karsten Fries, LION bioscience AG
 * @rewritten January 07, 2001
 */
public class Ruler extends AbstractObject {

    /** The verticals are pointing downwards. */
    public static final int VERTICALS_DOWN = 1;

    /** The verticals are pointing upwards. */
    public static final int VERTICALS_UP = 2;

    /** The verticals are pointing in both directions. */
    public static final int VERTICALS_BOTH = 3;
    private Collection verticals = new HashSet();
    private Collection horizontals = new HashSet();
    private Vector3f orientation = new Vector3f(1, 0, 0);
    private float height = 1;
    private boolean isLabeled = true;
    private int verticalDirection;

    /**
     * Sets the direction of verticals.
     *
     * @param verticalDirection Vertical direction.
     */
    public final void setVerticalDirection(int verticalDirection) {
        this.verticalDirection = verticalDirection;
    }

    /**
     * Gets the direction of the verticals.
     *
     * @return The <code>verticalDirection</code> value.
     */
    public final int getVerticalDirection() {
        return verticalDirection;
    }

    /**
     * Gets the <code>verticals</code> attribute of the <code>Ruler</code> object.
     *
     * @return The <code>verticals</code> value.
     */
    public final Collection getVerticals() {
        return verticals;
    }

    /**
     * Get collection of horizontals of the ruler.
     *
     * @return Collection of horizontals.
     */
    public final Collection getHorizontals() {
        return horizontals;
    }

    /**
     * Produes a string for the ruler;
     *
     * @return String representation.
     */
    public String toString() {
        String string = new String("Ruler ");
        string += "(Horizontals: " + horizontals;
        string += "; Verticals: " + verticals + ")";
        return string;
    }

    /**
     * Clears all object references.
     */
    public void cleanup() {
        super.cleanup();
        cleanup(horizontals);
        horizontals = null;
        cleanup(verticals);
        horizontals = null;
        orientation = null;
    }

    /**
     * Adds a horizontal to the rulers horizontal list.
     *
     * @param horizontal The horizontal to be added.
     */
    public void addHorizontal(Horizontal horizontal) {
        horizontals.add(horizontal);
    }

    /**
     * Adds a vertical to the rulers vertical list.
     *
     * @param vertical The vertical to be added.
     */
    public void addVertical(Vertical vertical) {
        verticals.add(vertical);
    }

    /**
     * Method description.
     *
     * @param height Parameter description.
     */
    public void setHeight(float height) {
        this.height = height;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public float getHeight() {
        return height;
    }

    /**
     * Method description.
     *
     * @param isLabeled Parameter description.
     */
    public void setLabeled(boolean isLabeled) {
        this.isLabeled = isLabeled;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public boolean isLabeled() {
        return isLabeled;
    }

    /**
     * Horizontal class.
     *
     * @author Karsten Klein
     *
     * @created January 07, 2002
     */
    public static final class Horizontal {
        private float start = 0;
        private float stop = 0;

        /**
         * <code>Horizontal</code> constructor.
         *
         * @param start Start offset of the horizontal.
         * @param stop Stop offset of the horizontal.
         */
        public Horizontal(float start, float stop) {
            this.start = start;
            this.stop = stop;
        }

        /**
         * Returns the start offset of the hoizontal.
         *
         * @return Start offset.
         */
        public final float getStart() {
            return start;
        }

        /**
         * Returns the stop offset of the hoizontal.
         *
         * @return Stop offset.
         */
        public final float getStop() {
            return stop;
        }
    }

    /**
     * Vertical class.
     *
     * @author Karsten Klein
     *
     * @created January 07, 2002
     */
    public static class Vertical {
        private float position = 0;
        private float length = 0;

        /**
         * <code>Vertical</code> constructor.
         *
         * @param position Position of the vertical.
         * @param length Length of the vertical.
         */
        public Vertical(float position, float length) {
            this.position = position;
            this.length = length;
        }

        /**
         * Indicates whether the vertical is labeled.
         *
         * @return This implementation always returns false.
         */
        public boolean isLabeled() {
            return false;
        }

        /**
         * Returns the position of the vertical.
         *
         * @return Position of the vertical.
         */
        public final float getPosition() {
            return position;
        }

        /**
         * Returns the length of the vertical.
         *
         * @return Length of the vertical.
         */
        public final float getLength() {
            return length;
        }

        /**
         * Default implementation.
         *
         * @return This implementation return <code>null</code>
         */
        public String getLabel() {
            return null;
        }
    }

    /**
     * Specialization of the Vertical class including label code.
     *
     * @author Karsten Klein
     *
     * @created January 07, 2002
     */
    public static final class LabeledVertical extends Vertical {
        private String label;

        /**
         * <code>LabeledVertical</code> constructor.
         *
         * @param position Position of the vertical.
         * @param length Length of the vertical.
         * @param label Label for the vertical.
         */
        public LabeledVertical(float position, float length, String label) {
            super(position, length);
            this.label = label;
        }

        /**
         * Indicates whether the vertical is labeled.
         *
         * @return True if the label string is not <code>null</code>.
         */
        public final boolean isLabeled() {
            return label != null;
        }

        /**
         * Returns the label of the vertical.
         *
         * @return Label string.
         */
        public final String getLabel() {
            return label;
        }
    }
}
