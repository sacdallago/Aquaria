/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.modules;

import java.awt.event.ActionEvent;

import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.Selection;
import org.srs3d.viewer.visualization.MarchingCube;
import org.srs3d.viewer.visualization.ProbeDistanceProperty;

/**
 * <code>Module</code> implementation displaying a probe excluded surface.
 *
 * @author Karsten Klein
 *
 * @created May 14, 2001
 */
public class ProbeSurfaceModule extends AtomSurfaceModule {

    /**
     * <code>AtomSurfaceModule</code> constructor.
     *
     * @param name Description of parameter.
     * @param radius Description of parameter.
     */
    public ProbeSurfaceModule(String name, ContextData contextData, float radius) {
        super(name, contextData, radius);
    }

    /**
     * Description of the method.
     *
     * @param e Description of parameter.
     */
    public void process(ActionEvent e) {
        Selection selection =
            getContextData().getSelectionManager().getSelection();
        ProbeDistanceProperty probeProperty = new ProbeDistanceProperty();
        setProperties(probeProperty, probeProperty, null, getRadius());
        displaySurface(selection);
    }

    /**
     * Method description.
     *
     * @param mc Parameter description.
     */
    public void finalizeComputation(MarchingCube mc) {
        mc.computeDefaultNormals();
        super.finalizeComputation(mc);
    }
}
