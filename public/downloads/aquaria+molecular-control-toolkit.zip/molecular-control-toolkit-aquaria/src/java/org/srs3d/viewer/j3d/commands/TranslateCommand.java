/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.commands;

import javax.media.j3d.Transform3D;
import javax.vecmath.Tuple3f;
import javax.vecmath.Vector3f;

import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.Transform;

/**
 * Translate command.
 *
 * @author Karsten Klein
 *
 * @created April 03, 2001
 */
public class TranslateCommand extends ObjectCommand {

    /** Description of the field */
    Vector3f translation = new Vector3f(0, 0, 0);

    /**
     * Constructor description.
     *
     * @param contextData Parameter description.
     */
    public TranslateCommand(ContextData contextData) {
        super(contextData);
    }

    /**
     * Sets the <code>Translation</code> attribute of the <code>TranslateCommand
     * </code>object.
     *
     * @param translation The new <code>Translation</code> value.
     */
    public void setTranslation(Tuple3f translation) {
        this.translation.set(translation);
    }

    /**
     * Gets the <code>Translation</code> attribute of the <code>TranslateCommand
     * </code>object.
     *
     * @return The <code>Translation</code> value.
     */
    public Vector3f getTranslation() {
        return translation;
    }

    /**
     * Description of the method.
     */
    public void execute() {
        Transform transform =
            getContextData().getTransformManager().getTransform(getObject());
        if (transform != null && transform.isEnabled()) {
            Transform3D transform3D = transform.getTransform();
            transform3D.set(translation);
            transform.setTransform(transform3D);
        }
    }
}
