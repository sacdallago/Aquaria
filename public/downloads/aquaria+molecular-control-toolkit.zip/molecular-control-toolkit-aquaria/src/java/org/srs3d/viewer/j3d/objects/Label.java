/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.objects;

import javax.vecmath.Color3f;
import javax.vecmath.Point3f;
import javax.vecmath.Tuple3f;
import javax.vecmath.Vector3f;

import org.srs3d.viewer.j3d.Colorable;
import org.srs3d.viewer.objects.AbstractObject;

/**
 * Instances of this class show a lable when drawn.
 *
 * @author Karsten Klein
 *
 * @created April 20, 2001
 */
public class Label extends AbstractObject implements Colorable {
    private Point3f coordinate = new Point3f();
    private Vector3f alignment = new Vector3f(10, 0, 0);
    private Color3f color = new Color3f(1, 1, 1);
    private boolean isAligned = true;
    private String string = new String();

    /**
     * Sets the <code>alignment</code> attribute of the <code>Label</code> object.
     *
     * @param alignment The new <code>alignment</code> value.
     */
    public void setAlignment(Tuple3f alignment) {
        this.alignment.set(alignment);
    }

    /**
     * Sets the <code>String</code> attribute of the <code>Label</code> object.
     *
     * @param string The new <code>String</code> value.
     */
    public void setString(String string) {
        this.string = new String(string);
    }

    /**
     * Sets the <code>aligned</code> attribute of the <code>Label</code> object.
     *
     * @param isAligned The new <code>aligned</code> value.
     */
    public void setAligned(boolean isAligned) {
        this.isAligned = isAligned;
    }

    /**
     * Gets the <code>alignment</code> attribute of the <code>Label</code> object.
     *
     * @return The <code>alignment</code> value.
     */
    public Vector3f getAlignment() {
        return alignment;
    }

    /**
     * Gets the <code>Coordinate</code> attribute of the <code>Label</code> object.
     *
     * @return The <code>Coordinate</code> value.
     */
    public Point3f getCoordinate() {
        return coordinate;
    }

    /**
     * Gets the <code>String</code> attribute of the <code>Label</code> object.
     *
     * @return The <code>String</code> value.
     */
    public String getString() {
        return new String(string);
    }

    /**
     * Gets the <code>aligned</code> attribute of the <code>Label</code> object.
     *
     * @return The <code>aligned</code> value.
     */
    public boolean isAligned() {
        return isAligned;
    }

    /**
     * Description of the method.
     */
    public void cleanup() {
        super.cleanup();
        coordinate = null;
        alignment = null;
        color = null;
    }

    /**
     * Method description.
     *
     * @param color Parameter description.
     */
    public void setColor(Color3f color) {
        this.color = color;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public Color3f getColor() {
        return color;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public String toString() {
        return "Label";
    }
}
