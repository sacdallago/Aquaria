/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.integration.component;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;

import org.srs3d.viewer.integration.event.ComponentEvent;

/**
 * Class description.
 *
 * @author $author$
 */
public class AbstractEventController implements EventController {
    private ArrayList listeners = new ArrayList();
    private EventController parentEventController = null;

    /**
     * Creates a new AbstractEventController object.
     *
     * @param parentEventController Parameter description.
     */
    public AbstractEventController(EventController parentEventController) {
        this.parentEventController = parentEventController;
    }

    /**
     * Description of the method.
     *
     * @param listener Parameter description.
     */
    public void addComponentEventListener(ComponentEventListener listener) {
        if (!listeners.contains(listener)) {
            listeners.add(listener);
        }
    }

    /**
     * Description of the method.
     *
     * @param event Parameter description.
     */
    public void receive(ComponentEvent event) {
        parentEventController.receive(event);
    }

    /**
     * Description of the method.
     *
     * @param event Parameter description.
     */
    public void publish(ComponentEvent event) {
        Iterator iterator = listeners.iterator();
        ComponentEventListener listener;
        while (iterator.hasNext()) {
            listener = (ComponentEventListener) iterator.next();
            listener.receive(event);
        }
    }

    /**
     * Description of the method.
     *
     * @return Return parameter description.
     */
    public Collection getEventControllers() {
        return Collections.singleton(this);
    }
}
