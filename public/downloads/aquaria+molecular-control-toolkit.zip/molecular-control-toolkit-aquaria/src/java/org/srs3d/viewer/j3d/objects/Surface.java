/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.objects;

import java.util.Collection;

import javax.vecmath.Point3f;
import javax.vecmath.Vector3f;

import org.srs3d.viewer.objects.AbstractObject;

/**
 * Instances of this class show a surface when drawn.
 *
 * @author Karsten Klein
 *
 * @created April 20, 2001
 */
public class Surface extends AbstractObject {
    private Collection triangles = null;
    private Point3f center = new Point3f();
    private Vector3f extend = new Vector3f();

    /**
     * Method description.
     *
     * @param triangles Parameter description.
     */
    public void setTriangles(Collection triangles) {
        this.triangles = triangles;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public Collection getTriangles() {
        return triangles;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public String toString() {
        return "Surface";
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public Point3f getCenter() {
        return center;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public Vector3f getExtend() {
        return extend;
    }

    /**
     * Method description.
     */
    public void cleanup() {
        cleanup(triangles);
        triangles = null;
        center = null;
        extend = null;
    }
}
