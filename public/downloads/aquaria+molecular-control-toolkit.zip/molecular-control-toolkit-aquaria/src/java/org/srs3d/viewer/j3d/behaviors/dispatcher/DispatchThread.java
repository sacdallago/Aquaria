/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.behaviors.dispatcher;

import java.util.Vector;

import org.srs3d.viewer.objects.Operation;
import org.srs3d.viewer.util.ExceptionHandler;

/**
 * Dispatch thread.
 *
 * @author Karsten Klein
 *
 * @created April 03, 2001
 */
public class DispatchThread extends Thread {
    private static DispatchThread dispatchThread = new DispatchThread();
    private static boolean isVerbose = false;
    private Vector operationQueue = new Vector();
    private Vector dispatcherQueue = new Vector();

    /**
     * <code>DispatchThread</code> constructor.
     */
    private DispatchThread() {
        super(DispatchThread.class.toString());
        setDaemon(true);
        setPriority(Math.max(getPriority() - 2, Thread.MIN_PRIORITY));
        start();
    }

    /**
     * Main processing method for the <code>DispatchThread</code> object.
     */
    public void run() {
        Operation operation = null;
        Dispatcher dispatcher = null;
        org.srs3d.viewer.swing.SwingSettings.update();
        try {
            while (true) {
                while (!operationQueue.isEmpty()) {
                    try {
                        operation = (Operation) operationQueue.firstElement();
                        dispatcher =
                            (Dispatcher) dispatcherQueue.firstElement();
                        if (operation.getContext().getContextData().isValid()) {
                            dispatcher.runDispatch(operation);
                        }
                    } catch (Exception e) {
                        ExceptionHandler.handleException(e,
                            ExceptionHandler.VISIBLE_IN_RELEASE, this);
                    } catch (OutOfMemoryError e) {
                        ExceptionHandler.handleException(e,
                            ExceptionHandler.VISIBLE_IN_RELEASE, this);
                        if (dispatcher != null) {
                            org.srs3d.viewer.j3d.DispatchManager.getContext(dispatcher)
                                                                .getContextData()
                                                                .setProperty("EXCEPTION",
                                e);

                            //              GCThread.runFinalization();
                            //              GCThread.gc();
                        }
                    } catch (NoClassDefFoundError e) {
                        ExceptionHandler.handleException(e,
                            ExceptionHandler.VISIBLE_IN_RELEASE, this);
                    }

                    // remove the objects after the dispatch was completed (successfull or not)
                    // :NOTE: if a ThreadDeath exception happens the execution will be
                    //   started again! It seemed that sometimes operations were omitted.
                    operationQueue.remove(0);
                    dispatcherQueue.remove(0);

                    // make sure the objects are not keept on the threads stack
                    operation = null;
                    dispatcher = null;
                }
                try {
                    sleep(10000);
                } catch (InterruptedException e) {

                    // empty; the queue was updated from the outside
                    // :SILENT EXCEPTION:
                }
            }
        } catch (Throwable t) {
            ExceptionHandler.handleException(t,
                ExceptionHandler.VISIBLE_IN_RELEASE, this);
            try {
                run();
                throw (t);
            } catch (Throwable e) {

                // silent; should not happen; nothing to do more
                ExceptionHandler.handleException(e,
                    ExceptionHandler.SILENT_IN_DEBUG, this);
            }
        }
    }

    /**
     * Description of the method.
     */
    public void destroy() {

        // clear static reference when destroyed
        dispatchThread = null;
        super.destroy();
    }

    /**
     * Description of the method.
     *
     * @param dispatcher Description of parameter.
     * @param operation Description of parameter.
     */
    public static void schedule(Dispatcher dispatcher, Operation operation) {
        if (dispatchThread == null) {
            dispatchThread = new DispatchThread();
        }
        dispatchThread.operationQueue.add(operation);
        dispatchThread.dispatcherQueue.add(dispatcher);
        try {
            dispatchThread.interrupt();
        } catch (Exception e) {
            ExceptionHandler.handleException(e,
                ExceptionHandler.VISIBLE_IN_RELEASE, dispatchThread);

            // indirectly restart thread
            dispatchThread = null;
            schedule(dispatcher, operation);
        }
    }

    /**
     * Assures that the class is loaded and the Thread initialized
     */
    public static void initialize() {
    }

    /**
     * Method description.
     */
    public static void waitForEmptyQueue() {
        if (Thread.currentThread() != dispatchThread) {
            while (!dispatchThread.operationQueue.isEmpty()) {
                try {
                    Thread.sleep(50);
                } catch (InterruptedException e) {
                    ExceptionHandler.handleException(e,
                        ExceptionHandler.SILENT_IN_DEBUG, dispatchThread);
                }
            }
        }
    }
}
