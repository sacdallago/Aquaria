/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.objects;

import javax.vecmath.Color3f;
import javax.vecmath.Tuple3f;
import javax.vecmath.Vector3f;

import org.srs3d.viewer.annotation.objects.Referenceable;
import org.srs3d.viewer.j3d.Colorable;
import org.srs3d.viewer.objects.AbstractObject;

/**
 * @author Karsten Klein
 *
 * @created October 25, 2001
 */
public class Sensor extends AbstractObject implements Colorable, Referenceable {
    private Vector3f extend = new Vector3f(0, 0, 0);
    private AbstractObject reference = null;

    /**
     * Sets the <code>extend</code> attribute of the <code>Sensor</code> object.
     *
     * @param extend The new <code>extend</code> value.
     */
    public void setExtend(Tuple3f extend) {
        extend.set(extend);
    }

    /**
     * Gets the <code>extend</code> attribute of the <code>Sensor</code> object.
     *
     * @return The <code>extend</code> value.
     */
    public Vector3f getExtend() {
        return extend;
    }

    /**
     * Description of the method.
     */
    public void cleanup() {
        super.cleanup();
        extend = null;
        reference = null;
    }

    /**
     * Method description.
     *
     * @param color Parameter description.
     */
    public void setColor(Color3f color) {
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public Color3f getColor() {
        return new Color3f(0, 0, 0);
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public AbstractObject getReference() {
        return reference;
    }

    /**
     * Method description.
     *
     * @param reference Parameter description.
     */
    public void setReference(AbstractObject reference) {
        this.reference = reference;
    }
}
