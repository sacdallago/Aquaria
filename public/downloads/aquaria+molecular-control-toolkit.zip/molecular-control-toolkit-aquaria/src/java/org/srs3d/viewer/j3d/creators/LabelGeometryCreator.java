/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.creators;

import javax.media.j3d.Appearance;
import javax.media.j3d.BoundingSphere;
import javax.media.j3d.BranchGroup;
import javax.media.j3d.ImageComponent2D;
import javax.media.j3d.Raster;
import javax.media.j3d.RenderingAttributes;
import javax.media.j3d.Shape3D;
import javax.media.j3d.TransparencyAttributes;
import javax.vecmath.Point3d;
import javax.vecmath.Point3f;

import org.srs3d.viewer.j3d.AppearanceHelper;
import org.srs3d.viewer.j3d.LabelManager;
import org.srs3d.viewer.j3d.ShapeManager;
import org.srs3d.viewer.j3d.behaviors.AlignmentBehavior;
import org.srs3d.viewer.j3d.objects.Label;
import org.srs3d.viewer.objects.AbstractObject;

/**
 * Description of the class.
 *
 * @author Karsten Klein
 *
 * @created March 20, 2001
 */
public class LabelGeometryCreator extends AbstractGeometryCreator {

    /** Description of the Field */
    public static int GEOMETRY = 1;

    /** Description of the Field */
    public int labelMode = GEOMETRY;

    /**
     * Description of the method.
     *
     * @param object Description of parameter.
     * @param branchGroup Description of parameter.
     */
    public void create(AbstractObject object, BranchGroup branchGroup) {
        create((Label) object, branchGroup);
    }

    /**
     * Description of the method.
     *
     * @param label Description of parameter.
     * @param branchGroup Description of parameter.
     */
    public void create(Label label, BranchGroup branchGroup) {
        if ((labelMode & GEOMETRY) != 0) {
            createGeometry(label, branchGroup);
        }
    }

    /**
     * Description of the method.
     *
     * @param label Description of parameter.
     * @param branchGroup Description of parameter.
     */
    public void createGeometry(Label label, BranchGroup branchGroup) {
        ImageComponent2D image =
            getContextData().getLabelManager().getLabel(label.getString(),
                LabelManager.convertColor(label.getColor().get(), 1));
        Raster raster = new Raster();
        raster.setImage(image);
        raster.setCapability(Raster.ALLOW_POSITION_WRITE);
        raster.setCapability(Raster.ALLOW_POSITION_READ);
        Point3f position = new Point3f(label.getCoordinate());
        position.add(label.getAlignment());
        raster.setSize(image.getWidth(), image.getHeight());
        raster.setPosition(position);
        Shape3D text = new Shape3D(raster);
        getContextData().getShapeManager().register(label, text);
        ShapeManager.setCapabilities(text, label);
        text.clearCapability(Shape3D.ALLOW_APPEARANCE_WRITE);
        text.setPickable(false);
        Appearance appearance = new Appearance();
        AppearanceHelper.setDefaults(appearance);
        TransparencyAttributes transparencyAttributes =
            new TransparencyAttributes(TransparencyAttributes.BLENDED, 0.0f);
        appearance.setTransparencyAttributes(transparencyAttributes);
        RenderingAttributes renderingAttributes = new RenderingAttributes();
        renderingAttributes.setDepthBufferEnable(false);
        renderingAttributes.setDepthBufferWriteEnable(false);
        appearance.setRenderingAttributes(renderingAttributes);
        text.setAppearance(appearance);
        branchGroup.addChild(text);
    }

    /**
     * Adds a <code>AlignmentBehavior</code> object to the
     * <code>LabelGeometryCreator</code> object.
     *
     * @param label The <code>AlignmentBehavior</code> object to be added.
     * @param branchGroup The <code>AlignmentBehavior</code> object to be added.
     */
    public void addAlignmentBehavior(Label label, BranchGroup branchGroup) {
        AlignmentBehavior alignmentBehavior =
            new AlignmentBehavior(getContextData(), label);
        alignmentBehavior.setCenter(label.getCoordinate());
        alignmentBehavior.setAlignment(label.getAlignment());
        BoundingSphere boundingSphere =
            new BoundingSphere(new Point3d(), Double.MAX_VALUE);
        alignmentBehavior.setSchedulingBounds(boundingSphere);
        alignmentBehavior.setEnable(true);
        branchGroup.addChild(alignmentBehavior);
    }
}
