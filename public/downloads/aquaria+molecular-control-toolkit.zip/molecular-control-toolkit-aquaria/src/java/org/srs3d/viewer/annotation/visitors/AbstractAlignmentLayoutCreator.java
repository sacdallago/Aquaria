/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.annotation.visitors;

import java.util.Collection;
import java.util.Iterator;
import java.util.Vector;

import org.srs3d.viewer.annotation.attributes.AlignmentLayout;
import org.srs3d.viewer.annotation.objects.Alignment;
import org.srs3d.viewer.annotation.objects.ChainAnnotation;
import org.srs3d.viewer.annotation.objects.Ruler;
import org.srs3d.viewer.bioatlas.Parameter;
import org.srs3d.viewer.bioatlas.objects.Chain;
import org.srs3d.viewer.bioatlas.objects.Layer;
import org.srs3d.viewer.util.Log;

/**
 * Description of the class.
 *
 * @author Christian Zofka
 *
 * @created October 17, 2001
 */
public abstract class AbstractAlignmentLayoutCreator {
    private static final Log log =
        new Log(AbstractAlignmentLayoutCreator.class);

    /** Description of the field. */
    protected Alignment alignment;

    /** Description of the field. */
    protected Object[] rows;

    /** Description of the field. */
    protected float[] rowYPos;

    /** Description of the field. */
    protected int index;

    /** Description of the field. */
    private AlignmentLayout alignmentLayout = null;
    private float currentPosition;

    /**
     * <code>AlignmentLayout</code> constructor.
     *
     * @param alignment Description of parameter.
     * @param position Description of parameter.
     */
    public AbstractAlignmentLayoutCreator(Alignment alignment, float position) {
        this.alignment = alignment;
        this.currentPosition = position;
    }

    /**
     * Gets the <code>alignmentLayout</code> attribute of the
     * <code>AlignmentLayoutCreator</code> object.
     *
     * @return The <code>alignmentLayout</code> value.
     */
    public AlignmentLayout getAlignmentLayout() {
        return alignmentLayout;
    }

    /**
     * Description of the method.
     */
    public void create() {
        int value = alignment.getLayoutMode();
        index = 0;
        alignmentLayout = new AlignmentLayout();
        if (value == Alignment.DEFAULT) {
            createDefault();
        }
        if (value == Alignment.FLIPPED) {
            createChainsAtBottom();
        }
        alignmentLayout.setRows(rows);
        alignmentLayout.setPositions(rowYPos);
        alignmentLayout.setBottomYPosition(currentPosition);

        //    alignmentLayout.objectsToString();
    }

    /**
     * Gets the <code>currentPosition</code> attribute of the
     * <code>AbstractAlignmentLayoutCreator</code> object.
     *
     * @return The <code>currentPosition</code> value.
     */
    protected float getCurrentPosition() {
        return currentPosition;
    }

    /**
     * Gets the <code>chainAnnotationAt</code> attribute of the
     * <code>AlignmentLayoutCreator</code> object.
     *
     * @param index Description of parameter.
     *
     * @return The <code>chainAnnotationAt</code> value.
     */
    protected ChainAnnotation getChainAnnotationAt(int index) {
        Vector layers = alignment.getLayers();
        if (layers.size() > index) {
            Layer layer = (Layer) layers.elementAt(index);
            ChainAnnotation chainAnnotation;
            Collection chainAnnotations = alignment.getChainAnnotations();
            Chain chain;
            Iterator chainIterator;
            Iterator iterator = chainAnnotations.iterator();
            while (iterator.hasNext()) {
                chainAnnotation = (ChainAnnotation) iterator.next();
                chainIterator = chainAnnotation.getChains().iterator();
                while (chainIterator.hasNext()) {
                    chain = (Chain) chainIterator.next();
                    if (layer.getObjects().contains(chain)) {
                        return chainAnnotation;
                    }
                }
            }
        }
        return null;
    }

    /**
     * Description of the method.
     */
    protected abstract void createDefault();

    /**
     * creates bar-scheme: 1) all annotations 2) all chains
     */
    protected abstract void createChainsAtBottom();

    /**
     * u cannot find out the height only from the given object: in case of a null there
     * are many possiblities
     *
     * @param object Description of parameter.
     * @param height Description of parameter.
     */
    protected void insert(Object object, float height) {
        rows[index] = object;
        rowYPos[index] = currentPosition;
        currentPosition -= height;
        index++;
    }

    /**
     * Generates the ruler(s) of the chainannotation and saves it properly in the
     * alignment
     *
     * @param alignment Description of parameter.
     * @param chainAnnotation Description of parameter.
     */
    protected void initializeRuler(Alignment alignment,
        ChainAnnotation chainAnnotation) {

        // create Ruler
        RulerCreator rulerCreator =
            new RulerCreator(getRulerHeight(), isRulerLabeled(), isDetailRuler());
        rulerCreator.visit(chainAnnotation);

        // add Ruler
        Collection rulers = rulerCreator.getRulers();
        alignment.getRulers().addAll(rulers);

        // register rulers
        alignment.getRulersMap().put(chainAnnotation, rulers);
    }

    /**
     * Description of the method.
     *
     * @param verticalDirection Description of parameter.
     * @param chainAnnotation Description of parameter.
     */
    public void insertRulers(ChainAnnotation chainAnnotation,
        int verticalDirection) {
        initializeRuler(alignment, chainAnnotation);
        Collection rulers =
            (Collection) alignment.getRulersMap().get(chainAnnotation);
        if (rulers.size() > 1) {
            log.debug("multiple rulers detected.");
        } else if (rulers.size() == 0) {

            // :NOTE: this also happens when no aligment is available for a chain
            log.debug("no rulers created.");
        }
        Iterator iterator = rulers.iterator();
        Ruler ruler;
        while (iterator.hasNext()) {
            ruler = (Ruler) iterator.next();
            ruler.setVerticalDirection(verticalDirection);
            insert(ruler, getRulerHeight());
        }
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public float getRulerHeight() {
        return Parameter.annotationRulerHeight;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public boolean isRulerLabeled() {
        return false;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public boolean isDetailRuler() {
        return false;
    }
}
