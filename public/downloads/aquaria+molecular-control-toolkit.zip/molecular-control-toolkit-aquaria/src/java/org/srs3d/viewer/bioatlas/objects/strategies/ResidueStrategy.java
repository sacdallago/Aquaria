/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.objects.strategies;

import java.util.Collection;
import java.util.HashSet;

import javax.media.j3d.Appearance;
import javax.media.j3d.Texture;
import javax.vecmath.Color3f;
import javax.vecmath.Color4f;

import org.srs3d.viewer.bioatlas.attributes.AtomRepresentation;
import org.srs3d.viewer.bioatlas.attributes.Representation;
import org.srs3d.viewer.bioatlas.attributes.ResidueRepresentation;
import org.srs3d.viewer.bioatlas.objects.Residue;
import org.srs3d.viewer.bioatlas.objects.Site;
import org.srs3d.viewer.bioatlas.objects.Subchain;
import org.srs3d.viewer.j3d.AppearanceHelper;
import org.srs3d.viewer.j3d.AppearanceManager;
import org.srs3d.viewer.j3d.AppearanceManager.TextureColors;
import org.srs3d.viewer.j3d.ColorSchemeBucket;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.IntersectionManager;
import org.srs3d.viewer.j3d.Reaction;
import org.srs3d.viewer.j3d.Selection;
import org.srs3d.viewer.j3d.attributes.Expanded;
import org.srs3d.viewer.j3d.commands.ColorCommand;
import org.srs3d.viewer.j3d.commands.ExpandCommand;
import org.srs3d.viewer.j3d.commands.IdentificationCommand;
import org.srs3d.viewer.j3d.commands.IntersectCommand;
import org.srs3d.viewer.j3d.commands.PreSelectCommand;
import org.srs3d.viewer.j3d.commands.RegisterCommand;
import org.srs3d.viewer.j3d.commands.RemoveStateCommand;
import org.srs3d.viewer.j3d.commands.RepresentationCommand;
import org.srs3d.viewer.j3d.commands.SpawnCommand;
import org.srs3d.viewer.j3d.commands.VisibleCommand;
import org.srs3d.viewer.j3d.objects.strategies.AbstractStrategy;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.objects.Attribute;
import org.srs3d.viewer.objects.Command;
import org.srs3d.viewer.objects.ObjectManager;
import org.srs3d.viewer.objects.State;
import org.srs3d.viewer.objects.StrategyManager;

/**
 * @author Karsten Klein
 *
 * @created April 03, 2001
 */
public class ResidueStrategy extends AbstractStrategy {

    /**
     * Constructor description.
     */
    public ResidueStrategy() {
        register(ExpandCommand.class, new ExpandReaction());
        register(PreSelectCommand.class, new PreSelectReaction());
        register(RegisterCommand.class, new RegisterReaction());

        // :TEST: texture coloring
        register(ColorCommand.class, new ColorReaction());
        register(IntersectCommand.class, new IntersectReaction());
        register(IdentificationCommand.class, new IdentificationReaction());
        register(RepresentationCommand.class, new RepresentationReaction());
        register(VisibleCommand.class, new VisibleReaction());
        register(RemoveStateCommand.class, new RemoveStateReaction());
    }

    /**
     * Class description.
     *
     * @author Karsten Klein, LION bioscience AG
     */
    public class RemoveStateReaction implements Reaction {

        /**
         * Method description.
         *
         * @param command Parameter description.
         */
        public void execute(Command command) {
            command.execute();
            RemoveStateCommand removeCommand = (RemoveStateCommand) command;
            ContextData contextData = removeCommand.getContextData();
            contextData.getStrategyManager().propagate(command.getObject(),
                new RegisterCommand(contextData, false), null);
        }
    }

    /**
     * Class description.
     *
     * @author Karsten Klein, LION bioscience AG
     */
    public class VisibleReaction implements Reaction {

        /**
         * Method description.
         *
         * @param command Parameter description.
         */
        public void execute(Command command) {
            Residue residue = (Residue) command.getObject();
            command.execute();
            if (residue.getTemplate().isWater()) {
                VisibleCommand visibleCommand = (VisibleCommand) command;
                if (visibleCommand.isShow()) {
                    if (residue.getAtoms().size() > 1) {
                        if (residue.getBonds().isEmpty()) {
                            residue.addBonds(residue.computeBonds());
                        }
                    }
                    ColorSchemeBucket bucket =
                        visibleCommand.getContextData().getColorSchemeManager()
                                      .getColorSchemeBucket(residue);
                    if (bucket == null || bucket.isEmpty()) {
                        bucket =
                            visibleCommand.getContextData()
                                          .getColorSchemeBucket();
                        visibleCommand.getContextData().getStrategyManager()
                                      .propagate(residue,
                            new ColorCommand(visibleCommand.getContextData(),
                                bucket));
                    }
                }
            }
        }
    }

    /**
     * Class description.
     *
     * @author Karsten Klein, LION bioscience AG
     */
    public class RegisterReaction implements Reaction {

        /**
         * Method description.
         *
         * @param command Parameter description.
         */
        public void execute(Command command) {
            RegisterCommand registerCommand = (RegisterCommand) command;
            if (registerCommand.getParent() != null) {
                if (registerCommand.getParent().getClass() == Site.class) {
                    registerCommand.setApplicationMode(0);
                }
            }
            registerCommand.execute();
        }
    }

    /**
     * Class description.
     *
     * @author Karsten Klein, LION bioscience AG
     */
    public class ExpandReaction implements Reaction {

        /**
         * Method description.
         *
         * @param command Parameter description.
         */
        public void execute(Command command) {
            ExpandCommand expandCommand = (ExpandCommand) command;
            Residue residue = (Residue) expandCommand.getObject();
            ContextData contextData = expandCommand.getContextData();
            State.Immutable state =
                contextData.getStateManager().getImmutableState(residue);
            if (expandCommand.isExpand()) {
                if (!state.hasAttribute(Expanded.class)) {
                    Collection bonds = residue.getBonds();

                    // :NOTE: exclusion of ligands not possible (1ag5, 1mpa)
                    if (bonds.isEmpty()) {
                        bonds.addAll(residue.computeBonds());
                    }
                    expandCommand.execute();

                    // we have to propagate the representation of the residue
                    ResidueRepresentation.Immutable representation =
                        (ResidueRepresentation.Immutable) state.getAttribute(ResidueRepresentation.class);
                    if (representation != null) {
                        if ((representation.getMode() &
                              Representation.REPRESENTATION_ATOM_MODE) != 0) {
                            AtomRepresentation atomRepresentation =
                                (AtomRepresentation) Attribute.getInstance(AtomRepresentation.class);
                            atomRepresentation.setMode(representation.getMode());
                            RepresentationCommand representationCommand =
                                new RepresentationCommand(contextData);
                            representationCommand.setRepresentation(atomRepresentation);
                            contextData.getStrategyManager().propagate(expandCommand.getObject(),
                                representationCommand);
                        }
                    }
                }
            } else {

                // :NOTE: exclusion of ligands not possible (1ag5, 1mpa)
                if (state.hasAttribute(Expanded.class)) {
                    expandCommand.execute();
                }
            }
        }
    }

    /**
     * Class description.
     *
     * @author Karsten Klein, LION bioscience AG
     */
    public class PreSelectReaction implements Reaction {

        /**
         * Method description.
         *
         * @param command Parameter description.
         */
        public void execute(Command command) {
            PreSelectCommand preSelect = (PreSelectCommand) command;
            ContextData contextData = preSelect.getContextData();
            State.Immutable state =
                contextData.getStateManager().getImmutableState(preSelect.getObject());
            if (!state.hasAttribute(Expanded.class)) {
                ResidueRepresentation.Immutable representation =
                    (ResidueRepresentation.Immutable) state.getAttribute(ResidueRepresentation.class);
                if (representation != null) {
                    if ((representation.getMode() &
                          Representation.REPRESENTATION_ATOM_MODE) != 0) {

                        // expand
                        ExpandCommand expandCommand =
                            new ExpandCommand(contextData);
                        expandCommand.setObject(preSelect.getObject());
                        ResidueStrategy.this.execute(expandCommand);

                        // respawn new geometry
                        Collection spawners = new HashSet();
                        spawners.add(preSelect.getObject());
                        SpawnCommand.searchSpawners(contextData, spawners);
                        SpawnCommand spawn = new SpawnCommand(contextData);
                        contextData.getStrategyManager().execute(spawners, spawn);
                        preSelect.setExpansion(true);
                    }
                }
            }
            preSelect.execute();
        }
    }

    /**
     * Class description.
     *
     * @author Karsten Klein, LION bioscience AG
     */
    public class ColorReaction implements Reaction {

        /**
         * Method description.
         *
         * @param command Parameter description.
         */
        public void execute(Command command) {
            ColorCommand colorCommand = (ColorCommand) command;
            Residue object = (Residue) colorCommand.getObject();

            // :NOTE: exclusion of ligands not possible (1ag5, 1mpa)
            if (!colorCommand.getExplicitColoredObjects().contains(object)) {

                // apply coloring (bucket extension + appearance)
                command.execute();
                AppearanceManager appearanceManager =
                    colorCommand.getContextData().getAppearanceManager();
                TextureColors textureColors =
                    appearanceManager.getTextureColors(object);
                if (textureColors != null) {
                    Appearance appearance =
                        appearanceManager.getAppearance(object);
                    Color4f color = new Color4f();
                    AppearanceHelper.getColor(appearance, color);
                    textureColors.setColor(0, color);
                    updateTexture(colorCommand, textureColors);
                }
                colorCommand.getExplicitColoredObjects().add(object);
            }
        }

        /**
         * Method description.
         *
         * @param colorCommand Parameter description.
         * @param textureColors Parameter description.
         */
        public void updateTexture(ColorCommand colorCommand,
            TextureColors textureColors) {
            ContextData contextData = colorCommand.getContextData();
            if (textureColors.getReferenceObject() != null) {
                if (textureColors.isActive()) {
                    Subchain subchain =
                        (Subchain) textureColors.getReferenceObject();
                    Texture texture = textureColors.createTexture(contextData);
                    Appearance appearance =
                        contextData.getAppearanceManager().getAppearance(subchain);
                    Appearance textureAppearance =
                        AppearanceHelper.createAppearance(new Color3f(1, 1, 1));

                    //          contextData.getAppearanceManager().register( subchain, textureAppearance );
                    textureAppearance.setTexture(texture);
                    AppearanceHelper.setTextureDefaults(textureAppearance,
                        texture);
                    if (textureColors.isTransparent()) {
                        AppearanceHelper.enableTransparency(textureAppearance,
                            0.0f, true);
                    }
                    AppearanceHelper.enableVertexColors(textureAppearance,
                        AppearanceHelper.areVertexColorsEnabled(appearance));
                    AppearanceHelper.enableMesh(textureAppearance,
                        AppearanceHelper.isMesh(appearance));
                    ColorCommand.apply(contextData, subchain, textureAppearance);
                }
            }
        }
    }

    /**
     * Class description.
     *
     * @author Karsten Klein, LION bioscience AG
     */
    public static class IntersectReaction implements Reaction {

        /**
         * Method description.
         *
         * @param command Parameter description.
         */
        public void execute(Command command) {
            IntersectCommand intersectCommand = (IntersectCommand) command;
            if (intersectCommand.getMode() == IntersectCommand.MODE_NORMAL) {
                AbstractObject object = intersectCommand.getObject();
                if (object != null) {
                    ContextData contextData = intersectCommand.getContextData();
                    ObjectManager objectManager =
                        contextData.getObjectManager();
                    Selection selection =
                        contextData.getSelectionManager().getSelection();
                    HashSet set = new HashSet();
                    if (expandSelectionDetail(contextData, set, object)) {

                        // issue new intersect command
                        IntersectionManager intersectionManager =
                            contextData.getIntersectionManager();
                        AbstractObject pickedObject =
                            intersectionManager.pickClosestObject(set,
                                intersectCommand.getPickResult());
                        if (pickedObject != object && pickedObject != null) {
                            intersectCommand.setObject(pickedObject);
                            object = pickedObject;
                            contextData.getStrategyManager().execute(object,
                                intersectCommand);
                        }
                    }
                }
            }
        }

        /**
         * Method description.
         *
         * @param contextData Parameter description.
         * @param expanded Parameter description.
         * @param object Parameter description.
         *
         * @return Return description.
         */
        public boolean expandSelectionDetail(final ContextData contextData,
            Collection expanded, final AbstractObject object) {
            if (object != null) {

                // start change
                PreSelectCommand preSelectCommand =
                    new PreSelectCommand(contextData);
                ObjectManager objectManager = contextData.getObjectManager();
                contextData.getStrategyManager().execute(object,
                    preSelectCommand);
                if (preSelectCommand.isExpansion()) {
                    objectManager.getDownAssociations(object, expanded);
                    return true;
                }
            }
            return false;
        }
    }

    /**
     * Reaction for retrieving the object identification.
     *
     * @author Karsten Klein
     *
     * @created March 26, 2002
     */
    public static class IdentificationReaction implements Reaction {

        /**
         * Execute implementation of the reaction interface.
         *
         * @param command Command to react to.
         */
        public void execute(Command command) {
            IdentificationCommand idCommand = (IdentificationCommand) command;
            idCommand.setObjectId("R:" + command.getObject());
            idCommand.execute();
        }
    }

    /**
     * Class description.
     *
     * @author Karsten Klein, LION bioscience AG
     */
    public class RepresentationReaction implements Reaction {

        /**
         * Method description.
         *
         * @param command Parameter description.
         */
        public void execute(Command command) {
            RepresentationCommand representationCommand =
                (RepresentationCommand) command;

            // perform the representation change
            command.execute();
            if ((representationCommand.getMode() &
                  RepresentationCommand.REMOVE) != 0) {
                ContextData contextData =
                    representationCommand.getContextData();
                State.Immutable state =
                    contextData.getStateManager().getImmutableState(command.getObject());
                ResidueRepresentation.Immutable rep =
                    (ResidueRepresentation.Immutable) state.getAttribute(ResidueRepresentation.class);
                if (rep == null ||
                      (rep.getMode() & Representation.REPRESENTATION_ATOM_MODE) == 0) {
                    if (state.hasAttribute(Expanded.class)) {

                        // collapsing and deregistering the residue
                        StrategyManager strategyManager =
                            contextData.getStrategyManager();
                        strategyManager.propagate(command.getObject(),
                            new RegisterCommand(contextData, false), null);
                        strategyManager.execute(command.getObject(),
                            new ExpandCommand(contextData, false));
                    } else {
                        StrategyManager strategyManager =
                            contextData.getStrategyManager();
                        strategyManager.propagate(command.getObject(),
                            new RegisterCommand(contextData, false), null);
                    }
                }
            }
        }
    }
}
