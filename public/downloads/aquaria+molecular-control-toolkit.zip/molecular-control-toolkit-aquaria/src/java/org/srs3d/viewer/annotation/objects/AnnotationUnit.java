/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.annotation.objects;

import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;

import javax.vecmath.Color3f;

import org.srs3d.viewer.bioatlas.objects.Annotation;
import org.srs3d.viewer.bioatlas.objects.Feature;
import org.srs3d.viewer.j3d.Colorable;
import org.srs3d.viewer.j3d.objects.Sensor;
import org.srs3d.viewer.objects.AbstractObject;

/**
 * Little wrapper around an annotation. An annotation can have more than one
 * AnnotationUnit. We introduced this objects to be able to draw more than one instance
 * of an Annotation.
 *
 * @author Karsten Klein
 *
 * @created October 12, 2001
 */
public final class AnnotationUnit extends AbstractObject
    implements Referenceable, Colorable {
    private Annotation annotation = null;
    private Collection featureUnits = new HashSet();
    private Sensor sensor = null;

    /**
     * <code>AnnotationUnit</code> constructor.
     *
     * @param annotation Description of parameter.
     */
    public AnnotationUnit(Annotation annotation) {
        create(annotation);
        sensor = new Sensor();
        sensor.setReference(this);
    }

    /**
     * Gets the <code>reference</code> attribute of the <code>AnnotationUnit</code>
     * object.
     *
     * @return The <code>reference</code> value.
     */
    public AbstractObject getReference() {
        return annotation;
    }

    /**
     * Gets the <code>annotation</code> attribute of the <code>AnnotationUnit</code>
     * object.
     *
     * @return The <code>annotation</code> value.
     */
    public Annotation getAnnotation() {
        return annotation;
    }

    /**
     * Gets the <code>featureUnits</code> attribute of the <code>AnnotationUnit</code>
     * object.
     *
     * @return The <code>featureUnits</code> value.
     */
    public Collection getFeatureUnits() {
        return featureUnits;
    }

    /**
     * Gets the <code>allObjects</code> attribute of the <code>AnnotationUnit</code>
     * object.
     *
     * @param collection Description of parameter.
     */
    public void getAllObjects(Collection collection) {
        collection.addAll(getFeatureUnits());
        collection.add(sensor);
    }

    /**
     * Gets the <code>sensor</code> attribute of the <code>AnnotationUnit</code> object.
     *
     * @return The <code>sensor</code> value.
     */
    public Sensor getSensor() {
        return sensor;
    }

    /**
     * Description of the method.
     *
     * @return Description of the returned value.
     */
    public String toString() {
        return "AnnotationUnit(" + annotation + ")";
    }

    /**
     * Description of the method.
     */
    public void cleanup() {
        annotation = null;
        sensor.setReference(null);
        sensor = null;
        cleanup(featureUnits);
        featureUnits = null;
    }

    /**
     * Copies the full Annotation structure in this AnnotationUnit
     *
     * @param annotation Description of parameter.
     */
    private final void create(Annotation annotation) {
        this.annotation = annotation;
        Iterator iterator = annotation.getFeatures().iterator();
        Feature feature;
        while (iterator.hasNext()) {
            feature = (Feature) iterator.next();
            featureUnits.add(new FeatureUnit(feature));
        }
    }

    /**
     * Method description.
     *
     * @param color Parameter description.
     */
    public void setColor(Color3f color) {
        annotation.setColor(color);
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public Color3f getColor() {
        return annotation.getColor();
    }
}
