/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.objects;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.util.Collection;
import java.util.Iterator;
import java.util.StringTokenizer;
import java.util.Vector;

import javax.media.j3d.ImageComponent2D;
import javax.vecmath.Point3f;
import javax.vecmath.Tuple3f;
import javax.vecmath.Vector3f;

import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.ImageHelper;
import org.srs3d.viewer.objects.AbstractObject;

/**
 * Instances of this class describe a rectangle that can be displayed in 3d. It is always
 * parallel to the xy plane.
 *
 * @author Karsten Klein
 *
 * @created March 20, 2001
 */
public class Overlay extends AbstractObject {
    public static final int ALIGN_BOTTOM = 1;
    public static final int ALIGN_RIGHT = 2;

    // combined
    public static final int ALIGN_TOP_LEFT = 0;
    public static final int ALIGN_TOP_RIGHT = 2;
    public static final int ALIGN_BOTTOM_RIGHT = 3;
    public static final int ALIGN_BOTTOM_LEFT = 1;
    private Point3f coordinate = new Point3f();
    private Vector3f extend = new Vector3f();
    private ImageComponent2D image = null;
    private BufferedImage bufferedImage = null;
    private Collection textLines = new Vector();
    private Collection textLinesColors = new Vector();
    private int height = 0;
    private int width = 0;
    private int maxWidth = 280;
    private int wrapWidth = 250;
    private String name;
    private Graphics graphics = null;
    private int lineHeight = 8;
    private int alignment = ALIGN_TOP_LEFT;
    private Font font = new Font("Arial", Font.PLAIN, 11);
    private Color colorOffset = new Color(50, 50, 50);

    /**
     * Constructor description.
     *
     * @param name Parameter description.
     */
    public Overlay(String name) {
        this.name = name;
        clearText();
        addTextLine("");
        addTextLine("Mouse Controls", Color.black);
        addTextLine("- Right click to open CONTEXT MENU.");
        addTextLine("- Left click to SELECT (extended");
        addTextLine("  selection with <shift> or <ctrl>).");
        addTextLine("- Left double-click to AUTO-ZOOM.");
        addTextLine("- Left drag to ROTATE.");
        addTextLine("- Left drag + <shift> to ZOOM.");
        addTextLine("");
        addTextLine("Typing characters will find matches");
        addTextLine("in the sequence; <esc> to reset.");
    }

    /**
     * Method description.
     *
     * @param text Parameter description.
     */
    public void addTextLine(String text) {
        textLines.add(text);
        textLinesColors.add(Color.lightGray);
    }

    /**
     * Method description.
     *
     * @param text Parameter description.
     * @param color Parameter description.
     * @param autoWrap Parameter description.
     */
    public void addTextLine(String text, Color color, boolean autoWrap) {
        color = org.srs3d.viewer.j3d.LabelManager.convertColor(color, 1);
        if (autoWrap) {
            Vector wrappedLines = wrap(text);
            Iterator iterator = wrappedLines.iterator();
            while (iterator.hasNext()) {
                addTextLine((String) iterator.next(), color);
            }
        } else {
            addTextLine(text);
        }
    }

    /**
     * Method description.
     *
     * @param text Parameter description.
     * @param color Parameter description.
     */
    public void addTextLine(String text, Color color) {
        color =
            org.srs3d.viewer.j3d.LabelManager.convertColor(color, colorOffset);
        textLines.add(text);
        textLinesColors.add(color);
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public int getLineHeight() {
        return lineHeight;
    }

    /**
     * Method description.
     *
     * @param alignment Parameter description.
     */
    public void setAlignment(int alignment) {
        this.alignment = alignment;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public int getAlignment() {
        return alignment;
    }

    /**
     * Method description.
     */
    public void clearText() {
        textLines.clear();
        textLinesColors.clear();
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the <code>Coordinate</code> attribute of the <code>Rectangle</code> object.
     *
     * @param coordinate The new <code>Coordinate</code> value.
     */
    public void setCoordinate(Tuple3f coordinate) {
        this.coordinate.set(coordinate);
    }

    /**
     * Sets the <code>extend</code> attribute of the <code>Overlay</code> object.
     *
     * @param extend The new <code>extend</code> value.
     */
    public void setExtend(Tuple3f extend) {
        this.extend.set(extend);
    }

    /**
     * Sets the <code>width</code> attribute of the <code>Overlay</code> object.
     *
     * @param width The new <code>width</code> value.
     */
    public final void setWidth(int width) {
        this.width = width;
    }

    /**
     * Sets the <code>height</code> attribute of the <code>Overlay</code> object.
     *
     * @param height The new <code>height</code> value.
     */
    public final void setHeight(int height) {
        this.height = height;
    }

    /**
     * Gets the <code>Coordinate</code> attribute of the <code>Rectangle</code> object.
     *
     * @return The <code>Coordinate</code> value.
     */
    public Point3f getCoordinate() {
        return coordinate;
    }

    /**
     * Gets the <code>extend</code> attribute of the <code>Overlay</code> object.
     *
     * @return The <code>extend</code> value.
     */
    public Vector3f getExtend() {
        return extend;
    }

    /**
     * Gets the <code>image</code> attribute of the <code>Overlay</code> object.
     *
     * @return The <code>image</code> value.
     */
    public ImageComponent2D getImage() {
        return image;
    }

    /**
     * Gets the <code>width</code> attribute of the <code>Overlay</code> object.
     *
     * @return The <code>width</code> value.
     */
    public final int getWidth() {
        return width;
    }

    /**
     * Gets the <code>height</code> attribute of the <code>Overlay</code> object.
     *
     * @return The <code>height</code> value.
     */
    public final int getHeight() {
        return height;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public int getCursorY() {
        return getLineHeight() * textLines.size();
    }

    /**
     * Method description.
     *
     * @param text Parameter description.
     *
     * @return Return description.
     */
    public Vector computeUnwrapable(String text) {
        Vector unwrapable = new Vector();
        StringTokenizer tokenizer =
            new StringTokenizer(text, " .,:;?!]})*/-+=$");
        String token;
        int tokenLength;
        int index;
        while (tokenizer.hasMoreElements()) {
            token = tokenizer.nextToken();
            tokenLength = token.length();
            index = text.indexOf(token);
            index += tokenLength;

            // token with delimiter
            if (text.length() > index + 1) {
                index++;
            }
            token = text.substring(0, index);
            text = text.substring(index);
            unwrapable.add(token);
        }
        unwrapable.add(text);
        return unwrapable;
    }

    /**
     * Method description.
     *
     * @param text Parameter description.
     *
     * @return Return description.
     */
    public Vector wrap(String text) {
        Vector wrappedLines = new Vector();

        // make width and height the power of 2
        int widthPower2 = ImageHelper.computeNextPowerOf2(getWidth());
        int heightPower2 = ImageHelper.computeNextPowerOf2(getHeight());
        BufferedImage bufferedImage =
            new BufferedImage(widthPower2, heightPower2,
                BufferedImage.TYPE_INT_ARGB);
        graphics = bufferedImage.createGraphics();
        graphics.setFont(font);
        FontMetrics fontMetrics = graphics.getFontMetrics();
        Vector unwrapableStrings = computeUnwrapable(text);
        String string = "";
        String token;
        String appendedString;
        Iterator iterator = unwrapableStrings.iterator();
        boolean isFirstLine = true;
        String prefix = "";
        while (iterator.hasNext()) {
            token = (String) iterator.next();
            appendedString = string + token;
            if (isFirstLine) {

                // extract leading whitespaces of token
                int count = 0;
                while (token.charAt(count) == ' ') {
                    prefix += " ";
                    count++;
                }
                prefix += " ";
                isFirstLine = false;
            }
            if (fontMetrics.stringWidth(appendedString) > wrapWidth) {
                if (string.length() > 0) {
                    wrappedLines.add(string);
                }
                string = prefix + token;
            } else {
                string = appendedString;
            }
        }
        if (string.length() > 0) {
            wrappedLines.add(string);
        }
        return wrappedLines;
    }

    /**
     * Description of the method.
     */
    public void update(ContextData contextData) {

        // make width and height the power of 2
        int widthPower2 = ImageHelper.computeNextPowerOf2(getWidth());
        int heightPower2 = ImageHelper.computeNextPowerOf2(getHeight());
        bufferedImage =
            new BufferedImage(widthPower2, heightPower2,
                BufferedImage.TYPE_INT_ARGB);
        graphics = bufferedImage.createGraphics();
        graphics.setFont(font);

        // First, erase the background to the text panel - set alpha to 0
        Color fillColor = new Color(0.8f, 0.8f, 0.8f, 0.2f);
        graphics.setColor(fillColor);
        graphics.fillRect(0, 0, getWidth(), getHeight());
        fillColor = new Color(0.2f, 0.2f, 0.2f, 0.2f);
        graphics.setColor(fillColor);
        graphics.fillRect(2, 2, getWidth() - 4, getHeight() - 4);
        graphics.setFont(font);
        Iterator iterator = textLines.iterator();
        Iterator colorIterator = textLinesColors.iterator();
        int index = 0;
        Color color;
        String string;
        FontMetrics fontMetrics = graphics.getFontMetrics();
        while (iterator.hasNext()) {
            color = (Color) colorIterator.next();
            string = (String) iterator.next();
            if (fontMetrics.stringWidth(string) > maxWidth) {
                while (fontMetrics.stringWidth(string + "...") > maxWidth) {
                    string = string.substring(0, string.length() - 3);
                }
                string += "...";
            }
            contextData.getLabelManager().drawString(string, 8, index,
                graphics, color, null);
            index += 2 * getLineHeight();
        }
    }

    /**
     * Method description.
     */
    public void finalizeUpdate() {
        this.image =
            new ImageComponent2D(ImageComponent2D.FORMAT_RGBA, bufferedImage);
        this.image.setCapability(ImageComponent2D.ALLOW_SIZE_READ);
        this.image.setCapability(ImageComponent2D.ALLOW_IMAGE_READ);
    }

    /**
     * Description of the method.
     */
    public void cleanup() {
        super.cleanup();
        image = null;
        bufferedImage = null;
        coordinate = null;
        extend = null;
        graphics = null;
        font = null;
        cleanup(textLines);
        textLines = null;
        cleanup(textLinesColors);
        textLinesColors = null;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public Graphics getGraphics() {
        return graphics;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public int getMaxPixels() {
        Iterator iterator = textLines.iterator();
        String string;
        int width = 0;
        int max = 0;
        BufferedImage bufferedImage =
            new BufferedImage(1, 1, BufferedImage.TYPE_INT_ARGB);
        Graphics graphics = bufferedImage.getGraphics();
        graphics.setFont(font);
        while (iterator.hasNext()) {
            string = (String) iterator.next();
            width = graphics.getFontMetrics().stringWidth(string);
            if (width > max) {
                max = width;
            }
        }
        return Math.min(max, maxWidth) + 16;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public String toString() {
        return getName();
    }
}
