/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.annotation.filters;

import org.srs3d.viewer.annotation.objects.ChainAnnotation;
import org.srs3d.viewer.bioatlas.objects.Chain;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.objects.filters.ObjectClassFilter;

/**
 * searches in a chainAnnotation for the residue
 *
 * @author Christian Zofka
 *
 * @created August 17, 2001
 */
public final class ChainAnnotationChainFilter extends ObjectClassFilter {
    private Chain chain;

    /**
     * <code>ResidueTemplateFilter</code> constructor.
     */
    public ChainAnnotationChainFilter() {
        super(ChainAnnotation.class);
    }

    /**
     * Method description.
     *
     * @param chain Parameter description.
     */
    public void setChain(Chain chain) {
        this.chain = chain;
    }

    /**
     * Description of the method.
     *
     * @param object Description of parameter.
     *
     * @return Description of the returned value.
     */
    public boolean filter(AbstractObject object) {
        if (super.filter(object)) {
            ChainAnnotation chainAnnotation = (ChainAnnotation) object;
            if (!chainAnnotation.getChains().isEmpty()) {
                return chainAnnotation.getChains().contains(chain);
            }
        }
        return false;
    }
}
