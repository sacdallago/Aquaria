/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.annotation.attributes;

import org.srs3d.viewer.objects.Attribute;

/**
 * Layout position attribute.
 *
 * @author Christian Zofka
 *
 * @created November, 2001
 */
public class AlignmentLayout extends Attribute {

    // ChainAnnotations, AnnotationUnits, Ruler & null are possible
    private Object[] rows;

    // y-values of left top corners of rows
    private float[] rowYPos;

    // y-value of left bottom corner of last row
    // needed for height-calculation
    private float bottomYPos;

    // start- & end-Y-Position of the ChainAnnotations-Area
    private float startChainPosition;

    // start- & end-Y-Position of the ChainAnnotations-Area
    private float endChainPosition;

    /**
     * Sets the <code>rows</code> attribute of the <code>AlignmentLayout</code> object.
     *
     * @param objects The new <code>rows</code> value.
     */
    public void setRows(Object[] objects) {
        rows = objects;
    }

    /**
     * Sets the <code>positions</code> attribute of the <code>AlignmentLayout</code>
     * object.
     *
     * @param positions The new <code>positions</code> value.
     */
    public void setPositions(float[] positions) {
        rowYPos = positions;
    }

    /**
     * Sets the <code>bottomYPosition</code> attribute of the
     * <code>AlignmentLayout</code> object.
     *
     * @param yMin The new <code>bottomYPosition</code> value.
     */
    public void setBottomYPosition(float yMin) {
        bottomYPos = yMin;
    }

    /**
     * Sets the <code>startChainPosition</code> attribute of the
     * <code>AlignmentLayout</code> object.
     *
     * @param yTop The new <code>startChainPosition</code> value.
     */
    public void setStartChainPosition(float yTop) {
        startChainPosition = yTop;
    }

    /**
     * Sets the <code>endChainPosition</code> attribute of the
     * <code>AlignmentLayout</code> object.
     *
     * @param yBottom The new <code>endChainPosition</code> value.
     */
    public void setEndChainPosition(float yBottom) {
        endChainPosition = yBottom;
    }

    /**
     * Gets the <code>rows</code> attribute of the <code>AlignmentLayout</code> object.
     *
     * @return The <code>rows</code> value.
     */
    public Object[] getRows() {
        return rows;
    }

    /**
     * Gets the <code>positions</code> attribute of the <code>AlignmentLayout</code>
     * object.
     *
     * @return The <code>positions</code> value.
     */
    public float[] getPositions() {
        return rowYPos;
    }

    /**
     * Gets the <code>startChainPosition</code> attribute of the
     * <code>AlignmentLayout</code> object.
     *
     * @return The <code>startChainPosition</code> value.
     */
    public float getStartChainPosition() {
        return startChainPosition;
    }

    /**
     * Gets the <code>endChainPosition</code> attribute of the
     * <code>AlignmentLayout</code> object.
     *
     * @return The <code>endChainPosition</code> value.
     */
    public float getEndChainPosition() {
        return endChainPosition;
    }

    /**
     * Gets the <code>hight</code> attribute of the <code>AlignmentLayout</code> object.
     *
     * @return The <code>hight</code> value.
     */
    public float getHeight() {
        float[] pos = getPositions();
        float height = pos[0] - bottomYPos;
        return height;
    }

    /**
     * Checks for equal content.
     *
     * @param attribute Second attribute to compare.
     *
     * @return Boolean flag indicating eual content.
     */
    public boolean isEqual(Attribute attribute) {
        return false;
    }

    /**
     * Gets the <code>immutable</code> attribute of the <code>AlignmentLayout</code>
     * object.
     *
     * @return The <code>immutable</code> value.
     */
    public Attribute.Immutable getImmutable() {
        return new Immutable();
    }

    /**
     * Copies the attributes content.
     *
     * @return Copied instance of the attribute.
     */
    public Attribute copy() {
        AlignmentLayout alignmentLayout = (AlignmentLayout) super.copy();
        alignmentLayout.setPositions(getPositions());
        alignmentLayout.setRows(getRows());
        alignmentLayout.setBottomYPosition(bottomYPos);
        alignmentLayout.setStartChainPosition(getStartChainPosition());
        alignmentLayout.setEndChainPosition(getEndChainPosition());
        return alignmentLayout;
    }

    /**
     * Description of the class.
     *
     * @author zofka, LION bioscience AG
     *
     * @created January 10, 2002
     */
    public class Immutable extends Attribute.Immutable {

        // implement read-only interface
    }
}
