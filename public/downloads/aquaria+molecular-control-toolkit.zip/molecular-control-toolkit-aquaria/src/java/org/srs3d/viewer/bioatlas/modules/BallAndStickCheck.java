/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.modules;

import java.util.Vector;

import org.srs3d.viewer.bioatlas.attributes.AtomRepresentation;
import org.srs3d.viewer.bioatlas.attributes.Representation;
import org.srs3d.viewer.bioatlas.objects.Atom;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.objects.State;

/**
 * @author Karsten Klein
 *
 * @created August 06, 2001
 */
public class BallAndStickCheck extends VanDerWaalsCheck {
    public static final BallAndStickCheck sharedInstance =
        new BallAndStickCheck();

    /**
     * Description of the method.
     *
     * @param atom Description of parameter.
     *
     * @return Description of the returned value.
     */
    public int check(ContextData contextData, Atom atom) {
        State.Immutable state =
            contextData.getStateManager().getImmutableState(atom);
        AtomRepresentation.Immutable representation =
            (AtomRepresentation.Immutable) state.getAttribute(AtomRepresentation.class);
        if ((representation.getMode() &
              Representation.REPRESENTATION_BALL_AND_STICK) != 0) {
            return CHECK_YES;
        }
        return CHECK_NO;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public int getMode() {
        return Representation.REPRESENTATION_BALL_AND_STICK;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public int getUndoMode() {
        return Representation.REPRESENTATION_WIREFRAME |
        Representation.REPRESENTATION_VAN_DER_WAALS;
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     *
     * @return Return description.
     */
    public static RepresentationModule createRepresentationModule(
        ContextData contextData) {
        Vector onCommands = new Vector();
        Vector offCommands = new Vector();
        sharedInstance.getAllOnCommands(contextData, onCommands);
        sharedInstance.getAllOffCommands(contextData, offCommands);
        return new RepresentationModule("Ball & Stick", contextData,
            onCommands, offCommands, sharedInstance);
    }
}
