/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.modules;

import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;

import javax.swing.JCheckBoxMenuItem;
import javax.vecmath.Color3f;

import org.srs3d.viewer.j3d.Context;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.behaviors.dispatcher.Dispatch;
import org.srs3d.viewer.objects.Operation;

/**
 * @author Karsten Klein
 *
 * @created February 06, 2002
 */
public class SwitchPrintModeModule extends CheckModule {
    public static final Color3f normalColor = new Color3f(0.3f, 0.3f, 0.3f);
    public static final Color3f brightColor = new Color3f(0.7f, 0.7f, 0.7f);
    private boolean isPrintMode = false;
    private HashSet contexts = new HashSet();

    /**
     * <code>ResetModule</code> constructor.
     *
     * @param name Description of parameter.
     * @param context Description of parameter.
     */
    public SwitchPrintModeModule(String name, ContextData contextData) {
        super(name, contextData);

        // register ResetOperationStore operation
        Dispatch dispatch =
            new Dispatch() {
                public void dispatch(ContextData contextData,
                    Operation operation) {
                    resetDefaultMode();
                }
            };
        ArrayList dispatches = new ArrayList(1);
        dispatches.add(dispatch);
        contextData.getDispatcher().registerDispatches("RESET_CONTEXT_MODE",
            dispatches);
    }

    /**
     * Description of the method.
     */
    public void updateIntern() {
        Context context = getContextData().getContext();
        ((JCheckBoxMenuItem) getComponent()).setState(isPrintMode);
        getComponent().setEnabled(true);
    }

    /**
     * Description of the method.
     *
     * @param e Description of parameter.
     */
    public void react(ActionEvent e) {

        //    Iterator iterator = contexts.iterator();
        //    ContextData contextData;
        //
        //    isPrintMode = !isPrintMode;
        //
        //    java.awt.Color outlineColor =
        //      isPrintMode ? new java.awt.Color( 1f, 1f, 1f, 1f ) : new java.awt.Color( 0f, 0f, 0f, 1f ) ;
        //
        //    while ( iterator.hasNext() ) {
        //
        //      contextData = (ContextData) iterator.next();
        //      contextData.getContext().switchPrintMode( isPrintMode );
        //
        //    }
        Iterator iterator = contexts.iterator();
        ContextData contextData;
        Color3f ambientColor = isPrintMode ? normalColor : brightColor;
        while (iterator.hasNext()) {
            contextData = (ContextData) iterator.next();
            contextData.getContext().setAmbientLightColor(ambientColor);
        }
        isPrintMode = !isPrintMode;
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     */
    public void register(ContextData contextData) {
        contexts.add(contextData);
    }

    /**
     * Method description.
     */
    public void resetDefaultMode() {
        this.isPrintMode = false;
        Iterator iterator = contexts.iterator();
        ContextData contextData;
        Color3f ambientColor = isPrintMode ? normalColor : brightColor;
        while (iterator.hasNext()) {
            contextData = (ContextData) iterator.next();
            contextData.getContext().setAmbientLightColor(normalColor);
        }
    }
}
