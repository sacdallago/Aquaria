/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.constraints;

import javax.vecmath.Point3d;
import javax.vecmath.Tuple3d;
import javax.vecmath.Vector3d;

/**
 * This class is a concrete implementation of the <code>Constraint</code> class. Use it
 * to constrain a position to a volume with sperical bounds.
 *
 * @author Karsten Klein
 *
 * @created April 23, 2001
 */
public class SphereConstraint implements Constraint {

    /** Defines the position of the sphere */
    private Point3d center = null;

    /** Radius of the sphere */
    private float radius = 1.0f;

    /**
     * Creates a <code>SphereConstraint</code> with the appropriate plane defined by the
     * specified parameters. Note that this constructor sets the
     * <code>permittedDirection</code> attribute to the negated <code>normal</code> .
     *
     * @param center Description of parameter.
     * @param radius Description of parameter.
     */
    public SphereConstraint(Point3d center, float radius) {
        this.center = center;
        this.radius = Math.abs(radius);
    }

    /**
     * This method implements the according <code>Constraint</code> method. Note that
     * only Point3d objects are processed.
     *
     * @param object Description of parameter.
     *
     * @return Description of the returned value.
     */
    public boolean process(Object object) {
        if (object instanceof Tuple3d) {
            return process((Tuple3d) object);
        }
        return false;
    }

    /**
     * Processes the point.
     *
     * @param point Description of parameter.
     *
     * @return <code>boolean</code> - <code>true</code> if a modification was applied to
     *         point
     */
    private boolean process(Tuple3d point) {
        Vector3d connect = new Vector3d(point);
        connect.sub(center);
        if (connect.length() > radius) {
            connect.normalize();
            connect.scale(radius);
            connect.add(center);
            point.set(connect);
            return true;
        }
        return false;
    }
}
