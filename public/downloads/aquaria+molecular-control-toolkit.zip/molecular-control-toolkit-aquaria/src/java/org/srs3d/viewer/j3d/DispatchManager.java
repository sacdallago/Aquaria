/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d;

import java.util.Collection;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;

import org.srs3d.viewer.j3d.behaviors.dispatcher.Dispatcher;
import org.srs3d.viewer.objects.Operation;
import org.srs3d.viewer.util.ExceptionHandler;

/**
 * Description of the class.
 *
 * @author Karsten Klein
 *
 * @created May 18, 2001
 */
public class DispatchManager {
    private static Hashtable contextMap = new Hashtable();
    private static Hashtable dispatcherMap = new Hashtable();

    /**
     * Gets the <code>context</code> attribute of the <code>DispatchManager</code> class.
     *
     * @param dispatcher Description of parameter.
     *
     * @return The <code>context</code> value.
     */
    public static Context getContext(Dispatcher dispatcher) {
        return (Context) dispatcherMap.get(dispatcher);
    }

    /**
     * Description of the method.
     *
     * @param source Description of parameter.
     * @param drain Description of parameter.
     */
    public static void register(Context source, Context drain) {
        Collection drains = (Collection) contextMap.get(source);
        if (drains == null) {
            drains = new HashSet();
            contextMap.put(source, drains);
        }
        drains.add(drain);
    }

    /**
     * Description of the method.
     *
     * @param dispatcher Description of parameter.
     * @param context Description of parameter.
     */
    public static void register(Dispatcher dispatcher, Context context) {
        dispatcherMap.put(dispatcher, context);
    }

    /**
     * Description of the method.
     *
     * @param context Description of parameter.
     */
    public static void removeDispatcher(Context context) {

        // remove context in drains
        Iterator iterator = contextMap.values().iterator();
        while (iterator.hasNext()) {
            ((Collection) iterator.next()).remove(context);
        }

        // remove as source
        Collection drains = (Collection) contextMap.remove(context);

        // clear the drains if available
        if (drains != null) {
            drains.clear();
        }
        dispatcherMap.values().remove(context);
    }

    /**
     * Dispatches the operation on the drain contexts of the specified source context.
     * The command must not be dispatched directly. Use the runDispatch for direct
     * execution.
     *
     * @param source Source context.
     * @param operation Operation for dispatch.
     */
    public static void dispatch(Context source, Operation operation) {
        Collection drains = (Collection) contextMap.get(source);
        if (drains != null) {
            Iterator iterator = drains.iterator();
            Context context;
            Dispatcher dispatcher;
            while (iterator.hasNext()) {
                context = (Context) iterator.next();
                if (context != source) {
                    dispatcher = getDispatcher(context);
                    try {
                        dispatcher.dispatch(operation);
                    } catch (Exception e) {
                        ExceptionHandler.handleException(e,
                            ExceptionHandler.SILENT_IN_RELEASE);
                    }
                }
            }
        }
    }

    /**
     * Dispatches the operation on the drain contexts of the specified source context.
     * The command directly executes the operation.
     *
     * @param source Source context.
     * @param operation Operation for dispatch.
     */
    public static void runDispatch(Context source, Operation operation) {
        Collection drains = (Collection) contextMap.get(source);
        if (drains != null) {
            Iterator iterator = drains.iterator();
            Context context;
            Dispatcher dispatcher;
            while (iterator.hasNext()) {
                context = (Context) iterator.next();
                if (context != source) {
                    dispatcher = getDispatcher(context);
                    try {
                        dispatcher.runDispatch(operation);
                    } catch (Exception e) {
                        ExceptionHandler.handleException(e,
                            ExceptionHandler.SILENT_IN_RELEASE);
                    }
                }
            }
        }
    }

    /**
     * Gets the <code>dispatcher</code> attribute of the <code>DispatchManager</code>
     * class.
     *
     * @param context Description of parameter.
     *
     * @return The <code>dispatcher</code> value.
     */
    private static Dispatcher getDispatcher(Context context) {
        return context.getContextData().getDispatcher();
    }
}
