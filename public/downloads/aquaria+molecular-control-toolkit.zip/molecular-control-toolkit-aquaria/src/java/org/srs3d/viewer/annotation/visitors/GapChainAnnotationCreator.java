/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.annotation.visitors;

import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Vector;

import org.srs3d.viewer.annotation.objects.Gap;
import org.srs3d.viewer.annotation.objects.Segment;
import org.srs3d.viewer.bioatlas.objects.Residue;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.objects.ObjectContainer;
import org.srs3d.viewer.objects.visitors.AbstractVisitor;
import org.srs3d.viewer.util.Log;

/**
 * modifies all segments for a sequence
 *
 * @author Christian Zofka
 *
 * @created September 5, 2001
 */
public class GapChainAnnotationCreator extends AbstractVisitor {
    private static final Log log = new Log(GapChainAnnotationCreator.class);
    private Collection segments;
    private Collection result;

    /**
     * <code>GapChainAnnotationCreator</code> constructor.
     *
     * @param segments Description of parameter.
     */
    public GapChainAnnotationCreator(Collection segments) {
        this.segments = segments;
    }

    /**
     * Description of the method.
     *
     * @param object Description of parameter.
     */
    public void visit(AbstractObject object) {
        if (object instanceof ObjectContainer) {
            super.visit((ObjectContainer) object);
        }
    }

    /**
     * Description of the method.
     *
     * @param gapSequence sequence to build and place the segments
     *
     * @return modified (new gapSegments, indecies updated) segments
     */
    public Collection createSegments(Vector gapSequence) {
        result = new HashSet();
        Segment actualSegment = null;
        Gap gap = null;
        int index = 0;
        Residue residue = null;
        Residue last = null;
        Iterator iterator = gapSequence.iterator();
        while (iterator.hasNext()) {
            residue = (Residue) iterator.next();

            // create gapsegment or find segment from list
            if (actualSegment == null) {
                if (residue == null) {
                    actualSegment = createGapSegment(index);
                    result.add(actualSegment);
                    gap = (Gap) actualSegment.getGaps().elementAt(0);
                } else {
                    actualSegment = initializeStartSegment(residue, index);
                }
            }
            // handle gapsegments
            else if (actualSegment.getSubchain() == null) {
                if (residue == null) {
                    gap.setLength(gap.getLength() + 1);
                } else {
                    actualSegment.setEndIndex(index - 1);

                    //          actualSegment.setEndResidue( residue );
                    gap = null;
                    actualSegment = initializeStartSegment(residue, index);
                }
            }
            // allready have segment(has a referenced subchain) that is not a gapsegment
            else {
                if (residue == null) {
                    segments.add(actualSegment.split(last));
                    actualSegment.setEndIndex(index - 1);
                    actualSegment = createGapSegment(index);
                    result.add(actualSegment);
                    gap = (Gap) actualSegment.getGaps().elementAt(0);
                } else {

                    // proceding with a residue in an existing segment
                    if (actualSegment != null) {
                        if (!(actualSegment.computeResidueIndex(residue) > 0 &&
                              last.getProceeding() == residue)) {
                            segments.add(actualSegment.split(last));
                            actualSegment.setEndIndex(index - 1);
                            actualSegment =
                                initializeStartSegment(residue, index);
                        }
                    }
                    if (actualSegment != null &&
                          residue == actualSegment.getEndResidue()) {
                        actualSegment.setEndIndex(index);
                        actualSegment = null;
                    }
                }
            }
            index++;
            if (residue != null) {
                last = residue;
            }
        }
        if (actualSegment != null) {
            if (actualSegment.getSubchain() != null) {
                segments.add(actualSegment.split(last));
            }
            actualSegment.setEndIndex(index - 1);
        }
        return result;
    }

    /**
     * finds the suitable segment for residue, removes it from the initial
     * segmentcollection and checks if it is a segment with the width of 1
     *
     * @param residue search object
     * @param index current index in the chainAnnotation
     *
     * @return segment that start with residue; null no segment was found or the segment
     *         has the size of 1
     */
    private Segment initializeStartSegment(Residue residue, int index) {

        // find suitable segment
        Segment segment = findStartSegment(segments, residue);
        segments.remove(segment);
        if (segment != null) {
            result.add(segment);
            segment.setStartIndex(index);
            if (segment.getEndResidue() == residue) {
                segment.setEndIndex(index);
                segment = null;
            }
        } else {
            log.error("no segment found for " + residue);
        }
        return segment;
    }

    /**
     * this method takes a collection of segments and searches for the given residue; if
     * the residue is in the middle of a segment a segment split will be performed, the
     * first half of the segment will be put to the initial segmentcollection and the
     * second half (that starts with the residue) will be returned.
     *
     * @param segments segments to search in
     * @param residue residue to find
     *
     * @return segment that starts with residue
     */
    public static Segment findStartSegment(Collection segments, Residue residue) {
        Segment segment = null;
        Iterator iterator = segments.iterator();
        while (iterator.hasNext()) {
            segment = (Segment) iterator.next();
            if (segment != null) {
                if (segment.getInitialResidue() != null) {
                    int index = segment.computeResidueIndex(residue);
                    if (index == 0) {
                        return segment;
                    } else if (index > 0) {

                        // segmentsplit, returns only the 2. part and push the 1. back to the collection
                        segment = segment.split(residue.getPreceeding());
                        segments.add(segment);
                        return segment;
                    }
                }
            } else {
                log.error("null segment encountered.");
            }
        }
        return null;
    }

    /**
     * creates a segment that only contains a gap of 1 length
     *
     * @param index startindex for the segment
     *
     * @return created gapsegment
     */
    private static Segment createGapSegment(int index) {
        Segment segment = new Segment(null);
        segment.setStartIndex(index);
        Gap gap = new Gap(1);

        //          gap.setPrevious( last );
        segment.addGap(gap);
        return segment;
    }
}
