/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.loaders.raster3d;

import java.util.StringTokenizer;
import java.util.Vector;

import javax.media.j3d.Appearance;
import javax.media.j3d.BranchGroup;
import javax.media.j3d.PolygonAttributes;
import javax.media.j3d.Shape3D;
import javax.media.j3d.TriangleArray;
import javax.vecmath.Color4f;
import javax.vecmath.Point3f;

import org.srs3d.viewer.j3d.AppearanceHelper;
import org.srs3d.viewer.j3d.ShapeManager;
import org.srs3d.viewer.j3d.geometry.GeometryHelper;
import org.srs3d.viewer.j3d.geometry.primitive.Triangle;

/**
 * Description of the class
 *
 * @author Karsten Klein
 *
 * @created March 20, 2001
 */
public class Raster3DTriangle extends Triangle
    implements AbstractRaster3DPrimitive {

    /**
     * Creates the Triangle from a raster3D string with the format "x1 y1 z2 x2 y2 z2 x3
     * y3 z3 r g b". Default normal setting is computed by ComputeNormal.
     *
     * @param string Description of parameter
     *
     * @return Description of the returned value
     */
    public boolean create(String string) {
        StringTokenizer tokenizer = new StringTokenizer(string);
        float f;

        // a triangle has 3x3 ordinates and 1x3 colors attributes (RGB)
        if (tokenizer.countTokens() == 12) {
            Point3f[] coordinates = getCoordinates().getBuffer();
            Color4f color = new Color4f();
            for (int index = 0; index < 12; index++) {
                f = Float.parseFloat(tokenizer.nextToken());
                switch (index) {

                    case 0:
                        coordinates[0].x = f;
                        break;

                    case 1:
                        coordinates[0].y = f;
                        break;

                    case 2:
                        coordinates[0].z = f;
                        break;

                    case 3:
                        coordinates[1].x = f;
                        break;

                    case 4:
                        coordinates[1].y = f;
                        break;

                    case 5:
                        coordinates[1].z = f;
                        break;

                    case 6:
                        coordinates[2].x = f;
                        break;

                    case 7:
                        coordinates[2].y = f;
                        break;

                    case 8:
                        coordinates[2].z = f;
                        break;

                    case 9:
                        color.x = f;
                        break;

                    case 10:
                        color.y = f;
                        break;

                    case 11:
                        color.z = f;
                        break;
                }
            }
            getNormals().setUniform(computeNormal());
            getColors().setUniform(color);
            return true;
        } else {
            return false;
        }
    }

    /**
     * Description of the method
     *
     * @param lines Description of parameter
     * @param triangles Description of parameter
     * @param branch Description of parameter
     */
    public void supply(Vector lines, Vector triangles, BranchGroup branch) {
        triangles.addElement(this);
    }

    /**
     * Description of the method
     *
     * @param triangles Description of parameter
     * @param branch Description of parameter
     */
    public static void supply(Vector triangles, BranchGroup branch) {
        if (triangles.size() > 0) {
            TriangleArray triangleArray =
                GeometryHelper.getDefaultTriangleArray(triangles.size(),
                    TriangleArray.COLOR_4);
            for (int i = 0; i < triangles.size(); i++) {
                ((Triangle) triangles.elementAt(i)).insertInto(i, triangleArray);
            }
            Appearance appearance = new Appearance();
            AppearanceHelper.setDefaults(appearance);
            PolygonAttributes polygonAttributes = new PolygonAttributes();
            polygonAttributes.setCullFace(PolygonAttributes.CULL_NONE);
            appearance.setPolygonAttributes(polygonAttributes);
            Shape3D shape = new Shape3D(triangleArray, appearance);
            ShapeManager.setCapabilities(shape, null);
            branch.addChild(shape);
        }
    }
}
