/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.annotation.objects.strategies;

import javax.media.j3d.Appearance;
import javax.media.j3d.Texture;
import javax.vecmath.Color3f;
import javax.vecmath.Color4f;

import org.srs3d.viewer.annotation.objects.Segment;
import org.srs3d.viewer.bioatlas.objects.Site;
import org.srs3d.viewer.j3d.AppearanceHelper;
import org.srs3d.viewer.j3d.AppearanceManager;
import org.srs3d.viewer.j3d.AppearanceManager.TextureColors;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.Reaction;
import org.srs3d.viewer.j3d.Selection;
import org.srs3d.viewer.j3d.commands.ColorCommand;
import org.srs3d.viewer.j3d.commands.ExpandCommand;
import org.srs3d.viewer.j3d.commands.PreSelectCommand;
import org.srs3d.viewer.j3d.commands.RegisterCommand;
import org.srs3d.viewer.j3d.objects.strategies.AbstractStrategy;
import org.srs3d.viewer.j3d.objects.strategies.reactions.EmptyReaction;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.objects.Command;

/**
 * @author Karsten Klein
 *
 * @created April 03, 2001
 */
public class ResidueStrategy extends AbstractStrategy {

    /**
     * Constructor description.
     */
    public ResidueStrategy() {
        register(ExpandCommand.class, EmptyReaction.getSharedInstance());
        register(PreSelectCommand.class, EmptyReaction.getSharedInstance());
        register(RegisterCommand.class, new RegisterReaction());

        // :TEST: texture coloring
        register(ColorCommand.class, new ColorReaction());
    }

    /**
     * Class description.
     *
     * @author Karsten Klein, LION bioscience AG
     */
    public class RegisterReaction implements Reaction {

        /**
         * Method description.
         *
         * @param command Parameter description.
         */
        public void execute(Command command) {
            RegisterCommand registerCommand = (RegisterCommand) command;
            if (registerCommand.getParent() != null) {
                if (registerCommand.getParent().getClass() == Site.class) {
                    registerCommand.setApplicationMode(0);
                }
            }
            registerCommand.execute();
        }
    }

    /**
     * Class description.
     *
     * @author Karsten Klein, LION bioscience AG
     */
    public class ColorReaction implements Reaction {

        /**
         * Method description.
         *
         * @param command Parameter description.
         */
        public void execute(Command command) {
            ColorCommand colorCommand = (ColorCommand) command;
            ContextData contextData = colorCommand.getContextData();
            ContextData referenceContextData =
                ((org.srs3d.viewer.annotation.contexts.AnnotationContextData) contextData).getReferenceContextData();
            AbstractObject object = (AbstractObject) command.getObject();
            Selection selection =
                referenceContextData.getSelectionManager().getSelection();
            if (!selection.contains(object)) {
                ColorCommand localCommand =
                    new ColorCommand(contextData,
                        contextData.getColorSchemeBucket());
                localCommand.setObject(object);
                localCommand.execute();

                // apply coloring (bucket extension + appearance)
                command.execute();
                AppearanceManager appearanceManager =
                    colorCommand.getContextData().getAppearanceManager();
                TextureColors textureColors =
                    appearanceManager.getTextureColors(object);
                if (textureColors != null) {
                    Appearance appearance =
                        appearanceManager.getAppearance(object);
                    Color4f color = new Color4f();
                    AppearanceHelper.getColor(appearance, color);
                    textureColors.setColor(0, color);
                    updateTexture(contextData, textureColors);
                }
            }
        }

        /**
         * Method description.
         *
         * @param contextData Parameter description.
         * @param textureColors Parameter description.
         */
        public void updateTexture(ContextData contextData,
            TextureColors textureColors) {
            Segment segment = (Segment) textureColors.getReferenceObject();
            Texture texture = textureColors.createTexture(contextData);
            Appearance appearance =
                contextData.getAppearanceManager().getAppearance(segment);
            Appearance textureAppearance =
                AppearanceHelper.createAppearance(new Color3f(1, 1, 1));
            textureAppearance.setTexture(texture);
            AppearanceHelper.setTextureDefaults(textureAppearance, texture);
            ColorCommand.apply(contextData, segment, textureAppearance);
        }
    }
}
