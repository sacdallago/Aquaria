/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.modules;

import java.awt.event.ActionEvent;
import java.awt.image.BufferedImage;
import java.awt.image.renderable.ParameterBlock;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import javax.media.j3d.GraphicsContext3D;
import javax.media.j3d.ImageComponent;
import javax.media.j3d.ImageComponent2D;
import javax.media.jai.JAI;
import javax.media.jai.PlanarImage;
import javax.vecmath.Point3f;

import org.srs3d.viewer.j3d.Context;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.util.Log;

import com.sun.media.jai.codec.ImageCodec;
import com.sun.media.jai.codec.ImageEncoder;
import com.sun.media.jai.codec.JPEGEncodeParam;

/**
 * <code>Module</code> implementation capturing images.
 *
 * @author Karsten Klein
 *
 * @created May 14, 2001
 */
public class CaptureModule extends CheckModule {
    private static final Log log = new Log(CaptureModule.class);
    private static int imageCounter = 1000;
    private String name;
    private boolean offscreen = false;
    private int width = 1024;
    private int height = 1024;

    /**
     * Constructor description.
     *
     * @param name Parameter description.
     * @param contextData Parameter description.
     */
    public CaptureModule(String name, ContextData contextData) {
        super(name, contextData);
        setOperationSerializeable(false);
    }

    /**
     * Method description.
     */
    public void updateIntern() {
        boolean isEnabled = false;
        String captureEnabled =
            (String) getContextData().getProperty("CAPTURE-ENABLED");
        if (captureEnabled != null) {
            isEnabled = true;
        }
        if (getCheckComponent() != null) {
            getCheckComponent().setState(isEnabled);
        }
    }

    /**
     * Description of the method.
     *
     * @param e Description of parameter.
     */
    public void react(ActionEvent e) {
        String captureEnabled =
            (String) getContextData().getProperty("CAPTURE-ENABLED");
        if (captureEnabled != null) {
            getContextData().setProperty("CAPTURE-ENABLED", null);
        } else {
            getContextData().setProperty("CAPTURE-ENABLED", "TRUE");
        }
    }

    /**
     * Method description.
     *
     * @param context Parameter description.
     * @param offscreen Parameter description.
     */
    public static void dumpImage(Context context, boolean offscreen) {
        if (context.getContextData().getProperty("CAPTURE-ENABLED") != null) {
            Object image = null;
            if (offscreen) {
                ImageComponent2D offScreenBuffer = context.getOffScreenBuffer();
                image = offScreenBuffer.getRenderedImage();
            } else {
                GraphicsContext3D graphicsContext =
                    context.getGraphicsContext3D();
                javax.media.j3d.Raster raster =
                    new javax.media.j3d.Raster(new Point3f(-1, -1, -1),
                        javax.media.j3d.Raster.RASTER_COLOR, 0, 0,
                        context.getWidth(), context.getHeight(),
                        new ImageComponent2D(ImageComponent.FORMAT_RGB,
                            new BufferedImage(context.getWidth(),
                                context.getHeight(), BufferedImage.TYPE_INT_RGB)),
                        null);
                graphicsContext.readRaster(raster);
                image = raster.getImage().getImage();
            }
            String filename =
                System.getProperty("user.home") +
                System.getProperty("file.separator") + "SRS3D" +
                imageCounter++ + ".jpg";
            try {
                ParameterBlock parameter = new ParameterBlock();
                parameter.add(image);
                PlanarImage planarImage =
                    (PlanarImage) JAI.create("awtImage", parameter);
                OutputStream outputStream = new FileOutputStream(filename);

                // JPEG version
                JPEGEncodeParam param = new JPEGEncodeParam();
                param.setQuality(1.0f);
                ImageEncoder encoder =
                    ImageCodec.createImageEncoder("JPEG", outputStream, param);
                encoder.encode(planarImage);

                // GIF version
                //        GIFEncodeParam param = new GIFEncodeParam();
                //        ImageEncoder encoder = ImageCodec.createImageEncoder( "GIF", outputStream, param );
                //        encoder.encode( planarImage );
                outputStream.close();
            } catch (IOException e) {
                log.error("cannot dump image.", e);
            }
        }
    }
}
