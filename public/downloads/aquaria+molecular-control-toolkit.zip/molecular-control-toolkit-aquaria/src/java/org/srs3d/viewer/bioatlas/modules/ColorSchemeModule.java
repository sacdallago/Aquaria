/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.modules;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeSet;
import java.util.Vector;

import javax.vecmath.Tuple3f;

import org.srs3d.viewer.bioatlas.objects.Annotation;
import org.srs3d.viewer.bioatlas.objects.Feature;
import org.srs3d.viewer.j3d.ColorScheme;
import org.srs3d.viewer.j3d.ColorSchemeBucket;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.DispatchManager;
import org.srs3d.viewer.j3d.Selection;
import org.srs3d.viewer.j3d.commands.ColorCommand;
import org.srs3d.viewer.j3d.commands.SpawnCommand;
import org.srs3d.viewer.objects.ObjectManager;
import org.srs3d.viewer.objects.Operation;

/**
 * <code>Module</code> implementation applying a <code>ColorScheme</code> to the
 * selection or the whole set of visible objects.
 *
 * @author Karsten Klein
 *
 * @created May 14, 2001
 */
public class ColorSchemeModule extends ProcessModule {
    private static int serial = 0;
    private ColorSchemeBucket colorSchemeBucket;
    private boolean isExtend = true;

    /**
     * <code>ColorSchemeModule</code> constructor.
     *
     * @param name Description of parameter.
     * @param colorScheme Description of parameter.
     * @param contextData Description of parameter.
     */
    public ColorSchemeModule(String name, ContextData contextData,
        ColorScheme colorScheme) {
        super(name, contextData);
        colorSchemeBucket = new ColorSchemeBucket(colorScheme);
    }

    /**
     * Constructor description.
     *
     * @param name Parameter description.
     * @param contextData Parameter description.
     * @param colorSchemeBucket Parameter description.
     */
    public ColorSchemeModule(String name, ContextData contextData,
        ColorSchemeBucket colorSchemeBucket) {
        super(name, contextData);
        this.colorSchemeBucket = colorSchemeBucket;
    }

    protected void process(final ColorCommand colorCommand) {
        getContextData().getContext().addUpdateCallback(new org.srs3d.viewer.j3d.behaviors.UpdateBehavior.Callback() {
                public void execute() {
                    ContextData contextData = getContextData();
                    ObjectManager objectManager =
                        contextData.getObjectManager();
                    Selection selection =
                        contextData.getSelectionManager().getSelection();
                    if (selection.isEmpty()) {
                        if (colorCommand.isRemoving()) {
                            colorCommand.propagate(contextData.getObjectContainer()
                                                              .getObjects(),
                                false);
                            contextData.getColorSchemeBucket().remove(colorSchemeBucket);
                        } else {
                            contextData.setColorSchemeBucket(colorSchemeBucket);
                            colorCommand.setForceRecoloring(true);
                            colorCommand.propagate(contextData.getObjectContainer()
                                                              .getObjects(),
                                false);
                            AnnotationToggleModule.updateColoring(contextData,
                                colorSchemeBucket);
                        }
                    } else {
                        colorCommand.propagate(selection);
                    }
                    org.srs3d.viewer.bioatlas.Capture.updateSelections(contextData,
                        true);
                    DispatchManager.runDispatch(contextData.getContext(),
                        new Operation(contextData.getContext(),
                            "UPDATE_COLORING", null));
                    updateLegendOverlay(contextData);
                }
            });
    }

    /**
     * Applies the color scheme to the whole scene or the current selection if available.
     *
     * @param e Description of parameter.
     */
    public void process(ActionEvent e) {
        ColorCommand colorCommand =
            new ColorCommand(getContextData(), colorSchemeBucket);
        process(colorCommand);
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     */
    public static void updateLegendOverlay(ContextData contextData) {
        Map featureMap = createAnnotationInformation(contextData);
        Map map = contextData.getColorSchemeBucket().getInformation(null);
        Vector order = (Vector) map.get("ORDER");
        if (order != null) {
            order.addAll((Collection) featureMap.get("ORDER"));
            featureMap.remove("ORDER");
            if (order.remove("no annotation")) {
                order.add("no annotation");
            }
        }
        map.putAll(featureMap);
        updateLegendOverlay(contextData, map);
    }

    /**
     * Description of the method.
     */
    public void cleanup() {
        super.cleanup();
        if (colorSchemeBucket != null) {
            colorSchemeBucket.clear();
            colorSchemeBucket = null;
        }
    }

    /**
     * Updates the infomrmation in the legend by adding the color scheme info. Most of
     * the code in this method will be moved to the overlay itself, so that we can
     * handle multiple colors ber line and libne wrapping.
     *
     * @param contextData Description of parameter.
     * @param colorScheme Description of parameter.
     */
    public static void updateLegendOverlay(final ContextData contextData,
        Map map) {

        // :FIXME: move this method to the overlay itself
        // update legend
        final org.srs3d.viewer.j3d.objects.Overlay overlay =
            contextData.getOverlayManager().getOverlay("Color Legend");
        if (overlay != null) {
            overlay.clearText();
            if (map != null) {
                Vector colors = new Vector();
                org.srs3d.viewer.vecmath.CubicBezierCurve3f curve =
                    (org.srs3d.viewer.vecmath.CubicBezierCurve3f) map.get(
                        "GRADIENT");
                int coloringStartLine = Integer.MAX_VALUE;
                int gradientStartLine = 0;
                int gradientEndLine = 0;
                overlay.addTextLine("");
                overlay.addTextLine(" Coloring: " + map.get("NAME"), Color.white);
                Collection set = (Collection) map.get("ORDER");
                Iterator iterator;
                if (set != null) {
                    iterator = set.iterator();
                } else {
                    iterator = map.keySet().iterator();
                }
                String string;
                Object object;
                Tuple3f tuple;
                Color color;
                int sharpIndex = 0;
                while (iterator.hasNext()) {
                    object = iterator.next();
                    string = object.toString();
                    if (!string.equals("ORDER")) {
                        if (!string.equals("NAME")) {
                            if (!string.startsWith("GRADIENT")) {
                                if (coloringStartLine > overlay.getCursorY()) {
                                    coloringStartLine = overlay.getCursorY();
                                }
                                tuple = (Tuple3f) map.get(object);
                                tuple.clamp(0f, 1f);
                                color =
                                    new Color(tuple.x, tuple.y, tuple.z, 1f);
                                sharpIndex = string.indexOf("#ID#");
                                if (sharpIndex != -1) {
                                    string = string.substring(0, sharpIndex);
                                }
                                overlay.addTextLine("        " + string, color);
                                colors.add(color);
                            } else {
                                if (string.equals("GRADIENT_START")) {
                                    gradientStartLine = overlay.getCursorY();
                                } else if (string.equals("GRADIENT_END")) {
                                    gradientEndLine = overlay.getCursorY();
                                }
                            }
                        }
                    }
                }
                overlay.setHeight(overlay.getCursorY() * 2 + 20);
                overlay.setWidth(overlay.getMaxPixels());
                overlay.update(contextData);
                Graphics g = overlay.getGraphics();
                iterator = colors.iterator();
                int offsetX = 14;
                int offsetY = 2 * coloringStartLine + 1;
                while (iterator.hasNext()) {
                    g.setColor(Color.gray);
                    g.drawRect(offsetX - 1, offsetY + 2, 12,
                        overlay.getLineHeight() + 1);
                    g.setColor(Color.darkGray);
                    g.drawRect(offsetX, offsetY + 3, 11, overlay.getLineHeight());
                    color = (Color) iterator.next();
                    g.setColor(color);
                    g.fillRect(offsetX, offsetY + 3, 11, overlay.getLineHeight());
                    offsetY += overlay.getLineHeight() * 2;
                }
                if (curve != null) {
                    offsetY = 2 * gradientStartLine + 1;
                    int delta = gradientEndLine - gradientStartLine - 1;
                    delta *= 2;
                    g.setColor(Color.gray);
                    g.drawRect(offsetX - 1, offsetY - 1, 12, delta + 1);
                    g.setColor(Color.darkGray);
                    g.drawRect(offsetX, offsetY, 11, delta);
                    for (int i = 0; i < delta; i++) {
                        tuple = curve.computePoint((float) i / (delta - 1));
                        tuple.clamp(0, 1);
                        color = new Color(tuple.x, tuple.y, tuple.z);
                        g.setColor(color);
                        g.drawLine(offsetX, offsetY + i, offsetX + 10,
                            offsetY + i);
                    }
                }
            } else {
                overlay.addTextLine("");
                overlay.addTextLine(" No data available", Color.red);
                overlay.setHeight(overlay.getCursorY() * 2 + 20);
                overlay.setWidth(overlay.getMaxPixels());
                overlay.update(contextData);
            }
            overlay.finalizeUpdate();
            contextData.getContext().addUpdateCallback(new org.srs3d.viewer.j3d.behaviors.UpdateBehavior.Callback() {
                    public void execute() {
                        SpawnCommand spawnCommand =
                            new SpawnCommand(contextData);
                        contextData.getStrategyManager().execute(overlay,
                            spawnCommand);
                    }
                });
        }
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     * @param annotation Parameter description.
     * @param names Parameter description.
     * @param nameMap Parameter description.
     */
    public static void getAnnotationColors(ContextData contextData,
        Annotation annotation, Collection names, Map nameMap) {
        boolean isAnnotationColor = true;
        HashMap colorMap = new HashMap();
        Collection colors;
        Iterator iterator = annotation.getFeatures().iterator();
        Feature feature;

        // determine if we need feature coloring at all
        while (iterator.hasNext()) {
            feature = (Feature) iterator.next();
            if (!feature.getColor().epsilonEquals(annotation.getColor(), 0.01f)) {
                isAnnotationColor = false;
            }
        }
        if (!isAnnotationColor) {
            iterator = annotation.getFeatures().iterator();
            boolean addFeature;
            while (iterator.hasNext()) {
                feature = (Feature) iterator.next();
                if (FeatureModule.isFeatureActive(contextData, feature)) {
                    String string = feature.getName();
                    if (feature.getDescription() != null) {
                        string += " " + feature.getDescription();
                    }
                    addFeature = true;
                    colors = (Collection) colorMap.get(string);
                    if (colors != null) {
                        if (colors.contains(feature.getColor().toString())) {
                            addFeature = false;
                        }
                    }
                    if (colors == null) {
                        colors = new HashSet();
                        colorMap.put(string, colors);
                    }
                    colors.add(feature.getColor().toString());
                    if (addFeature) {
                        string += "#ID#" + serial++;
                        names.add(string);
                        nameMap.put(string, feature.getColor());
                    }
                }
            }
        } else {
            String string = annotation.getName() + "#ID#" + serial++;
            nameMap.put(string, annotation.getColor());
            names.add(string);
        }
    }

    // :FIXME: move this method to a more appropriate site
    public static Map createAnnotationInformation(ContextData contextData) {
        Map map = new HashMap();
        Collection annotations = new HashSet();
        ObjectManager.extract(contextData.getObjectContainer().getObjects(),
            annotations, Annotation.class);
        Iterator iterator = annotations.iterator();
        Annotation annotation;
        TreeSet treeSet = new TreeSet();
        ColorScheme colorScheme;
        while (iterator.hasNext()) {
            annotation = (Annotation) iterator.next();
            if (AnnotationModule.isActiveAnnotation(contextData, annotation)) {
                getAnnotationColors(contextData, annotation, treeSet, map);
            }
        }
        Vector order = new Vector(treeSet);
        map.put("ORDER", order);
        return map;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public ColorSchemeBucket getColorSchemeBucket() {
        return colorSchemeBucket;
    }

    /**
     * Method description.
     *
     * @param colorSchemeBucket Parameter description.
     */
    public void setColorSchemeBucket(ColorSchemeBucket colorSchemeBucket) {
        this.colorSchemeBucket = colorSchemeBucket;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public String getModuleIdPrefix() {
        return "COLOR-";
    }
}
