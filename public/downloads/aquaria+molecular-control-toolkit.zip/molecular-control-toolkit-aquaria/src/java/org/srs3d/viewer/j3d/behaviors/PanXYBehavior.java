/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.behaviors;

import java.awt.event.MouseEvent;

import javax.media.j3d.Transform3D;
import javax.media.j3d.WakeupOnAWTEvent;
import javax.media.j3d.WakeupOr;
import javax.vecmath.Matrix3f;
import javax.vecmath.Point3d;
import javax.vecmath.Vector3f;

import org.srs3d.viewer.j3d.Context;
import org.srs3d.viewer.j3d.ContextData;

/**
 * Description of the class
 *
 * @author Karsten Klein
 *
 * @created March 20, 2001
 */
public class PanXYBehavior extends MouseBehavior {
    protected int lastX;
    protected int x;
    protected int lastY;
    protected int y;
    private float speedX = 1.0f;
    private float speedY = 1.0f;

    /**
     * <code>PanXYBehavior</code> constructor.
     *
     * @param context Description of parameter.
     */
    public PanXYBehavior(ContextData contextData) {
        super(contextData);
    }

    /**
     * Sets the <code>speedX</code> attribute of the <code>PanXYBehavior</code> object.
     *
     * @param x The new <code>speedX</code> value.
     */
    public void setSpeedX(float x) {
        speedX = x;
    }

    /**
     * Sets the <code>speedy</code> attribute of the <code>PanXYBehavior</code> object.
     *
     * @param y The new <code>speedy</code> value.
     */
    public void setSpeedy(float y) {
        speedY = y;
    }

    /**
     * Gets the <code>speedX</code> attribute of the <code>PanXYBehavior</code> object.
     *
     * @return The <code>speedX</code> value.
     */
    public float getSpeedX() {
        return speedX;
    }

    /**
     * Gets the <code>speedY</code> attribute of the <code>PanXYBehavior</code> object.
     *
     * @return The <code>speedY</code> value.
     */
    public float getSpeedY() {
        return speedY;
    }

    /**
     * Description of the method
     */
    public void initialize() {
        WakeupOnAWTEvent[] conditions = new WakeupOnAWTEvent[2];

        // set wakeup condition (waiting for further dragging events)
        conditions[0] =
            new WakeupOnAWTEvent(java.awt.event.MouseEvent.MOUSE_DRAGGED);

        // set wakeup condition (waiting first click)
        conditions[1] =
            new WakeupOnAWTEvent(java.awt.event.MouseEvent.MOUSE_PRESSED);
        wakeupOn(new WakeupOr(conditions));
    }

    /**
     * When processStilmulus is called by the framework the behavior will adjust scaling
     * and translation values of the viewplatform tranformation
     *
     * @param mouseEvent Description of parameter
     */
    public void processStimulus(MouseEvent mouseEvent) {
        lastX = x;
        lastY = y;
        x = mouseEvent.getX();
        y = mouseEvent.getY();

        // prepare members
        // NOTE: for a MOUSE_PRESSED event this is the only thing to
        //  be done for initializing the subsequent dragging events
        if (checkCriteria(mouseEvent)) {
            Context context = getContextData().getContext();
            KeyHandler.setCursor(getContextData(), "PanXY", true);
            Transform3D transform = context.getViewingPlatformTransform();
            Matrix3f matrix = new Matrix3f();
            transform.get(matrix);
            Vector3f directionX = new Vector3f();
            Vector3f directionY = new Vector3f();
            matrix.getColumn(0, directionX);
            matrix.getColumn(1, directionY);

            // get current translation of the ViewingPlatform
            Vector3f translation = new Vector3f();
            transform.get(translation);
            float panSpeed = (10.0f + translation.length()) / 1000;
            int deltaX = x - lastX;
            int deltaY = y - lastY;
            deltaX = Math.min(deltaX, MAX_DELTA);
            deltaX = Math.max(deltaX, -MAX_DELTA);
            deltaY = Math.min(deltaY, MAX_DELTA);
            deltaY = Math.max(deltaY, -MAX_DELTA);
            pan(context, -panSpeed * getSpeedX() * deltaX,
                panSpeed * getSpeedY() * deltaY);
        }
    }

    /**
     * Method description.
     *
     * @param context Parameter description.
     * @param deltaX Parameter description.
     * @param deltaY Parameter description.
     */
    public static void pan(Context context, float deltaX, float deltaY) {
        Transform3D transform = context.getViewingPlatformTransform();
        Matrix3f matrix = new Matrix3f();
        transform.get(matrix);
        Vector3f directionX = new Vector3f();
        Vector3f directionY = new Vector3f();
        matrix.getColumn(0, directionX);
        matrix.getColumn(1, directionY);

        // get current translation of the ViewingPlatform
        Vector3f translation = new Vector3f();
        transform.get(translation);
        directionX.scale(deltaX);
        translation.add(directionX);
        directionY.scale(deltaY);
        translation.add(directionY);
        context.setViewingPlatformPosition(new Point3d(translation));
    }

    /**
     * This method checks the mouseEvent (fail early, fail fast)
     *
     * @param mouseEvent Description of parameter
     *
     * @return Description of the returned value
     */
    protected boolean checkCriteria(MouseEvent mouseEvent) {

        // fail early, fail fast procedure for dragging
        if (mouseEvent.getID() != MouseEvent.MOUSE_DRAGGED) {
            return false;
        }
        if ((MouseEvent.BUTTON3_MASK & mouseEvent.getModifiers()) == 0) {
            return false;
        }
        if (mouseEvent.getClickCount() != 0) {
            return false;
        }
        if (mouseEvent.isAltDown()) {
            return false;
        }
        if (mouseEvent.isControlDown()) {
            return false;
        }
        if (mouseEvent.isShiftDown()) {
            return false;
        }
        return true;
    }
}
