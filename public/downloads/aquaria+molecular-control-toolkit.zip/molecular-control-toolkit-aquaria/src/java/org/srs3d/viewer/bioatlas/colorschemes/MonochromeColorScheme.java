/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.colorschemes;

import java.util.Map;
import java.util.Vector;

import javax.media.j3d.Appearance;
import javax.vecmath.Color3f;

import org.srs3d.viewer.j3d.AbstractColorScheme;
import org.srs3d.viewer.j3d.AppearanceHelper;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.objects.AbstractObject;

/**
 * The <code>MonochromeColorScheme</code> applies only for atom and bond representations.
 * The CPK color scheme is a standard method for coloring atoms by element.
 *
 * @author Karsten Klein
 *
 * @created March 20, 2001
 */
public class MonochromeColorScheme extends AbstractColorScheme {
    private static int id = 1;
    private Color3f color = new Color3f(0.8f, 0.8f, 0.8f);
    private String description = "unspecified #" + id++;
    private String name = "Monochromatic";

    /**
     * Constructor description.
     *
     * @param contextData Parameter description.
     */
    public MonochromeColorScheme(ContextData contextData) {
        super(contextData);
        setComplete(true);
    }

    /**
     * Constructor description.
     *
     * @param contextData Parameter description.
     * @param color Parameter description.
     */
    public MonochromeColorScheme(ContextData contextData, Color3f color) {
        super(contextData);
        setComplete(true);
        setColor(color);
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public Color3f getColor() {
        return color;
    }

    /**
     * Description of the method
     *
     * @param object Description of parameter
     * @param appearance Description of parameter
     */
    public boolean modify(AbstractObject object, Appearance appearance) {
        AppearanceHelper.enableVertexColors(appearance, false);
        AppearanceHelper.modifyAppearance(appearance, color);
        return true;
    }

    /**
     * Method description.
     *
     * @param color Parameter description.
     */
    public void setColor(Color3f color) {
        this.color = color;
    }

    /**
     * Method description.
     *
     * @param map Parameter description.
     *
     * @return Return description.
     */
    public Map getInformation(Map map) {
        map = super.getInformation(map);
        Vector order = new Vector();
        order.add(description);
        map.put(description, color);
        map.put("NAME", name);
        map.put("ORDER", order);
        return map;
    }

    /**
     * Method description.
     *
     * @param description Parameter description.
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * Method description.
     *
     * @param name Parameter description.
     */
    public void setName(String name) {
        this.name = name;
    }
}
