/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.annotation.colorschemes;

import javax.media.j3d.Appearance;

import org.srs3d.viewer.annotation.objects.Referenceable;
import org.srs3d.viewer.j3d.AppearanceHelper;
import org.srs3d.viewer.j3d.AppearanceManager.TextureColors;
import org.srs3d.viewer.j3d.Colorable;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.util.ExceptionHandler;

/**
 * This implementation of the colorscheme interface tears down information from other
 * contexts to determine the appropriate object colors. It doesn't provide any colors
 * settings itself.
 *
 * @author Karsten Klein
 *
 * @created July 20, 2001
 * @reviewed January 09, 2002
 */
public class AnnotationColorScheme
    extends org.srs3d.viewer.bioatlas.colorschemes.SimpleColorScheme {
    private ContextData referenceContextData = null;

    /**
     * <code>AnnotationColorScheme</code> constructor.
     *
     * @param contextData Description of parameter.
     * @param referenceContextData Description of parameter.
     */
    public AnnotationColorScheme(ContextData contextData,
        ContextData referenceContextData) {
        super(contextData);
        this.referenceContextData = referenceContextData;
    }

    /**
     * Colors the annotation objects as their counterparts in the reference view.
     *
     * @param object Description of Parameter
     * @param appearance Description of parameter.
     *
     * @return Description of the returned value.
     */
    public boolean modify(AbstractObject object, Appearance appearance) {
        try {
            Colorable colorable = (Colorable) object;
            AppearanceHelper.modifyAppearance(appearance, colorable.getColor());
            AppearanceHelper.enableVertexColors(appearance, false);
            return true;
        } catch (ClassCastException e) {
            ExceptionHandler.handleException(e, ExceptionHandler.SILENT_IN_DEBUG);
        }
        AbstractObject refObject = object;
        try {
            refObject = ((Referenceable) object).getReference();
        } catch (ClassCastException e) {
            ExceptionHandler.handleException(e, ExceptionHandler.SILENT_IN_DEBUG);
        }

        // :NOTE: ref object is the object that we compute the color for
        // object is the object that receives the appearance changes
        // they could be identical.
        if (refObject != null) {

            // we try to read the color from the texture colors
            TextureColors textureColors =
                getContextData().getAppearanceManager().getTextureColors(object);
            if (textureColors != null) {
                AppearanceHelper.modifyAppearance(appearance,
                    textureColors.getColor(0));
                return true;
            }
        }
        return false;
    }
}
