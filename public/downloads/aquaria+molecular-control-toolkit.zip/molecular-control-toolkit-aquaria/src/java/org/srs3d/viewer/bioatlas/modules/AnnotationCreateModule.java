/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.modules;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;

import javax.swing.JColorChooser;
import javax.swing.JMenuItem;
import javax.vecmath.Color3f;

import org.srs3d.viewer.bioatlas.PopupContext;
import org.srs3d.viewer.bioatlas.objects.Annotation;
import org.srs3d.viewer.bioatlas.objects.Feature;
import org.srs3d.viewer.bioatlas.operations.CreateAnnotationOperation;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.ProcessedSelection;
import org.srs3d.viewer.j3d.SelectionManager;
import org.srs3d.viewer.j3d.behaviors.UpdateBehavior;
import org.srs3d.viewer.j3d.behaviors.dispatcher.Dispatch;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.objects.Operation;
import org.srs3d.viewer.objects.visitors.ObjectCollector;
import org.srs3d.viewer.swing.Menu;
import org.srs3d.viewer.util.Log;

/**
 * Menu module enabling to switch between the epxert menu mode and the reduced menu.
 *
 * @author Karsten Klein
 *
 * @created May 14, 2001
 */
public class AnnotationCreateModule extends AbstractModule {
    private static final Log log = new Log(AnnotationCreateModule.class);
    private JMenuItem component = null;
    private transient Menu annotationMenu = null;

    /**
     * Constructor description.
     *
     * @param name Parameter description.
     * @param contextData Parameter description.
     */
    public AnnotationCreateModule(String name, ContextData contextData) {
        super(name, contextData);

        // register CREATE_ANNOTATION dispatch
        Dispatch dispatch =
            new Dispatch() {
                public void dispatch(ContextData contextData,
                    Operation operation) {
                    processCreateAnnotation(contextData, operation);
                }
            };
        ArrayList dispatches = new ArrayList(1);
        dispatches.add(dispatch);
        contextData.getDispatcher().registerDispatches("CREATE_ANNOTATION",
            dispatches);

        // register REMOVE_ALL_USERANNOTATIONS
        dispatch =
            new Dispatch() {
                    public void dispatch(final ContextData contextData,
                        Operation operation) {
                        contextData.getContext().addUpdateCallback(new UpdateBehavior.Callback() {
                                public void execute() {
                                    removeAll(contextData);
                                }
                            });
                    }
                };
        dispatches = new ArrayList(1);
        dispatches.add(dispatch);
        contextData.getDispatcher().registerDispatches("REMOVE_ALL_USERANNOTATIONS",
            dispatches);
    }

    /**
     * Gets the <code>component</code> attribute of the <code>SolidRenderingModule</code>
     * object.
     *
     * @return The <code>component</code> value.
     */
    public Component getComponent() {
        if (component == null) {
            component = new JMenuItem(getName());
            component.addActionListener(this);
        }
        return component;
    }

    /**
     * Description of the method.
     */
    public void updateIntern() {
        Collection set = collectFeatureObjects();
        if (component != null) {
            component.setEnabled(!set.isEmpty());
        }
    }

    private Collection collectFeatureObjects() {
        SelectionManager selectionManager =
            getContextData().getSelectionManager();
        ProcessedSelection processedSelection =
            selectionManager.getProcessedSelection(selectionManager.getSelection());
        Collection set =
            processedSelection.getObjectCollection("Feature-Selection");
        if (set == null) {
            HashSet collapsed = new HashSet();
            getContextData().getObjectManager().collapseUpExtended(selectionManager.getSelection(),
                collapsed);
            ObjectCollector objectCollector = new ObjectCollector(null);
            objectCollector.visit(collapsed);
            set = objectCollector.getObjects();
            set.addAll(collapsed);
            processedSelection.setObjectCollection("Feature-Selection", set);
        }
        return set;
    }

    /**
     * Method description.
     *
     * @param e Parameter description.
     */
    public void react(ActionEvent e) {
        Collection set = collectFeatureObjects();
        if (set != null) {
            String name =
                javax.swing.JOptionPane.showInputDialog(getContextData()
                                                            .getComponent(),
                    org.srs3d.viewer.bioatlas.Parameter.applicationName +
                    " - Enter annotation name");
            if (name != null && name.length() > 0) {
                java.awt.Color chooserColor = new java.awt.Color(205, 205, 0);
                JColorChooser colorChooser = new JColorChooser(chooserColor);

                // we're only interested in the nice panel
                colorChooser.removeChooserPanel(colorChooser.getChooserPanels()[0]);
                colorChooser.removeChooserPanel(colorChooser.getChooserPanels()[1]);
                JColorChooser.createDialog(getContextData().getComponent(),
                    org.srs3d.viewer.bioatlas.Parameter.applicationName +
                    "- Choose annotation color", true, colorChooser, null, null)
                             .setVisible(true);
                chooserColor = colorChooser.getColor();
                if (chooserColor != null) {
                    Color3f color = new Color3f();
                    color.x = chooserColor.getRed();
                    color.y = chooserColor.getGreen();
                    color.z = chooserColor.getBlue();
                    color.scale(1.0f / 255);

                    // create appropriate operation
                    CreateAnnotationOperation op =
                        new CreateAnnotationOperation(getContextData()
                                                          .getContext(),
                            "CREATE_ANNOTATION", name, color, null);

                    // execute operation
                    getContextData().getDispatcher().runDispatch(op);
                }
            }
        }
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     * @param operation Parameter description.
     */
    public void processCreateAnnotation(final ContextData contextData,
        Operation operation) {
        CreateAnnotationOperation op = (CreateAnnotationOperation) operation;
        Collection set = collectFeatureObjects();
        if (set != null) {
            Annotation annotation = new Annotation();
            annotation.setName(op.getAnnotationName());
            annotation.setColor(op.getAnnotationColor());
            annotation.setDescription("");
            Feature feature = new Feature();
            feature.addObjects(set);
            feature.setName(op.getAnnotationName());
            feature.setDescription("");
            feature.setColor(op.getAnnotationColor());
            annotation.addFeature(feature);

            // additionally add annotation to container
            contextData.getObjectContainer().addObject(annotation);
            contextData.addProperty("USER-ANNOTATIONS", annotation);
            Operation toggleOperation =
                new Operation(contextData.getContext(), "TOGGLE_ACTIVATION",
                    annotation);
            toggleOperation.setSerializable(false);
            contextData.getDispatcher().runDispatch(toggleOperation);
            contextData.getContext().addUpdateCallback(new org.srs3d.viewer.j3d.behaviors.UpdateBehavior.Callback() {
                    public void execute() {
                        org.srs3d.viewer.bioatlas.dispatcher.NavigateUpDispatcher.updateDescriptionOverlay(contextData,
                            null);
                    }
                });
            if (annotationMenu.size() == 1) {
                annotationMenu.add(new org.srs3d.viewer.swing.SeparatorModule());
            }
            annotationMenu.add(new AnnotationModule(annotation.getName(),
                    contextData, annotation));
            ((AbstractModule) annotationMenu.getLastModule()).setOperationSerializeable(false);
        } else {
            log.error("processed selection corrupted.");
        }
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     */
    public void removeAll(ContextData contextData) {

        // removes all user annotation made in the context
        Collection annotations =
            (Collection) contextData.getProperty("USER-ANNOTATIONS");
        if (annotations != null) {
            Iterator iterator = annotations.iterator();
            while (iterator.hasNext()) {
                contextData.getObjectContainer().removeObject((AbstractObject) iterator.next());
            }
        }
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     * @param popupContext Description of parameter.
     * @param listener Description of parameter.
     * @param annotations Description of parameter.
     * @param selections Description of parameter.
     * @param activatedSelections Description of parameter.
     *
     * @return Description of the returned value.
     */
    public static org.srs3d.viewer.swing.Menu createMenu(
        ContextData contextData, PopupContext popupContext,
        Collection annotations, Collection selections,
        Collection activatedSelections) {
        org.srs3d.viewer.swing.Menu m =
            new org.srs3d.viewer.swing.Menu("Annotations");
        AnnotationCreateModule module =
            new AnnotationCreateModule("Create New...", contextData);
        module.annotationMenu = m;
        m.add(module);
        ((AbstractModule) m.getLastModule()).setOperationSerializeable(false);
        if (!annotations.isEmpty()) {
            Iterator iterator = annotations.iterator();
            Annotation annotation;
            boolean needsSeparator = true;
            while (iterator.hasNext()) {
                annotation = (Annotation) iterator.next();
                if (annotation.isEnabled()) {
                    if (needsSeparator) {
                        m.add(new org.srs3d.viewer.swing.SeparatorModule());
                        needsSeparator = false;
                    }
                    m.add(new AnnotationModule(annotation.getName(),
                            contextData, annotation));
                    ((AbstractModule) m.getLastModule()).setOperationSerializeable(false);
                }
            }
        }
        return m;
    }
}
