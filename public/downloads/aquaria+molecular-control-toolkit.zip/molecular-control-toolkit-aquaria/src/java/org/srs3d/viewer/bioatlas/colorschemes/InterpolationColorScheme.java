/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.colorschemes;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeSet;
import java.util.Vector;

import javax.media.j3d.Appearance;
import javax.vecmath.Color3f;

import org.srs3d.viewer.j3d.AbstractColorScheme;
import org.srs3d.viewer.j3d.AppearanceHelper;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.vecmath.AbstractCurve3f;
import org.srs3d.viewer.vecmath.CubicBezierCurve3f;

/**
 * @author Karsten Klein
 *
 * @created March 20, 2001
 */
public class InterpolationColorScheme extends AbstractColorScheme {

    /** The cubic bezier curve interpolates the colors. */
    private AbstractCurve3f colorCurve = null;

    /** This map collects all the registed objects. */
    private Hashtable indexMap = new Hashtable();

    /**
     * Constructor description.
     *
     * @param contextData Parameter description.
     */
    public InterpolationColorScheme(ContextData contextData) {
        super(contextData);
        setComplete(true);

        // we use a cubic bezier curve for interpolation of the colors
        colorCurve = new CubicBezierCurve3f();
        ArrayList colors = new ArrayList();
        float max = 1f;
        float max2 = 1f;
        float min = 0.3f;
        float min2 = 0.3f;
        colors.add(new Color3f(min2, min2, max));
        colors.add(new Color3f(min, max2, max2));
        colors.add(new Color3f(min2, max, min2));
        colors.add(new Color3f(max2, max2, min));
        colors.add(new Color3f(max, min2, min2));
        colorCurve.setCoordinates(colors);
    }

    /**
     * Gets the <code>information</code> attribute of the <code>ChainColorScheme</code>
     * object.
     *
     * @return The <code>information</code> value.
     */
    public Map getInformation(Map map) {
        map = super.getInformation(map);
        TreeSet treeSet = new TreeSet();
        Iterator iterator = indexMap.keySet().iterator();
        Object object;
        int index;
        while (iterator.hasNext()) {
            object = iterator.next();
            map.put(object.toString(), computeColor(object));
            treeSet.add(object.toString());
        }
        Vector order = new Vector(treeSet);
        map.put("NAME", "Chain");
        map.put("ORDER", order);
        return map;
    }

    /**
     * Description of the method.
     *
     * @param object Description of parameter.
     * @param appearance Description of parameter.
     *
     * @return Description of the returned value.
     */
    public boolean modify(AbstractObject object, Appearance appearance) {

        // register the identifier (if not registered yet)
        register(object);
        AppearanceHelper.enableVertexColors(appearance, false);
        AppearanceHelper.modifyAppearance(appearance, computeColor(object));
        return true;
    }

    /**
     * Maps a object to a certain color.
     *
     * @param object Description of parameter.
     *
     * @return <code>Color3f</code> - the color mapped to the specified char.
     */
    public Color3f computeColor(Object object) {
        float parameter = ((Float) indexMap.get(object)).floatValue();
        Color3f color = new Color3f();
        color.set(colorCurve.computePoint(parameter));
        return color;
    }

    /**
     * Description of the method Registers a string to the static object list.
     *
     * @param object Description of parameter.
     */
    public void register(Object object) {
        if (!indexMap.containsKey(object)) {
            float parameter = 0;
            int numerator = indexMap.size();
            if (numerator != 0) {
                int exp = (int) (Math.log(numerator) / Math.log(2));
                int denominator = (int) Math.pow(2, exp);
                if (numerator != denominator) {
                    exp++;
                    denominator *= 2;
                }
                numerator -= (denominator / 2);
                numerator = 2 * numerator - 1;
                parameter = numerator;
                parameter /= denominator;
            }
            indexMap.put(object, new Float(parameter));
        }
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public AbstractCurve3f getColorCurve() {
        return colorCurve;
    }

    /**
     * Method description.
     *
     * @param colorCurve Parameter description.
     */
    public void setColorCurve(AbstractCurve3f colorCurve) {
        this.colorCurve = colorCurve;
    }
}
