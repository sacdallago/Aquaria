/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.objects;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.TreeSet;

import javax.vecmath.Color3f;

import org.srs3d.viewer.j3d.Colorable;
import org.srs3d.viewer.j3d.Linkable;
import org.srs3d.viewer.j3d.objects.Link;
import org.srs3d.viewer.objects.AbstractObject;

/**
 * Annotations accumulate features and are a special link. The current mechanism cannot
 * directly acitvate an annotation, but all features of an annotation. An annotation is
 * active if all it's features are active.
 *
 * @author Karsten Klein
 *
 * @created October 5, 2001
 */
public class Annotation extends AbstractObject implements Colorable, Linkable {
    private ArrayList features = new ArrayList();
    private String name = null;
    private Color3f color = new Color3f(0.3f, 0.3f, 0.3f);
    private Link link = null;
    private boolean isEnabled = true;
    private String description = "";

    /**
     * Sets the <code>name</code> attribute of the <code>Annotation</code> object.
     *
     * @param name The new <code>name</code> value.
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Sets the <code>color</code> attribute of the <code>Annotation</code> object.
     *
     * @param color The new <code>color</code> value.
     */
    public void setColor(Color3f color) {
        this.color.set(color);
    }

    /**
     * Gets the <code>name</code> attribute of the <code>Annotation</code> object.
     *
     * @return The <code>name</code> value.
     */
    public String getName() {
        return name;
    }

    /**
     * Gets the features attribute of the <code>Annotation</code> object.
     *
     * @return The <code>features</code> value.
     */
    public ArrayList getFeatures() {
        return features;
    }

    /**
     * Gets the <code>allObjects</code> attribute of the <code>Annotation</code> object.
     *
     * @param objects Description of parameter.
     */
    public void getAllObjects(Collection objects) {
        objects.addAll(features);
    }

    /**
     * Gets the <code>color</code> attribute of the <code>Annotation</code> object.
     *
     * @return The <code>color</code> value.
     */
    public Color3f getColor() {
        return color;
    }

    /**
     * Adds a <code>Feature</code> object to the <code>Annotation</code> object.
     *
     * @param feature The <code>Feature</code> object to be added.
     */
    public void addFeature(Feature feature) {
        features.add(feature);
    }

    /**
     * Adds a <code>AllFeatures</code> object to the <code>Annotation</code> object.
     *
     * @param features The <code>AllFeatures</code> object to be added.
     */
    public void addAllFeatures(Collection features) {
        this.features.addAll(features);
    }

    /**
     * Description of the method.
     */
    public void cleanup() {
        color = null;
        link = null;
        cleanup(features);
        features = null;
    }

    /**
     * Description of the method.
     *
     * @return Description of the returned value.
     */
    public String toString() {
        return getName() + " " + getDescription();
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public Link getLink() {
        return link;
    }

    /**
     * Method description.
     *
     * @param link Parameter description.
     */
    public void setLink(Link link) {
        this.link = link;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public String getDescription() {
        return description;
    }

    /**
     * Method description.
     *
     * @param description Parameter description.
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public boolean isEnabled() {
        return isEnabled;
    }

    /**
     * Method description.
     *
     * @param isEnabled Parameter description.
     */
    public void setEnabled(boolean isEnabled) {
        this.isEnabled = isEnabled;
    }

    /**
     * Method description.
     */
    public void sortFeatures() {
        Comparator comparator =
            new Comparator() {
                public int compare(Object o1, Object o2) {
                    Feature feature1 = (Feature) o1;
                    Feature feature2 = (Feature) o2;
                    int result =
                        feature1.getDescriptionHash() -
                        feature2.getDescriptionHash();

                    // don't allow them to be equal
                    if (result == 0) {
                        return -1;
                    }
                    return result;
                }

                public boolean equals(Object obj) {
                    return false;
                }
            };
        TreeSet set = new TreeSet(comparator);
        set.addAll(features);
        features = new ArrayList(set);
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public int getDescriptionHash() {
        int hash = 0;
        String string = getDescription();
        for (int i = 0; i < string.length(); i++) {
            hash += string.charAt(i);
        }
        return hash;
    }
}
