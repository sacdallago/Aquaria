/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.objects.strategies;

import java.util.HashMap;
import java.util.Map;

import org.srs3d.viewer.j3d.Reaction;
import org.srs3d.viewer.objects.Command;
import org.srs3d.viewer.objects.Strategy;

/**
 * Basic implementation of a strategy that uses reaction to operate with commands. The
 * mechanism maps the command to the associated (command specific) reaction that
 * executes the command.
 *
 * @author Karsten Klein
 *
 * @created April 03, 2001
 */
public class AbstractStrategy implements Strategy {
    private Map reactionMap = new HashMap();

    /**
     * Maps the command to teh appropriate reaction and executed the reaction. If no
     * reaction can be mapped the command will be executed directly. Note that
     * subclasses of a registered command are no covered.
     *
     * @param command Command to execute.
     */
    public final void execute(Command command) {
        Reaction reaction = (Reaction) reactionMap.get(command.getClass());
        if (reaction == null) {
            command.execute();
        } else {
            reaction.execute(command);
        }
    }

    /**
     * Registers a reaction to a certain specified commandclass. This registration is
     * used for mapping command classes to reactions.
     *
     * @param commandClass Command class to map to the selection.
     * @param reaction Reaction to associate with the command class.
     */
    public final void register(Class commandClass, Reaction reaction) {
        reactionMap.put(commandClass, reaction);
    }
}
