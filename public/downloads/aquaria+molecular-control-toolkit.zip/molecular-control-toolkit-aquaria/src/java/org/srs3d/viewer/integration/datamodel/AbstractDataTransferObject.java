/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.integration.datamodel;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import org.srs3d.viewer.integration.interfaces.DataTransferObject;
import org.srs3d.viewer.integration.interfaces.GenericDataProvider;

/**
 * Abstract implementation of the DataProvider and DataTransferObject interface.
 *
 * @author Karsten Klein
 *
 * @created September 24, 2002
 */
public abstract class AbstractDataTransferObject implements GenericDataProvider,
    DataTransferObject, Serializable {
    private Map map = new HashMap();

    /**
     * Set the object association for a specified key
     *
     * @param key Key for identification.
     * @param object Object to associate with the key.
     */
    public void set(Object key, Object object) {
        map.put(key, object);
    }

    /**
     * Get key associated object;
     *
     * @param key Key for identification.
     *
     * @return The associated object.
     */
    public Object get(Object key) {
        return map.get(key);
    }

    /**
     * Remove a key object association.
     *
     * @param key Key for identification.
     */
    public void remove(Object key) {
        map.remove(key);
    }

    /**
     * Remove all key object associations.
     */
    public void clear() {
        map.clear();
    }

    /**
     * Description of the method.
     *
     * @return Return parameter description.
     */
    public String toString() {
        return "DataTransferObject[" + map + "]";
    }
}
