/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.modules;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;

import javax.swing.JCheckBoxMenuItem;

import org.srs3d.viewer.bioatlas.attributes.Labeled;
import org.srs3d.viewer.bioatlas.objects.Layer;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.ProcessedSelection;
import org.srs3d.viewer.j3d.Selection;
import org.srs3d.viewer.j3d.commands.LabelCommand;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.objects.ObjectContainer;
import org.srs3d.viewer.objects.ObjectManager;
import org.srs3d.viewer.objects.State;
import org.srs3d.viewer.objects.StateManager;
import org.srs3d.viewer.objects.StrategyManager;
import org.srs3d.viewer.objects.visitors.ObjectCollector;

/**
 * <code>Module</code> implementation displaying a label for the current selection. The
 * label is computed dynamically depending of the current selection.
 *
 * @author Karsten Klein
 *
 * @created May 14, 2001
 */
public class LabelModule extends ProcessModule {

    /** Description of the field. */
    public static final int CHECK_YES = 1;

    /** Description of the field. */
    public static final int CHECK_NO = 2;

    /** Description of the field. */
    public static final int CHECK_SOME = 3;

    /** Description of the field. */
    public static final int CHECK_DISABLE = 4;

    /** Description of the field. */
    public boolean isGlobal = false;
    private JCheckBoxMenuItem component = null;
    private transient Collection processedObjects = new HashSet();
    private transient ObjectContainer objectContainer = null;
    private transient int labelState = CHECK_DISABLE;

    /**
     * <code>LabelModule</code> constructor.
     *
     * @param name Description of parameter.
     * @param contextData Description of parameter.
     */
    public LabelModule(String name, ContextData contextData) {
        this(name, contextData, false);
    }

    /**
     * <code>LabelModule</code> constructor.
     *
     * @param name Description of parameter.
     * @param contextData Description of parameter.
     * @param isGlobal Description of parameter.
     */
    public LabelModule(String name, ContextData contextData, boolean isGlobal) {
        super(name, contextData);
        this.isGlobal = isGlobal;
    }

    /**
     * Gets the <code>component</code> attribute of the <code>SolidRenderingModule</code>
     * object.
     *
     * @return The <code>component</code> value.
     */
    public Component getComponent() {
        if (component == null) {
            component = new JCheckBoxMenuItem(getName(), false);
            component.addActionListener(this);
            if (getAccelerator() != null) {
                component.setAccelerator(getAccelerator());
            }
        }
        return component;
    }

    /**
     * Gets the <code>moduleIdPrefix</code> attribute of the <code>LabelModule</code>
     * object.
     *
     * @return The <code>moduleIdPrefix</code> value.
     */
    public String getModuleIdPrefix() {
        return "LABEL-";
    }

    /**
     * Gets the <code>labelCandidates</code> attribute of the <code>LabelModule</code>
     * object.
     *
     * @param contextData Description of parameter.
     *
     * @return The <code>labelCandidates</code> value.
     */
    public Collection getLabelCandidates(ContextData contextData) {
        String cacheIdentifier =
            "LabelCandidates-" + (isGlobal ? "global" : "local");
        ProcessedSelection processedSelection =
            contextData.getSelectionManager().getProcessedSelection(contextData.getSelectionManager()
                                                                               .getSelection());
        Collection set;
        set = processedSelection.getObjectCollection(cacheIdentifier);
        if (set == null) {
            Selection selection =
                contextData.getSelectionManager().getSelection();
            if (isGlobal) {
                Collection objects =
                    RepresentationModule.collectObjects(contextData);
                set = new HashSet(objects);
                contextData.getObjectManager().getDownAssociations(objects, set);
            } else {
                set = new HashSet(selection);
                contextData.getObjectManager().getDownAssociations(selection,
                    set);
            }
            excludeObjects(contextData, set);
            processedSelection.setObjectCollection(cacheIdentifier, set);
        }
        return set;
    }

    /**
     * Description of the method.
     *
     * @param e Description of parameter.
     */
    public void process(ActionEvent e) {
        if (objectContainer != null) {
            final ContextData contextData = getContextData();
            contextData.getContext().addUpdateCallback(new org.srs3d.viewer.j3d.behaviors.UpdateBehavior.Callback() {
                    public void execute() {
                        StrategyManager strategyManager =
                            contextData.getStrategyManager();
                        Iterator iterator = processedObjects.iterator();
                        AbstractObject object;
                        boolean isLabel = (labelState & CHECK_NO) != 0;
                        if ((labelState & CHECK_YES) != 0) {
                            isLabel = false;
                        }
                        while (iterator.hasNext()) {
                            object = (AbstractObject) iterator.next();
                            LabelCommand labelCommand =
                                new LabelCommand(contextData,
                                    object.toString(), isLabel);
                            labelCommand.setLabelContainer(objectContainer);
                            strategyManager.execute(object, labelCommand);
                        }
                    }
                });
        }
    }

    /**
     * Description of the method.
     */
    public void updateIntern() {
        ContextData contextData = getContextData();
        processedObjects.clear();
        Collection set = getLabelCandidates(contextData);
        preProcess(contextData, set, processedObjects, true);

        // :FIXME: remove invisible objects from the processed objects if
        //   not checked (enable to turn off labels of invisible objects; never label
        //   sequence elements)
        boolean isChecked = false;
        boolean isEnabled = true;
        labelState = checkLabeled(contextData, processedObjects);
        isChecked =
            (labelState & CHECK_YES) != 0 && (labelState & CHECK_DISABLE) == 0;
        isEnabled = (labelState & CHECK_DISABLE) == 0;
        if (!isEnabled) {
            processedObjects.clear();
            preProcess(contextData, set, processedObjects, false);
            int localLabelState = checkLabeled(contextData, processedObjects);
            if ((localLabelState & CHECK_YES) != 0) {
                labelState = CHECK_YES;
                isChecked = true;
                isEnabled = true;
            }
        }

        // we use the set here, because the identified objects could have no association
        // to the container anymore
        objectContainer = searchContainer(contextData, set);
        if (component != null) {
            component.setState(isChecked);
            component.setEnabled(isEnabled);
        }
    }

    /**
     * Searches for a rooting ObjectContainer for the objects in the specified
     * collection.
     *
     * @param contextData Description of parameter.
     * @param objects Description of parameter.
     *
     * @return Description of the returned value.
     */
    public ObjectContainer searchContainer(ContextData contextData,
        Collection objects) {
        if (!objects.isEmpty()) {
            ObjectManager objectManager = contextData.getObjectManager();
            ArrayList collapsed = new ArrayList(objects.size());
            objectManager.collapseUpExtended(objects, collapsed);
            ArrayList roots = new ArrayList(collapsed.size());
            objectManager.getUpAssociations(collapsed, roots);
            roots.addAll(collapsed);
            ObjectManager.extract(roots, ObjectContainer.class);
            ObjectContainer root = null;
            if (!roots.isEmpty()) {
                root = (ObjectContainer) roots.get(0);
            }
            return root;
        }
        return null;
    }

    /**
     * Collapses up the specified set and removes
     *
     * @param contextData Description of parameter.
     * @param objects Description of parameter.
     * @param processedObjects Description of parameter.
     * @param useAssociations Description of parameter.
     */
    public void preProcess(ContextData contextData, Collection objects,
        Collection processedObjects, boolean useAssociations) {

        // :FIXME: the processed selection may possible be cached for sharing with
        //  other modules
        ObjectManager objectManager = contextData.getObjectManager();
        if (!objects.isEmpty()) {
            Collection set = new HashSet(objects.size());
            objectManager.collapseUpExtended(objects, set);
            processedObjects.addAll(set);
        }
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     * @param set Description of parameter.
     */
    public static void excludeObjects(ContextData contextData, Collection set) {
        Collection layers = new ArrayList();
        ObjectManager.extract(contextData.getObjectContainer().getObjects(),
            layers, Layer.class);
        Iterator iterator = layers.iterator();
        Layer layer;
        while (iterator.hasNext()) {
            layer = (Layer) iterator.next();
            if (!layer.isSequenceLayer()) {
                iterator.remove();
            }
        }

        // got all sequence layers
        ObjectCollector objectCollector = new ObjectCollector(null);
        objectCollector.visit(layers);
        set.removeAll(objectCollector.getObjects());
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     * @param objects Description of parameter.
     *
     * @return Description of the returned value.
     */
    private static int checkLabeled(ContextData contextData, Collection objects) {
        if (!objects.isEmpty()) {
            StateManager stateManager = contextData.getStateManager();
            Iterator iterator = objects.iterator();
            AbstractObject object;
            State.Immutable state;
            int checkResult = 0;
            while (iterator.hasNext()) {
                state =
                    stateManager.getImmutableState((AbstractObject) iterator.next());
                if (!state.hasAttribute(Labeled.class)) {
                    checkResult |= CHECK_NO;
                } else {
                    checkResult |= CHECK_YES;
                }
            }
            return checkResult;
        }
        return CHECK_DISABLE;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public String createReport() {
        String report = super.createReport();
        if (component != null) {
            report += "|";
            report += component.getState() ? "C" : "U";
        }
        return report;
    }
}
