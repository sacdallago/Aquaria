/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.modules;

import java.util.Collection;
import java.util.Iterator;
import java.util.Vector;

import org.srs3d.viewer.bioatlas.objects.Residue;
import org.srs3d.viewer.bioatlas.objects.Subchain;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.attributes.Visible;
import org.srs3d.viewer.j3d.commands.ExecuteClassCommand;
import org.srs3d.viewer.j3d.commands.ParentCommand;
import org.srs3d.viewer.j3d.commands.PreSelectCommand;
import org.srs3d.viewer.j3d.commands.PropagateClassCommand;
import org.srs3d.viewer.j3d.commands.VisibleCommand;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.objects.Command;
import org.srs3d.viewer.objects.State;
import org.srs3d.viewer.objects.StateManager;

/**
 * @author Karsten Klein
 *
 * @created November 8, 2001
 */
public class VisibleCheck extends RepresentationCheck {
    public static final VisibleCheck sharedInstance = new VisibleCheck();

    /**
     * Description of the method.
     *
     * @param objects Description of parameter.
     *
     * @return Description of the returned value.
     */
    public int check(ContextData contextData, Collection objects) {
        int checkResult = 0;
        StateManager stateManager = contextData.getStateManager();
        State.Immutable state;
        Collection extracted = extractDownAssociated(contextData, objects);
        Iterator iterator = extracted.iterator();
        AbstractObject object;
        while ((checkResult & CHECK_YES) == 0 && iterator.hasNext()) {
            object = (AbstractObject) iterator.next();
            state = stateManager.getImmutableState(object);
            checkResult |= check(object, state);
        }
        return checkResult;
    }

    /**
     * Description of the method.
     *
     * @param object Description of parameter.
     * @param state Description of parameter.
     *
     * @return Description of the returned value.
     */
    public int check(AbstractObject object, State.Immutable state) {
        if (state.hasAttribute(Visible.class)) {
            return CHECK_YES;
        } else {
            return CHECK_NO;
        }
    }

    /**
     * Gets the <code>offCommands</code> attribute of the <code>VisibleCheck</code>
     * class.
     *
     * @param contextData Description of parameter.
     * @param offCommands Description of parameter.
     */
    public void getAllOffCommands(ContextData contextData,
        Collection offCommands) {
        Command command = new PreSelectCommand(contextData);
        command = new ExecuteClassCommand(contextData, command, Subchain.class);
        command = new ParentCommand(contextData, command);
        command = new ExecuteClassCommand(contextData, command, Residue.class);
        offCommands.add(command);
        command = new VisibleCommand(contextData, false);
        command = new PropagateClassCommand(contextData, command, null);
        offCommands.add(command);
    }

    /**
     * Gets the <code>onCommands</code> attribute of the <code>VisibleCheck</code> class.
     *
     * @param contextData Description of parameter.
     * @param onCommands Description of parameter.
     */
    public void getAllOnCommands(ContextData contextData, Collection onCommands) {
        Command command = new PreSelectCommand(contextData);
        command = new ExecuteClassCommand(contextData, command, Subchain.class);
        command = new ParentCommand(contextData, command);
        command = new ExecuteClassCommand(contextData, command, Residue.class);
        onCommands.add(command);
        command = new VisibleCommand(contextData, true);
        command = new PropagateClassCommand(contextData, command, null);
        onCommands.add(command);
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     *
     * @return Description of the returned value.
     */
    public static RepresentationModule createRepresentationModule(
        ContextData contextData) {
        Vector onCommands = new Vector();
        Vector offCommands = new Vector();
        sharedInstance.getAllOnCommands(contextData, onCommands);
        sharedInstance.getAllOffCommands(contextData, offCommands);
        return new RepresentationModule("Visible", contextData, onCommands,
            offCommands, sharedInstance);
    }
}
