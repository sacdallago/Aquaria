/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.annotation.contexts;

import java.awt.GraphicsConfiguration;

import javax.media.j3d.BoundingSphere;
import javax.media.j3d.Transform3D;
import javax.vecmath.Matrix4f;
import javax.vecmath.Point3d;

import org.srs3d.viewer.j3d.behaviors.MouseOverBehavior;
import org.srs3d.viewer.j3d.behaviors.SelectZoomBehavior;
import org.srs3d.viewer.j3d.behaviors.ZoomBehavior;

/**
 * AnnotationContext
 *
 * @author Christian Zofka
 *
 * @created August 13, 2001
 */
public class AnnotationContext extends AbstractAnnotationContext {
    private float contentHeight = -1f;

    /**
     * Constructs a context with the appropriate <code>GraphicsContext</code>
     *
     * @param graphicsConfiguration Description of parameter
     */
    public AnnotationContext(GraphicsConfiguration graphicsConfiguration) {
        super(graphicsConfiguration);
    }

    /**
     * <code>AnnotationContext</code> contructor.
     */
    public AnnotationContext() {
        super();
    }

    /**
     * Constructs a context with the appropriate <code>GraphicsContext</code> and offset
     * screen flag
     *
     * @param graphicsConfiguration Description of parameter
     * @param offScreen Description of parameter
     */
    public AnnotationContext(GraphicsConfiguration graphicsConfiguration,
        boolean offScreen) {
        super(graphicsConfiguration, offScreen);
    }

    /**
     * Sets the <code>ViewingPlatformTransform</code> attribute of the
     * <code>Context</code> object.
     *
     * @param transform The new <code>ViewingPlatformTransform</code> value.
     */
    public void setViewingPlatformTransform(Transform3D transform) {
        if (getSceneTransform() != null) {

            // modifies the transform
            Matrix4f matrix = new Matrix4f();
            transform.get(matrix);

            // :FIXME: move this to a constraint for the zooming
            matrix.m23 = Math.max(50.0f, matrix.m23);
            Transform3D transformS = new Transform3D();
            getSceneTransform().getTransform(transformS);
            Matrix4f matrixScene = new Matrix4f();
            transformS.get(matrixScene);
            matrixScene.m00 = 350 / matrix.m23;
            if (contentHeight != -1f) {
                matrixScene.m11 = getHeight() / contentHeight;
            } else {
                matrixScene.m11 = 1;
            }
            transformS.set(matrixScene);
            matrix.m23 = 350;
            matrix.m03 *= matrixScene.m00;
            transform.set(matrix);
            getSceneTransform().setTransform(transformS);
            usesInternalTransformation = true;
        }
        super.setViewingPlatformTransform(transform);
    }

    /**
     * Method description.
     */
    public void setup() {
        super.setup();
        setupLights(true);

        // create a bounding sphere for the whole bunch of behaviors
        BoundingSphere bounds =
            new BoundingSphere(new Point3d(0.0, 0.0, 0.0), Double.MAX_VALUE);
        ZoomBehavior zoom = new ZoomBehavior(getContextData());
        zoom.setSchedulingBounds(bounds);
        getBehaviorLevel().addChild(zoom);
        SelectZoomBehavior zoomer = new SelectZoomBehavior(getContextData());
        zoomer.setSchedulingBounds(bounds);
        getBehaviorLevel().addChild(zoomer);
        MouseOverBehavior mouseOverBehavior =
            new MouseOverBehavior(getContextData());
        mouseOverBehavior.setEnable(true);
        mouseOverBehavior.setSchedulingBounds(bounds);
        getBehaviorLevel().addChild(mouseOverBehavior);
    }

    /**
     * Method description.
     *
     * @param contentHeight Parameter description.
     */
    public void setContentHeight(float contentHeight) {
        this.contentHeight = contentHeight;
    }
}
