/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.styles;

import java.util.Collection;
import java.util.HashSet;
import java.util.Vector;

import org.srs3d.viewer.bioatlas.attributes.AtomRepresentation;
import org.srs3d.viewer.bioatlas.attributes.Representation;
import org.srs3d.viewer.bioatlas.attributes.ResidueRepresentation;
import org.srs3d.viewer.bioatlas.attributes.SubchainRepresentation;
import org.srs3d.viewer.bioatlas.colorschemes.CPKColorScheme;
import org.srs3d.viewer.bioatlas.colorschemes.CPKGColorScheme;
import org.srs3d.viewer.bioatlas.colorschemes.MoleculeColorScheme;
import org.srs3d.viewer.bioatlas.filters.LigandFilter;
import org.srs3d.viewer.bioatlas.modules.BallAndStickCheck;
import org.srs3d.viewer.bioatlas.modules.ProximityModule;
import org.srs3d.viewer.bioatlas.modules.WireframeCheck;
import org.srs3d.viewer.bioatlas.objects.Atom;
import org.srs3d.viewer.bioatlas.objects.Coil;
import org.srs3d.viewer.bioatlas.objects.Helix;
import org.srs3d.viewer.bioatlas.objects.Layer;
import org.srs3d.viewer.bioatlas.objects.NucleicChain;
import org.srs3d.viewer.bioatlas.objects.Residue;
import org.srs3d.viewer.bioatlas.objects.Strand;
import org.srs3d.viewer.bioatlas.objects.Subchain;
import org.srs3d.viewer.bioatlas.objects.Turn;
import org.srs3d.viewer.j3d.ColorScheme;
import org.srs3d.viewer.j3d.ColorSchemeBucket;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.attributes.Visible;
import org.srs3d.viewer.j3d.commands.ColorCommand;
import org.srs3d.viewer.j3d.commands.ExpandCommand;
import org.srs3d.viewer.j3d.commands.RemoveStateCommand;
import org.srs3d.viewer.j3d.commands.RepresentationCommand;
import org.srs3d.viewer.j3d.commands.VisibleCommand;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.objects.Attribute;
import org.srs3d.viewer.objects.ObjectManager;
import org.srs3d.viewer.objects.State;
import org.srs3d.viewer.objects.StrategyManager;
import org.srs3d.viewer.objects.visitors.ObjectCollector;

/**
 * <code>BindingSiteStyle</code> .
 *
 * @author Karsten Klein
 *
 * @created July 11, 2001
 */
public class BindingSiteStyle extends FirstImpressionStyle {

    /**
     * <code>FirstImpressionStyle</code> constructor.
     *
     * @param contextData Description of parameter.
     */
    public BindingSiteStyle(ContextData contextData) {
        super(contextData);
        MoleculeColorScheme colorScheme = new MoleculeColorScheme(contextData);
        colorScheme.setColorScale(0.4f);
        colorScheme.setComplete(true);
        contextData.setProperty(MoleculeColorScheme.class, colorScheme);
    }

    protected void adaptStatePrototypes() {
        ContextData contextData = getContextData();
        State state;

        // subchain state prototype changed
        state = new State();
        state.setAttribute(Attribute.getInstance(Visible.class));
        SubchainRepresentation subchainRepresentation =
            (SubchainRepresentation) Attribute.getInstance(SubchainRepresentation.class);
        subchainRepresentation.setMode(Representation.REPRESENTATION_CATRACE);
        state.setAttribute(subchainRepresentation);
        contextData.getStatePrototypeManager().register(Helix.class, state);
        contextData.getStatePrototypeManager().register(Strand.class, state);
        contextData.getStatePrototypeManager().register(Turn.class, state);
        contextData.getStatePrototypeManager().register(Coil.class, state);
        contextData.getStatePrototypeManager().register(NucleicChain.class,
            state);

        // residue state prototype changed
        state = new State();
        state.setAttribute(Attribute.getInstance(Visible.class));
        ResidueRepresentation residueRepresentation =
            (ResidueRepresentation) Attribute.getInstance(ResidueRepresentation.class);
        residueRepresentation.setMode(Representation.REPRESENTATION_CATRACE);
        state.setAttribute(residueRepresentation);
        contextData.getStatePrototypeManager().register(Residue.class, state);

        // atom state prototype changed
        state = new State();
        state.setAttribute(Attribute.getInstance(Visible.class));
        AtomRepresentation atomRepresentation =
            (AtomRepresentation) Attribute.getInstance(AtomRepresentation.class);
        atomRepresentation.setMode(Representation.REPRESENTATION_WIREFRAME);
        state.setAttribute(atomRepresentation);
        contextData.getStatePrototypeManager().register(Atom.class, state.copy());
    }

    /**
     * Description of the method.
     *
     * @param layer Description of parameter.
     */
    public void applyColorScheme(Layer layer) {
        ColorScheme cpkColorScheme = new CPKColorScheme(getContextData());
        ColorScheme cpkgColorScheme = new CPKGColorScheme(getContextData());
        ColorSchemeBucket bucket = new ColorSchemeBucket();
        bucket.add(getColorScheme(MoleculeColorScheme.class));
        bucket.add(cpkColorScheme);
        ColorCommand colorCommand = new ColorCommand(getContextData(), bucket);
        colorCommand.setForceRecoloring(true);
        colorCommand.propagate(layer);
        ObjectCollector objectCollector =
            new ObjectCollector(new LigandFilter());
        objectCollector.visit((AbstractObject) layer);
        colorCommand = new ColorCommand(getContextData(), cpkgColorScheme);
        colorCommand.propagate(objectCollector.getObjects(), false);
        bucket.remove(cpkColorScheme);
        bucket.extend(cpkgColorScheme);
        bucket.extend(cpkColorScheme);
        getContextData().setColorSchemeBucket(bucket);
    }

    /**
     * Method description.
     *
     * @param layer Parameter description.
     */
    public void processLigands(Layer layer) {
        processWaters(layer);
        ContextData contextData = getContextData();
        StrategyManager strategyManager = contextData.getStrategyManager();

        // collect all ligands
        ObjectCollector objectCollector =
            new ObjectCollector(new LigandFilter(true));
        objectCollector.visit((AbstractObject) layer);
        ExpandCommand expand = new ExpandCommand(contextData);
        RepresentationCommand representationCommand =
            new RepresentationCommand(contextData);

        // apply ball and stick
        Vector ballAndStickCommands = new Vector();
        BallAndStickCheck.sharedInstance.getAllOnCommands(contextData,
            ballAndStickCommands);
        ballAndStickCommands.add(new VisibleCommand(contextData, true));
        strategyManager.propagate(objectCollector.getObjects(),
            new RemoveStateCommand(contextData), null);
        strategyManager.propagate(objectCollector.getObjects(),
            new ExpandCommand(contextData, true), Residue.class);
        strategyManager.execute(objectCollector.getObjects(),
            ballAndStickCommands);
        strategyManager.setCancelEnable(true);
        Collection atoms =
            ProximityModule.computeAtomProximity(contextData,
                objectCollector.getObjects(), 4);
        if (atoms != null) {
            Collection proximity =
                ProximityModule.computeRelatedObjects(contextData, atoms);
            if (proximity != null) {
                Collection subchains = new HashSet();
                ObjectManager.extract(proximity, subchains, Subchain.class);
                strategyManager.execute(subchains,
                    new ExpandCommand(contextData, true, false));
                ObjectManager.extract(proximity, Residue.class);
                Collection wireframeCommands = new Vector();
                WireframeCheck.sharedInstance.getAllOnCommands(contextData,
                    wireframeCommands);
                strategyManager.execute(proximity, wireframeCommands);
            }
        }
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public String getName() {
        return "Binding Site";
    }
}
