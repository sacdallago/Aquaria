/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.annotation.visitors;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Vector;

import org.srs3d.viewer.bioatlas.objects.Residue;

/**
 * creates the sequences of reference and aligned chains: inserts gaps where needed; note
 * use only one instance to create the whole alignment for all chains (because used
 * residues will be removed from list when creating a sequence) but get the result
 * sequences after every single visit of a chain.
 *
 * @author Christian Zofka
 *
 * @created July 19, 2001
 */
public class ResidueGapCreator {

    // will be initialize for every new chain
    private SequenceCreator referenceSequenceCreator;
    private SequenceCreator alignSequenceCreator;

    // don't change while creating the sequences
    private Map downMap;
    private Map upMap;

    // used residues are removed from the list
    private Collection templateResidues = new HashSet();
    private SequenceAlignmentCreator creator;

    /**
     * <code>ResidueGapCreator</code> constructor.
     *
     * @param alignmentUp inverted alignmentDownMap
     * @param creator Description of parameter.
     */
    public ResidueGapCreator(Map alignmentUp, SequenceAlignmentCreator creator) { // , Collection residues ) {
        this.creator = creator;
        upMap = alignmentUp;
        Iterator iterator;
        Residue residue;

        // fill downMap
        downMap = new HashMap();
        iterator = upMap.keySet().iterator();
        while (iterator.hasNext()) {
            residue = (Residue) iterator.next();
            downMap.put(upMap.get(residue), residue);
        }
    }

    /**
     * Gets the <code>referenceSequence</code> attribute of the
     * <code>ResidueGapCreator</code> object.
     *
     * @return The <code>referenceSequence</code> value.
     */
    public Vector getReferenceSequence() {
        return referenceSequenceCreator.getSequence();
    }

    /**
     * Gets the <code>alignSequence</code> attribute of the
     * <code>ResidueGapCreator</code> object.
     *
     * @return The <code>alignSequence</code> value.
     */
    public Vector getAlignSequence() {
        return alignSequenceCreator.getSequence();
    }

    /**
     * Gets the <code>templateResidues</code> attribute of the <code>ResidueGapCreator
     * </code> object. Gets the <code>templateResidues</code> attribute of the
     * <code>ResidueGapCreator </code> object. keymethod for creating gaps: takes a
     * chain, build the sequence with gaps inserted and build the aligned sequence
     *
     * @param ReferenceSequence Description of parameter.
     */
    public void visit(Vector referenceSequence) {
        referenceSequenceCreator = new SequenceCreator(downMap);
        alignSequenceCreator = new SequenceCreator(upMap);
        Residue lastAligned = null;
        Residue referencedResidue;
        Residue alignedResidue = null;
        Residue expectedResidue = null;

        // for each residue in the chainAnnotation
        for (int i = 0; i < referenceSequence.size(); i++) {
            referencedResidue = (Residue) referenceSequence.elementAt(i);
            if (referencedResidue == null) {

                // copy gaps from refrence to align sequence
                alignSequenceCreator.add(null);
                referenceSequenceCreator.add(null);
            } else {
                alignedResidue =
                    (Residue) getAlignmentDownMap().get(referencedResidue);
                if (alignedResidue != null) {

                    // insert gap(s) in referencedSequence & fills alignedSeqeunce with residues
                    if (lastAligned != null) {
                        expectedResidue =
                            fillSequences(lastAligned.getProceeding());

                        //            if ( expectedResidue != alignedResidue ) {
                        //
                        //              referenceSequenceCreator.add( null );
                        //              alignSequenceCreator.add( null );
                        //
                        //            }
                    }

                    // step back in alignedMap to find initialResidue
                    Residue residue = alignedResidue;
                    while ((residue.getPreceeding() != null) &&
                          !getAlignmentUpMap().containsKey(residue.getPreceeding())) {
                        residue = residue.getPreceeding();
                    }
                    if (residue.getPreceeding() == null) {
                        fillSequences(residue);
                    }
                    lastAligned = alignedResidue;
                }
                referenceSequenceCreator.add(referencedResidue);
                alignSequenceCreator.add(alignedResidue);
            }
        }
        if (lastAligned != null) {
            fillSequences(lastAligned.getProceeding());
        }
    }

    /**
     * Gets the <code>alignmentUpMap</code> attribute of the
     * <code>ResidueGapCreator</code> object.
     *
     * @return The <code>alignmentUpMap</code> value.
     */
    private Map getAlignmentUpMap() {
        return upMap;
    }

    /**
     * Gets the <code>alignmentDownMap</code> attribute of the
     * <code>ResidueGapCreator</code> object.
     *
     * @return The <code>alignmentDownMap</code> value.
     */
    private Map getAlignmentDownMap() {
        return downMap;
    }

    /**
     * fills the reference sequence with gaps(null) and the template with nonaligned
     * residues till an aligned residue is found
     *
     * @param startResidue start
     *
     * @return stopping residue
     */
    private Residue fillSequences(Residue startResidue) {
        Residue residue = startResidue;
        while (residue != null && !getAlignmentUpMap().containsKey(residue)) {
            referenceSequenceCreator.add(null);
            creator.insertInAligned(referenceSequenceCreator.getSequence().size() -
                1, 1);
            alignSequenceCreator.add(residue);
            residue = residue.getProceeding();
        }
        return residue;
    }

    /**
     * textoutput for the 2 aligned sequences
     *
     * @return string representation
     */
    private String alignmentToString() {
        String string = new String();
        Iterator iterator;
        Residue residue;
        iterator = getReferenceSequence().iterator();
        while (iterator.hasNext()) {
            residue = (Residue) iterator.next();
            string += residue + "\t";
        }
        string += "\n";
        iterator = getAlignSequence().iterator();
        while (iterator.hasNext()) {
            residue = (Residue) iterator.next();
            string += residue + "\t";
        }
        string += "\n";
        return string;
    }
}
