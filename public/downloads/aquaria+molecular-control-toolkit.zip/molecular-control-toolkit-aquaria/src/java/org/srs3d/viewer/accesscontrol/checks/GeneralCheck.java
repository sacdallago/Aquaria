/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.accesscontrol.checks;

import java.applet.AppletStub;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.srs3d.viewer.accesscontrol.AccessCheck;
import org.srs3d.viewer.accesscontrol.AccessCheckFactory;
import org.srs3d.viewer.util.XmlTag;

/**
 * @author Karsten Klein
 *
 * @created March 22, 2002
 */
public class GeneralCheck extends ExpirationCheck {
    public static final String VERSION = "1.1";
    Collection checks = new ArrayList();
    String version;

    /**
     * Method description.
     *
     * @return Return description.
     */
    public String getName() {
        return "GeneralCheck-1.0";
    }

    /**
     * Description of the method.
     *
     * @param object Description of parameter.
     */
    public void read(Object object) {
        super.read(object);
        Map map = (Map) object;
        version = (String) map.get("Version");
        if (version == null) {
            version = VERSION;
        }
        Collection accessChecks = (Collection) map.get("EmbeddedAccessChecks");
        Iterator iterator = accessChecks.iterator();
        Map localMap;
        AccessCheck accessCheck;
        while (iterator.hasNext()) {
            localMap = (Map) iterator.next();

            // read access check module
            accessCheck =
                AccessCheckFactory.getInstance(((Integer) localMap.get(
                        "AccessCheck")).intValue());
            accessCheck.read(localMap);
            checks.add(accessCheck);
        }
    }

    /**
     * Description of the method.
     *
     * @param object Description of parameter.
     */
    public void write(Object object) {
        super.write(object);
        Map map = (Map) object;
        Map accessMap;
        Iterator iterator = checks.iterator();
        AccessCheck check;
        Collection accessChecks = new ArrayList();
        while (iterator.hasNext()) {
            check = (AccessCheck) iterator.next();
            accessMap = new HashMap();
            accessMap.put("AccessCheck",
                new Integer(AccessCheckFactory.getId(check)));
            check.write(accessMap);
            accessChecks.add(accessMap);
        }
        map.put("EmbeddedAccessChecks", accessChecks);
        map.put("Version", version);
    }

    /**
     * Method description.
     *
     * @param appletStub Parameter description.
     *
     * @return Return description.
     */
    public boolean check(AppletStub appletStub) {
        if (super.check(appletStub)) {
            Iterator iterator = checks.iterator();
            AccessCheck accessCheck;
            while (iterator.hasNext()) {
                accessCheck = (AccessCheck) iterator.next();
                if (accessCheck.check(appletStub)) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public XmlTag createXmlTag() {
        XmlTag xmlTag = super.createXmlTag();
        xmlTag.setAttribute("version", version);
        Iterator iterator = checks.iterator();
        AccessCheck accessCheck;
        while (iterator.hasNext()) {
            accessCheck = (AccessCheck) iterator.next();
            xmlTag.getSubtags().add(accessCheck.createXmlTag());
        }
        return xmlTag;
    }
}
