/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas;

import java.applet.AppletContext;
import java.applet.AppletStub;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentEvent;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.net.URL;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.Vector;

import javax.media.j3d.BoundingSphere;
import javax.media.j3d.BranchGroup;
import javax.media.j3d.View;
import javax.swing.BorderFactory;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JPanel;
import javax.swing.JSplitPane;
import javax.swing.JToolBar;
import javax.swing.KeyStroke;
import javax.swing.SwingUtilities;
import javax.swing.ToolTipManager;
import javax.vecmath.Color3f;
import javax.vecmath.Point3d;
import javax.vecmath.Point3f;

import org.odonoghuelab.molecularcontroltoolkit.ConnectorType;
import org.odonoghuelab.molecularcontroltoolkit.MolecularControlToolkit;
import org.odonoghuelab.molecularcontroltoolkit.KinectConnector;
import org.odonoghuelab.molecularcontroltoolkit.LeapMotionConnector;
import org.srs3d.viewer.annotation.attributes.AlignmentLayout;
import org.srs3d.viewer.annotation.colorschemes.AnnotationColorScheme;
import org.srs3d.viewer.annotation.colorschemes.DisplacementColorScheme;
import org.srs3d.viewer.annotation.colorschemes.HomologyAltColorScheme;
import org.srs3d.viewer.annotation.colorschemes.HomologyColorScheme;
import org.srs3d.viewer.annotation.contexts.AnnotationContext;
import org.srs3d.viewer.annotation.contexts.AnnotationContextData;
import org.srs3d.viewer.annotation.dispatcher.AnnotationUpDispatcher;
import org.srs3d.viewer.annotation.dispatcher.ZoomBoxThread;
import org.srs3d.viewer.annotation.objects.Alignment;
import org.srs3d.viewer.annotation.objects.AnnotationContainer;
import org.srs3d.viewer.bioatlas.colorschemes.CPKColorScheme;
import org.srs3d.viewer.bioatlas.colorschemes.ChainColorScheme;
import org.srs3d.viewer.bioatlas.colorschemes.ChainFragmentColorScheme;
import org.srs3d.viewer.bioatlas.colorschemes.DarkenColorScheme;
import org.srs3d.viewer.bioatlas.colorschemes.MoleculeColorScheme;
import org.srs3d.viewer.bioatlas.colorschemes.MonochromeColorScheme;
import org.srs3d.viewer.bioatlas.colorschemes.SecondaryStructureColorScheme;
import org.srs3d.viewer.bioatlas.colorschemes.SimpleColorScheme;
import org.srs3d.viewer.bioatlas.colorschemes.StructureColorScheme;
import org.srs3d.viewer.bioatlas.colorschemes.TemperatureColorScheme;
import org.srs3d.viewer.bioatlas.colorschemes.TransparentColorScheme;
import org.srs3d.viewer.bioatlas.contexts.MoleculeContext;
import org.srs3d.viewer.bioatlas.creators.LayerGeometryCreator;
import org.srs3d.viewer.bioatlas.dispatcher.NavigateUpDispatcher;
import org.srs3d.viewer.bioatlas.dispatcher.ThreadedDispatcher;
import org.srs3d.viewer.bioatlas.filters.LigandFilter;
import org.srs3d.viewer.bioatlas.filters.WaterFilter;
import org.srs3d.viewer.bioatlas.loaders.GenericLoader;
import org.srs3d.viewer.bioatlas.modules.AboutModule;
import org.srs3d.viewer.bioatlas.modules.AbstractModule;
import org.srs3d.viewer.bioatlas.modules.AnimationModule;
import org.srs3d.viewer.bioatlas.modules.AnnotationCreateModule;
import org.srs3d.viewer.bioatlas.modules.AnnotationModule;
import org.srs3d.viewer.bioatlas.modules.AnnotationToggleExModule;
import org.srs3d.viewer.bioatlas.modules.AnnotationToggleModule;
import org.srs3d.viewer.bioatlas.modules.AtomSurfaceModule;
import org.srs3d.viewer.bioatlas.modules.AttenuationModule;
import org.srs3d.viewer.bioatlas.modules.AvatarSwitchModule;
import org.srs3d.viewer.bioatlas.modules.BallAndStickCheck;
import org.srs3d.viewer.bioatlas.modules.CATraceCheck;
import org.srs3d.viewer.bioatlas.modules.CaptureModule;
import org.srs3d.viewer.bioatlas.modules.CoilCheck;
import org.srs3d.viewer.bioatlas.modules.ColorSchemeCheckModule;
import org.srs3d.viewer.bioatlas.modules.ColorSchemeModule;
import org.srs3d.viewer.bioatlas.modules.ContactModule;
import org.srs3d.viewer.bioatlas.modules.DeleteViewModule;
import org.srs3d.viewer.bioatlas.modules.DistanceModule;
import org.srs3d.viewer.bioatlas.modules.ExpertMenuModule;
import org.srs3d.viewer.bioatlas.modules.HierarchyViewModule;
import org.srs3d.viewer.bioatlas.modules.HydrogenBondsModule;
import org.srs3d.viewer.bioatlas.modules.InterpreterModule;
import org.srs3d.viewer.bioatlas.modules.LabelClassModule;
import org.srs3d.viewer.bioatlas.modules.LabelModule;
import org.srs3d.viewer.bioatlas.modules.LinkModule;
import org.srs3d.viewer.bioatlas.modules.MeshCheck;
import org.srs3d.viewer.bioatlas.modules.OperationModule;
import org.srs3d.viewer.bioatlas.modules.OverlayModule;
import org.srs3d.viewer.bioatlas.modules.PasteModule;
import org.srs3d.viewer.bioatlas.modules.ProbeSurfaceModule;
import org.srs3d.viewer.bioatlas.modules.ProximityModule;
import org.srs3d.viewer.bioatlas.modules.RemoveDistanceModule;
import org.srs3d.viewer.bioatlas.modules.RemoveLabelModule;
import org.srs3d.viewer.bioatlas.modules.RemoveSurfaceModule;
import org.srs3d.viewer.bioatlas.modules.ResetModule;
import org.srs3d.viewer.bioatlas.modules.RestoreModule;
import org.srs3d.viewer.bioatlas.modules.RibbonCheck;
import org.srs3d.viewer.bioatlas.modules.RunApplicationModule;
import org.srs3d.viewer.bioatlas.modules.RuntimeTestModule;
import org.srs3d.viewer.bioatlas.modules.SaveAsModule;
import org.srs3d.viewer.bioatlas.modules.SaveModule;
import org.srs3d.viewer.bioatlas.modules.SelectAlignedResiduesModule;
import org.srs3d.viewer.bioatlas.modules.SelectFeatureModule;
import org.srs3d.viewer.bioatlas.modules.SelectModule;
import org.srs3d.viewer.bioatlas.modules.SelectResiduesModule;
import org.srs3d.viewer.bioatlas.modules.SlabModule;
import org.srs3d.viewer.bioatlas.modules.SoapFilmCheck;
import org.srs3d.viewer.bioatlas.modules.SolidRenderingModule;
import org.srs3d.viewer.bioatlas.modules.StereoModule;
import org.srs3d.viewer.bioatlas.modules.StructureModule;
import org.srs3d.viewer.bioatlas.modules.StyleModule;
import org.srs3d.viewer.bioatlas.modules.VanDerWaalsCheck;
import org.srs3d.viewer.bioatlas.modules.VisibleCheck;
import org.srs3d.viewer.bioatlas.modules.WireframeCheck;
import org.srs3d.viewer.bioatlas.objects.Atom;
import org.srs3d.viewer.bioatlas.objects.Chain;
import org.srs3d.viewer.bioatlas.objects.Coil;
import org.srs3d.viewer.bioatlas.objects.Layer;
import org.srs3d.viewer.bioatlas.objects.Residue;
import org.srs3d.viewer.bioatlas.objects.Subchain;
import org.srs3d.viewer.bioatlas.styles.BindingSiteStyle;
import org.srs3d.viewer.bioatlas.styles.CompoundStyle;
import org.srs3d.viewer.bioatlas.styles.DisplacementStyle;
import org.srs3d.viewer.bioatlas.styles.FirstImpressionStyle;
import org.srs3d.viewer.bioatlas.styles.HomologyStyle;
import org.srs3d.viewer.bioatlas.styles.Style;
import org.srs3d.viewer.bioatlas.styles.SuperpositionStyle;
import org.srs3d.viewer.integration.component.GenericComponentController;
import org.srs3d.viewer.integration.interfaces.Connector;
import org.srs3d.viewer.integration.interfaces.DataTransferObject;
import org.srs3d.viewer.interfaces.ModulePublisher;
import org.srs3d.viewer.j3d.AbstractColorScheme;
import org.srs3d.viewer.j3d.BranchGroupHelper;
import org.srs3d.viewer.j3d.ColorScheme;
import org.srs3d.viewer.j3d.ColorSchemeBucket;
import org.srs3d.viewer.j3d.Context;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.ContextManager;
import org.srs3d.viewer.j3d.DispatchManager;
import org.srs3d.viewer.j3d.Junction;
import org.srs3d.viewer.j3d.OverlayManager;
import org.srs3d.viewer.j3d.Selection;
import org.srs3d.viewer.j3d.SelectionManager;
import org.srs3d.viewer.j3d.behaviors.AquariaInteractiveDispatcher;
import org.srs3d.viewer.j3d.behaviors.InteractiveRotateBehavior;
import org.srs3d.viewer.j3d.behaviors.KeyHandler;
import org.srs3d.viewer.j3d.behaviors.LookAtBehavior;
import org.srs3d.viewer.j3d.behaviors.LookAtXYBehavior;
import org.srs3d.viewer.j3d.behaviors.SelectBehavior;
import org.srs3d.viewer.j3d.behaviors.dispatcher.DispatchThread;
import org.srs3d.viewer.j3d.commands.ColorCommand;
import org.srs3d.viewer.j3d.commands.ComputeCenterCommand;
import org.srs3d.viewer.j3d.commands.RegisterCommand;
import org.srs3d.viewer.j3d.commands.RepresentationCommand;
import org.srs3d.viewer.j3d.commands.SpawnCommand;
import org.srs3d.viewer.j3d.commands.VisibleCommand;
import org.srs3d.viewer.j3d.creators.GeometryCreator;
import org.srs3d.viewer.j3d.operations.CallbackOperation;
import org.srs3d.viewer.objects.ObjectContainer;
import org.srs3d.viewer.objects.ObjectManager;
import org.srs3d.viewer.objects.Operation;
import org.srs3d.viewer.objects.State;
import org.srs3d.viewer.objects.StateManager;
import org.srs3d.viewer.objects.Strategy;
import org.srs3d.viewer.objects.filters.ObjectClassFilter;
import org.srs3d.viewer.sequence.contexts.SequenceContext;
import org.srs3d.viewer.sequence.dispatcher.SequenceUpDispatcher;
import org.srs3d.viewer.sequence.modules.SequenceModule;
import org.srs3d.viewer.swing.Check;
import org.srs3d.viewer.swing.ContextPanel;
import org.srs3d.viewer.swing.CursorManager;
import org.srs3d.viewer.swing.JStatusBar;
import org.srs3d.viewer.swing.Module;
import org.srs3d.viewer.swing.PopupMenu;
import org.srs3d.viewer.swing.SeparatorModule;
import org.srs3d.viewer.swing.StrategyModule;
import org.srs3d.viewer.swing.SwingSettings;
import org.srs3d.viewer.util.Chronometer;
import org.srs3d.viewer.util.ExceptionHandler;
import org.srs3d.viewer.util.Log;

/**
 * Description of the class
 *
 * @author Karsten Klein
 *
 * @created March 20, 2001
 */
public class Capture extends GenericComponentController
    implements ActionListener, Application, PopupContext {
    private static final Log log = new Log(Capture.class);
    private Thread initThread;
    private ApplicationContext applicationContext = new ApplicationContext();

    /** Display contexts */
    protected Context context = null;
    protected AnnotationContext annotationContext = null;
    protected SequenceContext sequenceContext = null;
    protected MolecularControlToolkit molecularControlToolkit = null;

    /** Swing components */
    protected JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
    protected JSplitPane annotationSplitPane = null;
    protected ContextPanel contextPanel = null;
    protected ContextPanel annotationContextPanel = null;
    protected ContextPanel sequenceContextPanel = null;
    private transient JMenu menu = null;
    private transient JToolBar toolbar = null;
    private transient JStatusBar statusBar = null;
    private transient JComponent contextContainer = null;
    private transient JComponent sequenceContextContainer = null;
    private transient JComponent annotationContextContainer = null;

    /** Popup related components */
    protected org.srs3d.viewer.swing.PopupMenu popupMenu = null;

    /** sequence structure related data */
    protected Collection features = new Vector();
    protected Collection activeFeatures = new Vector();
    protected Collection annotations = new Vector();
    protected Collection links = new Vector();
    protected Collection linkedDatabases = new HashSet();

    /** maps layers to residue-residue maps */
    private Map layerAlignmentMap = new HashMap();

    /** Style setting. */
    protected Style style = null;

    /** Additional flags. */
    protected boolean initialized = false;
    private boolean isSequenceAlignment = false;

    /**
     * <code>Capture</code> constructor.
     */
    public Capture() {
        super(new JPanel(), null);
        SwingSettings.update();
        setVerbose(false);
        initializeMouseCursors();
    }

    /**
     * Gets the <code>appletStub</code> attribute of the <code>Capture</code> object.
     *
     * @return The <code>appletStub</code> value.
     */
    public AppletStub getAppletStub() {
        return (AppletStub) getApplicationContext().get("AppletStub");
    }

    /**
     * Gets the <code>context</code> attribute of the <code>Capture</code> object.
     *
     * @return The <code>context</code> value.
     */
    public Component getComponent() {
        initialized = true;
        return super.getComponent();
    }

    /**
     * Gets the <code>parent</code> attribute of the <code>Capture</code> object.
     *
     * @return The <code>parent</code> value.
     */
    public Container getParent() {
        try {
            Container parentContainer =
                (Container) getApplicationContext().get("ParentContainer");
            if (parentContainer == null) {
                return (Container) getComponent();
            } else {
                return parentContainer;
            }
        } catch (Exception e) {
            ExceptionHandler.handleException(e);
        }
        return null;
    }

    /**
     * Gets the <code>ready</code> attribute of the <code>Capture</code> object.
     *
     * @return The <code>ready</code> value.
     */
    public boolean isReady() {
        return context.getView().getLastFrameDuration() > 0;
    }

    /**
     * Description of the method.
     *
     * @param message Description of parameter.
     */
    public void showStatus(String message) {
        AppletContext appletContext = getAppletStub().getAppletContext();
        if (appletContext != null) {
            appletContext.showStatus(message);
        }
    }

    /**
     * Description of the method.
     */
    public void init() {

        // :NOTE: get the static threads started from the main thread
        //    GCThread.initialize();
        DispatchThread.initialize();
        SwingSettings.update();
        if (context == null) {

            // initialize the context
            initThread =
                new Thread(new Runnable() {
                        public void run() {
                            SwingSettings.update();
                            initializeView();
                            waitForContextInitialization();
                            SwingSettings.update();
                        }
                    });

            //      initThread.start();
            initThread.run();
        }
        SwingSettings.update();
    }

    /**
     * Description of the method.
     */
    public void startVisualization() {
        org.srs3d.viewer.j3d.behaviors.UpdateBehavior.Callback callback;
        CallbackOperation operation;
        if (molecularControlToolkit != null) {
            molecularControlToolkit.initialise();
        }

        // intepretation of parameters issues load operations
        callback =
            new org.srs3d.viewer.j3d.behaviors.UpdateBehavior.Callback() {
                    public void execute() {
                        OverlayManager.spawnOverlays(context.getContextData());
                        try {
                            interpreteParameters();
                        } catch (Exception e) {
                            ExceptionHandler.handleException(e);
                        }

                        // at this stage all loading is scheduled
                        // interpretation of parameters issues load operations
                        CallbackOperation annotationOperation;
                        org.srs3d.viewer.j3d.behaviors.UpdateBehavior.Callback annotationCallback =
                            new org.srs3d.viewer.j3d.behaviors.UpdateBehavior.Callback() {
                                public void execute() {

                                    // create annotations for annotation view
                                    org.srs3d.viewer.bioatlas.modules.AnnotationModule.preprocessAnnotations(context.getContextData());

                                    // :NOTE: during this callback the application is very fragile as
                                    // as an applet reload and back (applet destruction) will cause
                                    // a stall
                                    // visualize everything
                                    visualize();
                                    org.srs3d.viewer.bioatlas.modules.AnnotationModule.collapseAnnotations(context.getContextData());

                                    // :NOTE: always keep the popup after interpreteParamters()
                                    initializeControlOverlays();

                                    // setup popup menu
                                    initializePopupMenu();
                                    NavigateUpDispatcher.updateDescription(context.getContextData(),
                                        null);
                                    if (getAppletStub().getParameter("autoSpin") != null) {
                                        log.debug("Activating auto spin.");
                                        SwingUtilities.invokeLater(new Runnable() {
                                                public void run() {
                                                    LookAtXYBehavior.deltaX =
                                                        (int) (8.0 * Math.random() -
                                                        4);
                                                    LookAtXYBehavior.deltaY =
                                                        (int) (8.0 * Math.random() -
                                                        4);
                                                    AnimationModule.setDisableReset(context.getContextData(),
                                                        true);
                                                    context.getContextData()
                                                           .getDispatcher()
                                                           .runDispatch(new Operation(
                                                            context,
                                                            "SWITCH-SPIN", null));
                                                }
                                            });
                                    }
                                }
                            };
                        annotationOperation =
                            new CallbackOperation(context, "CALLBACK",
                                annotationCallback);
                        context.getContextData().getDispatcher().dispatch(annotationOperation);
                        context.waitForUpdate();

                        // restore old state if available
                        org.srs3d.viewer.j3d.behaviors.UpdateBehavior.Callback restoreCallback =
                            new org.srs3d.viewer.j3d.behaviors.UpdateBehavior.Callback() {
                                public void execute() {
                                    SwingUtilities.invokeLater(new Runnable() {
                                            public void run() {
                                                String instanceId =
                                                    (String) context.getContextData()
                                                                    .getProperty("INSTANCE-ID");
                                                if (instanceId != null) {
                                                    String value =
                                                        System.getProperty(
                                                            "org.srs3d.viewer.disableOperationStore");
                                                    if (value == null ||
                                                          value.equalsIgnoreCase(
                                                              "false")) {
                                                        RestoreModule restoreModule =
                                                            RestoreModule.getInstance(context.getContextData(),
                                                                instanceId);
                                                        if (restoreModule != null &&
                                                              restoreModule.hasViews()) {
                                                            try {
                                                                restoreModule.react(null);
                                                            } catch (Exception e) {
                                                                ExceptionHandler.handleException(e);
                                                            }
                                                            initializePopupMenu();
                                                        }
                                                    } else {
                                                        log.debug(
                                                            "Operation storing disabled.");
                                                    }
                                                }
                                            }
                                        });
                                }
                            };
                        Operation restoreOperation =
                            new CallbackOperation(context, "CALLBACK",
                                restoreCallback);
                        context.getContextData().getDispatcher().dispatch(restoreOperation);
                    }
                };
        operation = new CallbackOperation(context, "CALLBACK", callback);
        context.getContextData().getDispatcher().dispatch(operation);
    }

    /**
     * Description of the method.
     */
    public void start() {
        if (context == null || context.getContextData() == null) {
            return;
        }
        if (!context.getContextData().isValid()) {
            return;
        }
        update();

        //    GCThread.runFinalization();
        //    GCThread.gc();
        if (getAppletStub().getParameter("autoTerminate") != null) {
            log.debug("Activating autoTerminate.");
            String string = getAppletStub().getParameter("autoTerminate");
            final int duration = Integer.parseInt(string);
            Thread thread =
                new Thread(new Runnable() {
                        public void run() {
                            try {
                                Thread.sleep(duration * 1000);
                            } catch (InterruptedException e) {

                                // :SILENT EXCEPTION:
                            }
                            destroy();
                            log.info("System exits explicitly.");
                            System.exit(0);
                        }
                    });
            thread.setPriority(Thread.MAX_PRIORITY);
            thread.start();
        }

        // check the application context contrac
        if (!getApplicationContext().getContract().check(getApplicationContext())) {
            log.debug("Application context contract check failed!");
            log.debug("Please check application initialization.");
        }
        waitForContextInitialization();
    }

    /**
     * Method description.
     *
     * @param context Parameter description.
     */
    public void waitForContextInitialization(Context context) {
        context.waitForInitialization();
    }

    /**
     * Method description.
     */
    public void waitForContextInitialization() {
        org.srs3d.viewer.j3d.behaviors.dispatcher.Dispatch dispatch =
            new org.srs3d.viewer.j3d.behaviors.dispatcher.Dispatch() {
                public void dispatch(ContextData contextData,
                    Operation operation) {
                    waitForContextInitialization(context);
                    if (annotationContext != null) {
                        waitForContextInitialization(annotationContext);
                    }

                    // :FIXME: why is this still causing the context to stall??
                    //        if ( sequenceContext != null ) {
                    //
                    //          waitForContextInitialization( sequenceContext );
                    //
                    //        }
                }
            };
        ArrayList dispatches = new ArrayList(1);
        dispatches.add(dispatch);
        context.getContextData().getDispatcher().registerDispatches("INIT",
            dispatches);
        Operation operation = new Operation(context, "INIT", null);
        operation.setSerializable(false);
        context.getContextData().getDispatcher().dispatch(operation);
    }

    /**
     * Description of the method.
     */
    public void stop() {
    }

    /**
     * Description of the method.
     */
    public void destroy() {
        context.getContextData().invalidate();
        Chronometer c = Chronometer.getChronometer("Capture:Destroy()");
        c.setVerbose(true);
        c.start();
        if (context != null) {
            Module restoreModule =
                (Module) context.getContextData().getProperty("RESTORE_MODULE");
            if (restoreModule != null) {
                restoreModule.cleanup();
                context.getContextData().setProperty("RESTORE_MODULE", null);
            }
            destroy(sequenceContext, sequenceContextContainer);
            destroy(annotationContext, annotationContextContainer);
            destroy(context, contextContainer);
            sequenceContext = null;
            annotationContext = null;
            context = null;
            features.clear();
            activeFeatures.clear();

            //      GCThread.runFinalization();
            //      GCThread.gc();
        }
        c.stop("rest");
        Chronometer.displayAll();
        getApplicationContext().set("ApplicationState", "terminated");
        getApplicationContext().remove("MainContextData");
    }

    /**
     * Description of the method Description of the method
     */
    public void initializeView() {
        initializeMoleculeView();
        context.getContextData().setProperty("Application", this);
        String string;
        string = getAppletStub().getParameter("annotationView");
        if (string != null) {
            if (string.equalsIgnoreCase("on")) {
                initializeAnnotationView();

                // register dispatcher communication
                DispatchManager.register(context, annotationContext);
                DispatchManager.register(annotationContext, context);
                getApplicationContext().set("AnnotationContextData",
                    annotationContext.getContextData());
            }
        }
        string = getAppletStub().getParameter("sequenceView");
        if (string != null) {
            if (string.equalsIgnoreCase("on")) {
                initializeSequenceView();

                // register dispatcher communication
                DispatchManager.register(context, sequenceContext);
                DispatchManager.register(sequenceContext, context);
                getApplicationContext().set("SequenceContextData",
                    sequenceContext.getContextData());
            }
        }

        // register communication channels between annoation and sequence view
        if (annotationContext != null && sequenceContext != null) {
            DispatchManager.register(annotationContext, sequenceContext);
            DispatchManager.register(sequenceContext, annotationContext);
        }
        if (annotationContext != null && sequenceContext != null) {
            annotationSplitPane =
                new JSplitPane(JSplitPane.VERTICAL_SPLIT, annotationContext,
                    sequenceContext);
            annotationSplitPane.setBorder(null);
            annotationSplitPane.setDividerSize(3);
            annotationSplitPane.setContinuousLayout(false);
            annotationContextContainer = annotationSplitPane;
            sequenceContextContainer = annotationSplitPane;
        } else {
            if (annotationContext != null) {
                annotationSplitPane =
                    new JSplitPane(JSplitPane.VERTICAL_SPLIT,
                        annotationContext, null);
                annotationSplitPane.setBorder(null);
                annotationSplitPane.setDividerSize(3);
                annotationSplitPane.setContinuousLayout(false);
                annotationContextContainer = annotationSplitPane;
            } else if (sequenceContext != null) {
                annotationSplitPane =
                    new JSplitPane(JSplitPane.VERTICAL_SPLIT, sequenceContext,
                        null);
                annotationSplitPane.setBorder(null);
                annotationSplitPane.setDividerSize(3);
                annotationSplitPane.setContinuousLayout(false);
                sequenceContextContainer = annotationSplitPane;
            }
        }
        String parameter = getAppletStub().getParameter("toolbar");
        boolean hasToolbar =
            parameter == null || parameter.equalsIgnoreCase("on");
        parameter = getAppletStub().getParameter("statusbar");
        boolean hasStatusbar =
            parameter != null && parameter.equalsIgnoreCase("on");
        JComponent panel = (JComponent) getComponent();
        panel.setLayout(new BorderLayout());
        panel.setBackground(Parameter.panelBackgroundColor);
        SwingSettings.update();
        if (sequenceContext == null && annotationContext == null) {
            panel.add(context, BorderLayout.CENTER);
            contextContainer = panel;
        } else {
            panel.add(splitPane, BorderLayout.CENTER);
            contextContainer = splitPane;
            splitPane.setTopComponent(context);
            splitPane.setBottomComponent(annotationSplitPane);
            string = getAppletStub().getParameter("applicationMode");
            if (string == null || string.equalsIgnoreCase("applet")) {
                splitPane.setBorder(null);
            }
            splitPane.setDividerSize(3);
            splitPane.setContinuousLayout(false);
            splitPane.setContinuousLayout(false);
        }
        if (hasToolbar) {
            toolbar = new JToolBar();
            ToolTipManager.sharedInstance().registerComponent(toolbar);
            panel.add(toolbar, BorderLayout.NORTH);
            toolbar.setFloatable(false);
            toolbar.setBorderPainted(false);
            toolbar.setEnabled(true);
            Dimension size = new Dimension(10000, 20);
            toolbar.setPreferredSize(size);
        }
        if (hasStatusbar) {
            statusBar = new org.srs3d.viewer.swing.JStatusBar();
            statusBar.setBorder(BorderFactory.createEtchedBorder());
            panel.add(statusBar, BorderLayout.SOUTH);
            statusBar.setEnabled(true);
            Dimension size = new Dimension(10000, 20);
            statusBar.setPreferredSize(size);
            ((org.srs3d.viewer.applet.AppletStub) context.getContextData()
                                                         .getAppletStub()).setStatusDisplay(statusBar);
        }
        String interactiveString = getAppletStub().getParameter("interactive");
        if (interactiveString != null) {
        	System.out.println("Interactive string = " + interactiveString);
            String[] interactives = interactiveString.split(",");
	        Set<String> interactiveSet = new HashSet<String>(Arrays.asList(interactives));
	    	molecularControlToolkit = new MolecularControlToolkit();
	        for (String s : interactiveSet) {
	        	
		        if (s.trim().equalsIgnoreCase("kinect")){
		        	molecularControlToolkit.addConnector(ConnectorType.Kinect);
		        }
		        if (s.trim().equalsIgnoreCase("leap")){
		        	molecularControlToolkit.addConnector(ConnectorType.LeapMotion);
		        }
		        else {
		        	System.out.println("Adding nothing");
		        }
	        }
	        AquariaInteractiveDispatcher dispatcher = new AquariaInteractiveDispatcher();
	        dispatcher.initialise(context.getContextData());
	        molecularControlToolkit.setListeners(dispatcher);
        }
        initializeOverlays();
    }

    /**
     * Description of the method.
     */
    public void initializeOverlays() {

        // don't execute this as Callback (menu will not be initialized correctly)
        // add overlays
        ContextData contextData = context.getContextData();
        if (contextData.isValid()) {
            org.srs3d.viewer.j3d.objects.Overlay overlay;
            overlay = new org.srs3d.viewer.j3d.objects.Overlay("Color Legend");
            overlay.setAlignment(org.srs3d.viewer.j3d.objects.Overlay.ALIGN_BOTTOM_RIGHT);
            overlay.setCoordinate(new Point3f(10, 10, 0));
            overlay.clearText();
            overlay.addTextLine("");
            overlay.addTextLine("Color Legend", Color.white);
            overlay.setHeight(overlay.getCursorY() * 2 + 20);
            overlay.setWidth(overlay.getMaxPixels());
            overlay.update(contextData);
            overlay.finalizeUpdate();
            contextData.getOverlayManager().register(overlay);
            contextData.getStrategyManager().execute(overlay,
                new VisibleCommand(contextData, true));
            overlay = new org.srs3d.viewer.j3d.objects.Overlay("Selection");
            overlay.setAlignment(org.srs3d.viewer.j3d.objects.Overlay.ALIGN_BOTTOM_LEFT);
            overlay.setCoordinate(new Point3f(6, 10, 0));
            overlay.clearText();
            overlay.addTextLine("");
            overlay.addTextLine("Initializing", Color.white);
            overlay.setHeight(overlay.getCursorY() * 2 + 20);
            overlay.setWidth(overlay.getMaxPixels());
            overlay.update(contextData);
            overlay.finalizeUpdate();
            contextData.getOverlayManager().register(overlay);
            contextData.getStrategyManager().execute(overlay,
                new VisibleCommand(contextData, true));
        }
    }

    /**
     * Description of the method.
     */
    public void initializeControlOverlays() {

        // don't execute this as Callback (menu will not be initialized correctly)
        // add overlays
        final ContextData contextData = context.getContextData();
        if (contextData.isValid()) {
            final org.srs3d.viewer.j3d.objects.Overlay overlay =
                new org.srs3d.viewer.j3d.objects.Overlay("Mouse Controls");
            overlay.setCoordinate(new Point3f(6, 10, 0));
            overlay.setHeight(overlay.getCursorY() * 2 + 20);
            overlay.setWidth(overlay.getMaxPixels());
            contextData.getOverlayManager().register(overlay);
            contextData.getStrategyManager().execute(overlay,
                new VisibleCommand(contextData, !contextData.isExpertContext()));
            overlay.update(contextData);
            overlay.finalizeUpdate();
            contextData.getStrategyManager().execute(overlay,
                new VisibleCommand(contextData, !contextData.isExpertContext()));
            SpawnCommand spawnCommand = new SpawnCommand(contextData);
            spawnCommand.setBranchGroup(context.getAvatarJunction().getOnBranch());
            contextData.getStrategyManager().execute(overlay, spawnCommand);
        }
    }

    /**
     * Description of the method
     */
    public void initializeAnnotationView() {

        // create context manager with new annotation context
        //    annotationContext = ( AnnotationContext ) ContextManager.getNewContext( AnnotationContext.class );
        annotationContext = null;
        if (annotationContext == null) {
            annotationContext =
                new AnnotationContext(Context.getDefaultGraphicsConfiguration());
            ((AnnotationContextData) annotationContext.getContextData()).setReferenceContextData(context.getContextData());
            annotationContext.getContextData().setComponent(getParent());

            // initialize zoomBoxThread from outside j3d thread
            ZoomBoxThread zoomBoxThread = new ZoomBoxThread();
            ((org.srs3d.viewer.annotation.contexts.AnnotationContextData) annotationContext.getContextData()).setZoomBoxThread(zoomBoxThread);
        }

        // the progress dialog should appear outside the 3d view if possible
        context.getContextData().setProperty("DialogComponent",
            annotationContext);
        annotationContext.lockRenderer();
        ContextManager.addContext(annotationContext);

        // setup environment
        org.srs3d.viewer.annotation.Configuration.configure(annotationContext.getContextData());
        annotationContext.setup();
        annotationContext.finalizeSetup();
        Cursor cursor = CursorManager.getCursor("Select");
        CursorManager.setCursor(annotationContext, cursor);
        annotationContext.getContextData().setColorScheme(new AnnotationColorScheme(
                annotationContext.getContextData(), context.getContextData()));

        // set dispatcher
        ThreadedDispatcher dispatcher = new AnnotationUpDispatcher();
        annotationContext.getContextData().setDispatcher(dispatcher);
        DispatchManager.register(dispatcher, annotationContext);
        BranchGroup branchGroup = new BranchGroup();
        BranchGroupHelper.setDefaultCapabilities(branchGroup);
        SelectBehavior selectBehavior =
            new SelectBehavior(annotationContext.getContextData());
        branchGroup.addChild(selectBehavior);
        BoundingSphere bounds =
            new BoundingSphere(new Point3d(0, 0, 0), Double.MAX_VALUE);
        selectBehavior.setSchedulingBounds(bounds);
        annotationContext.getBehaviorLevel().addChild(branchGroup);
        annotationContext.getView().setWindowResizePolicy(View.VIRTUAL_WORLD);
        annotationContext.getContextData().setAppletStub(getAppletStub());
        disableFocusTraversalKeys(annotationContext);
        KeyHandler keyHandler =
            (KeyHandler) context.getContextData().getProperty("KeyHandler");
        annotationContext.addKeyListener(keyHandler);
        keyHandler.registerComponent(annotationContext);
        annotationContext.getContextData().setProperty("KeyHandler", keyHandler);
        annotationContext.unlockRenderer();
        annotationContext.getView().startBehaviorScheduler();
    }

    /**
     * Description of the method
     */
    public void initializeMoleculeView() {

        // create context manager with new molecule context
        //    context = ( MoleculeContext ) ContextManager.getNewContext( MoleculeContext.class );
        context = null;
        if (context == null) {
            context =
                new MoleculeContext(Context.getDefaultGraphicsConfiguration());
            context.getContextData().setComponent(getParent());
            context.getContextData().setProperty("DialogComponent", getParent());
            context.setIncludeTransform(false);
        }
        context.lockRenderer();
        ContextManager.addContext(context);
        ContextData contextData = context.getContextData();

        // setup environment
        org.srs3d.viewer.bioatlas.Configuration.configure(contextData);

        // context must be managed by ContextManager
        context.setup();
        context.finalizeSetup();
        Cursor cursor = CursorManager.getCursor("Select");
        CursorManager.setCursor(context, cursor);

        // set default dispatcher
        NavigateUpDispatcher dispatcher = new NavigateUpDispatcher();
        dispatcher.registerKeys(contextData);
        contextData.setDispatcher(dispatcher);
        DispatchManager.register(dispatcher, context);

        // register modules not covered by the menu or that are needed in advance
        instantiateModules();
        BranchGroup branchGroup = new BranchGroup();
        BranchGroupHelper.setDefaultCapabilities(branchGroup);
        SelectBehavior selectBehavior = new SelectBehavior(contextData);
        branchGroup.addChild(selectBehavior);
        BoundingSphere bounds =
            new BoundingSphere(new Point3d(0, 0, 0), Double.MAX_VALUE);
        selectBehavior.setSchedulingBounds(bounds);
        LookAtXYBehavior lookAtXYBehavior = new LookAtXYBehavior(contextData);
        lookAtXYBehavior.setSchedulingBounds(bounds);
        branchGroup.addChild(lookAtXYBehavior);
        InteractiveRotateBehavior kinectRotate = new InteractiveRotateBehavior(contextData);
        kinectRotate.setSchedulingBounds(bounds);
        branchGroup.addChild(kinectRotate);
        
        LookAtBehavior lookAtBehavior = new LookAtBehavior(contextData);
        lookAtBehavior.setSchedulingBounds(bounds);
        branchGroup.addChild(lookAtBehavior);
        context.getBehaviorLevel().addChild(branchGroup);
        contextData.setAppletStub(getAppletStub());
        disableFocusTraversalKeys(context);
        KeyHandler keyHandler = new KeyHandler(contextData);
        context.addKeyListener(keyHandler);

        //    parentContainer.addKeyListener( keyHandler );
        getParent().addKeyListener(keyHandler);
        context.getContextData().setProperty("KeyHandler", keyHandler);
        keyHandler.registerComponent(context);
        keyHandler.registerComponent(getParent());
        //    keyHandler.registerComponent( parentContainer );
        context.unlockRenderer();
        getApplicationContext().set("MainContextData", context.getContextData());
    }

    /**
     * Description of the method
     */
    public void initializeSequenceView() {

        // create context manager with new annotation context
        //    sequenceContext = ( SequenceContext ) ContextManager.getNewContext( SequenceContext.class );
        sequenceContext = null;
        if (sequenceContext == null) {
            sequenceContext =
                new SequenceContext(Context.getDefaultGraphicsConfiguration());
            ((AnnotationContextData) sequenceContext.getContextData()).setReferenceContextData(context.getContextData());
            sequenceContext.getContextData().setComponent(getParent());
        }
        sequenceContext.lockRenderer();
        ContextData sequenceContextData = sequenceContext.getContextData();
        ContextManager.addContext(sequenceContext);

        // setup environment
        org.srs3d.viewer.sequence.Configuration.configure(sequenceContextData);
        sequenceContext.setup();
        sequenceContext.finalizeSetup();
        Cursor cursor = CursorManager.getCursor("Select");
        CursorManager.setCursor(sequenceContext, cursor);
        sequenceContextData.setColorScheme(new AnnotationColorScheme(
                sequenceContextData, context.getContextData()));

        // set dispatcher
        ThreadedDispatcher dispatcher = new SequenceUpDispatcher();
        sequenceContextData.setDispatcher(dispatcher);
        DispatchManager.register(dispatcher, sequenceContext);
        BranchGroup branchGroup = new BranchGroup();
        BranchGroupHelper.setDefaultCapabilities(branchGroup);
        SelectBehavior selectBehavior = new SelectBehavior(sequenceContextData);
        branchGroup.addChild(selectBehavior);
        BoundingSphere bounds =
            new BoundingSphere(new Point3d(0, 0, 0), Double.MAX_VALUE);
        selectBehavior.setSchedulingBounds(bounds);
        sequenceContext.getBehaviorLevel().addChild(branchGroup);
        sequenceContext.getContextData().setAppletStub(getAppletStub());
        disableFocusTraversalKeys(sequenceContext);
        KeyHandler keyHandler =
            (KeyHandler) context.getContextData().getProperty("KeyHandler");
        sequenceContext.addKeyListener(keyHandler);
        keyHandler.registerComponent(sequenceContext);
        sequenceContext.getContextData().setProperty("KeyHandler", keyHandler);
        sequenceContext.unlockRenderer();
    }

    /**
     * Description of the method.
     *
     * @param url Description of parameter.
     *
     * @return Description of the returned value.
     */
    public ObjectContainer loadGeneric(URL url) {
        if (context != null) {
            try {
                GenericLoader loader = new GenericLoader();
                ObjectContainer tempContainer = loader.load(url);
                if (tempContainer != null) {

                    // :FIXME: this should be done in the loader
                    Layer layer = new Layer();
                    layer.merge(tempContainer);
                    layer.setDescription(tempContainer.getName());
                    ComputeCenterCommand computeCenterCommand =
                        new ComputeCenterCommand(context.getContextData());
                    context.getContextData().getStrategyManager().execute(layer.getObjects(),
                        computeCenterCommand);
                    layer.setCenter(computeCenterCommand.getCenter());
                    layer.setExtend(computeCenterCommand.getExtend());
                    return layer;
                } else {
                    log.error("No data found in file.");
                }
            } catch (Exception e) {
                ExceptionHandler.handleException(e, this);
            }
            try {
                org.srs3d.viewer.j3d.loaders.GenericLoader loader =
                    new org.srs3d.viewer.j3d.loaders.GenericLoader();
                BranchGroup scene = loader.load(url).getSceneGroup();
                context.getSceneLevel().addChild(scene);
            } catch (Exception e) {
                ExceptionHandler.handleException(e, this);
            }
        }
        return null;
    }

    /**
     * Description of the method
     */
    public void preprocessView() {
        Operation operation = new Operation(context, "ZOOM_OUT", null);
        operation.setSerializable(false);
        NavigateUpDispatcher.processZoomOut(context.getContextData(),
            operation, 0);
    }

    /**
     * Method description.
     *
     * @param context Parameter description.
     */
    public void lockContext(final Context context) {
        context.lockRenderer();
    }

    /**
     * Method description.
     *
     * @param context Parameter description.
     */
    public void unlockContext(final Context context) {
        context.unlockRenderer();
    }

    /**
     * Method description.
     */
    public void lockAllContexts() {
        lockContext(context);
        if (annotationContext != null) {
            lockContext(annotationContext);
        }
        if (sequenceContext != null) {
            lockContext(sequenceContext);
        }
    }

    /**
     * Method description.
     */
    public void unlockAllContexts() {
        unlockContext(context);
        if (annotationContext != null) {
            unlockContext(annotationContext);
        }
        if (sequenceContext != null) {
            unlockContext(sequenceContext);
        }
    }

    /**
     * Description of the method
     */
    public void visualize() {
        final ContextData contextData = context.getContextData();
        visualize(context);
        if (annotationContext != null) {
            try {
                org.srs3d.viewer.annotation.modules.AnnotationModule.visualizeSegmentInformation(contextData.getObjectContainer(),
                    context, annotationContext, sequenceContext,
                    layerAlignmentMap);
                if (isSequenceAlignment) {

                    // :NOTE: the gap creator might have extended the features so that we
                    // need to update the expansion of the residue subchains.
                    AnnotationModule.finalizeAnnotations(context.getContextData(),
                        annotations, features, activeFeatures, true);
                }
            } catch (Exception e) {
                ExceptionHandler.handleException(e, this);
                log.error("Annotation creation failed.");
            }
        }
        if (!context.getContextData().isValid()) {
            return;
        }
        if (sequenceContext != null) {
            try {
                SequenceModule.visualizeResidueInformation(context.getContextData()
                                                                  .getObjectContainer(),
                    annotationContext, sequenceContext, context);
            } catch (Exception e) {
                ExceptionHandler.handleException(e, this);
                log.error("Sequence creation failed.");
            }
        }
        if (!context.getContextData().isValid()) {
            return;
        }
        if (activeFeatures.isEmpty()) {
            context.addUpdateCallback(new org.srs3d.viewer.j3d.behaviors.UpdateBehavior.Callback() {
                    public void execute() {
                        if (contextData.getProperty("GENERIC_DATA") != null) {
                            ColorScheme colorScheme =
                                new SimpleColorScheme(contextData);
                            contextData.setColorScheme(colorScheme);
                            ColorCommand colorCommand =
                                new ColorCommand(contextData, colorScheme);
                            contextData.getStrategyManager().propagate(contextData.getObjectContainer(),
                                colorCommand);
                        } else {
                            StyleModule.applyColorScheme(contextData, style);
                            ColorSchemeModule.updateLegendOverlay(contextData,
                                contextData.getColorSchemeBucket()
                                           .getInformation(null));
                        }
                    }
                });
        } else {
            if (annotationContext != null) {
                AnnotationModule.fullAnnotationActivation(contextData,
                    annotationContext, activeFeatures);
            }
        }

        // what are these lines good for?
        // visualize structure before visualizing the rest
        context.waitForUpdate();
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {

            // :SILENT EXCEPTION:
        }
        contextData.getContext().addUpdateCallback(null);
        if (!context.getContextData().isValid()) {
            return;
        }
        context.addUpdateCallback(new org.srs3d.viewer.j3d.behaviors.UpdateBehavior.Callback() {
                public void execute() {
                    if (sequenceContext != null) {
                        NavigateUpDispatcher.processUpdateColoring(sequenceContext.getContextData());
                    }
                    if (annotationContext != null) {
                        NavigateUpDispatcher.processUpdateColoring(annotationContext.getContextData());
                    }

                    // this is reapply of the style coloring
                    StyleModule.applyColorScheme(contextData, style);
                    updateSelections(contextData, false);
                    update();
                }
            });
    }

    /**
     * Visualizes a <code>ObjectContainer</code> of layers of the method in the specified
     * context.
     *
     * @param context Context to display the layers in.
     */
    public void visualize(final Context context) {
        ContextData contextData = context.getContextData();
        HashSet layers = new HashSet();
        ObjectManager.extract(contextData.getObjectContainer().getObjects(),
            layers, Layer.class);
        Iterator iterator = layers.iterator();
        Layer layer;
        Junction junction;
        BranchGroup layerBranch;
        while (iterator.hasNext()) {
            layer = (Layer) iterator.next();

            // :NOTE: use this as long as we have the texturing in place (for coloring)
            RegisterCommand registerCommand =
                new RegisterCommand(context.getContextData());
            context.getContextData().getStrategyManager().propagate(layer,
                registerCommand, Residue.class);

            // use a transform node with appropriate behaviors
            //      Transform transform = new Transform();
            //      transform.setTransform( layer.getCoordinate() );
            // register transform
            //      contextData.getTransformManager().register( layer, transform );
            // use a junction to able to switch between two representations
            junction = new Junction();
            contextData.getJunctionManager().register(layer, junction);
            if (!layer.isSequenceLayer()) {
                style.applyStateChange(layer);
            }

            // 1st representation
            // use spawn strategy to built the layer geometry (dynamic geometry)
            Strategy strategy =
                contextData.getStrategyManager().getStrategy(layer);
            SpawnCommand spawn = new SpawnCommand(contextData);
            spawn.setBranchGroup(junction.getOnBranch());

            //      spawn.setBranchGroup( layerBranch );
            contextData.getStrategyManager().execute(layer, spawn);
            if (!layer.isSequenceLayer()) {

                // :FIXME: move this into the object container strategy
                GeometryCreator pgc =
                    contextData.getGeometryCreatorFactory().getGeometryCreator(layer);
                if (pgc != null && pgc instanceof LayerGeometryCreator) {
                    ((LayerGeometryCreator) pgc).createAlternate(layer,
                        junction.getOffBranch());
                }
            }

            // built the rest of the layer scene graph anchor
            //      transform.transformGroup.addChild( junction.getEntry() );
            // stick it into the life scene graph of the context
            //      context.getSceneLevel().addChild( transform.getEntry() );
            layerBranch = new BranchGroup();
            BranchGroupHelper.setDefaultCapabilities(layerBranch);
            layerBranch.addChild(junction.getEntry());
            context.getSceneLevel().addChild(layerBranch);
        }
    }

    /**
     * Description of the method
     */
    public void initializePopupMenu() {
        final ContextData contextData = context.getContextData();
        if (!contextData.isValid()) {
            return;
        }
        SwingSettings.update();
        clearPopupMenu();
        if (popupMenu == null) {
            popupMenu = new org.srs3d.viewer.swing.PopupMenu(context, this);
            context.addMouseListener(popupMenu.getMouseListener());
            context.addMouseMotionListener(popupMenu.getMouseListener());
            if (annotationContext != null) {
                PopupMenu.PopupMouseAdapter annotationMouseListener = null;
                annotationMouseListener =
                    popupMenu.getMouseListener(annotationContext, this);
                annotationContext.addMouseListener(annotationMouseListener);
                annotationContext.addMouseMotionListener(annotationMouseListener);
            }
            if (sequenceContext != null) {
                PopupMenu.PopupMouseAdapter sequenceMouseListener = null;
                sequenceMouseListener =
                    popupMenu.getMouseListener(sequenceContext, this);
                sequenceContext.addMouseListener(sequenceMouseListener);
                sequenceContext.addMouseMotionListener(sequenceMouseListener);
            }
        }
        populateMenu(popupMenu);
    }

    /**
     * Method description.
     *
     * @param popupMenu Parameter description.
     */
    public void populateMenu(PopupMenu popupMenu) {
        final ContextData contextData = context.getContextData();
        Check expertCheck =
            new org.srs3d.viewer.swing.Check() {
                public boolean getResult() {
                    return contextData.isExpertContext();
                }
            };
        if (toolbar != null) {
            toolbar.removeAll();
        }
        org.srs3d.viewer.swing.Menu m;
        org.srs3d.viewer.swing.Menu n;
        org.srs3d.viewer.swing.Menu o;
        Vector commands;
        Vector propagateCommands;
        Vector onCommands;
        Vector offCommands;
        m = new org.srs3d.viewer.swing.Menu("Style");
        popupMenu.add(m);
        m.add(new StyleModule("First Impression", contextData,
                new FirstImpressionStyle(contextData)));
        m.getLastModule().addActionListener(this);
        m.add(new StyleModule("Binding Site", contextData,
                new BindingSiteStyle(contextData)));
        m.getLastModule().addActionListener(this);
        if (contextData.getProperty("Compound") != null) {
            m.add(new StyleModule("Compound", contextData,
                    new CompoundStyle(contextData)));
            m.getLastModule().addActionListener(this);
        }
        if (contextData.getProperty("Homology") != null) {
            m.add(new StyleModule("Homology", contextData,
                    new HomologyStyle(contextData)));
            m.getLastModule().addActionListener(this);
        }
        if (contextData.getProperty("Displacement") != null) {
            m.add(new StyleModule("Displacement", contextData,
                    new DisplacementStyle(contextData)));
            m.getLastModule().addActionListener(this);
            m.add(new StyleModule("Superposition", contextData,
                    new SuperpositionStyle(contextData)));
            m.getLastModule().addActionListener(this);
        }
        final org.srs3d.viewer.swing.Menu styleMenu = m;
        SwingUtilities.invokeLater(new Runnable() {
                public void run() {
                    if (toolbar != null) {
                        SwingSettings.update();
                        JLabel label = new JLabel("Style ");
                        label.setHorizontalAlignment(JLabel.RIGHT);
                        toolbar.add(label);
                        JComboBox styleComboBox = styleMenu.createComboBox();
                        styleComboBox.setEnabled(false);
                        styleComboBox.setSelectedItem(((Style) contextData.getProperty(
                                "STYLE")).getName());
                        styleComboBox.setEnabled(true);
                        toolbar.add(styleComboBox);
                        styleMenu.addComboBoxActionListeners(styleComboBox);
                    }
                }
            });

        RestoreModule restoreModule =
            (RestoreModule) context.getContextData().getProperty("RESTORE_MODULE");
        if (restoreModule != null) {
            m = restoreModule.createMenu();
        } else {
            m = RestoreModule.createDefaultMenu(contextData);
        }
        final org.srs3d.viewer.swing.Menu viewMenu = m;
        SwingUtilities.invokeLater(new Runnable() {
                public void run() {
                    if (toolbar != null) {
                        SwingSettings.update();
                        JLabel label = new JLabel("  View ");
                        label.setHorizontalAlignment(JLabel.RIGHT);
                        toolbar.add(label);
                        JComboBox viewComboBox = viewMenu.createComboBox();
                        boolean isComboBoxEnabled = viewComboBox.isEnabled();
                        viewComboBox.setEnabled(false);
                        viewComboBox.setSelectedItem(contextData.getProperty(
                                "VIEW"));
                        log.debug("Setting view to " +
                            contextData.getProperty("VIEW"));
                        viewComboBox.setEnabled(isComboBoxEnabled);
                        toolbar.add(viewComboBox);
                    }
                }
            });

        // add color scheme menu items
        m = new org.srs3d.viewer.swing.Menu("Coloring");
        popupMenu.add(m);
        ColorSchemeBucket colorSchemeBucket;
        AbstractColorScheme colorScheme;
        CPKColorScheme cpkColorScheme = new CPKColorScheme(contextData);
        cpkColorScheme.setComplete(true);
        cpkColorScheme.setInformation(false);
        if (contextData.getProperty("Superposition") != null) {
            colorScheme =
                (AbstractColorScheme) contextData.getProperty(StructureColorScheme.class);
            colorScheme.setComplete(true);
            colorSchemeBucket = new ColorSchemeBucket(colorScheme);
            m.add(new ColorSchemeModule("Structure", contextData,
                    colorSchemeBucket));
            m.getLastModule().addActionListener(this);
        }
        colorSchemeBucket = new ColorSchemeBucket(cpkColorScheme);
        colorSchemeBucket.extend(new MoleculeColorScheme(contextData));
        m.add(new ColorSchemeModule("Molecule", contextData, colorSchemeBucket));
        m.getLastModule().addActionListener(this);
        colorSchemeBucket = new ColorSchemeBucket(cpkColorScheme);
        colorSchemeBucket.extend(new ChainColorScheme(contextData));
        m.add(new ColorSchemeModule("Chain", contextData, colorSchemeBucket));
        m.getLastModule().addActionListener(this);
        colorSchemeBucket = new ColorSchemeBucket(cpkColorScheme);
        colorSchemeBucket.extend(new ChainFragmentColorScheme(contextData));
        m.add(new ColorSchemeModule("Chain Fragment", contextData,
                colorSchemeBucket));
        m.getLastModule().addActionListener(this);
        ((StrategyModule) m.getLastModule()).setVisibleCheck(expertCheck);
        colorSchemeBucket = new ColorSchemeBucket(cpkColorScheme);
        colorSchemeBucket.extend(new SecondaryStructureColorScheme(contextData));
        m.add(new ColorSchemeModule("Secondary Structure", contextData,
                colorSchemeBucket));
        m.getLastModule().addActionListener(this);
        if (contextData.getProperty("Homology") != null) {
            colorScheme =
                (AbstractColorScheme) contextData.getProperty(HomologyColorScheme.class);
            colorScheme.setComplete(true);
            colorSchemeBucket = new ColorSchemeBucket(colorScheme);
            m.add(new ColorSchemeModule("Sequence Similarity", contextData,
                    colorSchemeBucket));
            m.getLastModule().addActionListener(this);
            colorScheme =
                (AbstractColorScheme) contextData.getProperty(HomologyAltColorScheme.class);
            colorScheme.setComplete(true);
            colorSchemeBucket = new ColorSchemeBucket(colorScheme);
            m.add(new ColorSchemeModule("Sequence Similarity (alt.)",
                    contextData, colorSchemeBucket));
            m.getLastModule().addActionListener(this);
        }
        if (contextData.getProperty("Displacement") != null) {
            colorScheme =
                (AbstractColorScheme) contextData.getProperty(DisplacementColorScheme.class);
            colorScheme.setComplete(true);
            colorSchemeBucket = new ColorSchemeBucket(colorScheme);
            m.add(new ColorSchemeModule("Displacement", contextData,
                    colorSchemeBucket));
            m.getLastModule().addActionListener(this);
        }
        colorScheme = new TemperatureColorScheme(contextData);
        colorScheme.setComplete(true);
        m.add(new ColorSchemeModule("Temperature", contextData, colorScheme));
        m.getLastModule().addActionListener(this);
        colorScheme = new CPKColorScheme(contextData);
        m.add(new ColorSchemeModule("Element", contextData, colorScheme));
        m.getLastModule().addActionListener(this);
        m.add(new SeparatorModule());
        ((StrategyModule) m.getLastModule()).setVisibleCheck(expertCheck);
        m.add(new ColorSchemeModule("Gray", contextData,
                new MonochromeColorScheme(contextData,
                    new Color3f(0.5f, 0.5f, 0.5f))));
        ((StrategyModule) m.getLastModule()).setVisibleCheck(expertCheck);
        m.getLastModule().addActionListener(this);
        m.add(new ColorSchemeModule("Red", contextData,
                new MonochromeColorScheme(contextData,
                    new Color3f(1.0f, 0.3f, 0.3f))));
        ((StrategyModule) m.getLastModule()).setVisibleCheck(expertCheck);
        m.getLastModule().addActionListener(this);
        m.add(new ColorSchemeModule("Green", contextData,
                new MonochromeColorScheme(contextData,
                    new Color3f(0.2f, 0.9f, 0.2f))));
        m.getLastModule().addActionListener(this);
        ((StrategyModule) m.getLastModule()).setVisibleCheck(expertCheck);
        m.add(new ColorSchemeModule("Blue", contextData,
                new MonochromeColorScheme(contextData,
                    new Color3f(0.3f, 0.3f, 1.0f))));
        m.getLastModule().addActionListener(this);
        ((StrategyModule) m.getLastModule()).setVisibleCheck(expertCheck);
        final org.srs3d.viewer.swing.Menu coloringMenu = m;
        SwingUtilities.invokeLater(new Runnable() {
                public void run() {
                    if (toolbar != null) {
                        SwingSettings.update();
                        JLabel label = new JLabel("  Coloring ");
                        label.setHorizontalAlignment(JLabel.RIGHT);
                        toolbar.add(label);
                        JComboBox coloringComboBox =
                            coloringMenu.createComboBox();
                        toolbar.add(coloringComboBox);
                        coloringMenu.addComboBoxActionListeners(coloringComboBox);
                        final org.srs3d.viewer.swing.Menu localMenu =
                            coloringMenu;
                        final JComboBox localComboBox = coloringComboBox;
                        Iterator iterator = styleMenu.iterator();
                        while (iterator.hasNext()) {
                            final Module module = (Module) iterator.next();

                            // add coloring combobox update listener to style combobox
                            module.addActionListener(new ActionListener() {
                                    public void actionPerformed(ActionEvent e) {

                                        // update coloring
                                        Iterator iterator =
                                            localMenu.iterator();
                                        ColorSchemeModule colorSchemeModule;
                                        boolean isFound = false;
                                        while (!isFound && iterator.hasNext()) {
                                            try {
                                                colorSchemeModule =
                                                    (ColorSchemeModule) iterator.next();
                                                ColorSchemeBucket bucket =
                                                    colorSchemeModule.getColorSchemeBucket();
                                                ColorSchemeBucket currentBucket =
                                                    context.getContextData()
                                                           .getColorSchemeBucket();
                                                if (bucket != null &&
                                                      currentBucket != null) {
                                                    if (bucket.getBaseColorScheme() != null) {
                                                        if (currentBucket.getBaseColorScheme() != null) {
                                                            if (currentBucket.getBaseColorScheme()
                                                                               .getClass() == bucket.getBaseColorScheme()
                                                                                                      .getClass()) {
                                                                isFound = true;
                                                                boolean enable =
                                                                    localComboBox.isEnabled();
                                                                localComboBox.setEnabled(false);
                                                                localComboBox.setSelectedItem(colorSchemeModule.getName());
                                                                localComboBox.setEnabled(enable);
                                                                KeyHandler.requestFocus(context);
                                                            }
                                                        }
                                                    }
                                                }
                                            } catch (ClassCastException ex) {
                                                ExceptionHandler.handleException(ex,
                                                    ExceptionHandler.SILENT_IN_DEBUG,
                                                    this);
                                            }
                                        }
                                        if (!isFound) {

                                            // :TODO: invalidate combo box entry
                                        }
                                    }
                                });
                        }
                    }
                }
            });

        // add reduce contrast module
        m.add(new SeparatorModule());
        ((StrategyModule) m.getLastModule()).setVisibleCheck(expertCheck);
        m.add(new ColorSchemeCheckModule("Reduced Contrast", contextData,
                new DarkenColorScheme(contextData, new Color3f(0.3f, 0.3f, 0.3f))));
        m.getLastModule().addActionListener(this);
        ((StrategyModule) m.getLastModule()).setVisibleCheck(expertCheck);

        // add representation menu items
        m = new org.srs3d.viewer.swing.Menu("Representation");
        popupMenu.add(m);

        // ribbon representation module
        m.add(RibbonCheck.createRepresentationModule(contextData));
        m.getLastModule().addActionListener(this);
        ((AbstractModule) m.getLastModule()).setKeyStroke(KeyStroke.getKeyStroke(
                KeyEvent.VK_R, KeyEvent.CTRL_MASK | KeyEvent.SHIFT_MASK));

        // coil representation
        m.add(CoilCheck.createRepresentationModule(contextData));
        m.getLastModule().addActionListener(this);
        ((AbstractModule) m.getLastModule()).setKeyStroke(KeyStroke.getKeyStroke(
                KeyEvent.VK_C, KeyEvent.CTRL_MASK | KeyEvent.SHIFT_MASK));

        // ca trace representation
        m.add(CATraceCheck.createRepresentationModule(contextData));
        m.getLastModule().addActionListener(this);
        ((AbstractModule) m.getLastModule()).setKeyStroke(KeyStroke.getKeyStroke(
                KeyEvent.VK_T, KeyEvent.CTRL_MASK | KeyEvent.SHIFT_MASK));

        // :NOTE: activated for 1.1.2 patch
        if (contextData.getProperty("Displacement") != null) {

            // soap representation module
            m.add(SoapFilmCheck.createRepresentationModule(contextData));
            m.getLastModule().addActionListener(this);
            ((StrategyModule) m.getLastModule()).setVisibleCheck(expertCheck);
        }
        m.add(new SeparatorModule());

        // wireframe representation menu item
        m.add(WireframeCheck.createRepresentationModule(contextData));
        m.getLastModule().addActionListener(this);
        ((AbstractModule) m.getLastModule()).setKeyStroke(KeyStroke.getKeyStroke(
                KeyEvent.VK_W, KeyEvent.CTRL_MASK | KeyEvent.SHIFT_MASK));

        // ball and stick menu item
        m.add(BallAndStickCheck.createRepresentationModule(contextData));
        m.getLastModule().addActionListener(this);
        ((StrategyModule) m.getLastModule()).setVisibleCheck(expertCheck);
        ((AbstractModule) m.getLastModule()).setKeyStroke(KeyStroke.getKeyStroke(
                KeyEvent.VK_B, KeyEvent.CTRL_MASK | KeyEvent.SHIFT_MASK));

        // van der waals menu item
        m.add(VanDerWaalsCheck.createRepresentationModule(contextData));
        m.getLastModule().addActionListener(this);
        ((StrategyModule) m.getLastModule()).setVisibleCheck(expertCheck);
        ((AbstractModule) m.getLastModule()).setKeyStroke(KeyStroke.getKeyStroke(
                KeyEvent.VK_F, KeyEvent.CTRL_MASK | KeyEvent.SHIFT_MASK));
        m.add(new SeparatorModule());
        ((StrategyModule) m.getLastModule()).setVisibleCheck(expertCheck);

        // additional (color scheme) representations
        m.add(new ColorSchemeCheckModule("Transparent", contextData,
                (ColorScheme) contextData.getProperty(
                    TransparentColorScheme.class)));
        m.getLastModule().addActionListener(this);
        ((StrategyModule) m.getLastModule()).setVisibleCheck(expertCheck);
        m.add(MeshCheck.createRepresentationModule(contextData));
        m.getLastModule().addActionListener(this);
        ((StrategyModule) m.getLastModule()).setVisibleCheck(expertCheck);
        m.add(new SeparatorModule());
        ((StrategyModule) m.getLastModule()).setVisibleCheck(expertCheck);
        m.add(VisibleCheck.createRepresentationModule(contextData));
        m.getLastModule().addActionListener(this);
        ((StrategyModule) m.getLastModule()).setVisibleCheck(expertCheck);
        ((AbstractModule) m.getLastModule()).setKeyStroke(KeyStroke.getKeyStroke(
                KeyEvent.VK_V, KeyEvent.CTRL_MASK | KeyEvent.SHIFT_MASK));
        m = new org.srs3d.viewer.swing.Menu("Label");
        popupMenu.add(m);
        m.add(new LabelClassModule("Structure", contextData, Layer.class, true));
        m.add(new LabelClassModule("Chain", contextData, Chain.class, true));
        m.add(new LabelClassModule("Secondary Structure", contextData,
                Subchain.class, Coil.class));
        m.add(new LabelClassModule("Residue", contextData, Residue.class));
        m.add(new LabelClassModule("Atom", contextData, Atom.class));
        m.add(new SeparatorModule());
        m.add(new LabelModule("Selection", contextData, false));
        m.getLastModule().addActionListener(this);
        ((AbstractModule) m.getLastModule()).setKeyStroke(KeyStroke.getKeyStroke(
                KeyEvent.VK_L, KeyEvent.CTRL_MASK | KeyEvent.SHIFT_MASK));
        popupMenu.add(new SeparatorModule());
        m = new org.srs3d.viewer.swing.Menu("Calculate");
        popupMenu.add(m);
        ((StrategyModule) m).setVisibleCheck(expertCheck);
        m.add(new DistanceModule("Distance", contextData));
        m.getLastModule().addActionListener(this);
        ((StrategyModule) m.getLastModule()).setVisibleCheck(expertCheck);
        m.add(new ContactModule("Contacts", contextData));
        m.getLastModule().addActionListener(this);
        ((StrategyModule) m.getLastModule()).setVisibleCheck(expertCheck);

        // :NOTE: activated for patch release; was only available in debug mode
        m.add(new HydrogenBondsModule("Hydrogen Bonds", contextData));
        m.getLastModule().addActionListener(this);
        ((StrategyModule) m.getLastModule()).setVisibleCheck(expertCheck);
        m.add(new SeparatorModule());
        m.add(new AtomSurfaceModule("Surface", contextData, 0));
        ((StrategyModule) m.getLastModule()).setVisibleCheck(expertCheck);
        m.add(new AtomSurfaceModule("Surface (reduced)", contextData, -0.5f));
        ((StrategyModule) m.getLastModule()).setVisibleCheck(expertCheck);
        m.add(new ProbeSurfaceModule("Accessible Surface", contextData, 0));
        ((StrategyModule) m.getLastModule()).setVisibleCheck(expertCheck);
        if (addDynamicMenuItems(contextData, popupMenu)) {
            popupMenu.add(new SeparatorModule());
        }
        o = new org.srs3d.viewer.swing.Menu("Edit");
        popupMenu.add(o);
        Operation operation = new Operation(context, "COPY", null);
        operation.setSerializable(false);
        o.add(new OperationModule("Copy", contextData, operation));
        o.getLastModule().addActionListener(this);
        ((AbstractModule) o.getLastModule()).setKeyStroke(KeyStroke.getKeyStroke(
                KeyEvent.VK_C, KeyEvent.CTRL_MASK));
        operation = new Operation(context, "PASTE", null);
        operation.setSerializable(false);
        o.add(new PasteModule("Paste", contextData, operation));
        o.getLastModule().addActionListener(this);
        ((AbstractModule) o.getLastModule()).setKeyStroke(KeyStroke.getKeyStroke(
                KeyEvent.VK_V, KeyEvent.CTRL_MASK));
        o.add(new SeparatorModule());
        ((StrategyModule) o.getLastModule()).setVisibleCheck(expertCheck);
        o.add(new RemoveDistanceModule("Remove Distances", contextData));
        ((StrategyModule) o.getLastModule()).setVisibleCheck(expertCheck);
        o.add(new RemoveLabelModule("Remove Labels", contextData));
        ((StrategyModule) o.getLastModule()).setVisibleCheck(expertCheck);
        o.add(new RemoveSurfaceModule("Remove Surfaces", contextData));
        ((StrategyModule) o.getLastModule()).setVisibleCheck(expertCheck);
        m = new org.srs3d.viewer.swing.Menu("Select");
        popupMenu.add(m);
        m.add(new SelectModule("All", contextData,
                new ObjectClassFilter(Layer.class)));
        m.getLastModule().addActionListener(this);
        ((AbstractModule) m.getLastModule()).setKeyStroke(KeyStroke.getKeyStroke(
                KeyEvent.VK_A, KeyEvent.CTRL_MASK));
        m.add(new SelectModule("Ligands", contextData, new LigandFilter(true)));
        m.getLastModule().addActionListener(this);
        ((AbstractModule) m.getLastModule()).setKeyStroke(KeyStroke.getKeyStroke(
                KeyEvent.VK_L, KeyEvent.CTRL_MASK));
        m.add(new ProximityModule("Proximity 4 �", contextData, 4));
        m.getLastModule().addActionListener(this);
        ((StrategyModule) m.getLastModule()).setVisibleCheck(expertCheck);
        m.add(new ProximityModule("Proximity 6 �", contextData, 6));
        m.getLastModule().addActionListener(this);
        ((StrategyModule) m.getLastModule()).setVisibleCheck(expertCheck);
        String customProximityDistance =
            System.getProperty("srs3d.custom.proximity");
        if (customProximityDistance != null) {
            try {
                float distance = Float.parseFloat(customProximityDistance);
                m.add(new ProximityModule("Proximity " + distance + " �",
                        contextData, distance));
                m.getLastModule().addActionListener(this);
                ((StrategyModule) m.getLastModule()).setVisibleCheck(expertCheck);
            } catch (Exception e) {
                log.error("Cannot create custom proximity module.", e);
            }
        }
        m.add(new SelectResiduesModule("Residues", contextData));
        m.getLastModule().addActionListener(this);
        ((StrategyModule) m.getLastModule()).setVisibleCheck(expertCheck);
        m.add(new SelectAlignedResiduesModule("Aligned Residues", contextData));
        m.getLastModule().addActionListener(this);
        ((StrategyModule) m.getLastModule()).setVisibleCheck(expertCheck);
        m.add(new SelectModule("Water", contextData, new WaterFilter()));
        m.getLastModule().addActionListener(this);
        ((StrategyModule) m.getLastModule()).setVisibleCheck(expertCheck);
        m.add(new SeparatorModule());
        m.add(new SelectFeatureModule("Active Annotation", contextData));
        m.getLastModule().addActionListener(this);
        o = new org.srs3d.viewer.swing.Menu("View");
        popupMenu.add(o);
        o.add(new SaveModule("Save", contextData));
        ((AbstractModule) o.getLastModule()).setKeyStroke(KeyStroke.getKeyStroke(
                KeyEvent.VK_S, KeyEvent.CTRL_MASK));
        o.add(new SaveAsModule("Save As...", contextData, this));
        ((AbstractModule) o.getLastModule()).setKeyStroke(KeyStroke.getKeyStroke(
                KeyEvent.VK_S, KeyEvent.CTRL_MASK | KeyEvent.SHIFT_MASK));
        o.add(new ResetModule("Revert", contextData, this));
        ((AbstractModule) o.getLastModule()).setKeyStroke(KeyStroke.getKeyStroke(
                KeyEvent.VK_R, KeyEvent.CTRL_MASK));
        ((AbstractModule) o.getLastModule()).setOperationSerializeable(false);
        o.add(new DeleteViewModule("Delete", contextData, this));
        ((AbstractModule) o.getLastModule()).setKeyStroke(KeyStroke.getKeyStroke(
                KeyEvent.VK_D, KeyEvent.CTRL_MASK | KeyEvent.SHIFT_MASK));
        o.add(viewMenu);
        o.add(new SeparatorModule());
        operation = new Operation(context, "ZOOM", null);
        operation.setSerializable(false);
        o.add(new OperationModule("Zoom to Selection", contextData, operation));
        o.getLastModule().addActionListener(this);
        ((AbstractModule) o.getLastModule()).setKeyStroke(KeyStroke.getKeyStroke(
                KeyEvent.VK_ENTER, 0));
        operation = new Operation(context, "ZOOM_OUT", null);
        operation.setSerializable(false);
        o.add(new OperationModule("Zoom Out", contextData, operation));
        o.getLastModule().addActionListener(this);
        ((AbstractModule) o.getLastModule()).setKeyStroke(KeyStroke.getKeyStroke(
                KeyEvent.VK_ENTER, KeyEvent.SHIFT_MASK));
        o.add(new SeparatorModule());
        Collection overlays = contextData.getOverlayManager().getOverlays();
        if (!overlays.isEmpty()) {

            // add links to menu
            Iterator iterator = overlays.iterator();
            org.srs3d.viewer.j3d.objects.Overlay overlay;
            int index;
            while (iterator.hasNext()) {
                overlay =
                    (org.srs3d.viewer.j3d.objects.Overlay) iterator.next();
                o.add(new OverlayModule(overlay.getName(), contextData));
            }
        }

        //    o.add( new SeparatorModule() );
        //
        //    SwitchPrintModeModule printModule = new SwitchPrintModeModule( "Bright Mode", contextData );
        //    printModule.register( contextData );
        //    o.add( printModule );
        //
        if (contextData.getProperty("ApplicationMode") != null) {
            o.add(new SeparatorModule());
            o.add(new RunApplicationModule("Full Screen", contextData));
        }
        o = new org.srs3d.viewer.swing.Menu("Options");
        popupMenu.add(o);
        o.add(new SolidRenderingModule("Move as C-alpha Trace", contextData));
        ((AbstractModule) o.getLastModule()).setKeyStroke(KeyStroke.getKeyStroke(
                KeyEvent.VK_M, KeyEvent.CTRL_MASK));
        o.add(new AnimationModule("Spin", contextData));
        ((AbstractModule) o.getLastModule()).setKeyStroke(KeyStroke.getKeyStroke(
                KeyEvent.VK_P, KeyEvent.CTRL_MASK | KeyEvent.SHIFT_MASK));
        if (context.getContextData().getContext().getStereoAvailable()) {
            o.add(new StereoModule("Stereo", contextData));
        }
        if (contextData.getProperty("DebugMode") != null) {
            o.add(new HierarchyViewModule("Browse Hierarchy", contextData));
            if (annotationContext != null) {
                o.add(new HierarchyViewModule("Browse Annotation Hierarchy",
                        annotationContext.getContextData()));
            }
            if (sequenceContext != null) {
                o.add(new HierarchyViewModule("Browse Sequence Hierarchy",
                        sequenceContext.getContextData()));
            }
        }
        if (contextData.getProperty("CaptureMode") != null) {
            try {
                o.getLastModule().addActionListener(this);
                o.add(new CaptureModule("Image Capturing", contextData));
                o.add(new InterpreterModule("Open Interpreter", contextData));
            } catch (NoClassDefFoundError e) {

                // :SILENT-EXCEPTION:
                ExceptionHandler.handleException(e,
                    ExceptionHandler.SILENT_IN_DEBUG, this);
            }
        }

        //    if (contextData.getProperty("TestMode") != null) {
        o.add(new SlabModule("Slab", contextData));
        o.add(new AttenuationModule("Depth cueing", contextData));

        //    }
        o.add(new AvatarSwitchModule("Persistent Overlays", contextData));
        ((AbstractModule) o.getLastModule()).setKeyStroke(KeyStroke.getKeyStroke(
                KeyEvent.VK_O, KeyEvent.CTRL_MASK | KeyEvent.SHIFT_MASK));
        o.add(new SeparatorModule());
        o.add(new ExpertMenuModule("Full Menus", contextData));
        ((AbstractModule) o.getLastModule()).setKeyStroke(KeyStroke.getKeyStroke(
                KeyEvent.VK_M, KeyEvent.CTRL_MASK | KeyEvent.SHIFT_MASK));
        o.add(new SeparatorModule());
        o.add(new AboutModule("About...", contextData));
        if (toolbar != null) {
            SwingUtilities.invokeLater(new Runnable() {
                    public void run() {
                        toolbar.validate();
                        toolbar.repaint();
                    }
                });
        }

        //    ( ( AbstractModule ) o.getLastModule() ).setKeyStroke(
        //        KeyStroke.getKeyStroke( KeyEvent.VK_O, KeyEvent.CTRL_MASK | KeyEvent.SHIFT_MASK ) );
    }

    /**
     * Adds a <code>DynamicMenuItems</code> object to the <code>Capture</code> object.
     *
     * @param contextData The <code>DynamicMenuItems</code> object to be added.
     * @param popupMenu The <code>DynamicMenuItems</code> object to be added.
     */
    public boolean addDynamicMenuItems(ContextData contextData,
        org.srs3d.viewer.swing.PopupMenu popupMenu) {
        org.srs3d.viewer.swing.Menu m;
        boolean hasEntries = false;
        Collection annotations = new Vector();
        AnnotationModule.getAnnotations(contextData, annotations);
        m = AnnotationCreateModule.createMenu(contextData, this, annotations,
                features, activeFeatures);
        if (m != null) {
            popupMenu.add(m);
            hasEntries = true;
        }

        // dynamic menu item
        if (!links.isEmpty()) {

            // add links to menu
            Iterator iterator = links.iterator();
            m = new org.srs3d.viewer.swing.Menu("Links");
            popupMenu.add(m);
            String descriptor;
            int index;
            LinkModule.LinkTemplate template;
            while (iterator.hasNext()) {
                descriptor = (String) iterator.next();
                template =
                    LinkModule.createLinkTemplate(contextData, descriptor);
                m.add(new LinkModule(template.name, template, contextData));
            }
            hasEntries = true;
        }
        try {
            ApplicationContext applicationContext = getApplicationContext();
            ModulePublisher modulePublisher =
                (ModulePublisher) applicationContext.get(
                    "CustomModulePublisher");
            if (modulePublisher != null) {
                modulePublisher.publishModules(contextData, popupMenu);
            }
        } catch (Exception e) {
            ExceptionHandler.handleException(e, this);
        }
        contextData.setProperty("POPUP-MENU", popupMenu);
        return hasEntries;
    }

    /**
     * Description of the method.
     */
    public void clearPopupMenu() {
        ContextData contextData = context.getContextData();
        if (popupMenu != null) {
            popupMenu.clear();
        }
    }

    /**
     * Method description.
     */
    public void validate() {
        update();
    }

    /**
     * Description of the method
     */
    public void update() {
        if (!context.getContextData().isValid()) {
            return;
        }
        float annotationSizeY = 80f;
        float sequenceSizeY = 80f;
        if (splitPane != null) {
            int sizeY = splitPane.getHeight();
            annotationSizeY = 80f;
            sequenceSizeY = 80f;

            //      float sequenceSizeY = 120f;
            if (annotationContext != null) {
                AnnotationContainer annotationContainer =
                    ((AnnotationContextData) annotationContext.getContextData()).getAnnotationContainer();
                if (annotationContainer != null) {
                    Collection alignments = annotationContainer.getAlignments();
                    Alignment alignment = null;
                    if (alignments.size() > 0) {
                        alignment = (Alignment) alignments.iterator().next();
                    }
                    if (alignment != null) {
                        StateManager stateManager =
                            annotationContext.getContextData().getStateManager();
                        State state = stateManager.getState(alignment);
                        AlignmentLayout alignmentLayout =
                            (AlignmentLayout) state.getAttribute(AlignmentLayout.class);
                        if (alignmentLayout != null) {
                            annotationSizeY = alignmentLayout.getHeight();
                            annotationSizeY *= 4.4f;
                        }
                    }
                }
                float contentHeight =
                    annotationSizeY * splitPane.getWidth() / 1280f;
                annotationSizeY *= 800f / 1280;
                annotationContext.setContentHeight(contentHeight);
                if (annotationSizeY > splitPane.getHeight() / 3) {
                    annotationSizeY = splitPane.getHeight() / 3;
                }
                sizeY -= annotationSizeY;
            }
            if (sequenceContext != null) {
                AnnotationContextData sequenceContextData =
                    (AnnotationContextData) sequenceContext.getContextData();
                Alignment alignment =
                    sequenceContextData.getActiveBoxAlignment();
                if (alignment != null) {
                    StateManager stateManager =
                        sequenceContext.getContextData().getStateManager();
                    State state = stateManager.getState(alignment);
                    AlignmentLayout alignmentLayout =
                        (AlignmentLayout) state.getAttribute(AlignmentLayout.class);
                    if (alignmentLayout != null) {
                        sequenceSizeY = alignmentLayout.getHeight();
                        sequenceSizeY *= 5;
                    }
                }

                //        sequenceSizeY *= splitPane.getWidth() / 1280f;
                //        sequenceSizeY *= 700.0f / 1280f;
                sizeY -= sequenceSizeY;
            }
            if (context.getContextData().isValid()) {
                if (sequenceContext != null && annotationContext != null) {
                    splitPane.setDividerLocation(sizeY);
                } else {
                    if (sequenceContext == null && annotationContext == null) {
                        splitPane.setDividerLocation(1.0);
                    } else {
                        splitPane.setDividerLocation(sizeY);
                    }
                }
            }
        }
        final int annotationSizeYDummy = (int) annotationSizeY;
        SwingUtilities.invokeLater(new Runnable() {
                public void run() {
                    if (context.getContextData() != null &&
                          context.getContextData().isValid()) {
                        splitPane.validate();
                        splitPane.doLayout();
                        if (annotationSplitPane != null) {
                            annotationSplitPane.setDividerLocation(annotationSizeYDummy);
                            annotationSplitPane.validate();
                            annotationSplitPane.doLayout();
                        }
                        org.srs3d.viewer.j3d.behaviors.UpdateBehavior.Callback callback;
                        callback =
                            new org.srs3d.viewer.j3d.behaviors.UpdateBehavior.Callback() {
                                    public void execute() {
                                        context.update();
                                        OverlayManager.spawnOverlays(context.getContextData());
                                        if (annotationContext != null) {
                                            annotationContext.update();
                                        }
                                        if (sequenceContext != null) {
                                            sequenceContext.update();
                                        }
                                    }
                                };
                        context.addUpdateCallback(callback);
                    }
                }
            });
    }

    /**
     * Description of the method.
     *
     * @param e Description of parameter.
     */
    public void actionPerformed(ActionEvent e) {

        // update the selections
        //    log.trace( this + ": memory after process: " );
        //    dumpMemoryAnalysis();
    }

    /**
     * Description of the method
     */
    public void interpreteParameters() {
        Map idMap = new HashMap();

        // setup context properties
        context.getContextData().setProperty("LAYER_IDMAP", idMap);
        context.getContextData().setProperty("ANNOTATIONS", annotations);
        context.getContextData().setProperty("LAYER_ALIGNMENTMAP",
            layerAlignmentMap);
        context.getContextData().setProperty("FEATURES", features);
        context.getContextData().setProperty("ACTIVE_FEATURES", activeFeatures);
        context.getContextData().setProperty("LINKED_DATABASES", linkedDatabases);

        // try to read the url from the applet parameters
        String string;
        string = getAppletStub().getParameter("structures");
        if (string != null) {
            context.getContextData().getDispatcher().dispatch(StructureModule.createLoadOperation(
                    context.getContextData(), string));
        }
        string = getAppletStub().getParameter("genericUrl");
        if (string != null) {
            URL url =
                Parameter.supplementUrl(getAppletStub().getCodeBase(), string);
            ObjectContainer objectContainer = loadGeneric(url);
            context.getContextData().setProperty("GENERIC_DATA", "YES");
            if (objectContainer != null) {
                context.getContextData().getObjectContainer().addObject(objectContainer);

                //        context.getContextData().setProperty( "GENERIC_DATA", "YES" );
            }

            //      else {
            //
            //        org.srs3d.viewer.swing.ComponentFactory.messageDialog( context,
            //          "The file " + string + " cannot be loaded.",
            //          "Error loading file", JOptionPane.WARNING_MESSAGE, null );
            //
            //      }
            AnnotationModule.convertLinksToAnnotations(context.getContextData()
                                                              .getObjectContainer());
        }

        // read sequence to structure alignment
        String alignmentString =
            getAppletStub().getParameter("sequenceAlignments");
        if (alignmentString != null) {
            context.getContextData().getDispatcher().dispatch(org.srs3d.viewer.annotation.modules.AnnotationModule.createLoadOperation(
                    context.getContextData(), alignmentString));
            isSequenceAlignment = true;
        }
        String annotationString = getAppletStub().getParameter("annotations");
        if (annotationString != null) {
            context.getContextData().getDispatcher().dispatch(org.srs3d.viewer.bioatlas.modules.AnnotationModule.createLoadOperation(
                    context.getContextData(), annotationString));
        }
        commonInterpreteParameters();
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     */
    public static void setDefaultFlags(ContextData contextData) {
        AppletStub appletStub = contextData.getAppletStub();
        String string = appletStub.getParameter("autoZoom");
        if (string != null && string.equalsIgnoreCase("off")) {
            contextData.setProperty("AutoZoom", "OFF");
            log.debug("Disabling autoZoom.");
        }
        string = appletStub.getParameter("debugMode");
        if (string != null && string.equalsIgnoreCase("on")) {
            contextData.setProperty("DebugMode", "ON");
        }
        string = appletStub.getParameter("testMode");
        if (string != null && string.equalsIgnoreCase("on")) {
            contextData.setProperty("TestMode", "ON");
        }
        string = appletStub.getParameter("runtimeTestMode");
        if (string != null && string.equalsIgnoreCase("on")) {
            contextData.setProperty("RuntimeTestMode", "ON");
        }
        string = appletStub.getParameter("captureMode");
        if (string != null && string.equalsIgnoreCase("on")) {
            contextData.setProperty("CaptureMode", "ON");
        }
        string = appletStub.getParameter("autoSpin");
        if (string != null && string.equalsIgnoreCase("on")) {
            contextData.setProperty("AutoSpin", "ON");
        }
        string = appletStub.getParameter("expertMode");
        if (string != null && string.equalsIgnoreCase("on")) {
            contextData.setExpertContext(true);
        } else {
            contextData.setExpertContext(false);
        }
    }

    /**
     * Description of the method.
     */
    public void commonInterpreteParameters() {
        setDefaultFlags(context.getContextData());
        String string = getAppletStub().getParameter("instanceId");
        if (string != null) {
            int index;
            String runTimeMode =
                getAppletStub().getParameter("runtimeTestMode");
            if (runTimeMode == null || runTimeMode.equalsIgnoreCase("off")) {
                index = string.lastIndexOf("\\");
                if (index != -1) {
                    string = string.substring(index + 1);
                }
            }
            index = string.lastIndexOf("/");
            if (index != -1) {
                string = string.substring(index + 1);
            }
            context.getContextData().setProperty("INSTANCE-ID", string);
        }
        string = getAppletStub().getParameter("applicationMode");
        if (string == null || string.equalsIgnoreCase("applet")) {
            context.getContextData().setProperty("ApplicationMode", "Applet");
        }
        string = getAppletStub().getParameter("links");
        if (string != null) {
            links.clear();
            linkedDatabases.clear();
            StringTokenizer tokenizer = new StringTokenizer(string, ";");
            String token;
            String dbId;
            int index;
            while (tokenizer.hasMoreTokens()) {
                token = tokenizer.nextToken();
                dbId = LinkModule.getDatabaseId(token);
                if (dbId != null) {
                    linkedDatabases.add(dbId);
                }
                links.add(token);
            }
        }
        string = getAppletStub().getParameter("defaultStyle");
        if (string != null) {
            if (string.equalsIgnoreCase("Superposition")) {
                style = new SuperpositionStyle(context.getContextData());
                context.getContextData().setProperty("Superposition", "ON");
            } else if (string.equalsIgnoreCase("Homology")) {
                style = new HomologyStyle(context.getContextData());
                Map alignmentMap = new Hashtable();
                AnnotationContainer.createAlignmentMap(layerAlignmentMap,
                    alignmentMap);
            } else if (string.equalsIgnoreCase("Displacement")) {
                style = new DisplacementStyle(context.getContextData());
                Map alignmentMap = new Hashtable();
                AnnotationContainer.createAlignmentMap(layerAlignmentMap,
                    alignmentMap);
            } else if (string.equalsIgnoreCase("BindingSite")) {
                style = new BindingSiteStyle(context.getContextData());
            } else if (string.equalsIgnoreCase("Compound")) {
                style = new CompoundStyle(context.getContextData());
                context.getContextData().setProperty("Compound", "ON");
            }
        }
        if (style == null) {
            style = new FirstImpressionStyle(context.getContextData());
        }
        context.getContextData().setProperty("STYLE", style);
        context.getContextData().setProperty("DEFAULT-STYLE", style);
    }

    /**
     * Description of the method.
     */
    public synchronized void initializeMouseCursors() {
        try {
            CursorManager.createCursor("RotateZ",
                getClass().getResource("/org/srs3d/viewer/bioatlas/resource/RotateZ.gif"),
                new Point(10, 10));
            CursorManager.createCursor("RotateXY",
                getClass().getResource("/org/srs3d/viewer/bioatlas/resource/RotateXY.gif"),
                new Point(12, 12));
            CursorManager.createCursor("PanXY",
                getClass().getResource("/org/srs3d/viewer/bioatlas/resource/PanXY.gif"),
                new Point(8, 8));
            CursorManager.createCursor("PanX",
                getClass().getResource("/org/srs3d/viewer/bioatlas/resource/PanX.gif"),
                new Point(8, 8));
            CursorManager.createCursor("PanZ",
                getClass().getResource("/org/srs3d/viewer/bioatlas/resource/PanZ.gif"),
                new Point(5, 7));
            CursorManager.createCursor("Select",
                getClass().getResource("/org/srs3d/viewer/bioatlas/resource/Select.gif"),
                new Point(1, 1));
            CursorManager.createCursor("SelectAdd",
                getClass().getResource("/org/srs3d/viewer/bioatlas/resource/SelectAdd.gif"),
                new Point(1, 1));
            CursorManager.createCursor("SelectMinus",
                getClass().getResource("/org/srs3d/viewer/bioatlas/resource/SelectMinus.gif"),
                new Point(1, 1));
            CursorManager.createCursor("SelectAll",
                getClass().getResource("/org/srs3d/viewer/bioatlas/resource/SelectAll.gif"),
                new Point(1, 1));
            CursorManager.createCursor("SelectAddAll",
                getClass().getResource("/org/srs3d/viewer/bioatlas/resource/SelectAddAll.gif"),
                new Point(1, 1));
            CursorManager.createCursor("SelectRange",
                getClass().getResource("/org/srs3d/viewer/bioatlas/resource/SelectRange.gif"),
                new Point(1, 1));
            CursorManager.createCursor("Activate",
                getClass().getResource("/org/srs3d/viewer/bioatlas/resource/Activate.gif"),
                new Point(10, 1));
            CursorManager.createCursor("ActivateAdd",
                getClass().getResource("/org/srs3d/viewer/bioatlas/resource/ActivateAdd.gif"),
                new Point(10, 1));
            CursorManager.createCursor("ActivateAddAll",
                getClass().getResource("/org/srs3d/viewer/bioatlas/resource/NoOperation.gif"),
                new Point(10, 1));
            CursorManager.createCursor("ActivateAll",
                getClass().getResource("/org/srs3d/viewer/bioatlas/resource/NoOperation.gif"),
                new Point(10, 1));
            CursorManager.createCursor("ActivateMinus",
                getClass().getResource("/org/srs3d/viewer/bioatlas/resource/ActivateAdd.gif"),
                new Point(10, 1));
            CursorManager.createCursor("ActivateRange",
                getClass().getResource("/org/srs3d/viewer/bioatlas/resource/NoOperation.gif"),
                new Point(10, 1));
            CursorManager.createCursor("PanXAdd",
                getClass().getResource("/org/srs3d/viewer/bioatlas/resource/NoOperation.gif"),
                new Point(10, 1));
            CursorManager.createCursor("PanXRange",
                getClass().getResource("/org/srs3d/viewer/bioatlas/resource/NoOperation.gif"),
                new Point(10, 1));
            CursorManager.createCursor("PanXAll",
                getClass().getResource("/org/srs3d/viewer/bioatlas/resource/NoOperation.gif"),
                new Point(10, 1));
        } catch (Exception e) {
            ExceptionHandler.handleException(e, this);
        }
    }

    /**
     * Description of the method.
     *
     * @param context Description of parameter.
     */
    private void destroy(final Context context, final Container container) {
        if (context != null) {
            context.getView().stopBehaviorScheduler();
            context.getView().stopView();

            // empty callback queue (no subsequent callbacks)
            context.terminateCallbacks();

            // no more update callbacks are put in the queue
            context.setUpdateEnabled(false);

            // allow waiting threads to stop waiting for the queue to finish
            context.setTimeoutEnabled(true);
            clearPopupMenu();
            ContextManager.removeContext(context);
            DispatchManager.removeDispatcher(context);
            container.remove(context);
            context.cleanup(true);
        }
    }

    /**
     * Sets the <code>verbose</code> attribute of the <code>Capture</code> class.
     *
     * @param isVerbose The new <code>verbose</code> value.
     */
    public static void setVerbose(boolean isVerbose) {

        //    ExecuteClassCommand.isVerbose = isVerbose;
        //    ExpandCommand.isVerbose = isVerbose;
        //    PreSelectCommand.isVerbose = isVerbose;
        //    RegisterCommand.isVerbose = isVerbose;
        RepresentationCommand.isVerbose = isVerbose;
        SpawnCommand.isVerbose = isVerbose;
        ColorCommand.isVerbose = isVerbose;

        //    VisibleCommand.isVerbose = isVerbose;
    }

    /**
     * Iterator through all selection of the context and reapplies the selection coloring
     *
     * @param contextData Description of parameter.
     * @param isRecolor Description of parameter.
     */
    public static void updateSelections(ContextData contextData,
        boolean isRecolor) {
        SelectionManager selectionManager = contextData.getSelectionManager();
        Selection selection;
        Selection mainSelection = selectionManager.getSelection();
        Iterator iterator =
            contextData.getSelectionManager().getApplicationOrder().iterator();
        while (iterator.hasNext()) {
            selection = (Selection) iterator.next();
            if (selection != mainSelection) {
                selection.reapplyColorScheme(isRecolor);
            }
        }

        // the main selection ia always colored last
        mainSelection.reapplyColorScheme(isRecolor);
    }

    /**
     * Description of the method.
     */
    public static void dumpMemoryAnalysis() {
        Runtime runtime = Runtime.getRuntime();
        float total = (float) runtime.totalMemory() / 1000000;
        float free = (float) runtime.freeMemory() / 1000000;
        float used = total - free;
        log.trace("Memory Status\nTotal: " + total + "; Free: " + free +
            "; Used: " + used);
    }

    protected void instantiateModules() {

        // :FIXME: refactor the popup generation!!! this shouldn't be necessary
        // anymore; could use setVisible attribute; care about updating the modules
        // (invisible modules are not updated); how handle separators
        ContextData contextData = context.getContextData();
        new AnnotationToggleModule("AnnotationToggle", contextData);
        new AnnotationToggleExModule("AnnotationToggleEx", contextData);
        String string = (String) contextData.getProperty("RuntimeTestMode");
        if (string != null && string.equalsIgnoreCase("on")) {
            new RuntimeTestModule("RuntimeTestModule", contextData);
        }
    }

    /**
     * Method description.
     *
     * @param applicationContext Parameter description.
     */
    public void setApplicationContext(ApplicationContext applicationContext) {
        this.applicationContext = applicationContext;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public ApplicationContext getApplicationContext() {
        return applicationContext;
    }

    /**
     * Read a DataTransferObject.
     *
     * @return The read DataTransferObject.
     */
    public DataTransferObject read() throws RemoteException {
        Connector connector =
            (Connector) getApplicationContext().get("Connector");
        if (connector != null) {

            // :TODO: define a defaul contract or just do the read for a specific
            //   source.
            return connector.read();
        }
        return null;
    }

    /**
     * Read a DataTransferObject and use the passed DataTransferObject as parameters for
     * the call.
     *
     * @param object Parameter DataTransferObject.
     *
     * @return Read DataTransferObject.
     */
    public DataTransferObject read(DataTransferObject object)
        throws RemoteException {
        Connector connector =
            (Connector) getApplicationContext().get("Connector");
        if (connector != null) {
            return connector.read(object);
        }
        return null;
    }

    /**
     * Writes the DataTransferObject.
     *
     * @param object The DataTransferObject for writing.
     */
    public void write(DataTransferObject object) throws RemoteException {
        Connector connector =
            (Connector) getApplicationContext().get("Connector");
        if (connector != null) {
            connector.write(object);
        }
    }

    /**
     * Method description.
     *
     * @param event Parameter description.
     */
    public void receive(ComponentEvent event) {
        log.debug(this + ": received " + event);
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public PopupMenu getPopupMenu() {
        while (popupMenu == null) {
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {

                // :SILENT EXCEPTION:
            }
        }
        return popupMenu;
    }

    /**
     * Method description.
     *
     * @param component Parameter description.
     */
    public static void disableFocusTraversalKeys(Component component) {
        try {
            component.setFocusTraversalKeysEnabled(false);
        } catch (NoSuchMethodError e) {

            // :SILENT EXCEPTION:
            // java 1.3 version
        } catch (Exception e) {

            // :SILENT EXCEPTION:
        }
    }

    /**
     * Method description.
     *
     * @param component Parameter description.
     * @param g Parameter description.
     */
    public void printContexts(Component component, Graphics g) {
        ApplicationContext context = getApplicationContext();
        BufferedImage image;
        ContextData contextData = (ContextData) context.get("MainContextData");
        if (contextData != null) {
            image = contextData.getContext().getRenderedImage();
            if (image != null) {
                int x = -component.getLocationOnScreen().x;
                int y = -component.getLocationOnScreen().y;
                x += contextData.getContext().getLocationOnScreen().x;
                y += contextData.getContext().getLocationOnScreen().y;
                g.drawImage(image, x, y, null);
            }
        }
        contextData = (ContextData) context.get("AnnotationContextData");
        if (contextData != null) {
            image = contextData.getContext().getRenderedImage();
            if (image != null) {
                int x = -component.getLocationOnScreen().x;
                int y = -component.getLocationOnScreen().y;
                x += contextData.getContext().getLocationOnScreen().x;
                y += contextData.getContext().getLocationOnScreen().y;
                g.drawImage(image, x, y, null);
            }
        }
        contextData = (ContextData) context.get("SequenceContextData");
        if (contextData != null) {
            image = contextData.getContext().getRenderedImage();
            if (image != null) {
                int x = -component.getLocationOnScreen().x;
                int y = -component.getLocationOnScreen().y;
                x += contextData.getContext().getLocationOnScreen().x;
                y += contextData.getContext().getLocationOnScreen().y;
                g.drawImage(image, x, y, null);
            }
        }
    }
}
