/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.objects;

import java.util.Collection;
import java.util.Vector;

import org.srs3d.viewer.bioatlas.visitors.SubchainAnalyser;

/**
 * @author Karsten Klein
 *
 * @created March 22, 2001
 */
public final class ChainFragment extends AbstractChain {

    /** Description of the field. */
    public static final char INVALID_ID = 0;

    /** Description of the field. */
    public static final int INVALID_SERIAL = -1;
    private char id = INVALID_ID;
    private int serial = INVALID_SERIAL;
    private Vector subchains = new Vector();

    /**
     * Sets the <code>Id</code> attribute of the <code>Chain</code> object.
     *
     * @param id The new <code>Id</code> value.
     */
    public void setId(char id) {
        this.id = id;
    }

    /**
     * Sets the <code>serial</code> attribute of the <code>ChainFragment</code> object.
     *
     * @param serial The new <code>serial</code> value.
     */
    public void setSerial(int serial) {
        this.serial = serial;
    }

    /**
     * Gets the <code>serial</code> attribute of the <code>ChainFragment</code> object.
     *
     * @return The <code>serial</code> value.
     */
    public int getSerial() {
        return serial;
    }

    /**
     * Gets the <code>Id</code> attribute of the <code>Chain</code> object.
     *
     * @return The <code>Id</code> value.
     */
    public char getId() {
        return id;
    }

    /**
     * Gets the <code>Subchains</code> attribute of the <code>Chain</code> object.
     *
     * @return The <code>Subchains</code> value.
     */
    public Vector getSubchains() {
        return subchains;
    }

    /**
     * Gets the <code>AllObjects</code> attribute of the <code>Chain</code> object.
     *
     * @param collection Description of parameter.
     */
    public void getAllObjects(Collection collection) {
        boolean needsResidueLevel = containsLigandResidues();
        boolean needsSubchainLevel = !needsResidueLevel;

        // subchains are added ALWAYS if available
        if (subchains == null || subchains.isEmpty()) {
            needsResidueLevel = true;
        } else {
            if (needsSubchainLevel) {
                collection.addAll(subchains);
            } else {
                needsResidueLevel = true;
            }
        }

        // residue are added, if no suchains are available or a ligand residue was
        // detected
        if (needsResidueLevel) {
            if (getEndResidue() != null) {
                Residue residue = getInitialResidue();
                Residue limit = getEndResidue().getProceeding();
                while (residue != null && residue != limit) {
                    collection.add(residue);
                    residue = residue.getProceeding();
                }
            }
        }
    }

    /**
     * Adds a feature to the <code>Subchain</code> attribute of the <code>Chain
     * </code>object.
     *
     * @param subchain The feature to be added to the <code>Subchain</code> attribute.
     */
    public void addSubchain(Subchain subchain) {
        subchains.addElement(subchain);
    }

    /**
     * Description of the method.
     *
     * @return Description of the returned value.
     */
    public String toString() {
        String string = new String("Chain");
        if (id != INVALID_ID) {
            string += id;
        }
        if (serial != INVALID_SERIAL) {
            string += serial;
        }
        if (getInitialResidue() != null) {
            if (isLigand()) {
                string += getInitialResidue().getTemplate().getName();
            }
        }

        // debug stuff
        //    string += getExceptionalResidues();
        //    string += " " + isLigand();
        return string;
    }

    /**
     * Updates the none transient data of the chain.
     */
    public void update() {
        super.update();
        if (!containsLigandResidues()) {
            SubchainAnalyser subchainAnalyser = new SubchainAnalyser();
            subchainAnalyser.visit(this);
        }
    }

    /**
     * Description of the method.
     */
    public void cleanup() {
        super.cleanup();
        cleanup(subchains);
        subchains = null;
    }
}
