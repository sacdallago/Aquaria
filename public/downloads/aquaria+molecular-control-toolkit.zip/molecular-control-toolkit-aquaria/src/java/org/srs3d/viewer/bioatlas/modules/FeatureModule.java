/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.modules;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Collection;
import java.util.Iterator;

import javax.swing.JCheckBoxMenuItem;

import org.srs3d.viewer.bioatlas.colorschemes.FeatureColorScheme;
import org.srs3d.viewer.bioatlas.objects.Annotation;
import org.srs3d.viewer.bioatlas.objects.Feature;
import org.srs3d.viewer.j3d.ColorScheme;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.DispatchManager;
import org.srs3d.viewer.j3d.Selection;
import org.srs3d.viewer.j3d.commands.ColorCommand;
import org.srs3d.viewer.objects.Operation;
import org.srs3d.viewer.util.Chronometer;

/**
 * <code>Module</code> implementation for displaying and switching on/off features. The
 * class also provides static methods for feature creation. Note that we use addObject()
 * and addObjects() of class <code>Selection</code> to activate the feature elements.
 * This way we prevent the elements from being rejected from the selection.
 *
 * @author Karsten Klein
 *
 * @created August 9, 2001
 */
public class FeatureModule extends AbstractModule {
    private Feature feature;
    private JCheckBoxMenuItem component = null;

    /**
     * <code>FeatureModule</code> constructor.
     *
     * @param name Description of parameter.
     * @param contextData Description of parameter.
     * @param feature Description of parameter.
     * @param activeFeatures Description of parameter.
     */
    public FeatureModule(String name, ContextData contextData, Feature feature) {
        super(name, contextData);
        this.feature = feature;
    }

    /**
     * Gets the <code>component</code> attribute of the <code>FeatureModule </code>
     * object.
     *
     * @return The <code>component</code> value.
     */
    public Component getComponent() {
        create();
        return component;
    }

    /**
     * Description of the method.
     *
     * @param e Description of parameter.
     */
    public void react(ActionEvent e) {
        if (isFeatureActive(getContextData(), feature)) {
            deactivateFeature(getContextData(), feature);
        } else {
            activateFeature(getContextData(), feature);
        }
        getContextData().getContext().addUpdateCallback(new org.srs3d.viewer.j3d.behaviors.UpdateBehavior.Callback() {
                public void execute() {
                    org.srs3d.viewer.bioatlas.modules.ColorSchemeModule.updateLegendOverlay(getContextData());
                }
            });

        //    super.actionPerformed( e );
    }

    /**
     * Description of the method.
     */
    public void updateIntern() {
        if (component != null) {
            component.setState(isFeatureActive(getContextData(), feature));
        }
    }

    /**
     * Description of the method.
     */
    public void cleanup() {
        super.cleanup();
        feature = null;
        component = null;
    }

    /**
     * Description of the method.
     */
    private void create() {
        if (component == null) {
            component = new JCheckBoxMenuItem(getName(), true);
            component.addActionListener(this);
        }
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     * @param listener Description of parameter.
     * @param features Description of parameter.
     * @param activeFeatures Description of parameter.
     *
     * @return Description of the returned value.
     */
    public static org.srs3d.viewer.swing.Menu createMenu(
        ContextData contextData, ActionListener listener, Collection features) {
        if (!features.isEmpty()) {
            org.srs3d.viewer.swing.Menu m =
                new org.srs3d.viewer.swing.Menu("Features");
            Iterator iterator = features.iterator();
            Feature feature;
            while (iterator.hasNext()) {
                feature = (Feature) iterator.next();
                m.add(new FeatureModule(feature.getName(), contextData, feature));
                if (listener != null) {
                    m.getLastModule().addActionListener(listener);
                }
            }
            return m;
        }
        return null;
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     * @param features Description of parameter.
     */
    public static void activateFeatures(final ContextData contextData,
        final Collection features) {
        Iterator iterator = features.iterator();
        Feature feature;
        while (iterator.hasNext()) {
            feature = (Feature) iterator.next();
            activateFeature(contextData, feature);
        }
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     * @param features Parameter description.
     */
    public static void deactivateFeatures(ContextData contextData,
        Collection features) {
        Iterator iterator = features.iterator();
        Feature feature;
        while (iterator.hasNext()) {
            feature = (Feature) iterator.next();
            deactivateFeature(contextData, feature);
        }
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     * @param feature Description of parameter.
     */
    public static void deactivateFeature(final ContextData contextData,
        final Feature feature) {

        // clear according selection
        Selection selection =
            contextData.getSelectionManager().getSelection(feature);
        selection.clear();
        contextData.getSelectionManager().remove(feature);

        // color the feature; NOT the feature objects
        ColorCommand colorCommand =
            new ColorCommand(contextData, (ColorScheme) null);
        contextData.getStrategyManager().execute(feature, colorCommand);
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     * @param feature Description of parameter.
     */
    public static void activateFeature(final ContextData contextData,
        final Feature feature) {
        Chronometer c = Chronometer.getChronometer("Feature activation");
        c.setVerbose(true);
        c.start();
        Selection selection =
            contextData.getSelectionManager().getSelection(feature);
        selection.clear();

        // color feature, NOT the feature objects
        ColorCommand colorCommand = new ColorCommand(contextData);
        contextData.getStrategyManager().execute(feature, colorCommand);
        selection.setColorScheme(new FeatureColorScheme(contextData,
                feature.getColor(), false));

        //    HashSet set = new HashSet( feature.getObjects().size() );
        //    contextData.getObjectManager().collapseUpExtended( feature.getObjects(), set );
        //    set.addAll( feature.getObjects() );
        // don't need the upper lines if the feature is collapsed anyway
        Collection set = feature.getObjects();
        selection.addAll(set, false);
        selection.setName(feature.getName());
        c.stop("feature activation full execute " + feature);
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     * @param feature Parameter description.
     *
     * @return Return description.
     */
    public static boolean isFeatureActive(ContextData contextData,
        Feature feature) {
        return contextData.getSelectionManager().hasSelection(feature);
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     * @param annotation Parameter description.
     */
    public static void deactivateAnnotation(ContextData contextData,
        Annotation annotation) {
        deactivateFeatures(contextData, annotation.getFeatures());
        DispatchManager.runDispatch(contextData.getContext(),
            new Operation(contextData.getContext(), "UPDATE_ACTIVATION",
                annotation));
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     * @param annotations Parameter description.
     */
    public static void deactivateAnnotations(ContextData contextData,
        Collection annotations) {
        Iterator iterator = annotations.iterator();
        while (iterator.hasNext()) {
            deactivateAnnotation(contextData, (Annotation) iterator.next());
        }
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     * @param annotation Parameter description.
     */
    public static void activateAnnotation(ContextData contextData,
        Annotation annotation) {
        activateFeatures(contextData, annotation.getFeatures());
        DispatchManager.runDispatch(contextData.getContext(),
            new Operation(contextData.getContext(), "UPDATE_ACTIVATION",
                annotation));
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     * @param annotations Parameter description.
     */
    public static void activateAnnotations(ContextData contextData,
        Collection annotations) {
        Iterator iterator = annotations.iterator();
        while (iterator.hasNext()) {
            activateAnnotation(contextData, (Annotation) iterator.next());
        }
    }
}
