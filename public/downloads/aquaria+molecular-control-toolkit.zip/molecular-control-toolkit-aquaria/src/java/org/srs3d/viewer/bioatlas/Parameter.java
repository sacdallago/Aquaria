/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas;

import java.awt.Color;
import java.net.URL;
import java.util.Date;

import org.srs3d.viewer.urn.URNStreamHandler;
import org.srs3d.viewer.util.ExceptionHandler;
import org.srs3d.viewer.util.Log;

/**
 * Parameter collection class.
 *
 * @author Karsten Klein
 *
 * @created March 22, 2001
 */
public class Parameter {
    private static final Log log = new Log(Parameter.class);
    public static String productName = "SRS 3D";
    public static String applicationName = "SRS 3D Viewer";
    public static final String productVersion = "";
    public static final String applicationVersion = "251";
    public static final String internalVersionInformation =
        "alpha: build 145; " + "SRS 3D RC 1: build 193; " +
        "SRS 3D RC2: build 203; " + "SRS 3D RC 3: build 213; " +
        "SRS 3D 1.0: build 216; " + "SRS 3D 1.1: build 226; " +
        "SRS 3D 1.1.2: build 248";
    public static Date expirationDate = null;
    public static float siteAtomRadiusScale = 0.35f;
    public static float siteBondRadius = 0.40f;
    public static float disulfideSiteAtomRadiusScale = 0.15f;
    public static float disulfideSiteBondRadius = 0.15f;
    public static float ligandAtomRadiusScale = 0.375f;
    public static float ligandBondRadius = 0.375f;
    public static float bondLengthTolerance = 0.2f;

    // coarse settings
    //  public static int helixFramesPerResidue = 4;
    //  public static int strandFramesPerResidue = 3;
    //  public static int naFramesPerResidue = 3;
    //  public static int coilFramesPerResidue = 3;
    //  public static int turnFramesPerResidue = 3;
    //  public static int helixDivisionsPerFrame = 4;
    //  public static int strandDivisionsPerFrame = 4;
    //  public static int naDivisionsPerFrame = 5;
    //  public static int coilDivisionsPerFrame = 3;
    //  public static int turnDivisionsPerFrame = 3;
    //  public static int sphereSegmentsPerAngstrom = 3;
    //  public static int cylinderDivisions = 3;
    // normal settings
    public static int helixFramesPerResidue = 5;
    public static int strandFramesPerResidue = 4;
    public static int naFramesPerResidue = 3;
    public static int coilFramesPerResidue = 4;
    public static int turnFramesPerResidue = 4;
    public static int helixDivisionsPerFrame = 4;
    public static int strandDivisionsPerFrame = 4;
    public static int naDivisionsPerFrame = 6;
    public static int coilDivisionsPerFrame = 5;
    public static int turnDivisionsPerFrame = 5;
    public static int sphereSegmentsPerAngstrom = 6;
    public static int cylinderDivisions = 6;

    //  // some nice settings
    //  public static int helixFramesPerResidue = 7;
    //  public static int strandFramesPerResidue = 6;
    //  public static int naFramesPerResidue = 6;
    //  public static int coilFramesPerResidue = 6;
    //  public static int turnFramesPerResidue = 6;
    //  public static int helixDivisionsPerFrame = 6;
    //  public static int strandDivisionsPerFrame = 6;
    //  public static int naDivisionsPerFrame = 8;
    //  public static int coilDivisionsPerFrame = 7;
    //  public static int turnDivisionsPerFrame = 7;
    //  public static int sphereSegmentsPerAngstrom = 8;
    //  public static int cylinderDivisions = 8;
    // some really nice settings
    //  public static int helixFramesPerResidue = 10;
    //  public static int strandFramesPerResidue = 8;
    //  public static int naFramesPerResidue = 6;
    //  public static int coilFramesPerResidue = 10;
    //  public static int turnFramesPerResidue = 10;
    //  public static int helixDivisionsPerFrame = 4;
    //  public static int strandDivisionsPerFrame = 4;
    //  public static int naDivisionsPerFrame = 10;
    //  public static int coilDivisionsPerFrame = 8;
    //  public static int turnDivisionsPerFrame = 8;
    //  public static int sphereSegmentsPerAngstrom = 12;
    //  public static int cylinderDivisions = 8;

    /** annotation parameters */
    public static int minimumAnnotationChainLength = 250;
    public static float chainAnnotationHeight = 6.5f;
    public static float alignmentDistance = 12.0f;
    public static int fragmentGapInsertion = 3;
    public static float annotationUnitHeight = 5;
    public static float featureHeight = 2.5f;
    public static float annotationRulerHeight = 2.5f;
    public static float sequenceRulerHeight = 1.5f;
    public static float voidHeight = 3.0f;
    public static float coilAnnotationSize = 0.5f;
    public static float helixAnnotationSize = 2.6f;
    public static float strandAnnotationSize = 1.5f;
    public static float strandAnnotationConeSize = 2.6f;
    public static float strandAnnotationDepth = 1.5f;
    public static float turnAnnotationSize = 1.7f;
    public static float sectionAnnotationSize = 1.2f;
    public static int segmentCylinder = 1;
    public static int segmentQuad = 2;
    public static int maxConeSize = 3;
    public static int segmentDivision = 6;

    /** sequence parameters */
    public static float sequenceChainAnnotationHeight = 6.0f;

    // not used, instead use sequenceLengthFactor
    public static int maximumSequenceLength = 120;
    public static float sequenceLengthFactor = 7.0f;
    public static int sequenceDistance = 8;
    public static int zoomBoxUpdateDelay = 1;

    /** sequencewidth != 1.0 creates problems (i.e. centerzooming) */
    public static float residueSequenceWidth = 1.0f;
    public static float helixSequenceSize = 2.6f;
    public static float strandSequenceSize = 2.0f;
    public static float strandSequenceConeSize = 2.6f;
    public static float turnSequenceSize = 1.5f;
    public static float coilSequenceSize = 1.5f;
    public static boolean helixUseCircleContour = false;
    public static boolean turnUseCircleContour = true;
    public static boolean naUseCircleContour = true;
    public static boolean coilUseCircleContour = true;
    public static boolean strandUseCircleContour = false;

    // :FIXME: get rid of these
    public static String pdbUrlPrefix =
        "http://dddbsvr01:8080/data2/db/pdb_gz/";
    public static String fileUrlPrefix = "file:///G:/bioATLAS/";
    public static final float aspectScaleX = 0.8f;
    public static final float aspectScaleY = 0.8f;
    public static final Color panelBackgroundColor = Color.black;
    public static final URNStreamHandler urnStreamHandler =
        new URNStreamHandler();

    /**
     * Composes a URL form the given context (applet documents base or code base) url
     * string and the urlString. This method is kind of orphan. It should be moved, once
     * a better fitting class is detected.
     *
     * @param urlContext Context url string.
     * @param urlString Url string.
     *
     * @return Composed Url.
     */
    public static URL supplementUrl(URL urlContext, String urlString) {

        // :FIXME: network places under windows are not considered; are they?
        URL url = null;
        try {
            URL urlRelative;
            try {
                if (urlString.toLowerCase().trim().startsWith("urn:")) {
                    urlRelative = new URL(null, urlString, urnStreamHandler);
                } else {
                    urlRelative = new URL(urlString);
                }
            } catch (java.net.MalformedURLException e) {
                ExceptionHandler.handleException(e,
                    ExceptionHandler.SILENT_IN_DEBUG, Parameter.class);
                urlRelative = new URL(urlContext.getProtocol(), "", urlString);
            }
            String protocol = urlRelative.getProtocol();
            if (protocol.equalsIgnoreCase(urlContext.getProtocol())) {
                String host = urlRelative.getHost();
                int port = urlRelative.getPort();
                String path = urlRelative.getPath();
                String query = urlRelative.getQuery();
                if (urlContext != null) {
                    if (path.indexOf("/") != 0) {
                        path = urlContext.getPath();
                        path = path.substring(0, path.lastIndexOf("/"));
                        path += '/' + urlRelative.getPath();
                    }
                    if (protocol == null || protocol.length() == 0) {
                        protocol = urlContext.getProtocol();
                    }
                    if (host == null || host.length() == 0) {
                        host = urlContext.getHost();
                    }
                    if (port == -1) {
                        port = urlContext.getPort();
                    }
                }
                if (query != null) {
                    path += '?' + query;
                }
                url = new URL(protocol, host, port, path);
            } else {
                url = urlRelative;
            }
        } catch (Exception e) {
            ExceptionHandler.handleException(e, Parameter.class);
        }
        log.info("Composed url: " + url);
        return url;
    }
}
