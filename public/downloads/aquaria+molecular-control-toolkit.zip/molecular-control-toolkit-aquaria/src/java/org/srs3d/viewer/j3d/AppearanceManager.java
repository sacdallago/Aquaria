/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d;

import java.awt.image.BufferedImage;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

import javax.media.j3d.Appearance;
import javax.media.j3d.ImageComponent;
import javax.media.j3d.ImageComponent2D;
import javax.media.j3d.Texture;
import javax.media.j3d.Texture2D;
import javax.vecmath.Color3f;
import javax.vecmath.Color4f;

import org.srs3d.viewer.objects.AbstractManager;
import org.srs3d.viewer.objects.AbstractObject;

/**
 * Formerly this class managed all appearances in the system. In order to adapt it to our
 * needs it's internal structure was totally replaced. The resulting implementation
 * simply interfaces the ColorSchemeBucketManager to recreate appearances on demand.
 *
 * @author Karsten Klein
 *
 * @created May 2, 2001
 */
public final class AppearanceManager extends AbstractManager {

    /** Description of the field. */
    public static final Color3f defaultColor = new Color3f(0.3f, 0.3f, 0.3f);

    /** Description of the field. */
    public static TextureColors defaultTextureColors = null;

    // maps opjects to images (texture coloring)
    private Map textureColorMap = new Hashtable();
    private Map appearanceMap = new Hashtable();

    /**
     * <code>AppearanceManager</code> constructor.
     *
     * @param contextData Description of parameter.
     */
    public AppearanceManager(ContextData contextData) {
        super(contextData);
    }

    /**
     * Gets the <code>textureColors</code> attribute of the
     * <code>AppearanceManager</code> object.
     *
     * @param object Description of parameter.
     *
     * @return The <code>textureColors</code> value.
     */
    public TextureColors getTextureColors(AbstractObject object) {
        return (TextureColors) textureColorMap.get(object);
    }

    /**
     * Creates a new Appearance for the specified object.
     *
     * @param object Object to create an appearance for.
     *
     * @return The generated <code>Appearance</code> instance.
     */
    public Appearance getAppearance(AbstractObject object) {
        Appearance appearance = (Appearance) appearanceMap.get(object);
        if (appearance == null) {
            appearance = AppearanceHelper.createAppearance(defaultColor);
            appearanceMap.put(object, appearance);
        }
        return appearance;
    }

    /**
     * Description of the method.
     *
     * @param object Description of parameter.
     * @param textureColors Description of parameter.
     */
    public void registerTextureColors(AbstractObject object,
        TextureColors textureColors) {
        textureColorMap.put(object, textureColors);
    }

    /**
     * Description of the method.
     */
    public void clear() {
        appearanceMap.clear();
    }

    /**
     * Description of the method.
     *
     * @param object Description of parameter.
     */
    public void remove(AbstractObject object) {
        appearanceMap.remove(object);
    }

    /**
     * Description of the method.
     *
     * @param object Description of parameter.
     * @param appearance Description of parameter.
     */
    public void register(AbstractObject object, Appearance appearance) {
        appearanceMap.put(object, appearance);
    }

    /**
     * Gets the <code>defaultTextureColors</code> attribute of the
     * <code>AppearanceManager</code> class.
     *
     * @return The <code>defaultTextureColors</code> value.
     */
    public static TextureColors getDefaultTextureColors() {
        if (defaultTextureColors == null) {
            defaultTextureColors = new TextureColors();
            defaultTextureColors.setImage(new BufferedImage(1, 1,
                    BufferedImage.TYPE_INT_ARGB));
            defaultTextureColors.setColor(0, new Color3f(1.0f, 0.3f, 0.3f));
        }
        return defaultTextureColors;
    }

    /**
     * Method description.
     */
    public void cleanup() {
        textureColorMap.clear();
        appearanceMap.clear();
        TextureColors.cleanup(getContextData());
    }

    /**
     * Description of the class.
     *
     * @author Karsten Klein
     *
     * @created February 7, 2002
     */
    public static class TextureColors {
        private static Map registryMap = new Hashtable();
        private AbstractObject referenceObject;
        private Texture texture;
        private ImageComponent2D imageComponent;
        private BufferedImage image;
        private int offset = 0;
        private int width = 0;
        private boolean isActive = false;

        /**
         * Sets the <code>width</code> attribute of the <code>TextureColors</code>
         * object.
         *
         * @param width The new <code>width</code> value.
         */
        public void setWidth(int width) {
            this.width = width;
        }

        /**
         * Sets the <code>image</code> attribute of the <code>TextureColors</code>
         * object.
         *
         * @param image The new <code>image</code> value.
         */
        public void setImage(BufferedImage image) {
            this.image = image;
        }

        /**
         * Sets the <code>active</code> attribute of the <code>TextureColors</code>
         * object.
         *
         * @param isActive The new <code>active</code> value.
         */
        public void setActive(boolean isActive) {
            this.isActive = isActive;
        }

        /**
         * Sets the <code>color</code> attribute of the <code>TextureColors</code>
         * object.
         *
         * @param index The new <code>color</code> value.
         * @param color The new <code>color</code> value.
         */
        public void setColor(int index, Color4f color) {
            int argb = 0;
            java.awt.Color c;
            color.clamp(0, 1);
            c = color.get();
            argb = c.getBlue();
            argb |= c.getGreen() << 8;
            argb |= c.getRed() << 16;
            int alpha = c.getAlpha();
            alpha = 255 - alpha;
            argb |= alpha << 24;
            image.setRGB(index + offset, 0, argb);
        }

        /**
         * Sets the <code>color</code> attribute of the <code>TextureColors</code>
         * object.
         *
         * @param index The new <code>color</code> value.
         * @param color The new <code>color</code> value.
         */
        public void setColor(int index, Color3f color) {
            int argb = 0;
            java.awt.Color c;
            color.clamp(0, 1);
            c = color.get();
            argb = c.getBlue();
            argb |= c.getGreen() << 8;
            argb |= c.getRed() << 16;
            image.setRGB(index + offset, 0, argb);
        }

        /**
         * Sets the <code>referenceObject</code> attribute of the
         * <code>TextureColors</code> object.
         *
         * @param referenceObject The new <code>referenceObject</code> value.
         */
        public void setReferenceObject(AbstractObject referenceObject) {
            this.referenceObject = referenceObject;
        }

        /**
         * Gets the <code>active</code> attribute of the <code>TextureColors</code>
         * object.
         *
         * @return The <code>active</code> value.
         */
        public boolean isActive() {
            return isActive;
        }

        /**
         * Gets the <code>offset</code> attribute of the <code>TextureColors</code>
         * object.
         *
         * @return The <code>offset</code> value.
         */
        public int getOffset() {
            return offset;
        }

        /**
         * Gets the <code>image</code> attribute of the <code>TextureColors</code>
         * object.
         *
         * @return The <code>image</code> value.
         */
        public BufferedImage getImage() {
            return image;
        }

        /**
         * Gets the <code>monochromatic</code> attribute of the
         * <code>TextureColors</code> object.
         *
         * @return The <code>monochromatic</code> value.
         */
        public boolean isMonochromatic() {
            if (image != null) {
                int color;
                int firstColor = -1;
                for (int i = width - 1; i >= 0; i--) {
                    color = image.getRGB(i, 0);
                    if (i == width - 1) {
                        firstColor = color;
                    } else {
                        if (color != firstColor) {
                            return false;
                        }
                    }
                }
            }
            return true;
        }

        /**
         * Checks the colors in the texture for alpha attributes that show transparency
         * of the particular pixel.
         *
         * @return <code>true</code> if at least one transparent pixel was found.
         */
        public boolean isTransparent() {
            if (image != null) {
                int color;
                for (int i = width - 1; i >= 0; i--) {
                    color = image.getRGB(i, 0) >> 24;
                    if (color < 0) {
                        color = -color - 1;
                    }
                    if (color > 0) {
                        return true;
                    }
                }
            }
            return false;
        }

        /**
         * Gets the <code>referenceObject</code> attribute of the
         * <code>TextureColors</code> object.
         *
         * @return The <code>referenceObject</code> value.
         */
        public AbstractObject getReferenceObject() {
            return referenceObject;
        }

        /**
         * Gets the <code>color</code> attribute of the <code>TextureColors</code>
         * object.
         *
         * @param index Description of parameter.
         *
         * @return The <code>color</code> value.
         */
        public Color4f getColor(int index) {
            int argb = image.getRGB(index + offset, 0);
            Color4f color = new Color4f();
            float factor = 1.0f / 255f;
            color.x = factor * ((argb >> 16) & 0xFF);
            color.y = factor * ((argb >> 8) & 0xFF);
            color.z = factor * (argb & 0xFF);
            color.w = factor * ((argb >> 24) & 0xFF);
            return color;
        }

        /**
         * Description of the method.
         *
         * @return Description of the returned value.
         */
        public String toString() {
            return getClass().toString() + ": [" + referenceObject.hashCode() +
            "][" + width + "][" + texture + "][" + offset + "]";
        }

        /**
         * Description of the method.
         *
         * @param contextData Description of parameter.
         *
         * @return Description of the returned value.
         */
        public Texture createTexture(ContextData contextData) {
            create(contextData);
            return texture;
        }

        /**
         * Description of the method.
         *
         * @param offset Description of parameter.
         *
         * @return Description of the returned value.
         */
        public TextureColors createOffset(int offset) {
            TextureColors textureColors = new TextureColors();
            textureColors.image = this.image;
            textureColors.width = this.width;
            textureColors.texture = this.texture;
            textureColors.imageComponent = this.imageComponent;
            textureColors.offset = this.offset + offset;
            textureColors.referenceObject = this.referenceObject;
            return textureColors;
        }

        /**
         * Gets the <code>texture</code> attribute of the <code>TextureColors</code>
         * object.
         *
         * @param contextData Description of parameter.
         *
         * @return The <code>texture</code> value.
         */
        private Texture getTexture(ContextData contextData) {
            HashMap textureColorsMap = (HashMap) registryMap.get(contextData);
            if (textureColorsMap != null) {
                return (Texture) textureColorsMap.get(this);
            }
            return null;
        }

        /**
         * Description of the method.
         *
         * @param contextData Description of parameter.
         * @param texture Description of parameter.
         */
        private void register(ContextData contextData, Texture texture) {
            Map textureColorsMap = (Map) registryMap.get(contextData);
            if (textureColorsMap == null) {
                textureColorsMap = new Hashtable();
                registryMap.put(contextData, textureColorsMap);
            }
            textureColorsMap.put(this, texture);
        }

        /**
         * Description of the method.
         *
         * @param contextData Description of parameter.
         */
        private void create(ContextData contextData) {

            // always reinitialize texture
            texture =
                new Texture2D(Texture2D.BASE_LEVEL, Texture2D.RGBA,
                    image.getWidth(), image.getHeight());
            imageComponent =
                new ImageComponent2D(ImageComponent.FORMAT_RGBA, image, true,
                    true);
            texture.setImage(0, imageComponent);
        }

        /**
         * Description of the method.
         *
         * @param contextData Description of parameter.
         */
        public static void cleanup(ContextData contextData) {
            registryMap.remove(contextData);
        }
    }
}
