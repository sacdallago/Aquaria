/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.objects;

import java.util.Collection;
import java.util.HashSet;

import javax.vecmath.Color3f;

import org.srs3d.viewer.j3d.Colorable;
import org.srs3d.viewer.j3d.Linkable;
import org.srs3d.viewer.j3d.objects.Link;
import org.srs3d.viewer.objects.AbstractObject;

/**
 * Features consist of a collection of objects and include a link. Currently the coloring
 * is feature based. This might change in the future. To activate a feature the current
 * mechanism is to create a selection from the feature objects and maintain a list of
 * activated features.
 *
 * @author Karsten Klein
 *
 * @created October 5, 2001
 */
public class Feature extends AbstractObject implements Colorable, Linkable {
    private Collection objects = new HashSet();
    private String name = null;
    private Color3f color = new Color3f();
    private Link link = null;
    private String description = "";

    /**
     * Sets the <code>name</code> attribute of the <code>Feature</code> object.
     *
     * @param name The new <code>name</code> value.
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Sets the <code>color</code> attribute of the <code>Feature</code> object.
     *
     * @param color The new <code>color</code> value.
     */
    public void setColor(Color3f color) {
        this.color.set(color);
    }

    /**
     * Gets the <code>name</code> attribute of the <code>Feature</code> object.
     *
     * @return The <code>name</code> value.
     */
    public String getName() {
        return name;
    }

    /**
     * Gets the <code>objects</code> attribute of the <code>Feature</code> object.
     *
     * @return The <code>objects</code> value.
     */
    public Collection getObjects() {
        return objects;
    }

    /**
     * Gets the <code>color</code> attribute of the <code>Feature</code> object.
     *
     * @return The <code>color</code> value.
     */
    public Color3f getColor() {
        return color;
    }

    /**
     * Adds a <code>Collection</code> of objects to the <code>Feature</code> object list.
     *
     * @param objects The <code>Collection</code> of objects to be added.
     */
    public void addObjects(Collection objects) {
        this.objects.addAll(objects);
    }

    /**
     * Adds an <code>AbstractObject</code> to the <code>Feature</code> objects.
     *
     * @param object The <code>AbstractObject</code> object to be added.
     */
    public void addObject(AbstractObject object) {
        objects.add(object);
    }

    /**
     * Checks if the <code>Feature</code> contains objects.
     *
     * @return <code>true</code> if at least one object is in the feature.
     */
    public boolean hasObjects() {
        return !objects.isEmpty();
    }

    /**
     * Method description.
     */
    public void cleanup() {
        cleanup(objects);
        objects = null;
        color = null;
        link = null;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public String toString() {
        return getName() + " " + getDescription();
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public Link getLink() {
        return link;
    }

    /**
     * Method description.
     *
     * @param link Parameter description.
     */
    public void setLink(Link link) {
        this.link = link;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public String getDescription() {
        return description;
    }

    /**
     * Method description.
     *
     * @param description Parameter description.
     */
    public void setDescription(String description) {
        this.description = description;
    }

    //  public void getAllObjects( Collection objects ) {
    //
    //    objects.addAll( this.objects );
    //
    //  }
    public int getDescriptionHash() {
        int hash = 0;
        String string = getDescription();
        for (int i = 0; i < string.length(); i++) {
            hash += string.charAt(i);
        }
        return hash;
    }
}
