/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.objects;

import javax.vecmath.Color3f;
import javax.vecmath.Point3f;

import org.srs3d.viewer.bioatlas.objects.templates.AtomTemplate;
import org.srs3d.viewer.objects.AbstractObject;

/**
 * Atom class. The class defines all the instrinsic data of an atom. Extrinsic atom type
 * and element specific data is stored in the AtomTemplate.
 *
 * @author Karsten Klein
 *
 * @created October 28, 2000
 */
public final class Atom extends AbstractObject {

    /** Char used to identify undefined laternate location */
    public static final char INVALID_ALTERNATE_LOCATION = 0;
    private AtomTemplate template = null;
    private Point3f coordinate = new Point3f();
    private char alternateLocation = INVALID_ALTERNATE_LOCATION;
    private float charge = 0.0f;
    private float occupancy = 1.0f;
    private float temperature = 1.0f;

    /**
     * Sets the <code>AtomTemplate</code> of the <code>Atom</code> object.
     *
     * @param template The new <code>AtomTemplate</code> .
     */
    public void setTemplate(AtomTemplate template) {
        this.template = template;
    }

    /**
     * Sets the <code>Coordinate</code> attribute of the <code>Atom</code> object.
     *
     * @param coordinate The new <code>Coordinate</code> value.
     */
    public void setCoordinate(Point3f coordinate) {
        this.coordinate.set(coordinate);
    }

    /**
     * Sets the <code>AlternateLocation</code> attribute of the <code>Atom </code>object.
     *
     * @param alternateLocation The new <code>AlternateLocation</code> value.
     */
    public void setAlternateLocation(char alternateLocation) {
        this.alternateLocation = alternateLocation;
    }

    /**
     * Sets the <code>temperature</code> attribute of the <code>Atom</code> object.
     *
     * @param temperature The new <code>temperature</code> value.
     */
    public void setTemperature(float temperature) {
        this.temperature = temperature;
    }

    /**
     * Sets the <code>occupancy</code> attribute of the <code>Atom</code> object.
     *
     * @param occupancy The new <code>occupancy</code> value.
     */
    public void setOccupancy(float occupancy) {
        this.occupancy = occupancy;
    }

    /**
     * Sets the <code>Charge</code> attribute of the <code>Atom</code> object.
     *
     * @param charge The new <code>Charge</code> value.
     */
    public void setCharge(float charge) {
        this.charge = charge;
    }

    /**
     * Gets the <code>AtomTemplate</code> of the <code>Atom</code> object.
     *
     * @return The <code>Template</code> value.
     */
    public AtomTemplate getTemplate() {
        return template;
    }

    /**
     * Gets the <code>coordinate</code> of the <code>Atom</code> object.
     *
     * @return The <code>coordinate</code> of the <code>Atom</code> .
     */
    public Point3f getCoordinate() {
        return coordinate;
    }

    /**
     * Gets the <code>alternateLocation</code> attribute of the <code>Atom </code>object.
     *
     * @return The <code>alternateLocation</code> value.
     */
    public char getAlternateLocation() {
        return alternateLocation;
    }

    /**
     * Gets the <code>temperature</code> attribute of the <code>Atom</code> object.
     *
     * @return The <code>temperature</code> value.
     */
    public float getTemperature() {
        return temperature;
    }

    /**
     * Gets the <code>occupancy</code> attribute of the <code>Atom</code> object.
     *
     * @return The <code>occupancy</code> value.
     */
    public float getOccupancy() {
        return occupancy;
    }

    /**
     * Gets the <code>charge</code> attribute of the <code>Atom </code> object.
     *
     * @return The <code>charge</code> value.
     */
    public float getCharge() {
        return charge;
    }

    /**
     * Gets the <code>vanDerWaalsRadius</code> attribute of the <code>Atom </code>object.
     *
     * @return The <code>VanDerWaalsRadius</code> value.
     */
    public float getVanDerWaalsRadius() {
        return template.getVanDerWaalsRadius();
    }

    /**
     * Gets the <code>covalentRadius</code> attribute of the <code>Atom</code> object.
     *
     * @return The <code>covalentRadius</code> value.
     */
    public float getCovalentRadius() {
        return template.getCovalentRadius();
    }

    /**
     * Gets the <code>electronegativity</code> attribute of the <code>Atom </code>object.
     *
     * @return The <code>electronegativity</code> value.
     */
    public float getElectronegativity() {
        return template.getElectronegativity();
    }

    /**
     * Gets the <code>color</code> attribute of the <code>Atom</code> object.
     *
     * @return The <code>color</code> value.
     */
    public Color3f getColor() {
        return template.getColor();
    }

    /**
     * Releases all associated data.
     */
    public void cleanup() {
        super.cleanup();
        template = null;
        coordinate = null;
    }

    /**
     * Converts the <code>Atom</code> to a string
     *
     * @return Description of the returned value.
     */
    public String toString() {
        String string = new String();
        if (template != null && template.getId() != null) {
            string += template.getId();
            if (alternateLocation != INVALID_ALTERNATE_LOCATION) {
                string += alternateLocation;
            }
        }
        return string;
    }
}
