/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.visitors;

import java.util.Collection;
import java.util.Iterator;

import javax.vecmath.Matrix4f;
import javax.vecmath.Point3f;
import javax.vecmath.Tuple3f;
import javax.vecmath.Vector3f;

import org.srs3d.viewer.bioatlas.filters.BaseObjectFilter;
import org.srs3d.viewer.bioatlas.objects.Atom;
import org.srs3d.viewer.objects.ObjectFilter;
import org.srs3d.viewer.objects.visitors.ObjectCollector;

/**
 * This class provides the methods to collect all the <code>Atom</code> instances from an
 * <code>AbstractObject</code> hierarchy. It additionally provides computational
 * methods, that access the found collection of atoms.
 *
 * @author Karsten Klein
 *
 * @created January 20, 2001
 */
public class AtomCollector extends ObjectCollector {
    private transient Point3f center = null;
    private transient Vector3f extend = null;

    /**
     * <code>AtomCollector</code> constructor.
     *
     * @param objectFilter Description of parameter.
     */
    public AtomCollector(ObjectFilter objectFilter) {
        super(objectFilter);
    }

    /**
     * <code>AtomCollector</code> constructor.
     */
    public AtomCollector() {
        super(new BaseObjectFilter(Atom.class));
    }

    /**
     * Computes the center of all atom coordinates.
     *
     * @return <code>Point3f</code> the coordinate of the center.
     */
    public Point3f computeCenter() {
        Point3f center = new Point3f();
        int size = getObjects().size();
        if (size > 0) {
            Iterator iterator = getObjects().iterator();
            while (iterator.hasNext()) {
                center.add(((Atom) iterator.next()).getCoordinate());
            }
            center.scale(1.0f / size);
        }
        return center;
    }

    /**
     * Translates all the collected atoms by <code>translation</code>
     *
     * @param translation vector to add on current atom position.
     */
    public void translateAtoms(Tuple3f translation) {
        Iterator iterator = getObjects().iterator();
        while (iterator.hasNext()) {
            ((Atom) iterator.next()).getCoordinate().add(translation);
        }
        computeCenter();
        center.add(translation);
    }

    /**
     * Tranforms all the collected atoms using the tranformation <code>matrix </code>.
     *
     * @param matrix transformation matrix that is applied to each atom coordinate.
     */
    public void transformAtoms(Matrix4f matrix) {
        Atom atom;
        Iterator iterator = getObjects().iterator();
        while (iterator.hasNext()) {
            atom = (Atom) iterator.next();
            matrix.transform(atom.getCoordinate());
        }
        getCenter();
        matrix.transform(center);
    }

    /**
     * Note that the extend is computed with reference to the center. This way it might
     * return an extend that is bigger than the real extend of the atom set.
     *
     * @return Description of the returned value.
     */
    public Vector3f computeExtend() {
        Vector3f min =
            new Vector3f(Float.MAX_VALUE, Float.MAX_VALUE, Float.MAX_VALUE);
        Vector3f max =
            new Vector3f(-Float.MAX_VALUE, -Float.MAX_VALUE, -Float.MAX_VALUE);
        Point3f point;
        float radius;
        Vector3f radiusVector = new Vector3f();
        Iterator iterator = getObjects().iterator();
        Atom atom;
        Point3f center = getCenter();
        while (iterator.hasNext()) {
            atom = (Atom) iterator.next();
            point = atom.getCoordinate();
            radius = atom.getVanDerWaalsRadius();
            min.x = (min.x < point.x - radius) ? min.x : point.x - radius;
            min.y = (min.y < point.y - radius) ? min.y : point.y - radius;
            min.z = (min.z < point.z - radius) ? min.z : point.z - radius;
            max.x = (max.x > point.x + radius) ? max.x : point.x + radius;
            max.y = (max.y > point.y + radius) ? max.y : point.y + radius;
            max.z = (max.z > point.z + radius) ? max.z : point.z + radius;
        }
        Vector3f dMin = new Vector3f(center);
        dMin.sub(min);
        Vector3f dMax = new Vector3f(max);
        dMax.sub(center);
        max.x = Math.max(dMin.x, dMax.x);
        max.y = Math.max(dMin.y, dMax.y);
        max.z = Math.max(dMin.z, dMax.z);
        max.add(max);
        return max;
    }

    /**
     * Computes the mean temperature of the atoms collected.
     *
     * @return The retured tuple contains the avarage temperature, the minimum
     *         temperature and the maximum temperature that were found in the atoms
     *         collection.
     */
    public Tuple3f computeTemperature() {
        Vector3f temperature =
            new Vector3f(0, Float.MAX_VALUE, -Float.MAX_VALUE);
        int size = getObjects().size();
        float t;
        Iterator iterator = getObjects().iterator();
        while (iterator.hasNext()) {
            t = ((Atom) iterator.next()).getTemperature();
            temperature.x += t;
            if (temperature.y > t) {
                temperature.y = t;
            }
            if (temperature.z < t) {
                temperature.z = t;
            }
        }
        if (size > 0) {
            temperature.x /= size;
        }
        return temperature;
    }

    /**
     * Description of the method.
     *
     * @param atomsA Description of parameter.
     * @param atomsB Description of parameter.
     *
     * @return Description of the returned value.
     */
    public static float computeMinimumDistance(Collection atomsA,
        Collection atomsB) {
        Iterator iteratorA = atomsA.iterator();
        Iterator iteratorB;
        float distance;
        float minDistance = Float.MAX_VALUE;
        Atom atomA;
        Atom atomB;
        Atom minAtomA = null;
        Atom minAtomB = null;
        Vector3f vector = new Vector3f();
        while (iteratorA.hasNext()) {
            atomA = (Atom) iteratorA.next();
            iteratorB = atomsB.iterator();
            while (iteratorB.hasNext()) {
                atomB = (Atom) iteratorB.next();
                vector.set(atomB.getCoordinate());
                vector.sub(atomA.getCoordinate());
                distance = vector.lengthSquared();
                if (distance < minDistance) {
                    minAtomA = atomA;
                    minAtomB = atomB;
                    minDistance = distance;
                }
            }
        }
        atomsA.clear();
        atomsA.add(minAtomA);
        atomsB.clear();
        atomsB.add(minAtomB);
        return (float) Math.sqrt(minDistance);
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public final Point3f getCenter() {
        if (center == null) {
            center = computeCenter();
        }
        return new Point3f(center);
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public final Vector3f getExtend() {
        if (extend == null) {
            extend = computeExtend();
        }
        return new Vector3f(extend);
    }
}
