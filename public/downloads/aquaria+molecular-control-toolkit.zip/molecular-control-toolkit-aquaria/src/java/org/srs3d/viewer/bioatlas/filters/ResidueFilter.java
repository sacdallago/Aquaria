/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.filters;

import org.srs3d.viewer.bioatlas.objects.Residue;
import org.srs3d.viewer.bioatlas.objects.templates.ResidueTemplate;
import org.srs3d.viewer.objects.AbstractObject;

/**
 * <code>ObjectFilter</code> implementation filtering <code>Residue</code> with
 * <code>ResidueTemplate</code> specific serial, and insertion code.
 *
 * @author Karsten Klein
 *
 * @created May 14, 2001
 */
public final class ResidueFilter extends ResidueTemplateFilter {
    private int residueId = Residue.INVALID_ID;
    private char residueICode = Residue.INVALID_ICODE;

    /**
     * <code>ResidueTemplateFilter</code> constructor.
     *
     * @param residueTemplate Description of parameter.
     * @param residueId Description of parameter.
     * @param residueICode Description of parameter.
     */
    public ResidueFilter(ResidueTemplate residueTemplate, int residueId,
        char residueICode) {
        super(residueTemplate);
        setResidueTemplate(residueTemplate);
        setResidueId(residueId);
        setResidueICode(residueICode);
    }

    /**
     * Sets the <code>residueId</code> attribute of the <code>ResidueFilter </code>
     * object.
     *
     * @param residueId The new <code>residueId</code> value.
     */
    public void setResidueId(int residueId) {
        this.residueId = residueId;
    }

    /**
     * Sets the <code>residueICode</code> attribute of the <code>ResidueFilter </code>
     * object.
     *
     * @param residueICode The new <code>residueICode</code> value.
     */
    public void setResidueICode(char residueICode) {
        this.residueICode = residueICode;
    }

    /**
     * Description of the method.
     *
     * @param object Description of parameter.
     *
     * @return Description of the returned value.
     */
    public boolean filter(AbstractObject object) {
        if (super.filter(object)) {
            Residue residue = (Residue) object;
            if (residue.getId() == residueId) {
                if (residue.getICode() == residueICode) {
                    return true;
                }
            }
        }
        return false;
    }
}
