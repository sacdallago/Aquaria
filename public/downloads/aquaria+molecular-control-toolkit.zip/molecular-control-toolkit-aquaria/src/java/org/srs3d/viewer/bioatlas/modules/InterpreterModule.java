/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.modules;

import java.awt.event.ActionEvent;

import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.swing.JConsole;
import org.srs3d.viewer.util.Log;

/**
 * <code>Module</code> implementation displaying the hierarchy of the visible objects.
 *
 * @author Karsten Klein
 *
 * @created May 14, 2001
 */
public class InterpreterModule extends AbstractModule {
    private static final Log log = new Log(InterpreterModule.class);
    private String name;
    private JConsole console = null;
    private boolean failed = false;

    /**
     * <code>ResetModule</code> constructor.
     *
     * @param name Description of parameter.
     */
    public InterpreterModule(String name, ContextData contextData) {
        super(name, contextData);
    }

    /**
     * Description of the method.
     *
     * @param e Description of parameter.
     */
    public void react(ActionEvent e) {
        if (console != null) {
            console.showInFrame();
        }

        //    super.actionPerformed( e );
    }

    /**
     * Description of the method.
     */
    public void cleanup() {
        super.cleanup();
        console = null;
    }

    /**
     * Description of the method.
     */
    private void create() {
        try {
            console = new JConsole();
        } catch (NoClassDefFoundError e) {
            log.error("console is not available.");
            failed = true;
        }
    }

    /**
     * Method description.
     */
    public void updateIntern() {
        if (!failed) {
            create();
        }
    }
}
