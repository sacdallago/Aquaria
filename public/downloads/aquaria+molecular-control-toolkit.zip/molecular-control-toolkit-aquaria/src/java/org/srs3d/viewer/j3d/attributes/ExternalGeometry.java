/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.attributes;

import javax.media.j3d.Shape3D;

import org.srs3d.viewer.objects.Attribute;

/**
 * This <code>Attribute</code> is used to save external geometry of some objects that may
 * depend on geometry created by others.
 *
 * @author Karsten Klein
 *
 * @created April 03, 2001
 */
public final class ExternalGeometry extends Attribute {

    /** The shape accumulates the geometry parts. */
    private Shape3D shape = null;

    /**
     * Sets the <code>shape</code> attribute of the <code>ExternalGeometry </code>object.
     *
     * @param shape The new <code>shape</code> value.
     */
    public void setShape(Shape3D shape) {
        this.shape = shape;
    }

    /**
     * Gets the <code>shape</code> attribute of the <code>ExternalGeometry </code>object.
     *
     * @return The <code>shape</code> value.
     */
    public Shape3D getShape() {
        return shape;
    }

    /**
     * Gets the <code>equal</code> attribute of the <code>ExternalGeometry</code> object.
     *
     * @param attribute Description of parameter.
     *
     * @return The <code>equal</code> value.
     */
    public boolean isEqual(Attribute attribute) {
        return shape == ((ExternalGeometry) attribute).getShape();
    }

    /**
     * Description of the method.
     *
     * @return Description of the returned value.
     */
    public Attribute copy() {
        ExternalGeometry externalGeometry = (ExternalGeometry) super.copy();
        externalGeometry.setShape(shape);
        return externalGeometry;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public Attribute.Immutable getImmutable() {
        return new Immutable();
    }

    /**
     * Class description.
     *
     * @author Karsten Klein, LION bioscience AG
     */
    public class Immutable extends Attribute.Immutable {

        /**
         * Method description.
         *
         * @return Return description.
         */
        public Shape3D getShape() {
            return ExternalGeometry.this.getShape();
        }
    }
}
