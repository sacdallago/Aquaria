/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.behaviors;

import java.awt.event.MouseEvent;

import javax.media.j3d.WakeupOnAWTEvent;

import org.srs3d.viewer.j3d.Context;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.objects.Operation;
import org.srs3d.viewer.util.Log;

/**
 * Triggers ZOOM command on mouse double click.
 *
 * @author Karsten Klein
 *
 * @created March 20, 2001
 */
public class SelectZoomBehavior extends MousePickBehavior {
    private static final Log log = new Log(SelectZoomBehavior.class);

    /**
     * <code>SelectZoomBehavior</code> constructor.
     *
     * @param context Description of parameter.
     */
    public SelectZoomBehavior(ContextData contextData) {
        super(contextData);
    }

    /**
     * Initialize wakeup criterion.
     */
    public void initialize() {

        // set wakeup condition:
        wakeupOn(new WakeupOnAWTEvent(java.awt.event.MouseEvent.MOUSE_CLICKED));
    }

    /**
     * Processes the mouse event provided.
     *
     * @param mouseEvent MouseEvent to proces
     */
    public void processStimulus(MouseEvent mouseEvent) {
        if (checkCriteria(mouseEvent)) {
            try {

                // no picking at all; zoom to the current selection
                Context context = getContextData().getContext();
                Operation operation = new Operation(context, "ZOOM", null);
                operation.setSerializable(false);
                getContextData().getDispatcher().dispatch(operation);
            } catch (Exception e) {
                log.debug(e, e);
            }
        }
    }

    /**
     * This method checks the mouseEvent (fail early, fail fast)
     *
     * @param mouseEvent Description of parameter
     *
     * @return Description of the returned value
     */
    private boolean checkCriteria(MouseEvent mouseEvent) {
        if (mouseEvent.getID() != MouseEvent.MOUSE_CLICKED) {
            return false;
        }
        if (mouseEvent.getClickCount() != 2) {
            return false;
        }
        if (mouseEvent.isAltGraphDown()) {
            return false;
        }
        return true;
    }
}
