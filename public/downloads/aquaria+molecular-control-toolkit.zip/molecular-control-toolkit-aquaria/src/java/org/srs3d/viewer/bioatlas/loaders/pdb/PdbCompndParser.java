/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.loaders.pdb;

import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Locale;
import java.util.StringTokenizer;

import org.srs3d.viewer.bioatlas.objects.Compound;
import org.srs3d.viewer.objects.ObjectContainer;
import org.srs3d.viewer.util.ExceptionHandler;
import org.srs3d.viewer.util.Log;

/**
 * This class is base class for all parsers that operate on one chain.
 *
 * @author Karsten Klein
 *
 * @created January 28, 2001
 */
public class PdbCompndParser extends AbstractPdbParser {
    private static final Log log = new Log(PdbCompndParser.class);
    private static final int ID = 1;
    private static final int MOLECULE = 2;
    private static final int FRAGMENT = 3;
    private static final int CHAIN = 4;
    private static final int DETAILS = 5;

    /** Description of the field. */
    public static final String TAG = new String("COMPND");
    private String line = null;
    private int id = Compound.INVALID_ID;
    private transient Collection pendingCompounds = new HashSet();
    private transient int lastParsed = 0;

    /**
     * Parses the formated pdb string for ENDMDL data. The data is stored locally and no
     * object is created.
     *
     * @param string Description of parameter.
     */
    public void create(String string) {
        clear();
        line = extractString(string, 6, 79);
    }

    /**
     * @param ObjectContainer the <code>ObjectContainer</code> instance to visit
     */
    public void visit(ObjectContainer objectContainer) {

        // optimization
        Iterator iterator;
        if (pendingCompounds.isEmpty()) {
            iterator = objectContainer.getIterator();
        } else {
            iterator = pendingCompounds.iterator();
        }
        Object object;
        Compound compound;
        while (!isSuccess() && iterator.hasNext()) {
            try {
                compound = (Compound) iterator.next();
                if (!compound.isComplete()) {
                    visit(compound);
                }
                if (compound.isComplete()) {
                    pendingCompounds.remove(compound);
                } else {
                    pendingCompounds.add(compound);
                }
            } catch (ClassCastException e) {
                ExceptionHandler.handleException(e,
                    ExceptionHandler.SILENT_IN_DEBUG, this);
            }
        }
        if (isSuccess()) {

            // complete uncompleted compounds
            while (iterator.hasNext()) {
                try {
                    compound = (Compound) iterator.next();
                    compound.setComplete(true);
                    pendingCompounds.remove(pendingCompounds);
                } catch (ClassCastException e) {
                    ExceptionHandler.handleException(e,
                        ExceptionHandler.SILENT_IN_DEBUG, this);
                }
            }
        }
        if (!isSuccess()) {

            // create a new compound
            compound = new Compound();
            visit(compound);
            if (!isSuccess() && PdbParser.isVerbose()) {
                log.error("compound creation failed.");
                log.error(line);
            } else {
                objectContainer.addObject(compound);
            }
        }
    }

    /**
     * Clears all attributes of the parser.
     */
    public void clear() {
        super.clear();
        line = null;
    }

    private String extractLineInfo(int index) {
        String substring = line.substring(index).trim();
        if (substring.endsWith(";")) {
            substring = substring.substring(0, substring.length() - 1);
        }
        index = substring.lastIndexOf(";");
        if (index != -1) {
            if (PdbParser.isVerbose()) {
                log.error("cutting from COMPND line: " +
                    substring.substring(index));
            }
            substring = substring.substring(0, index);
        }
        return substring;
    }

    /**
     * Method description.
     *
     * @param compound Parameter description.
     */
    public void visit(Compound compound) {
        setSuccess(true);
        String substring = "";
        int index;
        boolean parsed = false;
        index = line.indexOf("MOL_ID:");
        if (index != -1) {
            substring = extractLineInfo(index + 7);
            lastParsed = ID;
            parsed = true;
        }
        index = line.indexOf("MOLECULE:");
        if (index != -1) {
            substring = extractLineInfo(index + 9);
            lastParsed = MOLECULE;
            parsed = true;
        }
        index = line.indexOf("FRAGMENT:");
        if (index != -1) {
            substring = extractLineInfo(index + 9);
            lastParsed = FRAGMENT;
            parsed = true;
        }
        index = line.indexOf("DETAILS:");
        if (index != -1) {
            substring = extractLineInfo(index + 9);
            lastParsed = DETAILS;
            parsed = true;
        }
        index = line.indexOf("CHAIN:");
        if (index != -1) {
            substring = extractLineInfo(index + 6);
            parsed = true;
            lastParsed = CHAIN;
        }
        index = line.indexOf("ENGINEERED:");
        if (index != -1) {
            parsed = true;
            lastParsed = 0;
        }
        index = line.indexOf("BIOLOGICAL_UNIT:");
        if (index != -1) {
            parsed = true;
            lastParsed = 0;
        }
        index = line.indexOf("MUTATION:");
        if (index != -1) {
            parsed = true;
            lastParsed = 0;
        }
        index = line.indexOf("SYNONYM:");
        if (index != -1) {
            parsed = true;
            lastParsed = 0;
        }
        index = line.indexOf("EC:");
        if (index != -1) {
            parsed = true;
            lastParsed = 0;
        }
        index = line.indexOf("MUTATION:");
        if (index != -1) {
            parsed = true;
            lastParsed = 0;
        }
        index = line.indexOf("OTHER_DETAILS:");
        if (index != -1) {
            parsed = true;
            lastParsed = 0;
        }
        if (!parsed) {
            substring = extractLineInfo(5);
        }
        switch (lastParsed) {

            case ID:
                int id = extractInt(substring, 0, substring.length());
                if (compound.getId() != Compound.INVALID_ID) {
                    setSuccess(false);
                    compound.setComplete(true);
                } else {
                    compound.setId(id);
                }
                break;

            case MOLECULE:
                if (!parsed) {
                    substring = compound.getMolecule() + " " + substring;
                }
                compound.setMolecule(substring.toLowerCase(Locale.US));
                break;

            case FRAGMENT:
                if (!parsed) {
                    substring = compound.getFragment() + " " + substring;
                }
                compound.setFragment(substring.toLowerCase(Locale.US));
                break;

            case DETAILS:
                if (!parsed) {
                    substring = compound.getDetails() + " " + substring;
                }
                compound.setDetails(substring.toLowerCase(Locale.US));
                break;

            case CHAIN:
                StringTokenizer tokenizer =
                    new StringTokenizer(substring, ",;");
                String token;
                while (tokenizer.hasMoreTokens()) {
                    token = tokenizer.nextToken();
                    if (token.equalsIgnoreCase("NULL")) {
                        compound.getChainIds().add(" ");
                    } else {
                        compound.getChainIds().add(token.trim());
                    }
                }
                break;
        }
    }
}
