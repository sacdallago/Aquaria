/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.behaviors;

import java.awt.event.MouseEvent;

import javax.media.j3d.WakeupOnAWTEvent;

import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.operations.IntersectOperation;
import org.srs3d.viewer.util.Log;

/**
 * Triggers Intersect (SELECT) commands.
 *
 * @author Karsten Klein
 *
 * @created March 20, 2001
 */
public class SelectBehavior extends MousePickBehavior {
    private static final Log log = new Log(SelectBehavior.class);

    /**
     * <code>SelectBehavior</code> constructor.
     *
     * @param context Description of parameter.
     */
    public SelectBehavior(ContextData contextData) {
        super(contextData);
    }

    /**
     * Initializes the wakeup criterion
     */
    public void initialize() {
        wakeupOn(new WakeupOnAWTEvent(java.awt.event.MouseEvent.MOUSE_CLICKED));
    }

    /**
     * Description of the method
     *
     * @param mouseEvent Description of parameter
     */
    public void processStimulus(MouseEvent mouseEvent) {
        if (checkCriteria(mouseEvent)) {
            try {
                IntersectOperation operation =
                    new IntersectOperation(getContextData().getContext(),
                        "INTERSECT", null);
                operation.setTriggerId("DESELECT");
                if (mouseEvent.isControlDown() && mouseEvent.isShiftDown()) {
                    operation.setTriggerId("SELECT_SHIFT_CONTROL");
                } else if (mouseEvent.isShiftDown()) {
                    operation.setTriggerId("SELECT_SHIFT");
                } else if (mouseEvent.isControlDown()) {
                    if (mouseEvent.isAltDown()) {
                        operation.setTriggerId("SELECT_ALT_CTRL");
                    } else {
                        operation.setTriggerId("SELECT_CONTROL");
                    }
                } else if (mouseEvent.isAltDown()) {
                    operation.setTriggerId("SELECT_ALT");
                } else {
                    operation.setTriggerId("SELECT");
                }
                operation.setCoordinate(mouseEvent.getPoint());
                getContextData().getDispatcher().dispatch(operation);
                operation = null;
            } catch (Exception e) {
                log.debug(e, e);
            }
        }
    }

    /**
     * This method checks the mouseEvent (fail early, fail fast)
     *
     * @param mouseEvent Description of parameter
     *
     * @return Description of the returned value
     */
    private boolean checkCriteria(MouseEvent mouseEvent) {
        if (mouseEvent.getID() != MouseEvent.MOUSE_CLICKED) {
            return false;
        }
        if ((MouseEvent.BUTTON1_MASK & mouseEvent.getModifiers()) == 0) {
            return false;
        }
        if (mouseEvent.getClickCount() != 1) {
            return false;
        }
        if (mouseEvent.isAltGraphDown()) {
            return false;
        }
        return true;
    }
}
