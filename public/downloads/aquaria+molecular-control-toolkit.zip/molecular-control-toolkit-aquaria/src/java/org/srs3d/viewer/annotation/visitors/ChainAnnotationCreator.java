/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.annotation.visitors;

import java.util.Collection;
import java.util.Iterator;
import java.util.Vector;

import org.srs3d.viewer.annotation.objects.ChainAnnotation;
import org.srs3d.viewer.annotation.objects.Segment;
import org.srs3d.viewer.bioatlas.objects.Chain;
import org.srs3d.viewer.bioatlas.objects.Residue;
import org.srs3d.viewer.bioatlas.objects.Subchain;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.objects.ObjectContainer;
import org.srs3d.viewer.objects.visitors.AbstractVisitor;

/**
 * This class provides the methods to create the <code>Segment</code> instances from an
 * <code>Chain</code> . The segments represent the secondary structure e.g.
 *
 * @author Karsten Klein, 01/2001
 * @author Christian Zofka, 06/2001
 *
 * @created May 18, 2001
 * @modified June 27, 2001
 * @since 1.0
 */
public class ChainAnnotationCreator extends AbstractVisitor {

    /** Description of the field. Description of the field. */
    public static final int SECONDARYSTRUCTURE = 1;

    /** Description of the field. */
    public int mode = SECONDARYSTRUCTURE;
    private ChainAnnotation chainAnnotation;

    /**
     * Sets the <code>chainAnnotation</code> attribute of the
     * <code>ChainAnnotationCreator</code> object.
     *
     * @param chainAnnotation The new <code>chainAnnotation</code> value.
     */
    public void setChainAnnotation(ChainAnnotation chainAnnotation) {
        this.chainAnnotation = chainAnnotation;
    }

    /**
     * Gets the <code>chainAnnotation</code> attribute of the
     * <code>ChainAnnotationCreator</code> object.
     *
     * @return The <code>chainAnnotation</code> value.
     */
    public ChainAnnotation getChainAnnotation() {
        return chainAnnotation;
    }

    /**
     * Description of the method.
     *
     * @param object Description of parameter.
     */
    public void visit(AbstractObject object) {
        if (object instanceof Chain) {
            visit((Chain) object);
        }
        if (object instanceof ObjectContainer) {
            super.visit((ObjectContainer) object);
        }
    }

    /**
     * Visits a chain. Automatically creates segments for <code>Subchain</code>
     * instances.
     *
     * @param chain Description of parameter.
     */
    public void visit(Chain chain) {
        if (chainAnnotation == null) {
            chainAnnotation = new ChainAnnotation(chain);
        }
        Segment segment;
        if (mode == SECONDARYSTRUCTURE) {
            if (!chain.containsLigandResidues()) {
                Iterator iterator = chain.getSubchains().iterator();
                Subchain subchain;
                SegmentCreator segmentCreator = new SegmentCreator();
                while (iterator.hasNext()) {
                    subchain = (Subchain) iterator.next();
                    segmentCreator.visit(subchain);
                    segment = segmentCreator.getSegment();
                    if (segment != null) {
                        segment.setStartIndex(chain.computeResidueIndex(
                                subchain.getInitialResidue()));
                        segment.setEndIndex(chain.computeResidueIndex(
                                subchain.getEndResidue()));
                        chainAnnotation.add(segment);
                    }
                }
                Vector residues = new Vector();
                residues.addAll(getAllResidues(chain));
                chainAnnotation.setGapSequence(residues);
            }
        }
    }

    /**
     * Gets the <code>allResidues</code> attribute of the <code>GapCreator</code> object.
     *
     * @param chain Description of parameter.
     *
     * @return The <code>allResidues</code> value.
     */
    private Collection getAllResidues(Chain chain) {
        Collection residues = new Vector();
        if (chain != null) {
            Residue residue = chain.getInitialResidue();
            while (residue != null) {
                residues.add(residue);
                residue = residue.getProceeding();
            }
        }
        return residues;
    }
}
