/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.commands;

import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.Contextual;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.objects.Command;

/**
 * Show command.
 *
 * @author Karsten Klein
 *
 * @created April 03, 2001
 */
public abstract class ObjectCommand implements Command, Contextual {
    private AbstractObject object;
    private AbstractObject parent;
    private ContextData contextData;

    /**
     * Constructor description.
     *
     * @param contextData Parameter description.
     */
    public ObjectCommand(ContextData contextData) {
        this.contextData = contextData;
    }

    /**
     * Sets the <code>object</code> attribute of the <code>ObjectCommand</code> object.
     *
     * @param object The new <code>object</code> value.
     */
    public void setObject(AbstractObject object) {
        this.object = object;
    }

    /**
     * Sets the <code>parent</code> attribute of the <code>ObjectCommand</code> object.
     *
     * @param parent The new <code>parent</code> value.
     */
    public void setParent(AbstractObject parent) {
        this.parent = parent;
    }

    /**
     * Gets the <code>object</code> attribute of the <code>ObjectCommand</code> object.
     *
     * @return The <code>object</code> value.
     */
    public AbstractObject getObject() {
        return object;
    }

    /**
     * Gets the <code>parent</code> attribute of the <code>ObjectCommand</code> object.
     *
     * @return The <code>parent</code> value.
     */
    public AbstractObject getParent() {
        return parent;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public final ContextData getContextData() {
        return contextData;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public String toString() {
        String name = getClass().getName();
        int index = name.lastIndexOf(".");
        if (index != -1) {
            name = name.substring(index);
        }
        index = name.indexOf("Command");
        if (index != -1) {
            name = name.substring(0, index);
        }
        return name;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public String getDescription() {
        return "command";
    }
}
