/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.colorschemes;

import java.util.Collection;
import java.util.HashSet;
import java.util.Map;

import javax.media.j3d.Appearance;

import org.srs3d.viewer.bioatlas.objects.ChainFragment;
import org.srs3d.viewer.j3d.AppearanceHelper;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.objects.ObjectManager;

/**
 * The <code>ChainFragmentColorScheme</code> represents a special color scheme. Every
 * chain is meant to receive its own color in order to be distinguishable.
 *
 * @author Karsten Klein
 *
 * @created March 20, 2001
 */
public class ChainFragmentColorScheme extends ChainColorScheme {

    /**
     * Constructor description.
     *
     * @param contextData Parameter description.
     */
    public ChainFragmentColorScheme(ContextData contextData) {
        super(contextData);
    }

    /**
     * Method description.
     *
     * @param object Parameter description.
     * @param appearance Parameter description.
     *
     * @return Return description.
     */
    public boolean modify(AbstractObject object, Appearance appearance) {
        Collection chainCollection = new HashSet();
        getContextData().getObjectManager().getUpAssociations(object,
            chainCollection);
        chainCollection.add(object);
        ObjectManager.extract(chainCollection, ChainFragment.class);
        if (!chainCollection.isEmpty()) {
            ChainFragment chainFragment =
                (ChainFragment) chainCollection.iterator().next();
            if (!chainFragment.isLigand()) {

                // register the identifier (if not registered yet)
                register(chainFragment);
                AppearanceHelper.enableVertexColors(appearance, false);
                AppearanceHelper.modifyAppearance(appearance,
                    computeColor(chainFragment));
                return true;
            }
        }
        return super.modify(object, appearance);
    }

    /**
     * Method description.
     *
     * @param map Parameter description.
     *
     * @return Return description.
     */
    public Map getInformation(Map map) {
        map = super.getInformation(map);
        map.put("NAME", "Chain Fragment");
        return map;
    }
}
