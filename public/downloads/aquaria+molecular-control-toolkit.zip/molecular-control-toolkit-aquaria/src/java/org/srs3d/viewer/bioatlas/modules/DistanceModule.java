/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.modules;

import java.awt.event.ActionEvent;
import java.util.Collection;
import java.util.HashSet;
import java.util.Vector;

import javax.vecmath.Point3f;
import javax.vecmath.Vector3f;

import org.srs3d.viewer.bioatlas.colorschemes.MonochromeColorScheme;
import org.srs3d.viewer.bioatlas.objects.Atom;
import org.srs3d.viewer.bioatlas.visitors.AtomCollector;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.Selection;
import org.srs3d.viewer.j3d.commands.ColorCommand;
import org.srs3d.viewer.j3d.commands.RegisterCommand;
import org.srs3d.viewer.j3d.commands.SpawnCommand;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.objects.ObjectContainer;
import org.srs3d.viewer.objects.ObjectManager;
import org.srs3d.viewer.objects.StrategyManager;
import org.srs3d.viewer.util.Log;

/**
 * @author Karsten Klein
 *
 * @created May 14, 2001
 */
public class DistanceModule extends ProcessModule {
    public static final Log log = new Log(DistanceModule.class);

    /**
     * <code>DistanceModule</code> constructor.
     *
     * @param name Description of parameter.
     * @param contextData Description of parameter.
     */
    public DistanceModule(String name, ContextData contextData) {
        super(name, contextData, true, true);
    }

    /**
     * Description of the method.
     *
     * @param e Description of parameter.
     */
    public void process(ActionEvent e) {
        final ContextData contextData = getContextData();
        Selection selection = contextData.getSelectionManager().getSelection();
        if (!selection.isEmpty()) {
            ObjectManager objectManager = contextData.getObjectManager();
            final StrategyManager strategyManager =
                contextData.getStrategyManager();
            final Collection set = new HashSet(selection.size());
            objectManager.collapseUp(selection, set);
            Collection roots = new HashSet(set);
            objectManager.getUpAssociations(set, roots);
            ObjectManager.extract(roots, ObjectContainer.class);
            if (!roots.isEmpty()) {
                final ObjectContainer root =
                    (ObjectContainer) roots.iterator().next();
                getContextData().getContext().addUpdateCallback(new org.srs3d.viewer.j3d.behaviors.UpdateBehavior.Callback() {
                        public void execute() {
                            Vector vector = new Vector(set);
                            AtomCollector atomCollectorA = null;
                            AtomCollector atomCollectorB = null;
                            Collection atoms = new HashSet();
                            float distance = 0;
                            for (int i = 0; i < vector.size(); i++) {
                                atomCollectorA = new AtomCollector();
                                atomCollectorA.visit((AbstractObject) vector.elementAt(
                                        i));
                                if (!atomCollectorA.getObjects().isEmpty()) {
                                    for (int j = i + 1; j < vector.size();
                                          j++) {
                                        atomCollectorB = new AtomCollector();
                                        atomCollectorB.visit((AbstractObject) vector.elementAt(
                                                j));
                                        if (!atomCollectorB.getObjects()
                                                             .isEmpty()) {

                                            // find the minimum distance between the two atom sets
                                            distance =
                                                AtomCollector.computeMinimumDistance(atomCollectorA.getObjects(),
                                                    atomCollectorB.getObjects());
                                            Atom atomA =
                                                (Atom) atomCollectorA.getObjects()
                                                                     .iterator()
                                                                     .next();
                                            Atom atomB =
                                                (Atom) atomCollectorB.getObjects()
                                                                     .iterator()
                                                                     .next();
                                            Point3f center =
                                                new Point3f(atomA.getCoordinate());
                                            center.add(atomB.getCoordinate());
                                            center.scale(0.5f);
                                            if (distance > 0) {

                                                // 2 decimals accurarcy
                                                distance = ((float) ((int) (distance * 100)) / 100);
                                                ObjectContainer distanceContainer =
                                                    new ObjectContainer();
                                                distanceContainer.setName(
                                                    "Distance " +
                                                    atomA.getTemplate()
                                                         .getElement() + "-" +
                                                    atomB.getTemplate()
                                                         .getElement() + "(" +
                                                    distance + ")");
                                                org.srs3d.viewer.j3d.objects.Label label =
                                                    new org.srs3d.viewer.j3d.objects.Label();
                                                label.setString("" + distance +
                                                    " �");
                                                label.getCoordinate().set(center);
                                                label.setAlignment(new Vector3f(
                                                        0, 0, 0));
                                                org.srs3d.viewer.j3d.objects.Line line =
                                                    new org.srs3d.viewer.j3d.objects.Line();
                                                line.getCoordinates().setAt(0,
                                                    atomA.getCoordinate());
                                                line.getCoordinates().setAt(1,
                                                    atomB.getCoordinate());
                                                distanceContainer.addObject(label);
                                                distanceContainer.addObject(line);
                                                SpawnCommand spawnCommand =
                                                    new SpawnCommand(contextData);
                                                spawnCommand.setParent(root);
                                                strategyManager.execute(distanceContainer,
                                                    spawnCommand);
                                                RegisterCommand registerCommand =
                                                    new RegisterCommand(contextData);
                                                registerCommand.setParent(root);
                                                strategyManager.propagate(distanceContainer,
                                                    registerCommand);
                                                root.addObject(distanceContainer);
                                                ColorCommand colorCommand =
                                                    new ColorCommand(contextData,
                                                        new MonochromeColorScheme(
                                                            contextData));
                                                strategyManager.execute(line,
                                                    colorCommand);
                                                atoms.add(atomA);
                                                atoms.add(atomB);
                                            }
                                        }
                                    }
                                }
                            }
                            ProximityModule.expandAtomProximity(getContextData(),
                                atoms, true);
                            org.srs3d.viewer.bioatlas.Capture.updateSelections(getContextData(),
                                true);
                        }
                    });
            } else {
                log.error("no root container available. No geometry appended.");
            }
        }
    }

    /**
     * Description of the method.
     */
    public void updateIntern() {
        super.updateIntern();
        ContextData contextData = getContextData();
        Selection selection = contextData.getSelectionManager().getSelection();
        if (selection.isEmpty()) {
            getComponent().setEnabled(false);
        } else {
            Collection set = new HashSet(selection.size());
            contextData.getObjectManager().collapseUp(selection, set);
            getComponent().setEnabled(set.size() == 2);
        }
    }
}
