/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.loaders.pdb;

import java.util.ArrayList;
import java.util.Iterator;

import org.srs3d.viewer.bioatlas.filters.ChainIdFilter;
import org.srs3d.viewer.bioatlas.objects.Chain;
import org.srs3d.viewer.bioatlas.objects.Residue;
import org.srs3d.viewer.bioatlas.objects.Site;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.objects.ObjectContainer;
import org.srs3d.viewer.objects.ObjectFilter;
import org.srs3d.viewer.objects.visitors.ObjectCollector;
import org.srs3d.viewer.util.Log;

/**
 * This class parses strings for pdb SITE tags and tranfers/builts the appropriate
 * datastructure in a <code>ObjectContainer</code> . Note that the Site parser is a
 * retained parser.
 *
 * @author Karsten Klein, 01/2001
 *
 * @created March 22, 2001
 * @since 1.0
 */
public class PdbSiteParser extends AbstractPdbParser {
    private static final Log log = new Log(PdbSiteParser.class);

    /** Description of the field. */
    public static final String TAG = new String("SITE  ");

    /** Site serial number */
    private int siteId = Site.INVALID_ID;

    /** Site name */
    private String siteName = null;

    /** Number of the residues in the site */
    private int residueNumber = 0;

    /** Names of the residues in the site record */
    private String[] residueNames = null;

    /** Chain identifiers of the residues in the site record */
    private char[] residueChainIds = null;

    /** Serial numbers of the residues in the site record */
    private int[] residueIds = null;

    /** Insertion codes of the residues in the site record */
    private char[] residueICodes = null;

    /**
     * Gets the <code>Retained</code> attribute of the <code>PdbSiteParser </code>object.
     *
     * @return The <code>Retained</code> value.
     */
    public boolean isRetained() {
        return true;
    }

    /**
     * Description of the method.
     *
     * @param string Description of parameter.
     */
    public void create(String string) {
        clear();
        siteId = extractInt(string, 7, 10);
        siteName = extractString(string, 11, 14, true);
        residueNumber = extractInt(string, 15, 17);
        if (residueNumber > 0) {
            residueNames = new String[4];
            residueChainIds = new char[4];
            residueIds = new int[4];
            residueICodes = new char[4];

            // :NOTE: this is very tricky!!!
            string = string.trim() + " ";
            residueNumber = 0;
            int residueOffset = 18;
            int residueWidth = 11;
            int residueStart = 0;
            for (int i = 0; i < 4; i++) {
                residueStart = residueOffset + i * residueWidth;
                if (residueStart < string.length()) {
                    residueNames[i] =
                        extractString(string, residueStart, residueStart + 3);
                    residueChainIds[i] = extractChar(string, residueStart + 4);
                    residueIds[i] =
                        extractInt(string, residueStart + 5, residueStart + 9);
                    residueICodes[i] = extractChar(string, residueStart + 9);
                    residueNumber++;
                } else {
                    i = 4;
                }
            }
        }
    }

    /**
     * Specialized implementation visiting all objects contained in the specified
     * <code>ObjectContainer</code> instance.
     *
     * @param ObjectContainer the <code>ObjectContainer</code> instance to visit
     */
    public void visit(ObjectContainer ObjectContainer) {
        Iterator iterator = ObjectContainer.getIterator();
        AbstractObject object = null;
        while (iterator.hasNext()) {
            object = (AbstractObject) iterator.next();
            if (object instanceof Site) {
                Site site = (Site) object;
                if (site.getName().equals(siteName)) {
                    visit(site, ObjectContainer);
                }
            }
        }

        // supplement the site
        if (!isSuccess()) {
            Site site = new Site();
            site.setContentType(Site.ACTIVE_SITE);
            visit(site, ObjectContainer);
            ObjectContainer.addObject(site);
        }
    }

    /**
     * Description of the method.
     *
     * @param chain Description of parameter.
     */
    public void visit(Chain chain) {
    }

    /**
     * Description of the method.
     *
     * @param site Description of parameter.
     * @param objectContainer Description of parameter.
     */
    public void visit(Site site, ObjectContainer objectContainer) {
        site.setId(siteId);
        site.setName(siteName);
        ObjectFilter chainFilter;
        ObjectCollector chainCollector;
        ObjectFilter residueFilter;
        ObjectCollector residueCollector;
        Chain chain;
        Residue residue;
        ArrayList residues = new ArrayList();
        Iterator chainIterator;

        // create proper site information
        for (int i = 0; i < residueNumber; i++) {

            // filter all chains with the specific chain id
            chainFilter = new ChainIdFilter(residueChainIds[i]);
            chainCollector = new ObjectCollector(chainFilter);
            chainCollector.visit((AbstractObject) objectContainer);
            if (!chainCollector.getObjects().isEmpty()) {
                chainIterator = chainCollector.getObjects().iterator();
                residue = null;
                while (residue == null && chainIterator.hasNext()) {
                    chain = (Chain) chainIterator.next();
                    residue =
                        chain.getResidue(residueNames[i], residueIds[i],
                            residueICodes[i]);
                    if (residue != null) {
                        residues.add(residue);
                    }
                }
                if (PdbParser.isVerbose()) {
                    if (residue == null) {
                        log.error("no residue found with");
                        log.error("chain id: " + residueChainIds[i]);
                        log.error("residue name: " + residueNames[i]);
                        log.error("residue id: " + residueIds[i]);
                        log.error("residue insertion code: " +
                            residueICodes[i]);
                    }
                }
            }
        }
        site.getResidues().addAll(residues);
        setSuccess(true);
    }

    /**
     * Description of the method.
     */
    public void clear() {
        super.clear();
        siteName = null;
        siteId = Site.INVALID_ID;
        residueNames = null;
        residueChainIds = null;
        residueIds = null;
        residueICodes = null;
        residueNumber = 0;
    }
}
