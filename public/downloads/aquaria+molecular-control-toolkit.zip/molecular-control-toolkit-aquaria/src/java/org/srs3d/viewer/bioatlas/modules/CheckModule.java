/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.modules;

import java.awt.Component;

import javax.swing.JCheckBoxMenuItem;
import javax.swing.KeyStroke;

import org.srs3d.viewer.j3d.ContextData;

/**
 * Abstract class implementing the basis functionality of module with checkbox menu
 * properties.
 *
 * @author Karsten Klein
 *
 * @created February 06, 2002
 */
public abstract class CheckModule extends AbstractModule {
    private JCheckBoxMenuItem component = null;

    /**
     * <code>ResetModule</code> constructor.
     *
     * @param name Description of parameter.
     * @param contextData Description of parameter.
     */
    public CheckModule(String name, ContextData contextData) {
        super(name, contextData);
    }

    /**
     * Gets the <code>component</code> attribute of the <code>SolidRenderingModule</code>
     * object.
     *
     * @return The <code>component</code> value.
     */
    public Component getComponent() {
        if (component == null) {
            component = new JCheckBoxMenuItem(getName(), false);
            component.addActionListener(this);
            KeyStroke keyStroke = getAccelerator();
            if (keyStroke != null) {
                component.setAccelerator(keyStroke);
            }
        }
        return component;
    }

    /**
     * Gets the <code>checkComponent</code> attribute of the <code>CheckModule</code>
     * object.
     *
     * @return The <code>checkComponent</code> value.
     */
    public JCheckBoxMenuItem getCheckComponent() {
        return component;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public String getModuleIdPrefix() {
        return "SWITCH-";
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public String createReport() {
        String report = super.createReport();
        if (getCheckComponent() != null) {
            report += "|";
            report += getCheckComponent().getState() ? "C" : "U";
        }
        return report;
    }
}
