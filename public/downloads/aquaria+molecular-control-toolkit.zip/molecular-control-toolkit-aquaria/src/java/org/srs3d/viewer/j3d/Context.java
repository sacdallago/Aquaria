/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d;

import java.awt.Graphics;
import java.awt.GraphicsConfiguration;
import java.awt.Toolkit;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.image.BufferedImage;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

import javax.media.j3d.Alpha;
import javax.media.j3d.AmbientLight;
import javax.media.j3d.Background;
import javax.media.j3d.BadTransformException;
import javax.media.j3d.BoundingSphere;
import javax.media.j3d.Bounds;
import javax.media.j3d.BranchGroup;
import javax.media.j3d.Canvas3D;
import javax.media.j3d.Group;
import javax.media.j3d.LinearFog;
import javax.media.j3d.Node;
import javax.media.j3d.PointLight;
import javax.media.j3d.ShaderError;
import javax.media.j3d.ShaderErrorListener;
import javax.media.j3d.Transform3D;
import javax.media.j3d.TransformGroup;
import javax.media.j3d.ViewPlatform;
import javax.media.j3d.VirtualUniverse;
import javax.swing.JOptionPane;
import javax.vecmath.Color3f;
import javax.vecmath.Matrix3d;
import javax.vecmath.Matrix4d;
import javax.vecmath.Point3d;
import javax.vecmath.Point3f;
import javax.vecmath.Tuple3d;
import javax.vecmath.Tuple3f;
import javax.vecmath.Vector3d;
import javax.vecmath.Vector3f;

import org.srs3d.viewer.bioatlas.Parameter;
import org.srs3d.viewer.j3d.behaviors.KeyHandler;
import org.srs3d.viewer.j3d.behaviors.PositionInterpolator;
import org.srs3d.viewer.j3d.behaviors.UpdateBehavior;
import org.srs3d.viewer.j3d.constraints.Constraint;
import org.srs3d.viewer.j3d.loaders.GenericLoader;
import org.srs3d.viewer.util.ExceptionHandler;
import org.srs3d.viewer.util.Log;

import com.sun.j3d.utils.universe.ConfiguredUniverse;
import com.sun.j3d.utils.universe.SimpleUniverse;
import com.sun.j3d.utils.universe.ViewerAvatar;
import com.sun.j3d.utils.universe.ViewingPlatform;

/**
 * This class collects all context unique attributes to enable fast access (at least
 * using the <code>ContextManager</code> class). It additionally provides setup methods
 * to ease context creation. Note that this class is actually tightly coupled with the
 * <code>ContextManager</code> providing accurate active context control tracking the
 * mouse events.
 *
 * @author Karsten Klein
 *
 * @created November 14, 2000
 */
public class Context extends Canvas3D implements MouseListener,
    MouseMotionListener {
    public static final Log log = new Log(Context.class);

    /*  public static final Color3f BACKGROUND_COLOR = new Color3f(0.0f, 0.0f, 0.0f);
       public static final Color3f PRINTMODE_BACKGROUND_COLOR =
         new Color3f(1.0f, 1.0f, 1.0f);
       public static final Color3f AMBIENT_LIGHT_COLOR =
         new Color3f(0.3f, 0.3f, 0.3f);
     */
    public static final Color3f BACKGROUND_COLOR = new Color3f(0, 0, 0);
    public static final Color3f AMBIENT_LIGHT_COLOR =
        new Color3f(0.7f, 0.7f, 0.7f);
    private static GraphicsConfiguration graphicsConfiguration =
        getDefaultGraphicsConfiguration();
    private OffscreenContext offscreenContext = null;

    /** The universe the context is based on. */
    private SimpleUniverse universe = null;

    /** Controlled set of scenegraph elements. */
    private BranchGroup localLevel = null;
    private BranchGroup sceneLevel = null;
    private BranchGroup behaviorLevel = null;
    private BranchGroup lightBranch = null;
    private TransformGroup sceneTransform = null;
    private ViewingPlatform viewingPlatform = null;
    private ViewPlatform viewPlatform = null;
    private ViewerAvatar viewerAvatar = null;
    private PositionInterpolator positionInterpolator = null;
    private UpdateBehavior updateBehavior = null;
    private BranchGroup attenuationBranch = null;
    private Junction avatarJunction = null;
    private Background background = null;
    private LinearFog attenuation = null;

    /** Light settings. */
    private Color3f ambientLightColor = AMBIENT_LIGHT_COLOR;
    private AmbientLight ambientLight = null;

    /** Reference to context data */
    private ContextData contextData;

    /** Context controll flags. */
    private boolean autoSwitch = true;
    private boolean framerateDropped = false;
    private boolean solidRendering = false;
    private int frame = 0;
    private long avarageFullFrameDuration = 0;
    private int currentRepresentationMode = Junction.ON;
    private boolean needsClippingAdjustment = false;
    private boolean hasViewingPlatformChanged = false;
    private int rendererLocked = 0;
    private boolean canDumpCapturedImages = false;
    private Point3f centerOfRotation = new Point3f();
    private ArrayList constraints = new ArrayList();
    private boolean isUpdateEnabled = true;
    private boolean isTimeoutEnabled = false;
    private boolean isIncludeTransform = true;
    private boolean isAttenutationActive = false;
    private boolean isAvatarSwitching = true;

    /** Stereo properties */
    private double stereoBackplane = 250;
    private double stereoEyeOffset = 3.0f;
    private double stereoRotationAngle = 1.5f;

    /**
     * Constructs a context with the appropriate <code>GraphicsContext</code>
     *
     * @param graphicsConfiguration Description of parameter.
     */
    public Context(GraphicsConfiguration graphicsConfiguration) {
        this(graphicsConfiguration, false);
    }

    /**
     * <code>Context</code> contructor.
     */
    public Context() {
        this(graphicsConfiguration, false);
    }

    /**
     * Constructs a context with the appropriate <code>GraphicsContext</code> and offset
     * screen flag
     *
     * @param graphicsConfiguration Description of parameter.
     * @param offScreen Description of parameter.
     */
    public Context(GraphicsConfiguration graphicsConfiguration,
        boolean offScreen) {
        super(graphicsConfiguration, offScreen);
        intitialize();

        //    offscreenContext = new OffscreenContext(this);
    }

    /**
     * Sets the default context setting
     */
    public void setup() {

        // for the default stuff use the standard simple universe
        if (universe == null) {
            universe = new ConfiguredUniverse(this);
        }

        // Add a ShaderErrorListener
        universe.addShaderErrorListener(new ShaderErrorListener() {
            public void errorOccurred(ShaderError error) {
                error.printVerbose();
                JOptionPane.showMessageDialog(Context.this,
                              error.toString(),
                              "ShaderError",
                              JOptionPane.ERROR_MESSAGE);
            }
        });

        //    offscreenContext.setup();
        viewerAvatar = new ViewerAvatar();
        BranchGroupHelper.setDefaultCapabilities(viewerAvatar);
        avatarJunction = new Junction();
        BranchGroupHelper.setDefaultCapabilities(avatarJunction.getOnBranch());
        BranchGroupHelper.setDefaultCapabilities(avatarJunction.getOffBranch());
        viewerAvatar.addChild(avatarJunction.getEntry());

        // retrieve viewing platform
        viewingPlatform = (universe).getViewingPlatform();

        // this will move the ViewPlatform back a bit so the
        // objects in the scene can be viewed
        setViewingPlatformPosition(new Point3d(0, 0, 150));
        viewPlatform = viewingPlatform.getViewPlatform();
        viewPlatform.setActivationRadius(1000000.0f);

        // create the local and scene level branch groups
        localLevel = new BranchGroup();
        sceneLevel = new BranchGroup();
        sceneTransform = new TransformGroup();
        behaviorLevel = new BranchGroup();
        BranchGroupHelper.setDefaultCapabilities(localLevel);
        BranchGroupHelper.setDefaultCapabilities(sceneLevel);
        BranchGroupHelper.setDefaultCapabilities(behaviorLevel);
        background = new Background(BACKGROUND_COLOR);
        Bounds bounds = new BoundingSphere(new Point3d(), Double.MAX_VALUE);
        background.setApplicationBounds(bounds);
        background.setCapability(Background.ALLOW_COLOR_READ);
        background.setCapability(Background.ALLOW_COLOR_WRITE);
        localLevel.addChild(background);
        if (isIncludeTransform) {

            // set capabilities of sceneTransform
            sceneTransform.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
            sceneTransform.setCapability(TransformGroup.ALLOW_TRANSFORM_READ);
            sceneTransform.setCapability(Group.ALLOW_CHILDREN_EXTEND);
            localLevel.addChild(sceneTransform);
        }
        sceneLevel.addChild(behaviorLevel);
        if (isIncludeTransform) {
            sceneTransform.addChild(sceneLevel);
        } else {
            localLevel.addChild(sceneLevel);
        }

        // setup position interpolator
        positionInterpolator =
            new org.srs3d.viewer.j3d.behaviors.PositionInterpolator(getContextData());
        positionInterpolator.setEnable(false);
        positionInterpolator.setSchedulingBounds(bounds);
        behaviorLevel.addChild(positionInterpolator);
        updateBehavior.setSchedulingBounds(bounds);
        localLevel.addChild(updateBehavior);
        updateBehavior.setEnable(true);
        universe.getViewer().setAvatar(viewerAvatar);
    }

    /**
     * Description of the method.
     *
     * @param isBlackBackground Description of parameter.
     */
    public void setupLights(boolean isBlackBackground) {
        BranchGroup lightBranch = new BranchGroup();
        lightBranch.setCapability(BranchGroup.ALLOW_DETACH);
        setLightBranch(lightBranch);
        BoundingSphere bounds =
            new BoundingSphere(new Point3d(), Double.MAX_VALUE);
        PointLight pointLight0;
        PointLight pointLight1;
        pointLight0 =
            new PointLight(new Color3f(0.7f, 0.7f, 0.7f),
                new Point3f(-420000, 0, 210000), new Point3f(1, 0, 0));
        pointLight1 =
            new PointLight(new Color3f(0.3f, 0.3f, 0.3f),
                new Point3f(420000, 420000, 0), new Point3f(1, 0, 0));
        ambientLight = new AmbientLight(ambientLightColor);
        lightBranch.addChild(ambientLight);
        lightBranch.addChild(pointLight0);
        lightBranch.addChild(pointLight1);

        // set the influencing bounds
        ambientLight.setInfluencingBounds(bounds);
        pointLight0.setInfluencingBounds(bounds);
        pointLight1.setInfluencingBounds(bounds);
        viewerAvatar.addChild(lightBranch);
    }

    /**
     * Sets the translation of the viewing platform transformation to the proposed
     * position
     *
     * @param position The new <code>ViewingPlatformPosition</code> value.
     */
    public void setViewingPlatformPosition(Tuple3d position) {
        final Transform3D transform = getViewingPlatformTransform();
        transform.setTranslation(new Vector3d(position));
        setViewingPlatformTransform(transform);
    }

    /**
     * Sets the <code>ViewingPlatformTransform</code> attribute of the
     * <code>Context</code> object.
     *
     * @param transform The new <code>ViewingPlatformTransform</code> value.
     */
    public void setViewingPlatformTransform(final Transform3D transform) {
        Vector3d position = new Vector3d();
        transform.get(position);
        processConstraints(position);
        transform.setTranslation(position);
        TransformGroup transformGroup =
            viewingPlatform.getViewPlatformTransform();
        try {
            transformGroup.setTransform(transform);
        } catch (BadTransformException e) {
            ExceptionHandler.handleException(e,
                ExceptionHandler.SILENT_IN_RELEASE, this);

            // read and display matrix that caused the exception
            Matrix3d matrix = new Matrix3d();
            transform.get(matrix);
            Matrix4d matrix4 = new Matrix4d();
            transform.get(matrix4);
            matrix.normalize();
            try {
                matrix4.setRotationScale(matrix);
                transform.set(matrix4);
                transformGroup.setTransform(transform);
            } catch (BadTransformException f) {
                ExceptionHandler.handleException(f,
                    ExceptionHandler.SILENT_IN_RELEASE, this);

                // we use full identity for 4x4 matrix
                matrix4.setIdentity();
                try {
                    transform.set(matrix4);
                    transformGroup.setTransform(transform);
                } catch (BadTransformException g) {
                    ExceptionHandler.handleException(g, this);
                }
            }
        }
        needsClippingAdjustment = true;
        hasViewingPlatformChanged = true;
    }

    /**
     * Sets the <code>CanDumpCapturedImages</code> attribute of the <code>Context
     * </code>object.
     *
     * @param canDumpCapturedImages The new <code>CanDumpCapturedImages</code> value.
     */
    public void setCanDumpCapturedImages(boolean canDumpCapturedImages) {
        this.canDumpCapturedImages = canDumpCapturedImages;
    }

    /**
     * Sets the <code>UsesInteractionSpeedup</code> attribute of the <code>Context</code>
     * object.
     *
     * @param autoSwitch The new <code>autoSwitch</code> value.
     */
    public void setAutoSwitch(boolean autoSwitch) {
        this.autoSwitch = autoSwitch;
    }

    /**
     * Sets the <code>CenterOfRotation</code> attribute of the <code>Context
     * </code>object.
     *
     * @param tuple The new <code>CenterOfRotation</code> value.
     */
    public void setCenterOfRotation(Tuple3f tuple) {
        centerOfRotation.set(tuple);
    }

    /**
     * Sets the <code>solidRendering</code> attribute of the <code>Context</code> object.
     *
     * @param solidRendering The new <code>solidRendering</code> value.
     */
    public void setSolidRendering(boolean solidRendering) {
        this.solidRendering = solidRendering;
        if (!solidRendering) {
            framerateDropped = true;
        }
    }

    /**
     * Method description.
     */
    public void updateStereoSettings() {
        if (getStereoEnable()) {
            Point3d leftEye = new Point3d();
            getView().getPhysicalBody().getLeftEyePosition(leftEye);
            leftEye.x = -stereoEyeOffset;
            Point3d rightEye = new Point3d();
            getView().getPhysicalBody().getRightEyePosition(rightEye);
            rightEye.x = +stereoEyeOffset;
            getView().setCompatibilityModeEnable(true);
            Transform3D identity = new Transform3D();
            identity.setIdentity();
            Transform3D transform = new Transform3D();
            double aspect = getWidth();
            aspect /= getHeight();
            Transform3D leftTransform = new Transform3D();
            leftTransform.perspective(getView().getFieldOfView(), aspect, 1.2,
                stereoBackplane);
            transform.rotY(stereoRotationAngle * Math.PI / 180);
            leftTransform.mul(transform);
            transform.set(new Vector3f(leftEye));
            leftTransform.add(transform);
            leftTransform.sub(identity);
            getView().setLeftProjection(leftTransform);
            Transform3D rightTransform = new Transform3D();
            rightTransform.perspective(getView().getFieldOfView(), aspect, 1.2,
                stereoBackplane);
            transform.rotY(-stereoRotationAngle * Math.PI / 180);
            rightTransform.mul(transform);
            rightTransform.sub(identity);
            transform.set(new Vector3f(rightEye));
            rightTransform.add(transform);
            getView().setRightProjection(rightTransform);
        }
    }

    /**
     * Sets the <code>stereoEnable</code> attribute of the <code>Context</code> object.
     *
     * @param enable The new <code>stereoEnable</code> value.
     */
    public void setStereoEnable(boolean enable) {
        super.setStereoEnable(enable);
        if (enable) {
            adjustClipping();
        } else {
            getView().setCompatibilityModeEnable(false);
        }

        // recreate intersection context
        getContextData().getIntersectionManager().invalidate();
    }

    /**
     * Sets the <code>updateEnabled</code> attribute of the <code>Context</code> object.
     *
     * @param isUpdateEnabled The new <code>updateEnabled</code> value.
     */
    public void setUpdateEnabled(boolean isUpdateEnabled) {
        this.isUpdateEnabled = isUpdateEnabled;
    }

    /**
     * Sets the <code>timeoutEnabled</code> attribute of the <code>Context</code> object.
     *
     * @param isTimeoutEnabled The new <code>timeoutEnabled</code> value.
     */
    public void setTimeoutEnabled(boolean isTimeoutEnabled) {
        this.isTimeoutEnabled = isTimeoutEnabled;
    }

    /**
     * Sets the <code>includeTransform</code> attribute of the <code>Context</code>
     * object.
     *
     * @param isIncludeTransform The new <code>includeTransform</code> value.
     */
    public void setIncludeTransform(boolean isIncludeTransform) {
        this.isIncludeTransform = isIncludeTransform;
    }

    /**
     * Sets the <code>background</code> attribute of the <code>Context</code> object.
     *
     * @param color The new <code>background</code> value.
     */
    public void setBackground(final Color3f color) {
        addUpdateCallback(new UpdateBehavior.Callback() {
                public void execute() {
                    background.setColor(color);
                }
            });
    }

    /**
     * Sets the <code>avatarSwitching</code> attribute of the <code>Context</code>
     * object.
     *
     * @param isAvatarSwitching The new <code>avatarSwitching</code> value.
     */
    public void setAvatarSwitching(boolean isAvatarSwitching) {
        this.isAvatarSwitching = isAvatarSwitching;
    }

    /**
     * Sets the <code>lightBranch</code> attribute of the <code>Context</code> object.
     *
     * @param lightBranch The new <code>lightBranch</code> value.
     */
    public void setLightBranch(BranchGroup lightBranch) {
        if (this.lightBranch != null) {
            this.lightBranch.detach();
        }
        this.lightBranch = lightBranch;
        this.lightBranch.setCapability(BranchGroup.ALLOW_DETACH);
    }

    /**
     * Sets the <code>ambientLightColor</code> attribute of the <code>Context</code>
     * object.
     *
     * @param color The new <code>ambientLightColor</code> value.
     */
    public void setAmbientLightColor(Color3f color) {
        ambientLightColor.set(color);
        ambientLight.setColor(ambientLightColor);
    }

    /**
     * Gets the <code>ViewingPlatformPosition</code> attribute of the
     * <code>Context</code> object.
     *
     * @return The <code>ViewingPlatformPosition</code> value.
     */
    public Point3d getViewingPlatformPosition() {
        Transform3D transform = getViewingPlatformTransform();
        Vector3d translation = new Vector3d();
        transform.get(translation);
        transform = null;
        return new Point3d(translation);
    }

    /**
     * Gets the <code>ViewingPlatformTransform</code> attribute of the
     * <code>Context</code> object.
     *
     * @return The <code>ViewingPlatformTransform</code> value.
     */
    public Transform3D getViewingPlatformTransform() {
        if (viewingPlatform != null) {
            TransformGroup transformGroup =
                viewingPlatform.getViewPlatformTransform();
            Transform3D transform = new Transform3D();
            transformGroup.getTransform(transform);
            return transform;
        }
        return null;
    }

    /**
     * Gets the <code>CenterOfRotation</code> attribute of the <code>Context
     * </code>object.
     *
     * @return The <code>CenterOfRotation</code> value.
     */
    public Point3f getCenterOfRotation() {
        return new Point3f(centerOfRotation);
    }

    /**
     * Gets the <code>ContextData</code> attribute of the <code>Context</code> object.
     *
     * @return The <code>ContextData</code> value.
     */
    public final ContextData getContextData() {
        return contextData;
    }

    /**
     * Description of the method.
     *
     * @return Description of the returned value.
     */
    public boolean isAutoSwitchEnabled() {
        return autoSwitch;
    }

    /**
     * Gets the <code>rendererLocked</code> attribute of the <code>Context</code> object.
     *
     * @return The <code>rendererLocked</code> value.
     */
    public final boolean isRendererLocked() {
        return rendererLocked > 0;
    }

    /**
     * Gets the <code>solidRenderingEnabled</code> attribute of the <code>Context </code>
     * object.
     *
     * @return The <code>solidRenderingEnabled</code> value.
     */
    public boolean isSolidRenderingEnabled() {
        return solidRendering;
    }

    /**
     * Gets the <code>constraints</code> attribute of the <code>Context</code> object.
     *
     * @return The <code>constraints</code> value.
     */
    public Collection getConstraints() {
        return constraints;
    }

    /**
     * Gets the <code>universe</code> attribute of the <code>Context</code> object.
     *
     * @return The <code>universe</code> value.
     */
    public VirtualUniverse getUniverse() {
        return universe;
    }

    /**
     * Gets the <code>sceneTransform</code> attribute of the <code>Context</code> object.
     *
     * @return The <code>sceneTransform</code> value.
     */
    public TransformGroup getSceneTransform() {
        return sceneTransform;
    }

    /**
     * Gets the <code>viewerAvatar</code> attribute of the <code>Context</code> object.
     *
     * @return The <code>viewerAvatar</code> value.
     */
    public ViewerAvatar getViewerAvatar() {
        return viewerAvatar;
    }

    /**
     * Gets the <code>sceneLevel</code> attribute of the <code>Context</code> object.
     *
     * @return The <code>sceneLevel</code> value.
     */
    public BranchGroup getSceneLevel() {
        return sceneLevel;
    }

    /**
     * Gets the <code>localLevel</code> attribute of the <code>Context</code> object.
     *
     * @return The <code>localLevel</code> value.
     */
    public BranchGroup getLocalLevel() {
        return localLevel;
    }

    /**
     * Gets the <code>behaviorLevel</code> attribute of the <code>Context</code> object.
     *
     * @return The <code>behaviorLevel</code> value.
     */
    public BranchGroup getBehaviorLevel() {
        return behaviorLevel;
    }

    /**
     * Gets the <code>viewingPlatform</code> attribute of the <code>Context</code>
     * object.
     *
     * @return The <code>viewingPlatform</code> value.
     */
    public ViewingPlatform getViewingPlatform() {
        return viewingPlatform;
    }

    /**
     * Gets the <code>attenuationActive</code> attribute of the <code>Context</code>
     * object.
     *
     * @return The <code>attenuationActive</code> value.
     */
    public boolean isAttenuationActive() {
        return isAttenutationActive;
    }

    /**
     * Gets the <code>avatarJunction</code> attribute of the <code>Context</code> object.
     *
     * @return The <code>avatarJunction</code> value.
     */
    public Junction getAvatarJunction() {
        return avatarJunction;
    }

    /**
     * Gets the <code>avatarSwitching</code> attribute of the <code>Context</code>
     * object.
     *
     * @return The <code>avatarSwitching</code> value.
     */
    public boolean isAvatarSwitching() {
        return isAvatarSwitching;
    }

    /**
     * Gets the <code>lightBranch</code> attribute of the <code>Context</code> object.
     *
     * @return The <code>lightBranch</code> value.
     */
    public BranchGroup getLightBranch() {
        return lightBranch;
    }

    /**
     * Gets the <code>updateBehaviorRunning</code> attribute of the <code>Context</code>
     * object.
     *
     * @return The <code>updateBehaviorRunning</code> value.
     */
    public boolean isUpdateBehaviorRunning() {
        return updateBehavior.isInitialized();
    }

    /**
     * Implementation of the <code>Constrainable</code> interface method.
     *
     * @param object Description of parameter.
     *
     * @return Description of the returned value.
     */
    public boolean processConstraints(Object object) {
        boolean isModified = false;
        Iterator iterator = constraints.iterator();
        while (iterator.hasNext()) {
            isModified |= ((Constraint) iterator.next()).process(object);
        }
        return isModified;
    }

    /**
     * <code>MouseListener</code> method implementation
     *
     * @param mouseEvent Description of parameter.
     */
    public void mouseClicked(MouseEvent mouseEvent) {
        requestFocus();
    }

    /**
     * <code>MouseListener</code> method implementation
     *
     * @param mouseEvent Description of parameter.
     */
    public void mouseEntered(MouseEvent mouseEvent) {
        ContextManager.setActiveContext(this);
        KeyHandler.setCursor(getContextData(), "Select", true);
    }

    /**
     * <code>MouseListener</code> method implementation
     *
     * @param mouseEvent Description of parameter.
     */
    public void mouseExited(MouseEvent mouseEvent) {
    }

    /**
     * <code>MouseListener</code> method implementation
     *
     * @param mouseEvent Description of parameter.
     */
    public void mousePressed(MouseEvent mouseEvent) {
        requestFocus();
    }

    /**
     * <code>MouseListener</code> method implementation
     *
     * @param mouseEvent Description of parameter.
     */
    public void mouseReleased(final MouseEvent mouseEvent) {
        ContextManager.unlockContext(this);
        switchRepresentation(Junction.ON);
        KeyHandler.setCursor(getContextData(), "Select", true);
        KeyHandler.setCursor(getContextData(), mouseEvent, 0);

        // need this to ensure the cursor is really set after the last cursor-modifying
        // behavior was executed
        addUpdateCallback(null);
        addUpdateCallback(new UpdateBehavior.Callback() {
                public void execute() {
                    KeyHandler.setCursor(getContextData(), "Select", true);
                    KeyHandler.setCursor(getContextData(), mouseEvent, 0);
                }
            });

        // consume the event
        mouseEvent.consume();
    }

    /**
     * <code>MouseMotionListener</code> method implementation
     *
     * @param mouseEvent Description of parameter.
     */
    public void mouseMoved(MouseEvent mouseEvent) {
        KeyHandler.setCursor(getContextData(), mouseEvent, 0);
    }

    /**
     * <code>MouseListener</code> method implementation
     *
     * @param mouseEvent Description of parameter.
     */
    public void mouseDragged(MouseEvent mouseEvent) {

        // stop the position interpolator if still running
        positionInterpolator.setEnable(false);
        ContextManager.lockContext(this);
        switchRepresentation(Junction.OFF);
    }

    /**
     * Removes all the locales from the current scene graph and cleans up all context
     * references. After calling this method the context is not usable anymore. The
     * cleanup as complete as the context can get recovered by a new call to the setup()
     * method.
     *
     * @param fullCleanup Description of parameter.
     */
    public void cleanup(boolean fullCleanup) {
        if (offscreenContext != null) {
            offscreenContext.cleanup();
            offscreenContext = null;
        }
        contextData.cleanup();
        contextData = null;
        detach(localLevel, "local level");
        detach(sceneLevel, "scene level");
        detach(behaviorLevel, "behavior level");
        detach(viewerAvatar, "avatar");
        try {
            if (universe != null) {
                universe.removeAllLocales();
                if (fullCleanup) {
                    universe = null;
                }
                getView().removeCanvas3D(this);
            }
        } catch (Exception e) {
            ExceptionHandler.handleException(e,
                ExceptionHandler.SILENT_IN_RELEASE, this);
        }
        sceneTransform = null;
        viewingPlatform = null;
        viewPlatform = null;
        viewerAvatar = null;
        behaviorLevel = null;
        sceneLevel = null;
        localLevel = null;
        avarageFullFrameDuration = 0;
        currentRepresentationMode = Junction.ON;
        needsClippingAdjustment = false;
        hasViewingPlatformChanged = false;
        canDumpCapturedImages = false;
        centerOfRotation = new Point3f();
        Thread.yield();
    }

    /**
     * Description of the method.
     */
    public void finalizeSetup() {

        // finally attach the suggested tree to the universe
        universe.addBranchGraph(localLevel);
        setStereoEnable(false);
        adjustClipping();
    }

    /**
     * Adjusts the front (hither) and back (yon) clipping plane according to the current
     * viewing platform position FIXME: the default currently applies to the cell view
     * purpose. I propose to put this method in a specialized class of Context (e.g.
     * CellViewContext) and make this here more general (assuming measurements in
     * meters).
     */
    public void adjustClipping() {
        needsClippingAdjustment = false;
        Vector3f vector = new Vector3f(getViewingPlatformPosition());
        double back = vector.length() + 100;
        getView().setBackClipDistance(back);

        // :FIXME: we have to assure this clipping 'factor' works on EVERY machine
        getView().setFrontClipDistance(1.2);
        if (getStereoEnable()) {
            stereoBackplane = back;
            updateStereoSettings();
        }
    }

    /**
     * This method gets called before the rendering is done. we can establish some
     * neccessary things here
     */
    public void preRender() {
        if (needsClippingAdjustment) {
            adjustClipping();
        }
        super.preRender();
    }

    /**
     * This method is called after the renderering, we use it to drop external event
     * triggering
     */
    public void postRender() {
        super.postRender();
        observeFrameRate();
    }

    /**
     * Description of the method.
     */
    public void postSwap() {
        super.postSwap();
        hasViewingPlatformChanged = false;
    }

    /**
     * Description of the method.
     *
     * @param url Description of parameter.
     *
     * @return Description of the returned value.
     */
    public BranchGroup loadSubscene(URL url) {
        BranchGroup local = new BranchGroup();
        BranchGroupHelper.setDefaultCapabilities(local);
        GenericLoader loader = new GenericLoader();
        com.sun.j3d.loaders.Scene scene;
        try {
            scene = loader.load(url);
            if (scene != null) {

                // add it to the scene graph
                local.addChild(scene.getSceneGroup());
            } else {
                log.error("specified file " + url +
                    " was not loaded properly.");
            }
        } catch (Exception e) {
            ExceptionHandler.handleException(e, this);
        }
        local.setCapability(Node.ENABLE_PICK_REPORTING);

        //    GCThread.gc();
        return local;
    }

    /**
     * Description of the method.
     *
     * @return Description of the returned value.
     */
    public boolean hasViewingPlatformChanged() {
        return hasViewingPlatformChanged;
    }

    /**
     * Description of the method.
     */
    public void update() {

        // the update is done by setting the viewing platform to
        // the current position. As side effect the clipping will be
        // updated.
        setViewingPlatformTransform(getViewingPlatformTransform());
        adjustClipping();
    }

    /**
     * Description of the method.
     *
     * @param mode Description of parameter.
     */
    public void switchRepresentation(final int mode) {
        if (mode != currentRepresentationMode) {
            if (mode == Junction.ON) {
                getContextData().getJunctionManager().setMode(mode);
                currentRepresentationMode = mode;
            } else {
                if (!solidRendering) {
                    if (framerateDropped) {
                        getContextData().getJunctionManager().setMode(mode);
                        currentRepresentationMode = mode;
                    }
                }
            }
        }
        if (isAvatarSwitching) {
            addUpdateCallback(new UpdateBehavior.Callback() {
                    public void execute() {
                        if (avatarJunction.getMode() != mode) {
                            if (mode == Junction.OFF) {

                                // :WORKAROUND: this is a Java 3D version dependency
                                if (AppearanceHelper.java3DVersion == AppearanceHelper.JAVA3D_1_3) {
                                    OverlayManager.spawnOverlays(getContextData());
                                }
                            }
                            avatarJunction.setMode(mode);
                        }
                    }
                });
        }
    }

    /**
     * Description of the method.
     *
     * @param destination Description of parameter.
     * @param time Description of parameter.
     */
    public void interpolatePosition(Tuple3f destination, int time) {
        Point3f origin = new Point3f(getViewingPlatformPosition());
        Vector3f distance = new Vector3f(destination);
        distance.sub(origin);
        if (time > 0) {
            if (distance.lengthSquared() > 0.001f) {
                switchRepresentation(Junction.OFF);
                positionInterpolator.setOrigin(origin);
                positionInterpolator.setDestination(destination);
                Alpha alpha =
                    new Alpha(1, Alpha.INCREASING_ENABLE, 0, 0, time, 0, 0, 0,
                        0, 0);
                positionInterpolator.setAlpha(alpha);
                positionInterpolator.setEnable(true);
            } else {
                setViewingPlatformPosition(new Point3d(destination));
                interpolationStopped();
            }
        } else {
            setViewingPlatformPosition(new Point3d(destination));
            interpolationStopped();
        }
    }

    /**
     * Description of the method.
     */
    public void interpolationStopped() {
        addUpdateCallback(new UpdateBehavior.Callback() {
                public void execute() {
                    switchRepresentation(Junction.ON);
                }
            });
    }

    /**
     * Description of the method.
     */
    public void lockRenderer() {
        if (!isOffScreen()) {
            stopRenderer();
        }
        rendererLocked++;
    }

    /**
     * Description of the method.
     */
    public void unlockRenderer() {
        if (rendererLocked > 0) {
            rendererLocked--;
            if (rendererLocked == 0) {
                if (!isOffScreen()) {
                    startRenderer();
                }
            }
        } else {
            log.error("attempting unlock on running renderer.");
        }
    }

    /**
     * Description of the method.
     */
    public final void intitialize() {
        addMouseMotionListener(this);
        addMouseListener(this);
        initializeContextData();
        setBackground(Parameter.panelBackgroundColor);
        updateBehavior = new UpdateBehavior(getContextData());
    }

    /**
     * Adds a <code>UpdateCallback</code> object to the <code>Context</code> object.
     *
     * @param callback The <code>UpdateCallback</code> object to be added.
     */
    public void addUpdateCallback(final UpdateBehavior.Callback callback) {

        // callback will only be executed in case isUpdateEnabled is set
        if (isUpdateEnabled && getContextData().isValid()) {
            if (!updateBehavior.isExecutingThread(Thread.currentThread())) {
                updateBehavior.addCallback(callback);
            } else {
                if (callback != null) {
                    stopRenderer();

                    // execute the callback without putting into the queue (sub-callback)
                    callback.execute();
                    startRenderer();
                }
            }
        }
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public boolean isTimeoutExecutionEnabled() {
        return isTimeoutEnabled;
    }

    /**
     * Description of the method.
     */
    public void waitForUpdate() {
        int i = 10;
        if (getView() != null && getView().isBehaviorSchedulerRunning()) {
            if (!updateBehavior.isExecutingThread(Thread.currentThread())) {
                while (getContextData().isValid() &&
                      updateBehavior.hasCallbacks()) {
                    try {
                        Thread.sleep(50);
                        i--;
                        if (i < 0) {
                            if (isTimeoutExecutionEnabled()) {
                                if (isTimeoutEnabled) {

                                    // do NOT allow any more thing put into the queue
                                    setUpdateEnabled(false);
                                }
                                log.debug("timeout callback execution.");
                                updateBehavior.runAllCallbacks();
                                i = 10;
                            }
                        }
                    } catch (InterruptedException e) {

                        // :SILENT EXCEPTION:
                    }
                }
            }
        }
    }

    /**
     * Description of the method.
     */
    public void terminateCallbacks() {
        updateBehavior.terminateCallbacks();
    }

    /**
     * Description of the method.
     *
     * @param isActivate Description of parameter.
     */
    public void activateAttenuation(final boolean isActivate) {
        isAttenutationActive = isActivate;
        if (isActivate) {
            if (attenuation == null) {
                attenuation =
                    new LinearFog(new Color3f(0.1f, 0.1f, 0.1f), 100, 200);
                attenuation.setInfluencingBounds(new BoundingSphere(
                        new Point3d(), Double.MAX_VALUE));
                attenuation.addScope(sceneLevel);
                attenuationBranch = new BranchGroup();
                attenuationBranch.setCapability(BranchGroup.ALLOW_DETACH);
                attenuationBranch.addChild(attenuation);
            }
            viewerAvatar.addChild(attenuationBranch);
        } else {
            if (attenuationBranch != null) {
                attenuationBranch.detach();
            }
        }
    }

    /**
     * Description of the method.
     *
     * @param isPrintMode Description of parameter.
     */
    public void switchPrintMode(boolean isPrintMode) {
    }

    /**
     * Description of the method.
     */
    public void waitForInitialization() {
        int counter = 0;

        // wait for update behavior to get started
        while (getContextData().isValid() && !updateBehavior.isInitialized() &&
              counter++ < 15) {

            // trigger behavior scheduling
            updateBehavior.postId(UpdateBehavior.UPDATE_POST_ID);

            // give the other threads some time
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {

                // :SILENT EXCEPTION:
            }
        }
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public BufferedImage getRenderedImage() {
        if (offscreenContext != null) {

            // grab an image using the offscreen buffer
            Toolkit.getDefaultToolkit().sync();
            BufferedImage image = offscreenContext.getImage();
            return image;
        }
        return null;
    }

    /**
     * Paint method overwrite to accomplish printing
     *
     * @param g Graphics object to render to.
     */
    public void paint(Graphics g) {
        super.paint(g);
        Toolkit.getDefaultToolkit().sync();
    }

    /**
     * Sets the <code>contextData</code> attribute of the <code>Context</code> object.
     *
     * @param contextData The new <code>contextData</code> value.
     */
    protected void setContextData(ContextData contextData) {
        this.contextData = contextData;
    }

    /**
     * Description of the method.
     */
    protected void initializeContextData() {
        setContextData(new ContextData(this));
    }

    /**
     * Description of the method.
     */
    private void observeFrameRate() {
        if (autoSwitch && currentRepresentationMode == Junction.ON) {
            avarageFullFrameDuration *= 20;
            avarageFullFrameDuration += getView().getLastFrameDuration();
            avarageFullFrameDuration *= 1.0f / 21;

            // 10 frames per second is the limit
            if (avarageFullFrameDuration > 100) {
                framerateDropped = true;
                autoSwitch = false;
                setSolidRendering(false);
            }
        }
    }

    /**
     * Description of the method.
     *
     * @param branchGroup Description of parameter.
     * @param message Description of parameter.
     */
    private void detach(BranchGroup branchGroup, String message) {
        if (branchGroup != null) {
            try {
                branchGroup.detach();
            } catch (Exception e) {
                ExceptionHandler.handleException(e,
                    ExceptionHandler.SILENT_IN_RELEASE, this);
            }
            try {
                BranchGroupHelper.detach(getContextData(), branchGroup);
            } catch (Exception e) {
                ExceptionHandler.handleException(e,
                    ExceptionHandler.SILENT_IN_RELEASE, this);
            }
        }
    }

    /**
     * Gets the <code>offscreenGraphicsConfiguration</code> attribute of the
     * <code>Context</code> class.
     *
     * @return The <code>offscreenGraphicsConfiguration</code> value.
     */
    public static GraphicsConfiguration getOffscreenGraphicsConfiguration() {
        GraphicsConfiguration config = null;
        if (config == null) {
            config = SimpleUniverse.getPreferredConfiguration();
        }
        return config;
    }

    /**
     * Creates a default graphics context.
     *
     * @return Created graphics context.
     */
    public static GraphicsConfiguration getDefaultGraphicsConfiguration() {
        GraphicsConfiguration config =
            ConfiguredUniverse.getPreferredConfiguration();
        return config;

        //
        //    // start with a standard configuration
        //    GraphicsConfigTemplate3D template = new GraphicsConfigTemplate3D();
        //    template.setSceneAntialiasing(GraphicsConfigTemplate3D.UNNECESSARY);
        //
        //    try {
        //
        //      template.setStereo(GraphicsConfigTemplate3D.PREFERRED);
        //      config =
        //        GraphicsEnvironment.getLocalGraphicsEnvironment()
        //                           .getDefaultScreenDevice().getBestConfiguration(template);
        //
        //    }
        //    catch (Exception e) {
        //
        //      ExceptionHandler.handleException(e, ExceptionHandler.SILENT_IN_DEBUG);
        //      config = SimpleUniverse.getPreferredConfiguration();
        //
        //    }
        //
        //    // stop the app if config is still null
        //    if (config == null) {
        //
        //      throw (new RuntimeException(Context.class +
        //        ": cannot retrieve a valid graphic configuration!"));
        //
        //    }
        //
        //    return config;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public double getStereoRotationAngle() {
        return stereoRotationAngle;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public double getStereoBackplane() {
        return stereoBackplane;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public double getStereoEyeOffset() {
        return stereoEyeOffset;
    }

    /**
     * Method description.
     *
     * @param stereoRotationAngle Parameter description.
     */
    public void setStereoRotationAngle(double stereoRotationAngle) {
        this.stereoRotationAngle = stereoRotationAngle;
        updateStereoSettings();
        log.info("inter frustum rotation set to: " + stereoRotationAngle);
    }

    /**
     * Method description.
     *
     * @param stereoBackplane Parameter description.
     */
    public void setStereoBackplane(double stereoBackplane) {
        this.stereoBackplane = stereoBackplane;
        updateStereoSettings();
    }

    /**
     * Method description.
     *
     * @param stereoEyeOffset Parameter description.
     */
    public void setStereoEyeOffset(double stereoEyeOffset) {
        this.stereoEyeOffset = stereoEyeOffset;
        updateStereoSettings();
        log.info("eye offset set to: " + stereoEyeOffset);
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public OffscreenContext getOffscreenContext() {
        return offscreenContext;
    }

    protected void setNeedsClippingAdjustment(boolean needsClippingAdjustment) {
        this.needsClippingAdjustment = needsClippingAdjustment;
    }
}
