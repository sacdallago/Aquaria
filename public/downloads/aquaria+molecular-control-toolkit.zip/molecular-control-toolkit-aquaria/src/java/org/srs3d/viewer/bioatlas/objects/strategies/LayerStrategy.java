/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.objects.strategies;

import javax.vecmath.Point3f;

import org.srs3d.viewer.bioatlas.objects.Layer;
import org.srs3d.viewer.j3d.Reaction;
import org.srs3d.viewer.j3d.commands.ComputeCenterCommand;
import org.srs3d.viewer.j3d.commands.IdentificationCommand;
import org.srs3d.viewer.j3d.commands.RegisterCommand;
import org.srs3d.viewer.j3d.objects.strategies.AbstractStrategy;
import org.srs3d.viewer.j3d.objects.strategies.reactions.EmptyReaction;
import org.srs3d.viewer.objects.Command;

/**
 * @author Karsten Klein
 *
 * @created April 03, 2001
 */
public class LayerStrategy extends AbstractStrategy {

    /**
     * <code>LayerStrategy</code> constructor.
     */
    public LayerStrategy() {
        register(ComputeCenterCommand.class, new ComputeCenterReaction());
        register(RegisterCommand.class, EmptyReaction.getSharedInstance());
        register(IdentificationCommand.class, new IdentificationReaction());
    }

    /**
     * Description of the class.
     *
     * @author Karsten Klein
     *
     * @created March 26, 2002
     */
    public class ComputeCenterReaction implements Reaction {

        /**
         * Description of the method.
         *
         * @param command Description of parameter.
         */
        public void execute(Command command) {
            ComputeCenterCommand computeCenterCommand =
                (ComputeCenterCommand) command;
            Layer layer = (Layer) computeCenterCommand.getObject();
            Point3f center = layer.getCenter();
            computeCenterCommand.modifyCenter(center, layer.getExtend());
        }
    }

    /**
     * Reaction for retrieving the object identification.
     *
     * @author Karsten Klein
     *
     * @created March 26, 2002
     */
    public static class IdentificationReaction implements Reaction {

        /**
         * Execute implementation of the reaction interface.
         *
         * @param command Command to react to.
         */
        public void execute(Command command) {
            IdentificationCommand idCommand = (IdentificationCommand) command;
            idCommand.setObjectId("L:" +
                ((Layer) command.getObject()).getDescription());
            idCommand.execute();
        }
    }
}
