/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.annotation.objects.strategies;

import java.util.Collection;

import javax.media.j3d.Appearance;
import javax.media.j3d.Texture;
import javax.vecmath.Color3f;

import org.srs3d.viewer.annotation.contexts.AnnotationContextData;
import org.srs3d.viewer.annotation.objects.Segment;
import org.srs3d.viewer.bioatlas.objects.Residue;
import org.srs3d.viewer.bioatlas.objects.Subchain;
import org.srs3d.viewer.j3d.AppearanceHelper;
import org.srs3d.viewer.j3d.AppearanceManager;
import org.srs3d.viewer.j3d.AppearanceManager.TextureColors;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.Reaction;
import org.srs3d.viewer.j3d.Selection;
import org.srs3d.viewer.j3d.commands.ColorCommand;
import org.srs3d.viewer.j3d.commands.IntersectCommand;
import org.srs3d.viewer.j3d.commands.RegisterCommand;
import org.srs3d.viewer.j3d.objects.strategies.AbstractStrategy;
import org.srs3d.viewer.objects.Command;

/**
 * @author Karsten Klein
 *
 * @created April 03, 2001
 */
public class SegmentStrategy extends AbstractStrategy {

    /**
     * Constructor description.
     */
    public SegmentStrategy() {
        register(RegisterCommand.class, new RegisterReaction());
        register(ColorCommand.class, new ColorReaction());

        //    register( IntersectCommand.class, new IntersectReaction() );
    }

    /**
     * Class description.
     *
     * @author Karsten Klein, LION bioscience AG
     */
    public class RegisterReaction implements Reaction {

        /**
         * Method description.
         *
         * @param command Parameter description.
         */
        public void execute(Command command) {
            RegisterCommand registerCommand = (RegisterCommand) command;
            registerCommand.setApplicationMode(RegisterCommand.UP);
            registerCommand.execute();
        }
    }

    /**
     * Class description.
     *
     * @author Karsten Klein, LION bioscience AG
     */
    public class ColorReaction implements Reaction {

        /**
         * Method description.
         *
         * @param command Parameter description.
         */
        public final void execute(Command command) {
            ColorCommand colorCommand = (ColorCommand) command;
            Segment segment = (Segment) command.getObject();
            Subchain subchain = segment.getSubchain();

            // exclude gap segments
            if (subchain != null) {
                ContextData contextData = colorCommand.getContextData();
                ContextData referenceContextData =
                    ((AnnotationContextData) contextData).getReferenceContextData();
                AppearanceManager appearanceManager =
                    contextData.getAppearanceManager();
                AppearanceManager referenceAppearanceManager =
                    referenceContextData.getAppearanceManager();
                Appearance appearance =
                    AppearanceHelper.createAppearance(new Color3f(1, 0, 0));

                // reuse the texture from the reference context
                TextureColors textureColors =
                    referenceAppearanceManager.getTextureColors(segment.getSubchain());
                if (textureColors == null) {
                    textureColors = AppearanceManager.getDefaultTextureColors();
                }
                if (textureColors != null) {

                    // :TODO: partial selection is currently not used in the project
                    // enable this method once the partial selection is supported
                    // not that the above texture color reuse will not be possible anymore
                    //          textureColors =
                    //            highlightPartialSelectedResidues(contextData, referenceContextData,
                    //              segment, textureColors);
                    if (!textureColors.isMonochromatic()) {
                        Texture texture =
                            textureColors.createTexture(contextData);
                        AppearanceHelper.setTextureDefaults(appearance, texture);
                        AppearanceHelper.modifyAppearance(appearance,
                            new Color3f(1, 1, 1));
                    } else {
                        AppearanceHelper.modifyAppearance(appearance,
                            getResidueColor(contextData,
                                segment.getInitialResidue()));
                    }
                }
                ColorCommand.apply(contextData, subchain, appearance);
                ColorCommand.apply(contextData, segment, appearance);
            }
        }

        /**
         * Method description.
         *
         * @param contextData Parameter description.
         * @param referenceContextData Parameter description.
         * @param segment Parameter description.
         * @param textureColors Parameter description.
         *
         * @return Return description.
         */
        public TextureColors highlightPartialSelectedResidues(
            ContextData contextData, ContextData referenceContextData,
            Segment segment, TextureColors textureColors) {
            Selection selection =
                contextData.getSelectionManager().getSelection();
            if (!selection.isEmpty()) {
                if (selection.contains(segment)) {
                    Collection residues =
                        (Collection) contextData.getProperty(
                            "RESIDUE_HIGHLIGHT");
                    if (residues != null) {
                        Selection referenceSelection =
                            referenceContextData.getSelectionManager()
                                                .getSelection();
                        Residue residue = segment.getInitialResidue();
                        Residue limit = segment.getEndResidue().getProceeding();
                        while (residue != limit) {
                            if (residues.contains(residue)) {
                                if (!referenceSelection.contains(residue)) {

                                    // :TODO: hightlight partial selected residue
                                }
                            }
                            residue = residue.getProceeding();
                        }
                    }
                }
            }
            return textureColors;
        }

        /**
         * Method description.
         *
         * @param contextData Parameter description.
         * @param residue Parameter description.
         *
         * @return Return description.
         */
        public Color3f getResidueColor(ContextData contextData, Residue residue) {
            Color3f color = new Color3f();
            Appearance appearance =
                ((AnnotationContextData) contextData).getReferenceContextData()
                 .getAppearanceManager().getAppearance(residue);
            AppearanceHelper.getColor(appearance, color);
            return color;
        }
    }

    /**
     * Class description.
     *
     * @author Karsten Klein, LION bioscience AG
     */
    public class IntersectReaction implements Reaction {

        /**
         * Method description.
         *
         * @param command Parameter description.
         */
        public void execute(Command command) {
            IntersectCommand intersectCommand = (IntersectCommand) command;
            intersectCommand.setObject(((Segment) intersectCommand.getObject()).getSubchain());
        }
    }
}
