/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.creators;

import javax.media.j3d.BranchGroup;
import javax.media.j3d.LineArray;
import javax.media.j3d.Shape3D;
import javax.vecmath.Color4f;
import javax.vecmath.Point3f;

import org.srs3d.viewer.j3d.ShapeManager;
import org.srs3d.viewer.j3d.geometry.GeometryHelper;
import org.srs3d.viewer.j3d.objects.Line;
import org.srs3d.viewer.objects.AbstractObject;

/**
 * Description of the class.
 *
 * @author Karsten Klein
 *
 * @created March 20, 2001
 */
public class LineGeometryCreator extends AbstractGeometryCreator {

    /** Description of the Field */
    public static int GEOMETRY = 1;

    /** Description of the Field */
    public int type = GEOMETRY;

    /**
     * Creates the graphical description (subscenegraph) of an
     * <code>AbstractObject</code> rooted by the given branchGroup.
     *
     * @param object object to display. Only <code>Box</code> instances will be
     *        processed.
     * @param branchGroup root for the created subscenegraph.
     */
    public void create(AbstractObject object, BranchGroup branchGroup) {
        if (object instanceof Line) {
            create((Line) object, branchGroup);
        }
    }

    /**
     * Creates the representation of the <code>Box</code> object.
     *
     * @param box <code>Box</code> to display.
     * @param branchGroup root for the created subscenegraph.
     */
    public void create(Line line, BranchGroup branchGroup) {
        if ((type & GEOMETRY) != 0) {
            createGeometry(line, branchGroup);
        }
    }

    /**
     * Greates the geometry in <code>GEOMETRY</code> mode of the <code>Box </code>object.
     *
     * @param box <code>Line</code> to display.
     * @param branchGroup root for the created subscenegraph.
     */
    public void createGeometry(Line line, BranchGroup branchGroup) {
        Point3f min = line.getCoordinates().getAt(0);
        Point3f max = line.getCoordinates().getAt(1);
        LineArray lineArray =
            GeometryHelper.getDefaultLineArray(1, LineArray.COLOR_4);
        Color4f color = new Color4f(0.0f, 0.0f, 0.0f, 0.0f);
        org.srs3d.viewer.j3d.geometry.primitive.Line l =
            new org.srs3d.viewer.j3d.geometry.primitive.Line();
        l.getColors().setUniform(color);
        l.getCoordinates().setAt(0, min);
        l.getCoordinates().setAt(1, max);
        l.insertInto(0, lineArray);
        Shape3D shape = new Shape3D(lineArray);
        ShapeManager.setCapabilities(shape, line);
        getContextData().getShapeManager().register(line, shape);
        branchGroup.addChild(shape);
    }
}
