/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.modules;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Vector;

import javax.swing.JMenuItem;
import javax.swing.KeyStroke;

import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.behaviors.dispatcher.Dispatch;
import org.srs3d.viewer.j3d.behaviors.dispatcher.Dispatcher;
import org.srs3d.viewer.j3d.behaviors.dispatcher.OperationDispatch;
import org.srs3d.viewer.objects.Operation;
import org.srs3d.viewer.swing.StrategyModule;
import org.srs3d.viewer.util.Log;

/**
 * This partial implementation of the <code>Module</code> interface provides general
 * methods that are shared by its subclasses.
 *
 * @author Karsten Klein
 *
 * @created May 14, 2001
 */
public abstract class AbstractModule extends StrategyModule {
    private static final Log log = new Log(AbstractModule.class);
    private ContextData contextData = null;
    private String name;
    private Collection actionListeners = null;
    private JMenuItem component = null;
    private KeyStroke keyStroke = null;
    private boolean isOperationSerializeable = true;

    /**
     * <code>AbstractModule</code> constructor.
     *
     * @param name Description of parameter.
     */
    public AbstractModule(String name, ContextData contextData) {
        this.name = name;
        this.contextData = contextData;
        register(contextData.getDispatcher());
    }

    /**
     * Gets the <code>context</code> attribute of the <code>ProcessModule</code> object.
     *
     * @return The <code>context</code> value.
     */
    public final ContextData getContextData() {
        return contextData;
    }

    /**
     * Sets the <code>name</code> attribute of the <code>AbstractModule</code> object.
     *
     * @param name The new <code>name</code> value.
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Gets the <code>component</code> of the <code>Module</code> object.
     *
     * @return The <code>component</code> value.
     */
    public Component getComponent() {
        create();
        return component;
    }

    /**
     * Gets the <code>name</code> attribute of the <code>AbstractModule</code> object.
     *
     * @return The <code>name</code> value.
     */
    public String getName() {
        return name;
    }

    /**
     * Gets the <code>accelerator</code> attribute of the <code>AbstractModule</code>
     * object.
     *
     * @return The <code>accelerator</code> value.
     */
    public KeyStroke getAccelerator() {
        return keyStroke;
    }

    /**
     * Adds a <code>ActionListener</code> object to the <code>AbstractModule </code>
     * object.
     *
     * @param actionListener The <code>ActionListener</code> object to be added.
     */
    public void addActionListener(ActionListener actionListener) {
        if (actionListeners == null) {
            actionListeners = new Vector();
        }
        actionListeners.add(actionListener);
    }

    /**
     * Remopve a <code>ActionListener</code> object from the <code>AbstractModule </code>
     * object.
     *
     * @param actionListener The <code>ActionListener</code> object to be removed.
     */
    public void removeActionListener(ActionListener actionListener) {
        if (actionListeners != null) {
            actionListeners.remove(actionListener);
        }
    }

    /**
     * Description of the method.
     */
    public void cleanup() {
        if (actionListeners != null) {
            actionListeners.clear();
            actionListeners = null;
        }
        contextData = null;
    }

    /**
     * Create the component, if not already created.
     */
    private void create() {
        if (component == null) {
            component = new JMenuItem(name);
            component.addActionListener(this);
            KeyStroke keyStroke = getAccelerator();
            if (keyStroke != null) {
                component.setAccelerator(keyStroke);
            }
        }
    }

    /**
     * Method description.
     */
    public void updateIntern() {
    }

    /**
     * Method description.
     */
    public final void update() {
        boolean isVisibleByDefault = checkVisible();
        if (isVisibleByDefault) {
            if (getContextData() != null) {
                Operation operation =
                    new Operation(getContextData().getContext(),
                        getModuleUpdateId(), null);
                operation.setSerializable(false);
                getContextData().getDispatcher().runDispatch(operation);
            } else {
                log.debug("getContextData() returns null for " + this);
            }
        }
        if (getComponent() != null) {
            getComponent().setVisible(isVisibleByDefault);
        }
    }

    /**
     * Method description.
     *
     * @param event Parameter description.
     */
    public final void actionPerformed(ActionEvent event) {
        Operation operation =
            new Operation(getContextData().getContext(), getModuleId(), null);
        operation.setSerializable(isOperationSerializeable());
        getContextData().getDispatcher().runDispatch(operation);
        if (actionListeners != null) {
            Iterator iterator = actionListeners.iterator();
            while (iterator.hasNext()) {
                ((ActionListener) iterator.next()).actionPerformed(event);
            }
        }
    }

    /**
     * Method description.
     *
     * @param keyStroke Parameter description.
     */
    public void setKeyStroke(KeyStroke keyStroke) {
        ArrayList dispatches = new ArrayList(2);
        dispatches.add(new OperationDispatch(getModuleUpdateId(), false));
        dispatches.add(new OperationDispatch(getModuleId(),
                isOperationSerializeable()));
        getContextData().getDispatcher().registerDispatches(keyStroke,
            dispatches);
        this.keyStroke = keyStroke;
    }

    /**
     * Method description.
     *
     * @param dispatcher Parameter description.
     */
    public void register(Dispatcher dispatcher) {
        ArrayList dispatches = new ArrayList(1);
        ArrayList updateDispatches = new ArrayList(1);
        Dispatch dispatch =
            new Dispatch() {
                public void dispatch(ContextData contextData,
                    Operation operation) {
                    react(null);
                }
            };
        Dispatch updateDispatch =
            new Dispatch() {
                public void dispatch(ContextData contextData,
                    Operation operation) {
                    updateIntern();
                }
            };
        dispatches.add(dispatch);
        updateDispatches.add(updateDispatch);
        dispatcher.registerDispatches(getModuleId(), dispatches);
        dispatcher.registerDispatches(getModuleUpdateId(), updateDispatches);
    }

    /**
     * Method description.
     *
     * @param e Parameter description.
     */
    public abstract void react(ActionEvent e);

    /**
     * Method description.
     *
     * @return Return description.
     */
    public String getModuleIdPrefix() {
        return "PROCESS-";
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public String getModuleId() {
        return getModuleIdPrefix() + getConvertedName();
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public String getModuleUpdateId() {
        return "UPDATE-" + getModuleId();
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public String getConvertedName() {
        return convert(getName());
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public boolean isOperationSerializeable() {
        return isOperationSerializeable;
    }

    /**
     * Method description.
     *
     * @param isOperationSerializeable Parameter description.
     */
    public void setOperationSerializeable(boolean isOperationSerializeable) {
        this.isOperationSerializeable = isOperationSerializeable;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public String createReport() {
        String report = (checkVisible() ? "V" : "I");
        if (getComponent() != null) {
            report += "|";
            report += getComponent().isEnabled() ? "E" : "D";
        }
        return report;
    }

    /**
     * Method description.
     *
     * @param map Parameter description.
     */
    public final void createReport(Map map) {
        create();
        super.createReport(map);
    }
}
