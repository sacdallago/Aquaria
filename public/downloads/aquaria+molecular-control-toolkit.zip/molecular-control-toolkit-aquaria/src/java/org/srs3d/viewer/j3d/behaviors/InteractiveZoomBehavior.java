/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.behaviors;

import javax.media.j3d.Transform3D;
import javax.media.j3d.WakeupCriterion;
import javax.vecmath.Matrix3f;
import javax.vecmath.Point3d;
import javax.vecmath.Vector3f;

import org.srs3d.viewer.j3d.Context;
import org.srs3d.viewer.j3d.ContextData;

/**
 * The class <code>ZoomBehavior</code> represents a specialized
 * <code>MouseBehavior</code> . Note that zooming in this behavior is understood
 * as going nearer to an object. Use some other behavior class if you want to
 * scale things.
 * 
 * @author Karsten Klein, 11/2000
 * 
 * @created March 20, 2001
 * @since 1.0
 */
public class InteractiveZoomBehavior extends AwtBehavior implements InteractiveZoom {

	public static final int MAX_DELTA = 8;

	/** Integers used for saving the mouse positions */
	private int lastY;

	/** Integers used for saving the mouse positions */
	private int y;

	/**
	 * <code>ZoomBehavior</code> contructor.
	 * 
	 * @param context
	 *            Description of parameter.
	 */
	public InteractiveZoomBehavior(ContextData contextData) {
		setContextData(contextData);
	}

	public void processStimulus(WakeupCriterion wakeup) {
		// TODO Auto-generated method stub
		
	}
	/* (non-Javadoc)
	 * @see org.srs3d.viewer.j3d.behaviors.ConnectorZoom#initialize()
	 */
	@Override
	public void initialize() {

		AquariaInteractiveDispatcher.setZoom(this);
	}


	/* (non-Javadoc)
	 * @see org.srs3d.viewer.j3d.behaviors.ConnectorZoom#processStimulus(int)
	 */
	@Override
	public void processStimulus(int p_zoom) {
		lastY = y;
//		System.out.println("Processing zoom:" + p_zoom);
		y = p_zoom;
		Context context = getContextData().getContext();
		KeyHandler.setCursor(getContextData(), "PanZ", true);

		// get the current transformation of the viewing platform
		Transform3D transform = context.getViewingPlatformTransform();

		// extract current translation
		Vector3f translation = new Vector3f();
		transform.get(translation);

		// // extract current view direction
		// Vector3f viewDirection = new Vector3f();
		// Matrix3f rotation = new Matrix3f();
		// transform.get( rotation );
		//
		// rotation.getColumn( 2, viewDirection );
		float zoomSpeed = (translation.length() + 10) / 100;
		float delta = y;
		delta = Math.min(delta, MAX_DELTA);
		delta = Math.max(delta, -MAX_DELTA);
		pan(context, zoomSpeed * delta);
		processConstraints();
	}


	/**
	 * Description of the method.
	 * 
	 * @param context
	 *            Description of parameter.
	 * @param delta
	 *            Description of parameter.
	 */
	private void pan(Context context, float delta) {

		// get the current transformation of the viewing platform
		Transform3D transform = context.getViewingPlatformTransform();

		// extract current translation
		Vector3f translation = new Vector3f();
		transform.get(translation);

		// extract current view direction
		Vector3f viewDirection = new Vector3f();
		Matrix3f rotation = new Matrix3f();
		transform.get(rotation);
		rotation.getColumn(2, viewDirection);
		viewDirection.scale(delta);
		translation.add(viewDirection);

		// apply transformation
		context.setViewingPlatformPosition(new Point3d(translation));
	}
}
