/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.behaviors;

import java.awt.event.MouseEvent;

import javax.media.j3d.WakeupOnAWTEvent;
import javax.media.j3d.WakeupOr;
import javax.vecmath.AxisAngle4f;
import javax.vecmath.Matrix3f;
import javax.vecmath.Tuple3f;
import javax.vecmath.Vector3f;

import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.commands.RotateCommand;
import org.srs3d.viewer.objects.AbstractObject;

/**
 * The class <code>RotateBehavior</code> represents a specialized
 * <code>MouseBehavior</code> .
 *
 * @author Karsten Klein
 *
 * @created November 20, 2000
 */
public class RotateBehavior extends MouseBehavior {
    private AbstractObject object = null;
    private Vector3f axis = new Vector3f(0, 0, 1);
    private float speed = 5.0f / 180;

    /** Integers used for saving the mouse positions */
    private int lastX;

    /** Integers used for saving the mouse positions */
    private int x;
    private int lastY;
    private int y;

    /**
     * <code>RotateBehavior</code> contructor.
     *
     * @param context Description of parameter.
     * @param object Description of parameter.
     */
    public RotateBehavior(ContextData contextData, AbstractObject object) {
        super(contextData);
        this.object = object;
    }

    /**
     * Sets the speed of the behavior. The speed is measured in readians per pixel of
     * mouse the movement.
     *
     * @param speed The new <code>Speed</code> value.
     */
    public void setSpeed(float speed) {
        this.speed = speed;
    }

    /**
     * Sets the axis of the behavior. The rotation is performed around that axis.
     *
     * @param axis The new <code>Axis</code> value.
     */
    public void setAxis(Tuple3f axis) {
        axis.set(axis);
    }

    /**
     * Sets the axis of the behavior. The rotation is performed around that axis.
     *
     * @param x The new <code>Axis</code> value.
     * @param y The new <code>Axis</code> value.
     * @param z The new <code>Axis</code> value.
     */
    public void setAxis(float x, float y, float z) {
        axis.set(x, y, z);
    }

    /**
     * Initializes the wakeup conditions for the behavior.
     */
    public void initialize() {
        WakeupOnAWTEvent[] conditions = new WakeupOnAWTEvent[2];

        // set wakeup condition (waiting for further dragging events)
        conditions[0] = new WakeupOnAWTEvent(MouseEvent.MOUSE_DRAGGED);

        // set wakeup condition (waiting first click)
        conditions[1] = new WakeupOnAWTEvent(MouseEvent.MOUSE_PRESSED);
        wakeupOn(new WakeupOr(conditions));
    }

    /**
     * Processes the mouseEvent. This will directly result in a modification of the
     * viewingPlatform in the activated <code>Context</code> , if the according
     * conditions are met by the mouse event.
     *
     * @param mouseEvent Description of parameter.
     */
    public void processStimulus(MouseEvent mouseEvent) {
        lastX = x;
        lastY = y;
        x = mouseEvent.getX();
        y = mouseEvent.getY();
        if (checkCriteria(mouseEvent)) {
            mouseEvent.consume();
            AxisAngle4f axisAngle = new AxisAngle4f(axis, speed * (x - lastX));
            Matrix3f matrix = new Matrix3f();
            matrix.set(axisAngle);
            ContextData contextData = getContextData();
            RotateCommand rotateCommand = new RotateCommand(contextData);
            rotateCommand.setMatrix(matrix);
            contextData.getStrategyManager().execute(object, rotateCommand);
        }
    }

    /**
     * This method checks the mouseEvent (fail early, fail fast)
     *
     * @param mouseEvent Description of parameter.
     *
     * @return Description of the returned value.
     */
    protected boolean checkCriteria(MouseEvent mouseEvent) {
        if (mouseEvent.getID() != MouseEvent.MOUSE_DRAGGED) {
            return false;
        }
        if (mouseEvent.isAltGraphDown()) {
            return false;
        }
        if ((mouseEvent.getModifiers() & MouseEvent.BUTTON3_MASK) != 0) {
            if (!mouseEvent.isShiftDown()) {
                return false;
            }
        }
        if ((mouseEvent.getModifiers() & MouseEvent.BUTTON1_MASK) != 0) {
            if (!mouseEvent.isControlDown()) {
                return false;
            }
        }
        return true;
    }
}
