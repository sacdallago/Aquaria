/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.annotation.visitors;

import java.util.Collection;
import java.util.Iterator;
import java.util.Vector;

import org.srs3d.viewer.annotation.objects.AnnotationContainer;
import org.srs3d.viewer.bioatlas.Parameter;
import org.srs3d.viewer.bioatlas.objects.Chain;
import org.srs3d.viewer.bioatlas.objects.ChainFragment;
import org.srs3d.viewer.bioatlas.objects.Residue;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.objects.ObjectContainer;
import org.srs3d.viewer.objects.visitors.AbstractVisitor;

/**
 * Inserts gaps between ChainFragments; notice atm this must be done before the final
 * segment placement is done
 *
 * @author Chrstian Zofka, LION bioscience AG
 *
 * @created September 3, 2001
 */
public class ChainFragmentCreator extends AbstractVisitor {
    private AnnotationContainer annotationContainer;
    private Vector referenceSequence;
    private Collection templateSequences;
    private Vector gapSizes = new Vector();

    /**
     * normally not used <code>ChainFragmentCreator</code> constructor.
     *
     * @param annotationContainer Description of parameter.
     */
    public ChainFragmentCreator(AnnotationContainer annotationContainer) {
        this.annotationContainer = annotationContainer;
    }

    /**
     * <code>ChainFragmentCreator</code> constructor.
     *
     * @param reference Description of parameter.
     * @param templates Description of parameter.
     */
    public ChainFragmentCreator(Vector reference, Collection templates) {
        referenceSequence = reference;
        templateSequences = templates;
    }

    /**
     * Description of the method.
     *
     * @param object Description of parameter.
     */
    public void visit(ObjectContainer object) {
        super.visit(object);
    }

    /**
     * Description of the method.
     *
     * @param object Description of parameter.
     */
    public void visit(AbstractObject object) {
        if (object instanceof Chain) {
            visit((Chain) object);
        }
        if (object instanceof ObjectContainer) {
            visit((ObjectContainer) object);
        }
    }

    /**
     * inserts the splitGaps for the reference and template chain
     *
     * @param chain reference chain
     */
    public void visit(Chain chain) {
        int[] gapPositions =
            computeSplitPositions(referenceSequence, chain, templateSequences);
        if (gapPositions.length > 0) {
            insertSplitGaps(referenceSequence, gapPositions);
            Vector templateSequence;
            Iterator iterator = templateSequences.iterator();
            while (iterator.hasNext()) {
                templateSequence = (Vector) iterator.next();
                insertSplitGaps(templateSequence, gapPositions);
            }
        }
    }

    /**
     * actually inserts the splitGaps (insterts null in the sequence)
     *
     * @param gapSequence sequence to insert the gaps; notice: the vector will be changed
     * @param gapPositions array of the split positions
     */
    private void insertSplitGaps(Vector gapSequence, int[] gapPositions) {

        // create standard splitGap
        Collection gap = new Vector();
        for (int i = 0; i < Parameter.fragmentGapInsertion; i++) {
            gap.add(null);
        }

        // insert the splitGap at every position
        for (int i = 0; i < gapPositions.length; i++) {

            // important: add the size of the previous inserted splitGaps to the index
            int index = gapPositions[i] + i * Parameter.fragmentGapInsertion;
            gapSequence.addAll(index, gap);
        }
    }

    /**
     * calculates the position of the fragment splits; regards the previous inserted gaps
     *
     * @param chain reference chain
     * @param gapSequence the corresponding gapSequence of the reference chain
     * @param templateSequences Description of parameter.
     *
     * @return array of the fragment split positions; array has size 0 if only one
     *         fragment is found
     */
    private static int[] computeSplitPositions(Vector gapSequence, Chain chain,
        Collection templateSequences) {
        Vector gapPositions = new Vector();
        Vector template = null;
        if (!templateSequences.isEmpty()) {
            template = (Vector) templateSequences.iterator().next();
        }
        int position;
        ChainFragment chainFragment;
        Residue residue;
        Residue residue1;
        Residue residue2;
        Iterator iterator = chain.getChainFragments().iterator();
        chainFragment = (ChainFragment) iterator.next();
        while (iterator.hasNext()) {
            chainFragment = (ChainFragment) iterator.next();
            residue = chainFragment.getInitialResidue();
            position = gapSequence.indexOf(residue);

            // correct the position if preluding gaps are allready inserted
            // :CHRISTIAN: check back condition
            while (position > 1 && gapSequence.get(position - 1) == null) {
                position--;
            }

            // :CHRISTIAN: check back condition
            if (template != null && position > 0) {
                residue1 = (Residue) template.elementAt(position - 1);
                residue2 = (Residue) template.elementAt(position);

                /**
                 * @todo optimize
                 */
                if (residue1 != null && residue1.getProceeding() == residue2) {
                    if (gapSequence.get(position) == null) {

                        // don't do anything
                        // because we have allready a gap in reference but the template is continous
                    } else {
                        gapPositions.add(new Integer(position));
                    }
                } else {
                    gapPositions.add(new Integer(position));
                }
            } else {
                gapPositions.add(new Integer(position));
            }
        }

        // transform vector -> array
        int[] gapArray = new int[gapPositions.size()];
        iterator = gapPositions.iterator();
        for (int i = 0; i < gapArray.length; i++) {
            gapArray[i] = ((Integer) iterator.next()).intValue();
        }
        return gapArray;
    }
}
