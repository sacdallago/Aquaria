/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.modules;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.Vector;

import javax.swing.JCheckBoxMenuItem;
import javax.vecmath.Color3f;
import javax.vecmath.Tuple3f;

import org.srs3d.viewer.annotation.objects.AnnotationContainer;
import org.srs3d.viewer.bioatlas.colorschemes.InterpolationColorScheme;
import org.srs3d.viewer.bioatlas.dispatcher.NavigateUpDispatcher;
import org.srs3d.viewer.bioatlas.filters.ChainIdFilter;
import org.srs3d.viewer.bioatlas.filters.ResidueFilter;
import org.srs3d.viewer.bioatlas.filters.SiteContentTypeFilter;
import org.srs3d.viewer.bioatlas.objects.Annotation;
import org.srs3d.viewer.bioatlas.objects.Chain;
import org.srs3d.viewer.bioatlas.objects.DbRef;
import org.srs3d.viewer.bioatlas.objects.Feature;
import org.srs3d.viewer.bioatlas.objects.Layer;
import org.srs3d.viewer.bioatlas.objects.Residue;
import org.srs3d.viewer.bioatlas.objects.Site;
import org.srs3d.viewer.j3d.ColorScheme;
import org.srs3d.viewer.j3d.Colorable;
import org.srs3d.viewer.j3d.Context;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.Linkable;
import org.srs3d.viewer.j3d.commands.ColorCommand;
import org.srs3d.viewer.j3d.objects.Link;
import org.srs3d.viewer.j3d.operations.ParameterStringOperation;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.objects.ObjectContainer;
import org.srs3d.viewer.objects.ObjectFilter;
import org.srs3d.viewer.objects.ObjectManager;
import org.srs3d.viewer.objects.Operation;
import org.srs3d.viewer.objects.filters.ObjectClassFilter;
import org.srs3d.viewer.objects.visitors.ObjectCollector;
import org.srs3d.viewer.util.ExceptionHandler;
import org.srs3d.viewer.util.Log;
import org.srs3d.viewer.util.SetUtility;

/**
 * @author Karsten Klein
 *
 * @created August 9, 2001
 */
public class AnnotationModule extends ProcessModule {
    private static final Log log = new Log(AnnotationModule.class);
    private Annotation annotation;
    private JCheckBoxMenuItem component = null;

    /**
     * <code>FeatureModule</code> constructor.
     *
     * @param name Description of parameter.
     * @param contextData Description of parameter.
     * @param annotation Description of parameter.
     */
    public AnnotationModule(String name, ContextData contextData,
        Annotation annotation) {
        super(name, contextData);
        this.annotation = annotation;
    }

    /**
     * Gets the <code>component</code> attribute of the <code>FeatureModule </code>
     * object.
     *
     * @return The <code>component</code> value.
     */
    public Component getComponent() {
        create();
        return component;
    }

    /**
     * Description of the method.
     *
     * @param e Description of parameter.
     */
    public void process(ActionEvent e) {
        Operation operation =
            new Operation(getContextData().getContext(), "TOGGLE_ACTIVATION",
                annotation);
        getContextData().getDispatcher().runDispatch(operation);
    }

    /**
     * Description of the method.
     */
    public void updateIntern() {
        super.updateIntern();
        try {
            if (component != null) {
                if (annotation.isEnabled()) {
                    component.setState(isActiveAnnotation(getContextData(),
                            annotation));
                }
            }
        } catch (Exception e) {
            ExceptionHandler.handleException(e, ExceptionHandler.SILENT_IN_DEBUG);
            if (component != null) {
                component.setState(false);
                component.setEnabled(false);
                component.setVisible(false);
            }
        }
    }

    /**
     * Description of the method.
     */
    public void cleanup() {
        super.cleanup();
        annotation = null;
        component = null;
    }

    /**
     * Description of the method.
     */
    private void create() {
        if (component == null) {
            component = new JCheckBoxMenuItem(getName(), true);
            component.addActionListener(this);
        }
    }

    /**
     * Gets the <code>activeAnnotation</code> attribute of the
     * <code>AnnotationModule</code> class.
     *
     * @param contextData Description of parameter.
     * @param annotation Description of parameter.
     *
     * @return The <code>activeAnnotation</code> value.
     */
    public static boolean isActiveAnnotation(ContextData contextData,
        Annotation annotation) {
        Iterator iterator = annotation.getFeatures().iterator();
        while (iterator.hasNext()) {
            if (contextData.getSelectionManager().hasSelection(iterator.next())) {
                return true;
            }
        }
        return false;
    }

    /**
     * Gets the <code>attributeString</code> attribute of the
     * <code>AnnotationModule</code> class.
     *
     * @param string Description of parameter.
     *
     * @return The <code>attributeString</code> value.
     */
    public static String getAttributeString(String string) {
        int index = string.indexOf('{');
        if (index != -1) {
            string = string.substring(0, index);
        } else {
            index = string.indexOf('}');
            if (index != -1) {
                string = string.substring(0, index);
            }
        }
        return string;
    }

    /**
     * Parses the specified string for the next block marked by {...} and returns this
     * block including the parenthesis.
     *
     * @param string Description of parameter.
     *
     * @return The <code>nextBlock</code> value.
     */
    public static String getNextBlock(String string) {
        try {
            int startIndex = -1;
            int stopIndex = -1;
            int openBracketCount = -1;
            char c;
            int index = 0;
            while (openBracketCount != 0) {
                c = string.charAt(index);
                if (c == '{') {
                    if (openBracketCount == -1) {
                        openBracketCount = 1;
                        startIndex = index;
                    } else {
                        openBracketCount++;
                    }
                } else if (c == '}') {
                    if (openBracketCount > 0) {
                        openBracketCount--;
                        if (openBracketCount == 0) {
                            stopIndex = index;
                        }
                    } else {
                        log.debug("parsing error: unexpected '}'.");
                    }
                }
                index++;
            }
            String block = "";
            if (startIndex < stopIndex && stopIndex != -1) {
                block = string.substring(startIndex, stopIndex + 1);
            }
            return block;
        } catch (Exception e) {
            ExceptionHandler.handleException(e, ExceptionHandler.SILENT_IN_DEBUG);
        }
        return null;
    }

    /**
     * Gets the <code>annotations</code> attribute of the <code>AnnotationModule</code>
     * class.
     *
     * @param contextData Description of parameter.
     * @param annotations Description of parameter.
     */
    public static void getAnnotations(ContextData contextData,
        Collection annotations) {
        ObjectManager.extract(contextData.getObjectContainer().getObjects(),
            annotations, Annotation.class);
    }

    /**
     * Gets the <code>activeAnnotations</code> attribute of the
     * <code>AnnotationModule</code> class.
     *
     * @param contextData Description of parameter.
     * @param annotations Description of parameter.
     */
    public static void getActiveAnnotations(ContextData contextData,
        Collection annotations) {
        ObjectManager.extract(contextData.getObjectContainer().getObjects(),
            annotations, Annotation.class);
        Iterator iterator = annotations.iterator();
        while (iterator.hasNext()) {
            if (!isActiveAnnotation(contextData, (Annotation) iterator.next())) {
                iterator.remove();
            }
        }
    }

    /**
     * Description of the method.
     *
     * @param object Description of parameter.
     * @param chainId Description of parameter.
     * @param residueId Description of parameter.
     * @param residueICode Description of parameter.
     *
     * @return Description of the returned value.
     */
    public static Residue mapResidue(AbstractObject object, char chainId,
        int residueId, char residueICode) {
        Residue residue = null;

        // filter all chains with the specific chain id
        ObjectFilter chainFilter = new ChainIdFilter(chainId);
        ObjectCollector chainCollector = new ObjectCollector(chainFilter);
        chainCollector.visit(object);
        if (!chainCollector.getObjects().isEmpty()) {

            // filter all residues
            ResidueFilter residueFilter =
                new ResidueFilter(null, residueId, residueICode);
            ObjectCollector residueCollector =
                new ObjectCollector(residueFilter);
            residueCollector.setMode(ObjectCollector.COLLECT_ONE);
            residueCollector.visit(chainCollector.getObjects());
            if (residueCollector.getObjects().size() == 1) {

                // read the residue
                residue =
                    (Residue) residueCollector.getObjects().iterator().next();
            }
        }
        return residue;
    }

    /**
     * Description of the method.
     *
     * @param attributes Description of parameter.
     *
     * @return Description of the returned value.
     */
    public static Color3f createColor(String attributes) {
        Color3f color = new Color3f();
        readTuple(attributes, color);
        return color;
    }

    /**
     * Method description.
     *
     * @param attributes Parameter description.
     * @param tuple Parameter description.
     */
    public static void readTuple(String attributes, Tuple3f tuple) {
        attributes = insertToken(attributes, ":", "0");
        StringTokenizer tokenizer = new StringTokenizer(attributes, ":");
        if (tokenizer.countTokens() == 3) {
            tuple.x = Float.parseFloat(tokenizer.nextToken());
            tuple.y = Float.parseFloat(tokenizer.nextToken());
            tuple.z = Float.parseFloat(tokenizer.nextToken());
        } else {
            log.debug("number of attributes incorrect: '" + attributes + "'.");
        }
    }

    /**
     * Description of the method.
     *
     * @param object Description of parameter.
     * @param attributes Description of parameter.
     *
     * @return Description of the returned value.
     */
    public static Collection collectResidues(AbstractObject object,
        String attributes) {
        Collection objects = new HashSet();
        attributes = insertToken(attributes, ":", " ");
        StringTokenizer tokenizer = new StringTokenizer(attributes, ":");
        if (tokenizer.countTokens() == 5 || tokenizer.countTokens() == 2) {
            boolean isSequenceRange = tokenizer.countTokens() == 2;
            String token;
            char chainId;
            int serial;
            char iCode = ' ';
            if (isSequenceRange) {
                chainId = Chain.INVALID_ID;
                iCode = ' ';
            } else {
                token = tokenizer.nextToken();

                // read the chain identifier
                token = decode(token);
                chainId = token.charAt(token.length() - 1);
            }
            serial = Integer.parseInt(tokenizer.nextToken().trim());
            if (!isSequenceRange) {
                iCode = decode(tokenizer.nextToken()).charAt(0);
            }

            // read start residue
            Residue start = mapResidue(object, chainId, serial, iCode);
            if (start != null) {
                serial = Integer.parseInt(tokenizer.nextToken().trim());
                if (!isSequenceRange) {
                    iCode = decode(tokenizer.nextToken()).charAt(0);
                }

                // read end residue
                Residue end = mapResidue(object, chainId, serial, iCode);
                if (end != null) {
                    objects.add(start);
                    objects.add(end);
                    if (start != end) {
                        Residue residue = start.getProceeding();
                        Residue limit = end;
                        while (residue != null && residue != limit) {
                            mapResidue(object, chainId, residue.getId(),
                                residue.getICode());
                            objects.add(residue);
                            residue = residue.getProceeding();
                        }
                    }
                } else {
                    log.error("feature end residue was not found.");
                }
            } else {
                log.error("feature start residue was not found!");
            }
        } else {
            log.error("number of range attributes incorrect: '" + attributes +
                "'.");
        }
        if (objects.isEmpty()) {
            log.error("error in feature attributes: '" + attributes + "'.");
        }
        return objects;
    }

    /**
     * Creates a feature from a feature attributes string.
     *
     * @param object Object that contains the feature objects as subset.
     * @param attributes String representing the feature.
     * @param color Description of parameter.
     *
     * @return Newly created feature; <code>null</code> if an error occurred.
     */
    public static Feature createFeature(AbstractObject object,
        String attributes, Color3f color) {
        attributes = insertToken(attributes, ",", " ");
        StringTokenizer tokenizer = new StringTokenizer(attributes, ",");
        if (tokenizer.countTokens() == 5) {
            Feature feature = new Feature();
            feature.setName(decode(tokenizer.nextToken()));
            String colorString = tokenizer.nextToken();
            if (colorString.trim().length() > 0) {
                feature.setColor(createColor(colorString));
            } else {
                if (color != null) {
                    feature.setColor(color);
                }
            }
            feature.setDescription(decode(tokenizer.nextToken()));
            Link link = new Link();
            link.setLinks(decode(tokenizer.nextToken()));
            feature.setLink(link);
            String residueRange = tokenizer.nextToken();
            Collection objects = collectResidues(object, residueRange);
            if (!objects.isEmpty()) {
                feature.addObjects(objects);
                return feature;
            }
        } else {
            log.error("number of feature attributes incorrect: '" + attributes +
                "'.");
        }
        return null;
    }

    /**
     * Creates a set of features from a feature attribute list in String format.
     *
     * @param object Object that contains all the feature objects as subset.
     * @param attributes Feature attribute list.
     * @param color Description of parameter.
     *
     * @return Collection of created features.
     */
    public static Collection createFeatures(AbstractObject object,
        String attributes, Color3f color) {
        Collection features = new Vector();
        attributes = insertToken(attributes, ";", " ");
        StringTokenizer tokenizer = new StringTokenizer(attributes, ";");
        Feature feature;
        String token;
        while (tokenizer.hasMoreTokens()) {
            token = tokenizer.nextToken().trim();
            if (token.length() > 0) {
                feature = createFeature(object, token, color);
                if (feature != null) {
                    features.add(feature);
                }
            }
        }
        return features;
    }

    /**
     * Creates an Annotation object from an annotation attribute string and a feature
     * list string.
     *
     * @param object Object that contains all the annotation objects as subset.
     * @param attributes Attributes string of the feature.
     * @param string Feature attribute list.
     * @param activeFeatures Set of activated features.
     *
     * @return Newly created Annotation object; <code>null</code> if errors occured.
     */
    public static Annotation createAnnotation(AbstractObject object,
        String attributes, String string, Collection activeFeatures,
        InterpolationColorScheme colorScheme) {
        attributes = insertToken(attributes, ",", " ");
        StringTokenizer tokenizer = new StringTokenizer(attributes, ",");
        if (tokenizer.countTokens() == 6) {
            Annotation annotation = new Annotation();
            annotation.setName(decode(tokenizer.nextToken()));
            String colorString = tokenizer.nextToken();
            Color3f color = null;
            if (colorString.trim().length() > 0) {
                color = createColor(colorString);
                annotation.setColor(color);
            } else {
                annotation.setColor(new Color3f(0.6f, 0.6f, 0.6f));
            }
            String activationString = decode(tokenizer.nextToken());
            annotation.setDescription(decode(tokenizer.nextToken()));
            Link link = new Link();
            link.addLink("HTML", decode(tokenizer.nextToken()));
            annotation.setLink(link);
            String flags = tokenizer.nextToken().toLowerCase();
            boolean mustColorFeatures = flags.indexOf("color") != -1;

            // parse features
            Collection features = createFeatures(object, string, color);
            if (!features.isEmpty()) {
                if (mustColorFeatures) {
                    Iterator iterator = features.iterator();
                    Feature feature;
                    while (iterator.hasNext()) {
                        feature = (Feature) iterator.next();
                        colorScheme.register(feature);
                        feature.setColor(colorScheme.computeColor(feature));
                    }
                }
                annotation.addAllFeatures(features);
                if (activationString.trim().equalsIgnoreCase("on")) {
                    activeFeatures.addAll(features);
                }
                return annotation;
            }
        } else {
            log.error("not enough attribute tokens in '" + attributes + "'.");
        }
        return null;
    }

    /**
     * Creates a collection of annotations for a specified layer/chain object.
     *
     * @param object The object to create the annotations for.
     * @param string Annotations string.
     * @param activeFeatures Description of parameter.
     *
     * @return Description of the returned value.
     */
    public static Collection createAnnotations(AbstractObject object,
        String string, Collection activeFeatures,
        InterpolationColorScheme colorScheme) {
        Collection annotations = new Vector();
        String attributes;
        String content;
        Annotation annotation;
        boolean endOfAnnotations = false;
        while (!endOfAnnotations && string.length() > 0) {

            // parse layer id
            attributes = getAttributeString(string);
            if (attributes.trim().length() > 0) {
                content = getNextBlock(string);
                if (content.length() != 0) {
                    string =
                        string.substring(attributes.length() +
                            content.length()).trim();
                    attributes = attributes.trim();
                    content = content.substring(1, content.length() - 1);
                    annotation =
                        createAnnotation(object, attributes, content,
                            activeFeatures, colorScheme);
                    if (annotation != null) {
                        annotations.add(annotation);
                    }
                } else {
                    endOfAnnotations = true;
                }
            } else {
                log.error("no annotation attributes found.");
                endOfAnnotations = true;
            }
        }
        return annotations;
    }

    /**
     * Creates annotations from a layer annotation string.
     *
     * @param string Layer annotation string.
     * @param activeFeatures Features that are active.
     * @param idMap Map for identifying layer-ids with layers and chains.
     *
     * @return Collection of annotations.
     */
    public static Collection createAnnotations(String string,
        Collection activeFeatures, Map idMap) {
        InterpolationColorScheme colorScheme =
            new InterpolationColorScheme(null);
        Collection annotations = new Vector();
        int index;
        int maxIndex;
        String attributes;
        String content;
        AbstractObject object;
        boolean endOfLayers = false;
        while (!endOfLayers && string.length() > 0) {

            // parse layer id
            attributes = getAttributeString(string);
            if (attributes.trim().length() > 0) {
                content = getNextBlock(string);
                if (content != null && content.length() != 0) {
                    string =
                        string.substring(attributes.length() +
                            content.length()).trim();
                    attributes = decode(attributes).trim();
                    content = content.substring(1, content.length() - 1);
                    object = (AbstractObject) idMap.get(attributes);
                    if (object != null) {
                        annotations.addAll(createAnnotations(object, content,
                                activeFeatures, colorScheme));
                    } else {
                        Iterator iterator = idMap.keySet().iterator();
                        String id;
                        String originalId;
                        int found = 0;
                        Collection localAnnotations = new Vector();
                        while (iterator.hasNext()) {
                            id = (String) iterator.next();

                            // cut away last character
                            originalId = id.substring(0, id.length() - 1);
                            if (attributes.equals(originalId)) {
                                object = (AbstractObject) idMap.get(id);
                                if (object != null) {
                                    localAnnotations.addAll(createAnnotations(
                                            object, content, activeFeatures,
                                            colorScheme));
                                    found++;
                                }
                            }
                        }
                        if (found == 0) {
                            log.error("object with id '" + attributes +
                                "' not present.");
                        } else {
                            if (found > 1) {
                                annotations.addAll(mergeAnnotationsByName(
                                        localAnnotations));
                            } else {
                                annotations.addAll(localAnnotations);
                            }
                        }
                    }
                } else {
                    endOfLayers = true;
                }
            } else {
                log.error("no layer id found.");
                endOfLayers = true;
            }
        }
        return annotations;
    }

    /**
     * Merges annotations of the same name.
     *
     * @param annotations Description of parameter.
     *
     * @return Description of the returned value.
     */
    public static Collection mergeAnnotationsByName(Collection annotations) {
        Collection finalAnnotations = new Vector();
        Collection annotationGroup = new Vector();
        Collection openAnnotations = new Vector(annotations);
        Iterator iterator = openAnnotations.iterator();
        Annotation referenceAnnotation;
        Annotation annotation;
        while (iterator.hasNext()) {
            referenceAnnotation = (Annotation) iterator.next();
            iterator.remove();
            annotationGroup.add(referenceAnnotation);
            while (iterator.hasNext()) {
                annotation = (Annotation) iterator.next();
                if (annotation.getName().equals(referenceAnnotation.getName())) {
                    annotationGroup.add(annotation);
                    iterator.remove();
                }
            }
            if (annotationGroup.size() > 1) {
                annotation = mergeAnnotations(annotationGroup);
                if (annotation != null) {
                    finalAnnotations.add(annotation);
                }
            } else {
                finalAnnotations.add(referenceAnnotation);
            }
            annotationGroup.clear();
            iterator = openAnnotations.iterator();
        }
        return finalAnnotations;
    }

    /**
     * Merges all specified annotations to one single annotation.
     *
     * @param annotations Description of parameter.
     *
     * @return Description of the returned value.
     */
    public static Annotation mergeAnnotations(Collection annotations) {
        log.info("merging annotations " + annotations);
        if (!annotations.isEmpty()) {
            Annotation composedAnnotation = new Annotation();
            Iterator iterator = annotations.iterator();
            Annotation annotation;
            boolean isInitialized = false;
            while (iterator.hasNext()) {
                annotation = (Annotation) iterator.next();
                if (!isInitialized) {
                    composedAnnotation.setName(annotation.getName());
                    composedAnnotation.setColor(annotation.getColor());
                    composedAnnotation.setDescription(annotation.getDescription());
                }
                composedAnnotation.addAllFeatures(annotation.getFeatures());
            }
            return composedAnnotation;
        }
        return null;
    }

    /**
     * Replaces all occurences of %xx with the appropriate character. "This %41 is
     * an%20A" --> "This A is an A"
     *
     * @param string Description of parameter.
     *
     * @return Description of the returned value.
     */
    public static String decode(String string) {
        String decoded = "";
        String encoded;
        int index;
        char c;
        while ((index = string.indexOf('%')) != -1) {
            decoded += string.substring(0, index);
            encoded = "#" + string.substring(index + 1, index + 3);
            string = string.substring(index + 3);
            c = (char) Byte.decode(encoded).byteValue();
            decoded += c;
        }
        decoded += string;
        return decoded;
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     * @param annotations Description of parameter.
     * @param features Description of parameter.
     * @param activeFeatures Description of parameter.
     * @param isSpawning Description of parameter.
     */
    public static void finalizeAnnotations(final ContextData contextData,
        Collection annotations, Collection features, Collection activeFeatures,
        boolean isSpawning) {

        // collect all features (from container)
        ObjectCollector objectCollector =
            new ObjectCollector(new org.srs3d.viewer.objects.filters.ObjectClassFilter(
                    Feature.class));
        objectCollector.visit(annotations);

        // expand all associated subchains
        // collect all objects that represent the features
        Iterator iterator = objectCollector.getObjects().iterator();
        Feature feature;
        Collection residues = new Vector();
        while (iterator.hasNext()) {
            feature = (Feature) iterator.next();
            if (activeFeatures.contains(feature)) {
                residues.addAll(feature.getObjects());
            }

            // add missing features to feature list
            if (!features.contains(feature)) {
                features.add(feature);
            }
        }

        // deactivate features
        Collection inactiveFeatures = new HashSet(features);
        inactiveFeatures.removeAll(activeFeatures);
        FeatureModule.deactivateFeatures(contextData, inactiveFeatures);
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     * @param annotationContext Description of parameter.
     * @param activeFeatures Description of parameter.
     */
    public static void fullAnnotationActivation(ContextData contextData,
        Context annotationContext, Collection activeFeatures) {
        HashSet annotations = new HashSet();
        getAnnotations(contextData, annotations);
        Iterator iterator = annotations.iterator();
        Annotation annotation;
        while (iterator.hasNext()) {
            annotation = (Annotation) iterator.next();
            if (SetUtility.hasIntersection(annotation.getFeatures(),
                      activeFeatures)) {
                Operation operation =
                    new Operation(contextData.getContext(),
                        "TOGGLE_ACTIVATION", annotation);
                contextData.getDispatcher().runDispatch(operation);
            }
        }
    }

    /**
     * Description of the method.
     *
     * @param objects Description of parameter.
     * @param annotationContainer Description of parameter.
     */
    public static void extendAnnotations(Collection objects,
        AnnotationContainer annotationContainer) {
        ObjectCollector objectCollector =
            new ObjectCollector(new org.srs3d.viewer.objects.filters.ObjectClassFilter(
                    Feature.class));
        objectCollector.visit(objects);
        Iterator iterator = objectCollector.getObjects().iterator();
        Feature feature;
        while (iterator.hasNext()) {
            feature = (Feature) iterator.next();
            extendFeature(feature, annotationContainer);
        }
    }

    /**
     * Description of the method.
     *
     * @param feature Description of parameter.
     * @param annotationContainer Description of parameter.
     */
    public static void extendFeature(Feature feature,
        AnnotationContainer annotationContainer) {
        Collection residues = new HashSet();
        ObjectManager.extract(feature.getObjects(), residues, Residue.class);
        Iterator iterator = residues.iterator();
        Residue residue;
        Collection alignedResidues;
        while (iterator.hasNext()) {
            residue = (Residue) iterator.next();
            alignedResidues = annotationContainer.mapResidues(residue);
            if (alignedResidues != null) {
                feature.getObjects().addAll(alignedResidues);
            }
        }
    }

    /**
     * Inserts the token in between .
     *
     * @param string Description of parameter.
     * @param delimiter Description of parameter.
     * @param token Description of parameter.
     *
     * @return Description of the returned value.
     */
    public static String insertToken(String string, String delimiter,
        String token) {
        String inserted = "";
        String doubleDelimiter = delimiter + delimiter;
        int index;
        while ((index = string.indexOf(doubleDelimiter)) != -1) {
            inserted += string.substring(0, index);
            inserted += delimiter + token;
            string = string.substring(index + delimiter.length());
        }
        inserted += string;
        if (inserted.indexOf(delimiter) == 0) {
            inserted = token + inserted;
        }
        if (inserted.lastIndexOf(delimiter) == inserted.length() -
              delimiter.length()) {
            inserted += token;
        }
        return inserted;
    }

    /**
     * Description of the method.
     *
     * @param layer Description of parameter.
     */
    public static void convertSitesToAnnotations(Layer layer,
        Collection annotations) {
        Map contentAnnotationMap = new HashMap();
        ObjectCollector preCollector =
            new ObjectCollector(new ObjectClassFilter(Site.class));
        preCollector.visit((AbstractObject) layer);

        // we specify the ordering the site annotations appear in
        Collection sites = new Vector();
        SiteContentTypeFilter filter =
            new SiteContentTypeFilter(Site.UNSPECIFIED_CONTENT);
        ObjectCollector objectCollector = new ObjectCollector(filter);
        objectCollector.setObjects(sites);
        objectCollector.visit(preCollector.getObjects());
        filter.setSiteContentType(Site.EXCEPTIONAL_RESIDUES);
        objectCollector.visit(preCollector.getObjects());
        filter.setSiteContentType(Site.ACTIVE_SITE);
        objectCollector.visit(preCollector.getObjects());
        filter.setSiteContentType(Site.DISULFIDEBOND_RESIDUES);
        objectCollector.visit(preCollector.getObjects());
        Iterator iterator = sites.iterator();
        Site site;
        Annotation annotation;
        while (iterator.hasNext()) {
            site = (Site) iterator.next();
            if (site.getResidues().size() > 0) {
                annotation =
                    (Annotation) contentAnnotationMap.get(new Integer(
                            site.getContentType()));
                if (annotation == null) {
                    annotation = new Annotation();
                    contentAnnotationMap.put(new Integer(site.getContentType()),
                        annotation);
                    annotations.add(annotation);
                }
                Feature feature = new Feature();
                if (site.getContentType() == Site.ACTIVE_SITE) {
                    annotation.setName("Site_" + site.getName());
                    annotation.setDescription("(PDB)");
                    annotation.setColor(new Color3f(1.0f, 0.0f, 0.0f));
                    feature.setName(site.getName());
                    contentAnnotationMap.remove(new Integer(
                            site.getContentType()));
                } else if (site.getContentType() == Site.DISULFIDEBOND_RESIDUES) {
                    annotation.setName("Disulfide");
                    annotation.setDescription("(computed)");
                    annotation.setColor(new Color3f(1.0f, 1.0f, 0.0f));
                    feature.setName("bridge");
                } else {
                    annotation.setName(site.getName());
                    annotation.setDescription("(detected during parsing)");
                    annotation.setColor(new Color3f(1.0f, 0.6f, 0.6f));
                    feature.setName("exception");
                }
                Iterator siteIterator = site.getResidues().iterator();
                String description = "";
                while (siteIterator.hasNext()) {
                    description += siteIterator.next().toString();
                    if (siteIterator.hasNext()) {
                        description += '-';
                    }
                }
                feature.setDescription(description);
                feature.getObjects().addAll(site.getResidues());
                annotation.addFeature(feature);
                annotation.sortFeatures();
                feature.setColor(annotation.getColor());
            }
        }
    }

    /**
     * Description of the method.
     *
     * @param objectContainer Description of parameter.
     */
    public static void convertChainDbRefsToAnnotations(
        ObjectContainer objectContainer, Collection linkedDatabases) {
        ObjectCollector objectCollector =
            new ObjectCollector(new ObjectClassFilter(Chain.class));
        objectCollector.visit((AbstractObject) objectContainer);
        Iterator iterator = objectCollector.getObjects().iterator();
        Chain chain;
        Annotation annotation = null;
        if (iterator.hasNext()) {
            annotation = new Annotation();
            annotation.setName("Chain Links");
            annotation.setColor(new Color3f(1, 1, 1));
            annotation.setEnabled(false);
        }
        DbRef dbRef;
        Collection dbRefs;
        while (iterator.hasNext()) {
            chain = (Chain) iterator.next();
            dbRefs = chain.getDbRefs();
            if (dbRefs != null) {
                Iterator dbRefIterator = dbRefs.iterator();
                while (dbRefIterator.hasNext()) {
                    dbRef = (DbRef) dbRefIterator.next();
                    if (linkedDatabases.contains(dbRef.getDbId())) {
                        Feature feature = new Feature();
                        feature.setName(chain.toString());
                        feature.setDescription(dbRef.getDbId() + ":" +
                            dbRef.getDbAccession());
                        feature.getObjects().add(chain);
                        feature.setColor(new Color3f(1, 1, 1));
                        org.srs3d.viewer.j3d.objects.Link link =
                            new org.srs3d.viewer.j3d.objects.Link();
                        link.addLink(dbRef.getDbId(), dbRef.getDbAccession());
                        feature.setLink(link);
                        annotation.addFeature(feature);
                    }
                }
            }
        }
        if (annotation != null) {
            if (!annotation.getFeatures().isEmpty()) {
                annotation.sortFeatures();
                objectContainer.addObject(annotation);
            }
        }
    }

    /**
     * Description of the method.
     *
     * @param objectContainer Description of parameter.
     */
    public static void convertLinkablesToAnnotations(
        ObjectContainer objectContainer) {
        ObjectCollector objectCollector =
            new ObjectCollector(new ObjectClassFilter(Linkable.class));
        objectCollector.visit((AbstractObject) objectContainer);

        // layers and chains are excluded
        ObjectManager.filter(objectCollector.getObjects(), Layer.class);
        ObjectManager.filter(objectCollector.getObjects(), Chain.class);
        Iterator iterator = objectCollector.getObjects().iterator();
        Linkable linkable;
        Annotation annotation = null;
        if (iterator.hasNext()) {
            annotation = new Annotation();
            annotation.setName("Links");
            annotation.setColor(new Color3f(1, 1, 1));
        }
        while (iterator.hasNext()) {
            linkable = (Linkable) iterator.next();
            org.srs3d.viewer.j3d.objects.Link link = linkable.getLink();
            if (link != null) {
                Feature feature = new Feature();
                feature.setName(linkable.toString());
                feature.setDescription(link.toString());
                feature.getObjects().add(linkable);
                feature.setColor(new Color3f(1, 1, 1));
                feature.setLink(link);
                annotation.addFeature(feature);
            }
        }
        if (annotation != null) {
            annotation.sortFeatures();
            objectContainer.addObject(annotation);
        }
    }

    /**
     * Description of the method.
     *
     * @param objectContainer Description of parameter.
     */
    public static void convertLinksToAnnotations(
        ObjectContainer objectContainer) {
        ObjectCollector objectCollector =
            new ObjectCollector(new ObjectClassFilter(
                    org.srs3d.viewer.j3d.objects.Link.class));
        objectCollector.visit((AbstractObject) objectContainer);
        Iterator iterator = objectCollector.getObjects().iterator();
        org.srs3d.viewer.j3d.objects.Link link;
        Annotation annotation = null;
        if (iterator.hasNext()) {
            annotation = new Annotation();
            annotation.setName("Links");
            annotation.setColor(new Color3f(1, 1, 1));
        }
        while (iterator.hasNext()) {
            link = (org.srs3d.viewer.j3d.objects.Link) iterator.next();
            Feature feature = new Feature();
            feature.setName(link.toString());
            feature.getObjects().addAll(link.getObjects());
            HashSet colorables = new HashSet(link.getObjects());
            ObjectManager.extract(colorables, Colorable.class);
            if (colorables.size() > 1) {
                feature.setColor(new Color3f(1, 1, 1));
            } else {
                feature.setColor(((Colorable) colorables.iterator().next()).getColor());
            }
            feature.setLink(link);
            annotation.addFeature(feature);
        }
        if (annotation != null) {
            annotation.sortFeatures();
            objectContainer.addObject(annotation);
        }
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     * @param annotationString Parameter description.
     *
     * @return Return description.
     */
    public static Operation createLoadOperation(ContextData contextData,
        String annotationString) {
        ParameterStringOperation operation =
            new ParameterStringOperation(contextData.getContext(),
                "LOAD_ANNOTATION", annotationString, null);
        return operation;
    }

    /**
     * Method description.
     *
     * @param annotationString Parameter description.
     */
    public void loadAnnotation(String annotationString) {
        NavigateUpDispatcher.updateDescription(getContextData(),
            "Loading annotation...");
        getContextData().getContext().addUpdateCallback(null);

        //    Thread.currentThread().yield();
        Collection annotations =
            (Collection) getContextData().getProperty("ANNOTATIONS");
        Collection activeFeatures =
            (Collection) getContextData().getProperty("ACTIVE_FEATURES");
        Map idMap = (Map) getContextData().getProperty("LAYER_IDMAP");
        annotations.addAll(AnnotationModule.createAnnotations(
                annotationString, activeFeatures, idMap));
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     */
    public static void collapseAnnotations(ContextData contextData) {
        Collection annotations =
            (Collection) contextData.getProperty("ANNOTATIONS");
        if (annotations != null) {
            ObjectCollector objectCollector =
                new ObjectCollector(new org.srs3d.viewer.objects.filters.ObjectClassFilter(
                        Feature.class));
            objectCollector.visit(annotations);
            Iterator iterator = objectCollector.getObjects().iterator();
            Feature feature;
            while (iterator.hasNext()) {
                feature = (Feature) iterator.next();
                collapseFeature(contextData, feature);
            }
        }
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     * @param feature Parameter description.
     */
    public static void collapseFeature(ContextData contextData, Feature feature) {

        // collapse feature objects
        HashSet set = new HashSet();
        contextData.getObjectManager().collapseUpExtended(feature.getObjects(),
            set);
        feature.getObjects().clear();
        feature.getObjects().addAll(set);
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     */
    public static void preprocessAnnotations(ContextData contextData) {
        NavigateUpDispatcher.updateDescription(contextData,
            "Processing annotation...");
        contextData.getContext().addUpdateCallback(null);

        //    Thread.currentThread().yield();
        Collection annotations =
            (Collection) contextData.getProperty("ANNOTATIONS");
        Collection features = (Collection) contextData.getProperty("FEATURES");
        Collection linkedDatabases =
            (Collection) contextData.getProperty("LINKED_DATABASES");
        Collection activeFeatures =
            (Collection) contextData.getProperty("ACTIVE_FEATURES");
        AnnotationModule.finalizeAnnotations(contextData, annotations,
            features, activeFeatures, false);
        ColorCommand colorCommand =
            new ColorCommand(contextData, (ColorScheme) null);
        contextData.getStrategyManager().execute(annotations, colorCommand);
        contextData.getObjectContainer().addAll(annotations);

        // those annotation should not appear in the annotation view
        AnnotationModule.convertChainDbRefsToAnnotations(contextData.getObjectContainer(),
            linkedDatabases);
        AnnotationModule.convertLinkablesToAnnotations(contextData.getObjectContainer());
        NavigateUpDispatcher.updateDescription(contextData, "Visualizing...");
        contextData.getContext().addUpdateCallback(null);
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public boolean checkVisible() {
        if (annotation.isEnabled()) {
            return super.checkVisible();
        } else {
            return false;
        }
    }
}
