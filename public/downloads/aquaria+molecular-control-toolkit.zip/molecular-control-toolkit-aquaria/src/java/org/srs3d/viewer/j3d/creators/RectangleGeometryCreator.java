/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.creators;

import javax.media.j3d.Appearance;
import javax.media.j3d.BranchGroup;
import javax.media.j3d.LineArray;
import javax.media.j3d.PolygonAttributes;
import javax.media.j3d.Shape3D;
import javax.vecmath.Color3f;
import javax.vecmath.Point3f;
import javax.vecmath.Vector3f;

import org.srs3d.viewer.j3d.AppearanceHelper;
import org.srs3d.viewer.j3d.ShapeManager;
import org.srs3d.viewer.j3d.geometry.GeometryHelper;
import org.srs3d.viewer.j3d.geometry.primitive.Line;
import org.srs3d.viewer.j3d.geometry.primitive.Quad;
import org.srs3d.viewer.j3d.objects.Rectangle;
import org.srs3d.viewer.objects.AbstractObject;

/**
 * Description of the class.
 *
 * @author Karsten Klein
 *
 * @created March 20, 2001
 */
public class RectangleGeometryCreator extends AbstractGeometryCreator {

    /** Description of the Field */
    public static int GEOMETRY = 1;

    /** Description of the field. */
    public static int RECTANGLE_QUAD = 2;

    /** Description of the Field */
    public int type = RECTANGLE_QUAD | GEOMETRY;

    /**
     * Creates the description (subscenegraph) of an <code>AbstractObject</code>
     *
     * @param object object to display. Only <code>Rectangle</code> instances will be
     *        processed.
     * @param branchGroup root for the created subscenegraph.
     */
    public void create(AbstractObject object, BranchGroup branchGroup) {
        if (object instanceof Rectangle) {
            create((Rectangle) object, branchGroup);
        }
    }

    /**
     * Creates the representation of the <code>Rectangle</code> object.
     *
     * @param rectangle <code>Rectangle</code> to display.
     * @param branchGroup root for the created subscenegraph.
     */
    public void create(Rectangle rectangle, BranchGroup branchGroup) {
        if ((type & GEOMETRY) != 0) {
            createGeometry(rectangle, branchGroup);
        }
        if ((type & RECTANGLE_QUAD) != 0) {
            createQuadGeometry(rectangle, branchGroup);
        }
    }

    /**
     * Greates the geometry in <code>GEOMETRY</code> mode of the <code>Rectangle
     * </code>object.
     *
     * @param rectangle <code>Rectangle</code> to display.
     * @param branchGroup root for the created subscenegraph.
     */
    public void createGeometry(Rectangle rectangle, BranchGroup branchGroup) {
        float x = rectangle.getCoordinate().x;
        float y = rectangle.getCoordinate().y;
        float z = rectangle.getCoordinate().z;
        float width = rectangle.getWidth();
        float height = rectangle.getHeight();
        float minimumExtend = rectangle.getMinimumExtend();
        float leftX = x - 0.5f * width;
        float topY = y - 0.5f * height;
        float rightX = x + 0.5f * width;
        float bottomY = y + 0.5f * height;
        int count = 4;
        if (width / 2 < minimumExtend) {
            count += 2;
        }
        if (height / 2 < minimumExtend) {
            count += 2;
        }
        int index = 0;
        LineArray lineArray = GeometryHelper.getDefaultLineArray(count, 0);
        Line line = new Line();
        line.getCoordinates().set(new Point3f(leftX, topY, z),
            new Point3f(rightX, topY, z));
        line.insertInto(index++, lineArray);
        line.getCoordinates().set(new Point3f(leftX, bottomY, z),
            new Point3f(rightX, bottomY, z));
        line.insertInto(index++, lineArray);
        line.getCoordinates().set(new Point3f(leftX, topY, z),
            new Point3f(leftX, bottomY, z));
        line.insertInto(index++, lineArray);
        line.getCoordinates().set(new Point3f(rightX, topY, z),
            new Point3f(rightX, bottomY, z));
        line.insertInto(index++, lineArray);

        // additional lines:
        if (width / 2 < minimumExtend) {
            line.getCoordinates().set(new Point3f(x - minimumExtend, y, z),
                new Point3f(leftX, y, z));
            line.insertInto(index++, lineArray);
            line.getCoordinates().set(new Point3f(x + minimumExtend, y, z),
                new Point3f(rightX, y, z));
            line.insertInto(index++, lineArray);
        }
        if (height / 2 < minimumExtend) {
            line.getCoordinates().set(new Point3f(x, y - minimumExtend, z),
                new Point3f(x, topY, z));
            line.insertInto(index++, lineArray);
            line.getCoordinates().set(new Point3f(x, y + minimumExtend, z),
                new Point3f(x, bottomY, z));
            line.insertInto(index++, lineArray);
        }
        Shape3D shape = new Shape3D(lineArray);
        ShapeManager.setCapabilities(shape, rectangle);
        getContextData().getShapeManager().register(rectangle, shape);
        Appearance appearance =
            AppearanceHelper.createAppearance(new Color3f(0.3f, 0.3f, 0.3f));
        AppearanceHelper.enableVertexColors(appearance, true);
        shape.setAppearance(appearance);
        shape.clearCapability(Shape3D.ALLOW_APPEARANCE_WRITE);

        // modify capabilities
        lineArray.setCapability(LineArray.ALLOW_COORDINATE_READ);
        lineArray.setCapability(LineArray.ALLOW_COORDINATE_WRITE);
        branchGroup.addChild(shape);
    }

    /**
     * Greates the geometry in <code>GEOMETRY</code> mode of the <code>Rectangle
     * </code>object.
     *
     * @param rectangle <code>Rectangle</code> to display.
     * @param branchGroup root for the created subscenegraph.
     */
    public void createQuadGeometry(Rectangle rectangle, BranchGroup branchGroup) {
        float x = rectangle.getCoordinate().x;
        float y = rectangle.getCoordinate().y;
        float z = rectangle.getCoordinate().z;
        float width = rectangle.getWidth();
        float height = rectangle.getHeight();
        float minimumExtend = rectangle.getMinimumExtend();
        float leftX = x - 0.5f * width;
        float topY = y - 0.5f * height;
        float rightX = x + 0.5f * width;
        float bottomY = y + 0.5f * height;
        Quad quad = new Quad();
        quad.getCoordinates().scale(new Vector3f(rectangle.getWidth(),
                rectangle.getHeight(), 1));
        quad.getCoordinates().add(rectangle.getCoordinate());
        Shape3D shape = quad.getShape();
        ShapeManager.setCapabilities(shape, rectangle);
        getContextData().getShapeManager().register(rectangle, shape);
        Appearance appearance =
            AppearanceHelper.createAppearance(new Color3f(0.3f, 0.3f, 0.3f));
        PolygonAttributes polygonAttributes = new PolygonAttributes();
        polygonAttributes.setPolygonOffset(1);
        appearance.setPolygonAttributes(polygonAttributes);
        shape.setAppearance(appearance);
        shape.clearCapability(Shape3D.ALLOW_APPEARANCE_WRITE);
        branchGroup.addChild(shape);
    }
}
