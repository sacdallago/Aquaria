/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.visitors;

import javax.vecmath.Vector3f;

import org.srs3d.viewer.bioatlas.objects.Residue;

/**
 * Description of the class.
 *
 * @author Karsten Klein
 *
 * @created May 21, 2001
 */
public class StrandNormalPathCreator extends PathCreator {

    /*
     *  public void visit_( Subchain subchain ) {
     *  Vector3f vector0 = null;
     *  Residue residue = subchain.getInitialResidue();
     *  Residue limit = subchain.getEndResidue().getPreceeding();
     *  boolean invert = false;
     *  / insert intermediate residues
     *  while ( residue != null && residue != limit ) {
     *  if ( residue.refCA != null && residue.refCB != null ) {
     *  vector0 = new Vector3f( residue.refCB.getCoordinate() );
     *  vector0.sub( residue.refCA.getCoordinate() );
     *  if ( invert ) {
     *  vector0.negate();
     *  }
     *  invert = !invert;
     *  path.addElement( vector0 );
     *  }
     *  residue = residue.getProceeding();
     *  }
     *  }
     */

    /**
     * Description of the method.
     *
     * @param start Description of parameter.
     * @param end Description of parameter.
     */
    public void visit(Residue start, Residue end) {
        Vector3f vector0 = null;
        Vector3f vector1 = new Vector3f();
        Vector3f vector2 = new Vector3f();
        Vector3f previous = new Vector3f();
        Residue residue = start;
        Residue intermediate;
        Residue next;
        Residue limit = end.getPreceeding();
        boolean invert = false;

        // insert intermediate residues
        while (residue != null && residue != limit) {
            intermediate = residue.getProceeding();
            if (intermediate != null) {
                next = intermediate.getProceeding();
                if (next != null) {
                    vector0 = new Vector3f(getResidueCoordinate(intermediate));
                    vector1.set(getResidueCoordinate(residue));
                    vector2.set(getResidueCoordinate(next));
                    vector1.sub(vector0);
                    vector2.sub(vector0);
                    vector0.cross(vector2, vector1);
                    if (invert) {
                        vector0.negate();
                    }
                    invert = !invert;
                    if (previous.dot(vector0) < 0) {
                        vector0.negate();
                    }
                    previous.set(vector0);
                    path.add(vector0);
                }
            }
            residue = residue.getProceeding();
        }
        if (path.size() < 2) {
            path.clear();
            path.add(new Vector3f(1, 0, 0));
            path.add(new Vector3f(0, 1, 0));
        }
    }
}
