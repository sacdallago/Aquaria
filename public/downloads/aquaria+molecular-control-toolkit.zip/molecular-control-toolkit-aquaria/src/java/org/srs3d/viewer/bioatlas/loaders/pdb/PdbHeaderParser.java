/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.loaders.pdb;

import org.srs3d.viewer.bioatlas.objects.Chain;
import org.srs3d.viewer.bioatlas.objects.Layer;
import org.srs3d.viewer.objects.ObjectContainer;

/**
 * This class parses strings for pdb HEADER tags and tranfers/builts the appropriate
 * datastructure in a <code>ObjectContainer</code> .
 *
 * @author Karsten Klein, 01/2001
 *
 * @created May 18, 2001
 * @since 1.0
 */
public class PdbHeaderParser extends AbstractPdbParser {

    /** Description of the field. */
    public static final String TAG = new String("HEADER");

    /** The layer class identifier */
    public String layerClassification = null;

    /** The pdb identifier of the layer */
    public String layerId = null;

    /**
     * Mode retrieval method overwrite.
     *
     * @return The <code>retained</code> value.
     */
    public boolean isRetained() {
        return true;
    }

    /**
     * Parses the formated pdb string for HEADER data. The data is stored locally and no
     * object is created.
     *
     * @param string Description of parameter.
     */
    public void create(String string) {
        clear();

        // read layer identifier
        layerId = extractString(string, 62, 66);

        // read classification
        layerClassification = extractString(string, 10, 50);

        // convert string to lower case
        if (layerId != null) {
            layerId = layerId.trim().toLowerCase();
        }
        if (layerClassification != null) {
            layerClassification = layerClassification.trim().toLowerCase();
        }
    }

    /**
     * Specialized implementation.
     *
     * @param ObjectContainer the <code>ObjectContainer</code> instance to visit
     */
    public void visit(ObjectContainer ObjectContainer) {
        ObjectContainer.setName(layerId);
    }

    /**
     * Visits a <code>Layer</code> instance and transfers the headers data.
     *
     * @param layer the protoin to transfer the data to
     */
    public void visit(Layer layer) {

        // :FIXME: the current implementation does not create layer objects.
        //   perhaps we should retain the parser and give the layer information to
        //   all the created chains. This would enable us to perform a unique chain
        //   identification.
        layer.addId("PDB", layerId);
        layer.setClassification(layerClassification);
    }

    /**
     * Description of the method.
     *
     * @param chain Description of parameter.
     */
    public void visit(Chain chain) {

        // do nothing
        // :FIXME: see method visit( Layer )
        setSuccess(true);
    }

    /**
     * Description of the method.
     */
    public void clear() {
        super.clear();
        layerClassification = null;
        layerId = null;
    }
}
