/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.media.j3d.Appearance;

import org.srs3d.viewer.objects.AbstractObject;

/**
 * This class provides a default implementation for the <code>ColorScheme
 * </code>interface. It implements the methods that accesses <code>Collections
 * </code>and <code>Maps</code> of objects or rather objects and appearances.
 *
 * @author Karsten Fries, LION bioscience, 01/2001
 *
 * @created March 20, 2001
 */
public abstract class AbstractColorScheme implements ColorScheme, Contextual {
    private ContextData contextData = null;
    private float colorScale = 1;
    private float legendColorScale = 1;
    private boolean isComplete = false;
    private boolean hasInformation = true;

    /**
     * Constructor description.
     *
     * @param contextData Parameter description.
     */
    public AbstractColorScheme(ContextData contextData) {
        this.contextData = contextData;
    }

    /**
     * Gets the <code>Volatile</code> attribute of the <code>AbstractColorScheme
     * </code>object
     *
     * @return The <code>Volatile</code> value
     */
    public boolean isVolatile() {
        return false;
    }

    /**
     * Description of the method
     *
     * @param collection Description of parameter
     */
    public void modify(ContextData contextData, Collection collection) {

        // we use the shape manager of the specified
        ShapeManager shapeManager = contextData.getShapeManager();

        // the appearance manager uses the real context data instance (because it already
        // applies color scheme buckets of color schemes
        AppearanceManager appearanceMananger =
            getContextData().getAppearanceManager();
        Iterator iterator = collection.iterator();
        Appearance appearance;
        AbstractObject object;
        while (iterator.hasNext()) {
            object = (AbstractObject) iterator.next();
            appearance = appearanceMananger.getAppearance(object);
            if (modify(object, appearance)) {
                shapeManager.setUniformAppearance(object, appearance);
            }
        }
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public final ContextData getContextData() {
        return contextData;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public boolean isVertexBased() {
        return false;
    }

    /**
     * Method description.
     *
     * @param map Parameter description.
     *
     * @return Return description.
     */
    public Map getInformation(Map map) {
        if (map == null) {
            return new HashMap();
        }
        return map;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public float getColorScale() {
        return colorScale;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public float getLegendColorScale() {
        return legendColorScale;
    }

    /**
     * Method description.
     *
     * @param colorScale Parameter description.
     */
    public void setColorScale(float colorScale) {
        this.colorScale = colorScale;
        this.legendColorScale = colorScale + 0.5f * colorScale + 0.3f;
        this.legendColorScale = Math.min(1.5f, this.legendColorScale);
    }

    /**
     * Method description.
     *
     * @param isComplete Parameter description.
     */
    public void setComplete(boolean isComplete) {
        this.isComplete = isComplete;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public final boolean isComplete() {
        return isComplete;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public boolean hasInformation() {
        return hasInformation;
    }

    /**
     * Method description.
     *
     * @param hasInformation Parameter description.
     */
    public void setInformation(boolean hasInformation) {
        this.hasInformation = hasInformation;
    }
}
