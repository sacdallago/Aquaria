/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.integration.datamodel.contract;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.srs3d.viewer.integration.interfaces.ContractAttribute;
import org.srs3d.viewer.integration.interfaces.ContractQualifier;

/**
 * A generic ContractQualifier implementation.
 *
 * @author Karsten Klein
 *
 * @created September 11, 2002
 */
public class GenericContractQualifier implements ContractQualifier,
    Serializable {
    public Map attributeMap = null;

    /**
     * Creates a new GenericContractQualifier object.
     */
    public GenericContractQualifier() {
    }

    /**
     * Creates a new GenericContractQualifier object.
     *
     * @param attribute Parameter description.
     */
    public GenericContractQualifier(ContractAttribute attribute) {
        setAttribute(attribute);
    }

    /**
     * Check the qualifier with the provided key object pair.
     *
     * @param key Key object.
     * @param object Value object.
     *
     * @return <code>true></code> if the qualifier criteria were met.
     */
    public boolean check(Object key, Object object) {
        boolean isSuccess = true;
        if (attributeMap != null) {
            Iterator iterator = attributeMap.values().iterator();
            ContractAttribute attribute;
            while (iterator.hasNext()) {
                attribute = (ContractAttribute) iterator.next();
                isSuccess &= attribute.check(key, object);
            }
        }
        return isSuccess;
    }

    //  /**
    //   *  Check the qualifier with the provided key object pair.
    //   *
    //   * @param  key     Key object.
    //   * @param  object  Value object.
    //   * @param  out     PrintStream for providing output.
    //   * @return         <code>true></code> if the qualifier criteria were met.
    //   */
    //  public boolean check( Object key, Object object, PrintStream out ) {
    //
    //    boolean isSuccess = true;
    //
    //    if ( isMandatory() ) {
    //
    //      if ( object == null ) {
    //
    //        out.println( "mandatory object " + key + " not provided" );
    //
    //        if ( objectClass != null ) {
    //
    //          out.println( "expected object of type " + objectClass.getName() );
    //
    //        }
    //
    //        isSuccess = false;
    //
    //      }
    //
    //    }
    //    else {
    //
    //      if ( object == null ) {
    //
    //        object = defaultObject;
    //
    //      }
    //
    //    }
    //
    //    if ( object != null ) {
    //
    //      if ( objectClass != null ) {
    //
    //        if ( !isClass( object.getClass() ) ) {
    //
    //          out.println( "class check failed: expected " + objectClass +
    //              ", received " + object.getClass() );
    //          isSuccess = false;
    //
    //        }
    //
    //      }
    //
    //    }
    //
    //    return isSuccess;
    //  }

    /**
     * Converts the qualifier to a string.
     *
     * @return Converted string representation.
     */
    public String toString() {
        String string = "ContractQualifier" + System.identityHashCode(this);
        string += "[";
        if (attributeMap != null) {
            Iterator iterator = attributeMap.values().iterator();
            ContractAttribute attribute;
            while (iterator.hasNext()) {
                string += iterator.next();
                if (iterator.hasNext()) {
                    string += "; ";
                }
            }
        }
        string += "]";
        return string;
    }

    /**
     * Description of the method.
     *
     * @param attributeClass Parameter description.
     *
     * @return Return parameter description.
     */
    public ContractAttribute getAttribute(Class attributeClass) {
        return (ContractAttribute) attributeMap.get(attributeClass);
    }

    /**
     * Description of the method.
     *
     * @param attributeClass Parameter description.
     *
     * @return Return parameter description.
     */
    public boolean hasAttribute(Class attributeClass) {
        return attributeMap.get(attributeClass) != null;
    }

    /**
     * Description of the method.
     *
     * @param attribute Parameter description.
     */
    public void setAttribute(ContractAttribute attribute) {
        if (attributeMap == null) {
            attributeMap = new HashMap();
        }
        attributeMap.put(attribute.getClass(), attribute);
    }
}
