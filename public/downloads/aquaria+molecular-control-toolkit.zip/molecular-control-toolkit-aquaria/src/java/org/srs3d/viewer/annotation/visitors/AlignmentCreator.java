/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.annotation.visitors;

import org.srs3d.viewer.annotation.objects.Alignment;
import org.srs3d.viewer.annotation.objects.AnnotationUnit;
import org.srs3d.viewer.annotation.objects.ChainAnnotation;
import org.srs3d.viewer.bioatlas.objects.Annotation;
import org.srs3d.viewer.bioatlas.objects.Chain;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.objects.ObjectContainer;
import org.srs3d.viewer.objects.visitors.AbstractVisitor;

/**
 * This class provides the methods to create the <code>Segment</code> instances from a
 * <code>Chain</code> . The segments represent the secondary structure e.g.
 *
 * @author Christian Zofka, 06/2001
 *
 * @created July 4, 2001
 */
public class AlignmentCreator extends AbstractVisitor {
    private Alignment alignment = new Alignment();

    /**
     * @param alignment The new <code>alignment</code> value.
     */
    public void setAlignment(Alignment alignment) {
        this.alignment = alignment;
    }

    /**
     * Gets the <code>alignment</code> attribute of the <code>AlignmentCreator </code>
     * object.
     *
     * @return The <code>alignment</code> value.
     */
    public Alignment getAlignment() {
        return alignment;
    }

    /**
     * Description of the method.
     *
     * @param object Description of parameter.
     */
    public void visit(ObjectContainer object) {
        super.visit(object);
    }

    /**
     * Description of the method.
     *
     * @param object Description of parameter.
     */
    public void visit(AbstractObject object) {
        if (object instanceof Chain) {
            visit((Chain) object);
        } else if (object instanceof Annotation) {
            visit((Annotation) object);
        }
        if (object instanceof ObjectContainer) {
            visit((ObjectContainer) object);
        }
    }

    /**
     * Visits a chain. Automatically creates segments for <code>Subchain</code>
     * instances.
     *
     * @param chain Description of parameter.
     */
    public void visit(Chain chain) {
        ChainAnnotationCreator chainAnnotationCreator =
            new ChainAnnotationCreator();
        ChainAnnotation chainAnnotation;
        chainAnnotationCreator.visit(chain);
        chainAnnotation = chainAnnotationCreator.getChainAnnotation();
        if (!chainAnnotation.isEmpty()) {
            alignment.addChain(chainAnnotation);
            alignment.update();
        }
    }

    /**
     * Description of the method.
     *
     * @param annotation Description of parameter.
     */
    public void visit(Annotation annotation) {

        // in the current setting this never happens
        alignment.addAnnotationUnit(new AnnotationUnit(annotation));
        alignment.update();
        throw new RuntimeException("Code update necessary");
    }

    /**
     * inserts a chainAnnotation at the given position. fill the alignment with null till
     * position.
     */

    //  public void addAt( ChainAnnotation chainAnnotation, int position ) {
    //
    //    if ( !chainAnnotation.isEmpty() ) {
    //
    //      for ( int i = 1; i < position; i++ ) {
    //
    //        alignment.addChain( null );
    //
    //      }
    //
    //      alignment.addChain( chainAnnotation );
    //      alignment.update();
    //
    //    }
    //
    //  }
}
