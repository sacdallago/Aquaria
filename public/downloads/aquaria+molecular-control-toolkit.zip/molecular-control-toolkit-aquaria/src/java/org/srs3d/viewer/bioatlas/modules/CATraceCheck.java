/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.modules;

import java.util.Collection;
import java.util.Vector;

import org.srs3d.viewer.bioatlas.attributes.Representation;
import org.srs3d.viewer.bioatlas.attributes.ResidueRepresentation;
import org.srs3d.viewer.bioatlas.attributes.SubchainRepresentation;
import org.srs3d.viewer.bioatlas.objects.Residue;
import org.srs3d.viewer.bioatlas.objects.Subchain;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.commands.ExecuteClassCommand;
import org.srs3d.viewer.j3d.commands.ParentCommand;
import org.srs3d.viewer.j3d.commands.PreSelectCommand;
import org.srs3d.viewer.objects.Command;
import org.srs3d.viewer.objects.State;

/**
 * @author Karsten Klein
 *
 * @created August 06, 2001
 */
public class CATraceCheck extends RibbonCheck {
    public static final CATraceCheck sharedInstance = new CATraceCheck();

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     * @param subchain Parameter description.
     *
     * @return Return description.
     */
    public int check(ContextData contextData, Subchain subchain) {
        State.Immutable state =
            contextData.getStateManager().getImmutableState(subchain);
        SubchainRepresentation.Immutable representation =
            (SubchainRepresentation.Immutable) state.getAttribute(SubchainRepresentation.class);
        if (representation != null) {
            if ((representation.getMode() &
                  Representation.REPRESENTATION_CATRACE) != 0) {
                return CHECK_YES;
            } else {
                return CHECK_NO;
            }
        }
        return CHECK_YES;
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     * @param residue Parameter description.
     *
     * @return Return description.
     */
    public int check(ContextData contextData, Residue residue) {
        if (residue.isLigand()) {
            return CHECK_NO;

            //      return CHECK_FAIL;
        } else {
            State.Immutable state =
                contextData.getStateManager().getImmutableState(residue);
            ResidueRepresentation.Immutable representation =
                (ResidueRepresentation.Immutable) state.getAttribute(ResidueRepresentation.class);
            if (representation != null) {
                if ((representation.getMode() &
                      Representation.REPRESENTATION_CATRACE) != 0) {
                    return CHECK_YES;
                } else {
                    return CHECK_NO;
                }
            }
            return CHECK_YES;
        }
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public int getUndoMode() {
        return Representation.REPRESENTATION_COIL |
        Representation.REPRESENTATION_RIBBON;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public int getMode() {
        return Representation.REPRESENTATION_CATRACE;
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     * @param onCommands Parameter description.
     */
    public void getAllOnCommands(ContextData contextData, Collection onCommands) {
        Command subchainCommand =
            new ExecuteClassCommand(contextData,
                new PreSelectCommand(contextData), Subchain.class);
        onCommands.add(new ExecuteClassCommand(contextData,
                new ParentCommand(contextData, subchainCommand), Residue.class));
        super.getAllOnCommands(contextData, onCommands);
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     *
     * @return Return description.
     */
    public static RepresentationModule createRepresentationModule(
        ContextData contextData) {
        Vector onCommands = new Vector();
        Vector offCommands = new Vector();
        onCommands = new Vector();
        offCommands = new Vector();
        sharedInstance.getAllOnCommands(contextData, onCommands);
        sharedInstance.getAllOffCommands(contextData, offCommands);
        return new RepresentationModule("C-alpha Trace", contextData,
            onCommands, offCommands, sharedInstance);
    }
}
