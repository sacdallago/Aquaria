/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.annotation.behaviors;

import java.awt.event.MouseEvent;

import javax.media.j3d.Node;
import javax.media.j3d.WakeupOnAWTEvent;
import javax.media.j3d.WakeupOr;
import javax.vecmath.Point3f;
import javax.vecmath.Tuple3f;
import javax.vecmath.Vector3d;
import javax.vecmath.Vector3f;

import org.srs3d.viewer.j3d.Context;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.behaviors.KeyHandler;
import org.srs3d.viewer.j3d.behaviors.MouseBehavior;
import org.srs3d.viewer.j3d.objects.Rectangle;
import org.srs3d.viewer.j3d.operations.ZoomBoxOperation;

import com.sun.j3d.utils.picking.PickResult;

/**
 * ZoomBoxBehavior
 *
 * @author Christian Zofka
 *
 * @created August 12, 2001
 */
public class ZoomBoxBehavior extends MouseBehavior {
    private Vector3f offset = null;
    private Rectangle zoomBox = null;
    private Tuple3f speed = new Point3f(1.0f, 1.0f, 1.0f);

    /**
     * <code>ZoomBoxBehavior</code> constructor.
     *
     * @param context Description of parameter.
     */
    public ZoomBoxBehavior(ContextData contextData) {
        super(contextData);
    }

    /**
     * Sets the <code>speedX</code> attribute of the <code>PanXYBehavior</code> object.
     *
     * @param x The new <code>speedX</code> value.
     */
    public void setSpeedX(float x) {
        speed.x = x;
    }

    /**
     * Sets the <code>speedy</code> attribute of the <code>PanXYBehavior</code> object.
     *
     * @param y The new <code>speedy</code> value.
     */
    public void setSpeedy(float y) {
        speed.y = y;
    }

    /**
     * Gets the <code>speedX</code> attribute of the <code>PanXYBehavior</code> object.
     *
     * @return The <code>speedX</code> value.
     */
    public float getSpeedX() {
        return speed.x;
    }

    /**
     * Gets the <code>speedY</code> attribute of the <code>PanXYBehavior</code> object.
     *
     * @return The <code>speedY</code> value.
     */
    public float getSpeedY() {
        return speed.y;
    }

    /**
     * initialize mouseEvents
     */
    public void initialize() {
        WakeupOnAWTEvent[] conditions = new WakeupOnAWTEvent[3];

        // set wakeup conditions
        conditions[0] =
            new WakeupOnAWTEvent(java.awt.event.MouseEvent.MOUSE_PRESSED);
        conditions[1] =
            new WakeupOnAWTEvent(java.awt.event.MouseEvent.MOUSE_DRAGGED);
        conditions[2] =
            new WakeupOnAWTEvent(java.awt.event.MouseEvent.MOUSE_RELEASED);
        wakeupOn(new WakeupOr(conditions));
    }

    /**
     * Implementation of the <code>Behavior</code> interface.
     *
     * @param mouseEvent event
     */
    public void processStimulus(MouseEvent mouseEvent) {
        Context context = getContextData().getContext();
        Tuple3f now;
        Vector3d section;
        int x;
        int y;
        if (zoomBox == null) {
            if (checkInitialCriteria(mouseEvent)) {

                // click on / select zoomBox
                x = mouseEvent.getX();
                y = mouseEvent.getY();
                PickResult pickResult =
                    getContextData().getIntersectionManager().pickClosest(x, y);
                if (pickResult != null) {
                    Node node = pickResult.getObject();
                    if (node != null &&
                          node.getUserData() instanceof Rectangle) {
                        if (speed.y == 0) {
                            KeyHandler.setCursor(getContextData(), "PanX", true);
                        } else {
                            KeyHandler.setCursor(getContextData(), "PanXY", true);
                        }
                        zoomBox = (Rectangle) node.getUserData();

                        // because of update difficulties after viewplatform transformation
                        // (i.e. after zooming, new windowsize): 2 sections
                        // :NOTE: here is not the position to take care about this
                        // context.getContextData().getIntersectionManager().computeXYPlaneIntersection( x, y );
                        section =
                            context.getContextData().getIntersectionManager()
                                   .computeXYPlaneIntersection(x, y);
                        now = new Vector3f(section);
                        offset = new Vector3f(now);
                        offset.sub(zoomBox.getCoordinate());
                    }
                }
            }
        } else if (checkCriteria(mouseEvent)) {

            // mouseDragged / move zoomBox
            if (speed.y == 0) {
                KeyHandler.setCursor(getContextData(), "PanX", true);
            } else {
                KeyHandler.setCursor(getContextData(), "PanXY", true);
            }
            x = mouseEvent.getX();
            y = mouseEvent.getY();
            section =
                context.getContextData().getIntersectionManager()
                       .computeXYPlaneIntersection(x, y);
            now = new Vector3f(section);
            now.sub(offset);
            Tuple3f old = zoomBox.getCoordinate();
            now.sub(old);
            Tuple3f delta =
                new Point3f(now.x * speed.x, now.y * speed.y, now.z * speed.z);
            ZoomBoxOperation operation =
                new ZoomBoxOperation(context, "MOVE_ZOOMBOX", zoomBox);
            operation.setDeltaPosition(delta);
            old.add(delta);
            zoomBox.setCoordinate(old);
            context.getContextData().getDispatcher().dispatch(operation);
        } else {

            // zoomBox released
            zoomBox = null;
        }
    }

    /**
     * This method checks the mouseEvent (fail early, fail fast)
     *
     * @param mouseEvent event
     *
     * @return boolean
     */
    protected boolean checkInitialCriteria(MouseEvent mouseEvent) {

        // fail early, fail fast procedure for dragging
        if (mouseEvent.getID() == MouseEvent.MOUSE_DRAGGED) {
            return false;
        }
        if ((MouseEvent.BUTTON1_MASK & mouseEvent.getModifiers()) == 0) {
            return false;
        }
        if (mouseEvent.isAltDown()) {
            return false;
        }
        if (mouseEvent.isControlDown()) {
            return false;
        }
        if (mouseEvent.isShiftDown()) {
            return false;
        }
        return true;
    }

    /**
     * This method checks the mouseEvent (fail early, fail fast)
     *
     * @param mouseEvent event
     *
     * @return boolean
     */
    protected boolean checkCriteria(MouseEvent mouseEvent) {

        // don't care about what kind of mouse event, just do it
        if ((MouseEvent.BUTTON1_MASK & mouseEvent.getModifiers()) == 0) {
            return false;
        }
        if (mouseEvent.isAltDown()) {
            return false;
        }
        if (mouseEvent.isControlDown()) {
            return false;
        }
        if (mouseEvent.isShiftDown()) {
            return false;
        }
        return true;
    }
}
