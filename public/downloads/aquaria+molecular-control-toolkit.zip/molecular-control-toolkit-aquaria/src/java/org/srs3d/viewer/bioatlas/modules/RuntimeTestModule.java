/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.modules;

import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;

import org.srs3d.viewer.bioatlas.Application;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.Selection;
import org.srs3d.viewer.j3d.behaviors.dispatcher.Dispatch;
import org.srs3d.viewer.j3d.operations.TestOperation;
import org.srs3d.viewer.objects.ObjectManager;
import org.srs3d.viewer.objects.Operation;
import org.srs3d.viewer.util.ExceptionHandler;

/**
 * @author Karsten Klein
 *
 * @created February 06, 2002
 */
public class RuntimeTestModule extends AbstractModule {
    public long startTime = -1;
    public long deltaTime = -1;

    /**
     * Constructor description.
     *
     * @param name Parameter description.
     * @param contextData Parameter description.
     */
    public RuntimeTestModule(String name, ContextData contextData) {
        super(name, contextData);

        // register ResetOperationStore operation
        Dispatch dispatch =
            new Dispatch() {
                public void dispatch(ContextData contextData,
                    Operation operation) {
                    processTest(contextData, operation);
                }
            };
        ArrayList dispatches = new ArrayList(1);
        dispatches.add(dispatch);
        contextData.getDispatcher().registerDispatches("TEST", dispatches);
    }

    /**
     * Description of the method.
     *
     * @param e Description of parameter.
     */
    public void react(ActionEvent e) {
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     * @param operation Parameter description.
     */
    public void processTest(ContextData contextData, Operation operation) {
        if (startTime == -1) {
            startTime = System.currentTimeMillis();
        }
        long time = System.currentTimeMillis() - startTime;
        String timeString = " " + time + "(" + (time - deltaTime) + ")";
        deltaTime = time;
        Collection selection = new HashSet();
        Collection objects = new HashSet();
        contextData.getObjectManager().collapseUpExtended(contextData.getSelectionManager()
                                                                     .getSelection(),
            selection);
        contextData.getObjectManager().collapseUpExtended(operation.getObjects(),
            objects);

        // :FIXME: this has to disapperear; selections should have no bonds
        ObjectManager.filter(selection,
            org.srs3d.viewer.bioatlas.objects.Bond.class);
        ObjectManager.filter(objects,
            org.srs3d.viewer.bioatlas.objects.Bond.class);
        boolean isSuccess = false;
        String selectionTest = "";
        if (selection.containsAll(objects)) {
            if (objects.containsAll(selection)) {
                isSuccess = true;
                selectionTest = testSelection(contextData);
                if (selectionTest != null) {
                    isSuccess = false;
                }
            }
        }
        String logname = "test.log";
        String string;
        if (isSuccess) {
            Map testReportMap = null;
            try {
                TestOperation testOperation = (TestOperation) operation;
                testReportMap = testOperation.getReport();
            } catch (ClassCastException e) {
                ExceptionHandler.handleException(e);
            }
            if (testReportMap != null && !testReportMap.isEmpty()) {
                Map reportMap = new HashMap();
                ((org.srs3d.viewer.swing.PopupMenu) contextData.getProperty(
                    "POPUP-MENU")).createReport(reportMap);
                String comparisson = compareMaps(testReportMap, reportMap);
                if (comparisson == null) {
                    string = "SUCCESSFULL";
                } else {
                    string = "FAILED";
                    string += System.getProperty("line.separator") + "diff: " +
                    comparisson;
                    ((Application) getContextData().getProperty("Application")).getApplicationContext()
                     .set("RuntimeTestResult", "failure: " + comparisson);
                }
            } else {
                string = "SUCCESSFULL";
            }
        } else {
            string = "FAILED ";
            if (selectionTest == null) {
                string += System.getProperty("line.separator") +
                "Selection size: " + selection.size();
                string += System.getProperty("line.separator") +
                "Objects size: " + operation.getObjects().size();
                Collection remainder = new HashSet(selection);
                remainder.removeAll(operation.getObjects());
                string += System.getProperty("line.separator") +
                "selection/objects: " + remainder;
                remainder = new HashSet(operation.getObjects());
                remainder.removeAll(selection);
                string += System.getProperty("line.separator") +
                "objects/selection: " + remainder;
            } else {
                string += selectionTest;
            }
            ((Application) getContextData().getProperty("Application")).getApplicationContext()
             .set("RuntimeTestResult", "failure: " + selectionTest);
        }
        string += System.getProperty("line.separator");
        try {
            java.io.OutputStream out =
                new java.io.FileOutputStream(logname, true);
            if (out != null) {
                out.write(("" + new Date(System.currentTimeMillis()) + " " +
                    contextData.getProperty("INSTANCE-ID") + " " + timeString +
                    " ").getBytes());
                out.write(string.getBytes());
            }
        } catch (Exception e) {
            ExceptionHandler.handleException(e);
        }
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     * @param createReport Parameter description.
     *
     * @return Return description.
     */
    public static Operation createTestOperation(ContextData contextData,
        boolean createReport) {
        if (contextData.getProperty("RuntimeTestMode") != null) {

            // create test operation in test mode
            TestOperation testOperation =
                new TestOperation(contextData.getContext(), "TEST");
            testOperation.setObjects(new HashSet(contextData.getSelectionManager()
                                                            .getSelection()));
            ObjectManager.filter(testOperation.getObjects(),
                org.srs3d.viewer.bioatlas.objects.Bond.class);
            if (createReport) {

                //        String report = (( org.srs3d.viewer.swing.PopupMenu ) contextData.
                //          getProperty( "POPUP-MENU" ) ).createReport();
                //        testOperation.setReport( report );
                Map map = new HashMap();
                ((org.srs3d.viewer.swing.PopupMenu) contextData.getProperty(
                    "POPUP-MENU")).createReport(map);
                testOperation.setReport(map);
            }
            testOperation.setSerializable(true);
            return testOperation;
        }
        return null;
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     */
    public static void finalize(ContextData contextData) {
        if (contextData.getProperty("RuntimeTestMode") != null) {
            Application app =
                (Application) contextData.getProperty("Application");
            app.stop();
            app.destroy();
        }
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     * @param selection Parameter description.
     *
     * @return Return description.
     */
    public static String testSelection(ContextData contextData,
        Selection selection) {
        if (!selection.getColorScheme().isVolatile()) {

            // retrieve all objects that are colored with the selection color scheme
            Collection objects =
                contextData.getColorSchemeManager().getObjects(selection.getColorScheme());
            Collection collapsedObjects = new HashSet();
            contextData.getObjectManager().collapseUpExtended(objects,
                collapsedObjects);
            objects.clear();
            contextData.getObjectManager().getDownAssociations(collapsedObjects,
                objects);
            objects.addAll(collapsedObjects);
            Collection extended = new HashSet();
            Collection collapsedSelection = new HashSet();
            contextData.getObjectManager().collapseUpExtended(selection,
                collapsedSelection);
            contextData.getObjectManager().getDownAssociations(collapsedSelection,
                extended);
            extended.addAll(collapsedSelection);
            Collection objectRemainder = new HashSet(objects);
            objectRemainder.removeAll(extended);
            Collection selectionRemainder = new HashSet(extended);
            selectionRemainder.removeAll(objects);
            String testReport = null;
            if (objectRemainder.size() != 0) {
                testReport =
                    "Selection Test - object remainder: " + objectRemainder;
                testReport += System.getProperty("line.separator") +
                "Selection Test - objects: " + collapsedObjects;
                testReport += System.getProperty("line.separator") +
                "Selection Test - selection: " + collapsedSelection;
            }
            if (selectionRemainder.size() != 0) {
                testReport =
                    "Selection Test - selection remainder: " +
                    selectionRemainder;
                testReport += System.getProperty("line.separator") +
                "Selection Test - objects: " + collapsedObjects;
                testReport += System.getProperty("line.separator") +
                "Selection Test - selection: " + collapsedSelection;
            }
            return testReport;
        }
        return null;
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     *
     * @return Return description.
     */
    public static String testSelection(ContextData contextData) {
        Collection selections =
            contextData.getSelectionManager().getSelections();
        Iterator iterator = selections.iterator();
        String testReport = null;
        while (testReport == null && iterator.hasNext()) {
            testReport =
                testSelection(contextData, (Selection) iterator.next());
        }
        return testReport;
    }

    private String compareMaps(Map mapA, Map mapB) {
        Collection allKeys = new HashSet();
        allKeys.addAll(mapA.keySet());
        allKeys.addAll(mapB.keySet());
        Iterator iterator = allKeys.iterator();
        Object key;
        String valueA;
        String valueB;
        String string = "";
        while (iterator.hasNext()) {
            key = iterator.next();
            valueA = (String) mapA.get(key);
            valueB = (String) mapB.get(key);
            if (valueA == null || valueB == null) {
                string += "[" + key + " not included in both reports]";
            } else {
                if (!valueA.equals(valueB)) {
                    string += "[" + key + ": " + valueA + " unequal to " +
                    valueB + "]";
                }
            }
        }
        if (string == "") {
            return null;
        }
        return string;
    }
}
