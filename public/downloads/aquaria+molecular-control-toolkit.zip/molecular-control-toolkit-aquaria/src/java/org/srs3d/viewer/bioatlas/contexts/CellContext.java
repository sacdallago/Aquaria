/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.contexts;

import java.net.URL;

import javax.media.j3d.AmbientLight;
import javax.media.j3d.Appearance;
import javax.media.j3d.BoundingSphere;
import javax.media.j3d.BranchGroup;
import javax.media.j3d.PointLight;
import javax.media.j3d.PolygonAttributes;
import javax.media.j3d.QuadArray;
import javax.media.j3d.Shape3D;
import javax.media.j3d.Texture;
import javax.media.j3d.Transform3D;
import javax.media.j3d.TransformGroup;
import javax.vecmath.Color3f;
import javax.vecmath.Point3d;
import javax.vecmath.Point3f;
import javax.vecmath.Tuple3d;
import javax.vecmath.Tuple3f;
import javax.vecmath.Vector3d;
import javax.vecmath.Vector3f;

import org.srs3d.viewer.j3d.AppearanceHelper;
import org.srs3d.viewer.j3d.BranchGroupHelper;
import org.srs3d.viewer.j3d.Context;
import org.srs3d.viewer.j3d.DispatchManager;
import org.srs3d.viewer.j3d.behaviors.PanXY2DBehavior;
import org.srs3d.viewer.j3d.behaviors.SelectZoomBehavior;
import org.srs3d.viewer.j3d.behaviors.Zoom2DBehavior;
import org.srs3d.viewer.j3d.constraints.FrustumConstraint;
import org.srs3d.viewer.j3d.geometry.GeometryHelper;
import org.srs3d.viewer.j3d.geometry.primitive.Quad;
import org.srs3d.viewer.util.ExceptionHandler;
import org.srs3d.viewer.util.Log;

import com.sun.j3d.utils.image.TextureLoader;

/**
 * This class specializes the <code>Context</code> for the cell view application. Main
 * novelity to its base class is the <code>setup</code> method.
 *
 * @author Karsten Klein, 11/2000
 *
 * @created November 20, 2001
 */
public class CellContext extends Context {
    private static final Log log = new Log(CellContext.class);

    /**
     * Sets the default context setting FIXME: the default currently applies to the cell
     * view purpose. I propose to put this method in a specialized class of Context
     * (e.g. CellViewContext) and make this here more general (assuming measurements in
     * meters).
     */
    public void setup() {
        super.setup();
        setupLights(true);

        // doing out the cell view behavior setup
        setViewingPlatformPosition(new Point3d(0, 0, 470000));
        BoundingSphere bounds =
            new BoundingSphere(new Point3d(0.0, 0.0, 0.0), Double.MAX_VALUE);
        PanXY2DBehavior panner = new PanXY2DBehavior(getContextData());
        getBehaviorLevel().addChild(panner);
        panner.setSchedulingBounds(bounds);
        SelectZoomBehavior zoomer = new SelectZoomBehavior(getContextData());
        zoomer.setSchedulingBounds(bounds);
        getBehaviorLevel().addChild(zoomer);
        Zoom2DBehavior zoom = new Zoom2DBehavior(getContextData());
        zoom.setSchedulingBounds(bounds);
        getBehaviorLevel().addChild(zoom);
    }

    /**
     * Description of the Method
     *
     * @param rdbFilename Description of Parameter
     * @param jpgFilename Description of Parameter
     */
    public void setup(URL jpgUrl, URL epsUrl, Tuple3f scale) {

        // add noisy background
        if (jpgUrl != null) {
            try {
                QuadArray quadArray =
                    GeometryHelper.getDefaultQuadArray(1,
                        QuadArray.TEXTURE_COORDINATE_2);
                Quad quad = new Quad();
                quad.getCoordinates().scale(scale);
                TextureLoader loader = new TextureLoader(jpgUrl, "RGB", null);
                Texture texture = loader.getTexture();
                if (texture != null) {
                    quad.insertInto(0, quadArray);
                    Appearance appearance = new Appearance();
                    AppearanceHelper.setTextureDefaults(appearance, texture,
                        0.25f);
                    PolygonAttributes pa = new PolygonAttributes();
                    pa.setPolygonOffset(50);
                    appearance.setPolygonAttributes(pa);
                    BranchGroup branch = new BranchGroup();
                    BranchGroupHelper.setDefaultCapabilities(branch);
                    Shape3D shape = new Shape3D(quadArray, appearance);
                    shape.setPickable(false);
                    branch.addChild(shape);
                    getSceneLevel().addChild(branch);
                } else {
                    log.debug("no cell background texture available.");
                }
            } catch (Exception e) {
                log.debug("no cell background texture available!");
                ExceptionHandler.handleException(e,
                    ExceptionHandler.SILENT_IN_DEBUG, this);
            }
        }
        if (epsUrl != null) {
            try {
                TransformGroup transformGroup = new TransformGroup();
                Transform3D transform = new Transform3D();
                transform.setScale(new Vector3d(scale));
                Vector3f translation = new Vector3f(scale);
                translation.scale(-0.5f);
                transform.setTranslation(translation);
                transformGroup.setTransform(transform);
                transformGroup.addChild(loadSubscene(epsUrl));
                getSceneLevel().addChild(transformGroup);
            } catch (Exception e) {
                log.debug("no cell file available.");
                ExceptionHandler.handleException(e,
                    ExceptionHandler.SILENT_IN_DEBUG, this);
            }
        }
    }

    /**
     * Description of the Method
     */
    public void setupLights(boolean isBlackBackground) {
        if (isBlackBackground) {
            BoundingSphere bounds =
                new BoundingSphere(new Point3d(0.0, 0.0, 0.0), Double.MAX_VALUE);

            // create lights
            AmbientLight ambientLight =
                new AmbientLight(new Color3f(0.3f, 0.3f, 0.3f));
            PointLight pointLight0 =
                new PointLight(new Color3f(0.7f, 0.7f, 0.7f),
                    new Point3f(0, 0, 420000), new Point3f(1, 0, 0));
            PointLight pointLight1 =
                new PointLight(new Color3f(0.4f, 0.4f, 0.4f),
                    new Point3f(420000, 420000, 0), new Point3f(1, 0, 0));
            getLocalLevel().addChild(ambientLight);
            getLocalLevel().addChild(pointLight0);
            getLocalLevel().addChild(pointLight1);

            // Set the influencing bounds
            ambientLight.setInfluencingBounds(bounds);
            pointLight0.setInfluencingBounds(bounds);
            pointLight1.setInfluencingBounds(bounds);
        } else {
            log.error("not implemented.");
        }
    }

    /**
     * Adjusts the front (hither) and back (yon) clipping plane according to the current
     * viewing platform position FIXME: the default currently applies to the cell view
     * purpose. I propose to put this method in a specialized class of Context (e.g.
     * CellViewContext) and make this here more general (assuming measurements in
     * meters).
     */
    public void adjustClipping() {
        super.adjustClipping();
        Vector3f vector = new Vector3f(getViewingPlatformPosition());
        double back = vector.z + 100;
        getView().setBackClipDistance(back);
        getView().setFrontClipDistance(back / 75);
    }

    /**
     * Method description.
     *
     * @param tuple Parameter description.
     */
    public void setViewingPlatformPosition(Tuple3d tuple) {
        processConstraints(tuple);
        super.setViewingPlatformPosition(tuple);
    }

    /**
     * Method description.
     *
     * @param transform Parameter description.
     * @param sendMoveOverview Parameter description.
     */
    public void setViewingPlatformTransform(Transform3D transform,
        boolean sendMoveOverview) {
        super.setViewingPlatformTransform(transform);
        if (sendMoveOverview) {
            sendMoveOverview();
        }
    }

    /**
     * Method description.
     *
     * @param transform Parameter description.
     */
    public void setViewingPlatformTransform(Transform3D transform) {
        super.setViewingPlatformTransform(transform);
        sendMoveOverview();
    }

    /**
     * Method description.
     */
    public void sendMoveOverview() {
        Transform3D transform = getViewingPlatformTransform();
        org.srs3d.viewer.j3d.operations.ZoomBoxOperation operation =
            new org.srs3d.viewer.j3d.operations.ZoomBoxOperation(this,
                "MOVE_OVERVIEW", null);
        Vector3f translation = new Vector3f();
        transform.get(translation);
        Vector3f size = new Vector3f();
        size.x = translation.z * 1.0f / 1.3f;
        if (getHeight() != 0) {
            size.y = size.x * getHeight() / getWidth();
        }
        operation.setDeltaPosition(translation);
        operation.setDeltaSize(size);
        DispatchManager.runDispatch(this, operation);
    }

    /**
     * Method description.
     *
     * @param distance Parameter description.
     */
    public void resetConstraint(float distance) {
        FrustumConstraint constraint;
        constraint =
            new FrustumConstraint(new Point3d(0, 0, 50),
                new Point3d(0, 0, distance), new Vector3d(0, 1, 0), 0.4, 0.4);
        getConstraints().add(constraint);
    }
}
