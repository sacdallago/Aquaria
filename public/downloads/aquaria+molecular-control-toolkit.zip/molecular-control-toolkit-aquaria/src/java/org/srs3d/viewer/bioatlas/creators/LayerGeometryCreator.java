/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.creators;

import java.util.Iterator;

import javax.media.j3d.Appearance;
import javax.media.j3d.BranchGroup;
import javax.media.j3d.PointArray;
import javax.media.j3d.PointAttributes;
import javax.media.j3d.Shape3D;
import javax.vecmath.Color3f;
import javax.vecmath.Point3f;

import org.srs3d.viewer.bioatlas.filters.LigandFilter;
import org.srs3d.viewer.bioatlas.filters.SubchainFilter;
import org.srs3d.viewer.bioatlas.objects.Layer;
import org.srs3d.viewer.bioatlas.objects.Residue;
import org.srs3d.viewer.j3d.AppearanceHelper;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.ShapeManager;
import org.srs3d.viewer.j3d.attributes.Visible;
import org.srs3d.viewer.j3d.creators.AbstractGeometryCreator;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.objects.State;
import org.srs3d.viewer.objects.StateManager;
import org.srs3d.viewer.objects.filters.ObjectClassFilter;
import org.srs3d.viewer.objects.visitors.ObjectCollector;
import org.srs3d.viewer.util.ExceptionHandler;

/**
 * Special implementation of the <code>GeometryCreator</code> interface. The
 * implementation concentrates on the building geometry of <code>Layer</code> .
 *
 * @author Karsten Klein
 *
 * @created March 20, 2001
 */
public class LayerGeometryCreator extends AbstractGeometryCreator {

    /** Description of the field. */
    public static int LAYER_POINT = 1;

    /** Description of the field. */
    public int layerMode = 1;

    /**
     * Description of the method.
     *
     * @param object Description of parameter.
     * @param branchGroup Description of parameter.
     */
    public void create(AbstractObject object, BranchGroup branchGroup) {
        if ((layerMode & LAYER_POINT) != 0) {
            createPoint((Layer) object, branchGroup);
        }
    }

    /**
     * Description of the method.
     *
     * @param layer Description of parameter.
     * @param branchGroup Description of parameter.
     */
    public void createPoint(Layer layer, BranchGroup branchGroup) {

        // represent the layer as a single point
        PointArray pointArray =
            new PointArray(1, PointArray.COORDINATES | PointArray.COLOR_3);

        // :FIXME: this point at origin geometry shoudl be shared
        pointArray.setCoordinate(0, new Point3f());
        pointArray.setColor(0, new Color3f(1, 1, 1));

        // use for snapshots
        Appearance appearance = new Appearance();
        AppearanceHelper.setDefaults(appearance);
        PointAttributes pointAttributes = new PointAttributes();
        pointAttributes.setPointSize(2);
        appearance.setPointAttributes(pointAttributes);
        Shape3D shape = new Shape3D(pointArray, appearance);
        getContextData().getShapeManager().register(layer, shape);
        ShapeManager.setCapabilities(shape, layer);
        branchGroup.addChild(shape);
    }

    /**
     * Description of the method.
     *
     * @param layer Description of parameter.
     * @param branchGroup Description of parameter.
     */
    public void createAlternate(Layer layer, BranchGroup branchGroup) {
        try {
            Iterator iterator = layer.getIterator();
            AbstractObject object;
            SubchainFilter subchainFilter = new SubchainFilter();
            ObjectCollector objectCollector =
                new ObjectCollector(subchainFilter);
            objectCollector.visit((AbstractObject) layer);
            CoilGeometryCreator coilGeometryCreator = new CoilGeometryCreator();
            iterator = objectCollector.getObjects().iterator();
            while (iterator.hasNext()) {
                object = (AbstractObject) iterator.next();
                coilGeometryCreator.modifyAttributes(getContextData(), object);
                coilGeometryCreator.setMode(CoilGeometryCreator.CATRACE);
                coilGeometryCreator.setShapeLocking(true);
                coilGeometryCreator.create(object, branchGroup);
            }
            objectCollector = new ObjectCollector(new LigandFilter(true));
            objectCollector.visit((AbstractObject) layer);
            iterator = objectCollector.getObjects().iterator();
            State.Immutable state;
            StateManager stateManager = getContextData().getStateManager();
            ObjectCollector residueCollector;
            Iterator residueIterator;
            Shape3D bondsShape;
            while (iterator.hasNext()) {
                object = (AbstractObject) iterator.next();
                state = stateManager.getImmutableState(object);
                if (state.hasAttribute(Visible.class)) {
                    residueCollector =
                        new ObjectCollector(new ObjectClassFilter(Residue.class));
                    residueCollector.visit(object);
                    residueIterator = residueCollector.getObjects().iterator();
                    Residue residue;
                    while (residueIterator.hasNext()) {
                        residue = (Residue) residueIterator.next();
                        if (!residue.getBonds().isEmpty()) {
                            bondsShape =
                                BondGeometryCreator.createLines(getContextData(),
                                    residue.getBonds(), residue);
                            ShapeManager.setCapabilities(bondsShape, residue);
                            getContextData().getShapeManager().register(residue,
                                bondsShape);
                            getContextData().getShapeManager().setShapeLock(bondsShape,
                                true);
                            branchGroup.addChild(bondsShape);
                        }
                    }
                }
            }
        } catch (Exception e) {
            ExceptionHandler.handleException(e, this);
        }
    }

    /**
     * Description of the method.
     *
     * @param object Description of parameter.
     * @param contextData Description of parameter.
     */
    public void modifyAttributes(ContextData contextData, AbstractObject object) {
        super.modifyAttributes(contextData, object);
        if (((Layer) object).getSize() > 0) {
            layerMode = 0;
        } else {
            layerMode = LAYER_POINT;
        }
    }
}
