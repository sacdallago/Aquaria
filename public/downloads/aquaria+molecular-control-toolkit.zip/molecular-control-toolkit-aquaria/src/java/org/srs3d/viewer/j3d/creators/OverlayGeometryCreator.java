/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.creators;

import javax.media.j3d.Appearance;
import javax.media.j3d.BranchGroup;
import javax.media.j3d.ImageComponent2D;
import javax.media.j3d.OrderedGroup;
import javax.media.j3d.Raster;
import javax.media.j3d.RenderingAttributes;
import javax.media.j3d.Shape3D;
import javax.media.j3d.TransparencyAttributes;
import javax.vecmath.Point3f;
import javax.vecmath.Tuple3f;
import javax.vecmath.Vector3f;

import org.srs3d.viewer.j3d.AppearanceHelper;
import org.srs3d.viewer.j3d.Context;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.ShapeManager;
import org.srs3d.viewer.j3d.objects.Overlay;
import org.srs3d.viewer.objects.AbstractObject;

/**
 * Description of the class.
 *
 * @author Karsten Klein
 *
 * @created March 20, 2001
 */
public class OverlayGeometryCreator extends AbstractGeometryCreator {

    /** Description of the Field */
    public static int GEOMETRY = 1;

    /** Description of the Field */
    public int type = GEOMETRY;

    /**
     * Creates the description (subscenegraph) of an <code>AbstractObject</code>
     *
     * @param object object to display. Only <code>Rectangle</code> instances will be
     *        processed.
     * @param branchGroup root for the created subscenegraph.
     */
    public void create(AbstractObject object, BranchGroup branchGroup) {
        create((Overlay) object, branchGroup);
    }

    /**
     * Creates the representation of the <code>Rectangle</code> object.
     *
     * @param branchGroup root for the created subscenegraph.
     * @param overlay Description of parameter.
     */
    public void create(Overlay overlay, BranchGroup branchGroup) {
        if ((type & GEOMETRY) != 0) {
            createGeometry(overlay, branchGroup);
        }
    }

    /**
     * Greates the geometry in <code>GEOMETRY</code> mode of the <code>Rectangle
     * </code>object.
     *
     * @param branchGroup root for the created subscenegraph.
     * @param overlay Description of parameter.
     */
    public void createGeometry(Overlay overlay, BranchGroup branchGroup) {
        createContent(overlay, branchGroup);
    }

    /**
     * Description of the method.
     *
     * @param overlay Description of parameter.
     * @param branchGroup Description of parameter.
     */
    public void createContent(Overlay overlay, BranchGroup branchGroup) {
        ImageComponent2D image = overlay.getImage();
        if (image != null) {
            Raster raster = new Raster();
            raster.setImage(image);
            raster.setCapability(Raster.ALLOW_POSITION_WRITE);
            raster.setCapability(Raster.ALLOW_POSITION_READ);
            Point3f position =
                new Point3f(compute3DCoordinate(overlay, overlay.getCoordinate()));
            if ((overlay.getAlignment() & Overlay.ALIGN_BOTTOM) != 0) {

                // prevent the overlay to be clipped away
                if (position.y > 0.08f * getContextData().getContext()
                                               .getHeight()) {
                    position.y =
                        0.08f * getContextData().getContext().getHeight();
                }
            }
            raster.setSize(image.getWidth(), image.getHeight());
            raster.setPosition(position);
            Shape3D text = new Shape3D(raster);
            getContextData().getShapeManager().register(overlay, text);
            ShapeManager.setCapabilities(text, overlay);
            text.clearCapability(Shape3D.ALLOW_APPEARANCE_WRITE);
            text.setPickable(false);
            Appearance appearance = new Appearance();
            AppearanceHelper.setDefaults(appearance);
            TransparencyAttributes transparencyAttributes =
                new TransparencyAttributes(TransparencyAttributes.BLENDED, 0.0f);
            appearance.setTransparencyAttributes(transparencyAttributes);
            RenderingAttributes renderingAttributes = new RenderingAttributes();
            renderingAttributes.setDepthBufferEnable(false);
            appearance.setRenderingAttributes(renderingAttributes);

            //      PointAttributes pointAttributes = new PointAttributes();
            //      pointAttributes.setPointAntialiasingEnable(false);
            //      appearance.setPointAttributes(pointAttributes);
            //      
            //      LineAttributes lineAttributes = new LineAttributes();
            //      lineAttributes.setLineAntialiasingEnable(false);
            //      appearance.setLineAttributes(lineAttributes);
            text.setAppearance(appearance);

            // :WORKAROUND: this fixes that the overlay sometimes disappears
            // behind the 3D objects
            OrderedGroup orderedGroup = new OrderedGroup();
            orderedGroup.setCapability(OrderedGroup.ALLOW_CHILDREN_READ);
            orderedGroup.setCapability(OrderedGroup.ALLOW_CHILDREN_WRITE);
            orderedGroup.addChild(text);
            branchGroup.addChild(orderedGroup);
        }
    }

    /**
     * Description of the method.
     *
     * @param overlay Description of parameter.
     * @param tuple Description of parameter.
     *
     * @return Description of the returned value.
     */
    public Vector3f compute3DCoordinate(Overlay overlay, Tuple3f tuple) {
        ContextData contextData = getContextData();
        Context context = contextData.getContext();
        Vector3f vector = new Vector3f();
        if (context.getHeight() > 0) {
            int width = context.getWidth();
            int height = context.getHeight();
            float centerX = 0.5f * width;
            float centerY = 0.5f * height;
            float dX = tuple.x - centerX;
            float dY = tuple.y - centerY;
            vector =
                new Vector3f(dX * org.srs3d.viewer.bioatlas.Parameter.aspectScaleX,
                    -dY * org.srs3d.viewer.bioatlas.Parameter.aspectScaleX,
                    -width);
            if ((overlay.getAlignment() & Overlay.ALIGN_RIGHT) != 0) {
                vector.x =
                    -vector.x -
                    org.srs3d.viewer.bioatlas.Parameter.aspectScaleX * overlay.getWidth();
            }
            if ((overlay.getAlignment() & Overlay.ALIGN_BOTTOM) != 0) {
                vector.y =
                    -vector.y +
                    org.srs3d.viewer.bioatlas.Parameter.aspectScaleY * overlay.getHeight();
            }
            vector.scale(0.2f);
        }
        return vector;
    }
}
