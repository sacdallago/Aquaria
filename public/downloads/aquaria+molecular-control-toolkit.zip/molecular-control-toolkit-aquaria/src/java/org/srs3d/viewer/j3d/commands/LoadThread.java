/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.commands;

import java.util.Hashtable;
import java.util.Vector;

import org.srs3d.viewer.objects.AbstractObject;

/**
 * Load thread.
 *
 * @author Karsten Klein
 *
 * @created April 03, 2001
 */
public class LoadThread extends Thread {
    private static LoadThread loadThread = new LoadThread();
    private Hashtable commandMap = new Hashtable();
    private Vector objectQueue = new Vector();

    /**
     * Constructor description.
     */
    private LoadThread() {
        super(LoadThread.class.toString());
        setPriority(getPriority() - 1);
        start();
    }

    /**
     * Method description.
     *
     * @param loadCommand Parameter description.
     */
    public static void schedule(LoadCommand loadCommand) {
        synchronized (loadThread.objectQueue) {
            loadThread.objectQueue.remove(loadCommand.getObject());
            loadThread.objectQueue.add(loadCommand.getObject());
            loadThread.commandMap.put(loadCommand.getObject(), loadCommand);
        }
        try {
            loadThread.interrupt();
        } catch (Throwable t) {

            // restart thread
            loadThread = new LoadThread();
            try {
                throw (t);
            } catch (Throwable e) {

                // silent; should not happen; nothing to do more
            }
        }
    }

    /**
     * Method description.
     */
    public void run() {
        AbstractObject object;
        LoadCommand loadCommand;

        // stay referenced till death of JVM
        Thread thread = this;
        boolean loaded;
        while (true) {
            while (!loadThread.objectQueue.isEmpty()) {
                synchronized (loadThread.objectQueue) {
                    loadThread.setPriority(Thread.NORM_PRIORITY);
                    object = (AbstractObject) loadThread.objectQueue.remove(0);
                    loadCommand =
                        (LoadCommand) loadThread.commandMap.remove(object);
                    loaded = loadCommand.load();
                    loadThread.setPriority(Thread.MIN_PRIORITY);
                }
                if (!loaded) {
                    schedule(loadCommand);
                }
            }

            // keep thread stack clear
            object = null;
            loadCommand = null;

            //      GCThread.runFinalization();
            //      GCThread.gc();
            yield();
            try {
                sleep(10000);
            } catch (java.lang.InterruptedException e) {

                // :SILENT EXCEPTION:
                yield();
            }
        }
    }

    /**
     * Method description.
     */
    public static void initialize() {
    }
}
