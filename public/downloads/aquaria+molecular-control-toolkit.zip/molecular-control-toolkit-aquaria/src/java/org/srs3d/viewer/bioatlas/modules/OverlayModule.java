/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.modules;

import java.awt.event.ActionEvent;

import javax.swing.JCheckBoxMenuItem;

import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.attributes.Visible;
import org.srs3d.viewer.j3d.commands.SpawnCommand;
import org.srs3d.viewer.j3d.objects.Overlay;
import org.srs3d.viewer.objects.Attribute;
import org.srs3d.viewer.objects.State;

/**
 * @author Karsten Klein
 *
 * @created May 14, 2001
 */
public class OverlayModule extends CheckModule {

    /**
     * <code>ResetModule</code> constructor.
     *
     * @param name Description of parameter.
     * @param context Description of parameter.
     */
    public OverlayModule(String name, ContextData contextData) {
        super(name, contextData);
    }

    /**
     * Description of the method.
     */
    public void updateIntern() {
        JCheckBoxMenuItem component = getCheckComponent();
        if (component != null) {
            Overlay overlay =
                getContextData().getOverlayManager().getOverlay(getName());
            if (overlay != null) {
                State.Immutable state =
                    getContextData().getStateManager().getImmutableState(overlay);
                component.setState(state.hasAttribute(
                        org.srs3d.viewer.j3d.attributes.Visible.class));
                component.setEnabled(true);
            } else {
                component.setEnabled(false);
                component.setState(false);
            }
        }
    }

    /**
     * Description of the method.
     *
     * @param e Description of parameter.
     */
    public void react(ActionEvent e) {
        Overlay overlay =
            getContextData().getOverlayManager().getOverlay(getName());
        if (overlay != null) {
            State state = getContextData().getStateManager().getState(overlay);
            if (state.hasAttribute(Visible.class)) {
                state.removeAttribute(Visible.class);
            } else {
                state.setAttribute(Attribute.getInstance(Visible.class));
            }
            getContextData().getStateManager().register(overlay, state);
            SpawnCommand spawnCommand = new SpawnCommand(getContextData());
            spawnCommand.setBranchGroup(getContextData().getContext()
                                            .getAvatarJunction().getOnBranch());
            getContextData().getStrategyManager().execute(overlay, spawnCommand);
        } else {
            JCheckBoxMenuItem component = getCheckComponent();
            if (component != null) {
                component.setEnabled(false);
                component.setState(false);
            }
        }
    }
}
