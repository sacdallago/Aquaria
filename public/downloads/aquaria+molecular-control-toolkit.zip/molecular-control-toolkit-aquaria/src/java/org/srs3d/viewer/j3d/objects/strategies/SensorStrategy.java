/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.objects.strategies;

import javax.media.j3d.Appearance;
import javax.media.j3d.PolygonAttributes;

import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.Reaction;
import org.srs3d.viewer.j3d.commands.ColorCommand;
import org.srs3d.viewer.j3d.commands.ExpandCommand;
import org.srs3d.viewer.j3d.commands.LabelCommand;
import org.srs3d.viewer.j3d.commands.RegisterCommand;
import org.srs3d.viewer.j3d.objects.strategies.reactions.EmptyReaction;
import org.srs3d.viewer.objects.Command;

/**
 * @author Karsten Klein
 *
 * @created April 03, 2001
 */
public class SensorStrategy extends AbstractStrategy {

    /**
     * Constructor description.
     */
    public SensorStrategy() {
        register(RegisterCommand.class, EmptyReaction.getSharedInstance());
        register(ExpandCommand.class, EmptyReaction.getSharedInstance());
        register(LabelCommand.class, EmptyReaction.getSharedInstance());
        register(ColorCommand.class, new ColorReaction());
    }

    /**
     * Class description.
     *
     * @author Karsten Klein, LION bioscience AG
     */
    public class ColorReaction implements Reaction {

        /**
         * Method description.
         *
         * @param command Parameter description.
         */
        public void execute(Command command) {
            ColorCommand colorCommand = (ColorCommand) command;
            ContextData contextData = colorCommand.getContextData();
            command.execute();
            Appearance appearance =
                colorCommand.getContextData().getAppearanceManager()
                            .getAppearance(command.getObject());

            // :FIXME: the appearance helper should provide a method for that purpose
            // modify polygon attributes
            PolygonAttributes pa = new PolygonAttributes();
            pa.setPolygonOffset(10);
            appearance.setPolygonAttributes(pa);
            ColorCommand.apply(colorCommand.getContextData(),
                command.getObject(), appearance);
        }
    }
}
