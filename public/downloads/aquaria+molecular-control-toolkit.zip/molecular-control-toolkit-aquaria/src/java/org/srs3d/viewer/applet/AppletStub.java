/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.applet;

import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Properties;

import org.srs3d.viewer.bioatlas.Parameter;
import org.srs3d.viewer.swing.StatusDisplay;
import org.srs3d.viewer.util.ExceptionHandler;

/**
 * @author Karsten Klein
 *
 * @created March 20, 2001
 */
public class AppletStub implements java.applet.AppletStub {
    private HashMap parameterMap = new HashMap();
    private java.applet.AppletContext appletContext = new AppletContext();
    private java.applet.AppletStub appletStub = null;

    /**
     * Constructor description.
     *
     * @param appletStub Parameter description.
     */
    public AppletStub(java.applet.AppletStub appletStub) {
        this.appletStub = appletStub;
        appletContext = appletStub.getAppletContext();
    }

    /**
     * Constructor description.
     */
    public AppletStub() {
        parameterMap.put("toolbar", "off");
        parameterMap.put("statusbar", "on");
        parameterMap.put("expertMode", "on");
        parameterMap.put("annotationView", "on");
        parameterMap.put("sequenceView", "on");
    }

    /**
     * Method description.
     *
     * @param statusDisplay Parameter description.
     */
    public void setStatusDisplay(StatusDisplay statusDisplay) {
        ((AppletContext) appletContext).setStatusDisplay(statusDisplay);
    }

    /**
     * Method description.
     *
     * @param width Parameter description.
     * @param height Parameter description.
     */
    public void appletResize(int width, int height) {
        if (appletStub != null) {
            appletStub.appletResize(width, height);
        }
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public java.applet.AppletContext getAppletContext() {
        return appletContext;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public URL getCodeBase() {
        if (appletStub != null) {
            return appletStub.getCodeBase();
        } else {
            URL url = null;
            try {
                url = new URL(getParameter("codeBaseUrl"));
            } catch (MalformedURLException e) {
                ExceptionHandler.handleException(e,
                    ExceptionHandler.SILENT_IN_RELEASE, this);
                try {
                    url = new URL("file:///" + System.getProperty("user.dir") +
                            "/");
                } catch (MalformedURLException ex) {
                    ExceptionHandler.handleException(e,
                        ExceptionHandler.VISIBLE_IN_RELEASE, this);
                }
            }
            return url;
        }
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public URL getDocumentBase() {
        if (appletStub != null) {
            return appletStub.getCodeBase();
        } else {
            return getCodeBase();
        }
    }

    /**
     * Method description.
     *
     * @param name Parameter description.
     *
     * @return Return description.
     */
    public String getParameter(String name) {
        String parameter = (String) parameterMap.get(name);
        if (parameter == null && appletStub != null) {
            return appletStub.getParameter(name);
        }
        return parameter;
    }

    /**
     * Method description.
     *
     * @param args Parameter description.
     */
    public void createParameterMap(String[] args) {
        String arg;
        int index;
        for (int i = 0; i < args.length; i++) {
            arg = args[i];
            index = arg.indexOf("=");
            if (index != -1) {
                parameterMap.put(arg.substring(0, index),
                    arg.substring(index + 1));
            }
        }
        loadParameters();
    }

    /**
     * Method description.
     */
    public void loadParameters() {

        // see whether a parameter file url is specified
        loadParameterFileUrl();

        // in addiotion a local file could be specified
        loadParameterFile();
    }

    /**
     * Method description.
     */
    public void loadParameterFileUrl() {
        String parameterFileUrl = getParameter("parameterFileUrl");
        if (parameterFileUrl != null) {
            try {
                URL url =
                    Parameter.supplementUrl(getCodeBase(), parameterFileUrl);
                InputStream in = url.openStream();
                Properties p = readProperties(in);
                parameterMap.putAll(p);
                in.close();
            } catch (Exception e) {
                ExceptionHandler.handleException(e);
            }
        }
    }

    /**
     * Method description.
     */
    public void loadParameterFile() {
        String parameterFile = getParameter("parameterFile");
        if (parameterFile != null) {
            Properties p = readProperties(parameterFile);
            parameterMap.putAll(p);
        }
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public boolean isActive() {
        if (appletStub != null) {
            return appletStub.isActive();
        }
        return true;
    }

    /**
     * Method description.
     *
     * @param parameter Parameter description.
     * @param value Parameter description.
     */
    public void setParameter(String parameter, String value) {
        parameterMap.put(parameter, value);
    }

    /**
     * Method description.
     *
     * @param filename Parameter description.
     *
     * @return Return description.
     */
    public Properties readProperties(String filename) {
        try {
            return readProperties(new java.io.FileInputStream(filename));
        } catch (Exception e) {
            ExceptionHandler.handleException(e);
        }

        // return empty properties instead of null
        return new Properties();
    }

    /**
     * Method description.
     *
     * @param in Parameter description.
     *
     * @return Return description.
     */
    public static Properties readProperties(java.io.InputStream in) {
        Properties properties = new Properties();
        try {
            properties.load(in);
            Iterator iterator = properties.keySet().iterator();
            String key;
            String parameter;
            while (iterator.hasNext()) {
                key = (String) iterator.next();
                parameter = properties.getProperty(key);
                parameter = parameter.replace('\"', ' ').trim();
                properties.setProperty(key, parameter);
            }
        } catch (Exception e) {
            ExceptionHandler.handleException(e);
        }
        return properties;
    }
}
