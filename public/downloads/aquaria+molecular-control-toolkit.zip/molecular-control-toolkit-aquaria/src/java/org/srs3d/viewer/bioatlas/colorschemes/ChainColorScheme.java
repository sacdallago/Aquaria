/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.colorschemes;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeSet;
import java.util.Vector;

import javax.media.j3d.Appearance;
import javax.vecmath.Color3f;

import org.srs3d.viewer.bioatlas.objects.Chain;
import org.srs3d.viewer.bioatlas.objects.Layer;
import org.srs3d.viewer.j3d.AbstractColorScheme;
import org.srs3d.viewer.j3d.AppearanceHelper;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.objects.ObjectManager;
import org.srs3d.viewer.vecmath.CubicBezierCurve3f;

/**
 * The <code>ChainColorScheme</code> represents a special color scheme. Every chain is
 * meant to receive its own color in order to be distinguishable. The implementation
 * uses object indentification scheme to generate colors that enable the user to
 * distinguish between all the shown objects. To ensure proper function, you have to
 * register all objects before appying the color scheme using the register(
 * AbstractObject ) method. Or simply apply the scheme twice. The unregisted objects
 * will automatically be registered when before they are modified. Note that the colors
 * of the objects can change, when more and more objects are displayed. The color scheme
 * inherits additional behavior from its base class CPKColorScheme which applies for
 * ligands, atoms and bonds.
 *
 * @author Karsten Klein
 *
 * @created March 20, 2001
 */
public class ChainColorScheme extends AbstractColorScheme {

    /** The cubic bezier curve interpolates the colors. */
    private static CubicBezierCurve3f colorCurve = null;

    /** This map collects all the registed objects. */
    private Hashtable indexMap = new Hashtable();

    /**
     * <code>ChainColorScheme</code> contructor.
     *
     * @param contextData Description of parameter.
     */
    public ChainColorScheme(ContextData contextData) {
        super(contextData);
        if (colorCurve == null) {

            // we use a cubic bezier curve for interpolation of the colors
            colorCurve = new CubicBezierCurve3f();
            ArrayList colors = new ArrayList();
            float max = 0.9f;
            float max2 = 0.9f;
            float min = 0.2f;
            float min2 = 0.2f;

            // blue is perceived darker, thus we saturate it a little more than
            // the other colors
            colors.add(new Color3f(0.3f, 0.3f, 1));
            colors.add(new Color3f(min, max2, max2));
            colors.add(new Color3f(min2, max, min2));
            colors.add(new Color3f(max2, max2, min));
            colors.add(new Color3f(max, min2, min2));
            colorCurve.setCoordinates(colors);
        }

        //    indexMap.put( getClass(), new HashMap() );
    }

    /**
     * Gets the <code>information</code> attribute of the <code>ChainColorScheme</code>
     * object.
     *
     * @return The <code>information</code> value.
     */
    public Map getInformation(Map map) {
        if (map == null) {
            map = new HashMap();
        }
        TreeSet treeSet = new TreeSet();
        Iterator iterator = indexMap.keySet().iterator();
        Object object;
        int index;
        Color3f color;
        while (iterator.hasNext()) {
            object = iterator.next();
            color = computeColor(object);
            color.scale(getLegendColorScale());
            map.put(object.toString(), color);
            treeSet.add(object.toString());
        }
        Vector order = new Vector(treeSet);
        map.put("NAME", "Chain");
        map.put("ORDER", order);
        return map;
    }

    /**
     * Method description.
     *
     * @param object Parameter description.
     *
     * @return Return description.
     */
    public Object computeIdentifier(AbstractObject object) {
        return computeIdentifier(getContextData(), object);
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     * @param object Parameter description.
     *
     * @return Return description.
     */
    public static Object computeIdentifier(ContextData contextData,
        AbstractObject object) {

        // the scheme applies for chains and residues (in chain representation)
        ObjectManager objectManager = contextData.getObjectManager();
        Collection set = new HashSet();
        objectManager.getUpAssociations(object, set);
        set.add(object);
        Collection layers = new HashSet();
        ObjectManager.extract(set, layers, Layer.class);
        if (!layers.isEmpty()) {
            Collection chains = new HashSet();
            ObjectManager.extract(set, chains, Chain.class);
            if (!chains.isEmpty()) {
                String identifier = null;
                Chain chain = (Chain) chains.iterator().next();
                if (!chain.isLigand()) {
                    if (chain.getId() != Chain.INVALID_ID) {
                        identifier = chain.getId() + " ";
                    } else {
                        identifier = "";
                    }
                    if (chain.getCompound() != null) {
                        if (chain.getCompound().getMolecule() != null) {
                            identifier += chain.getCompound().getMolecule();
                        }
                        if (chain.getCompound().getFragment() != null) {
                            identifier += " " +
                            chain.getCompound().getFragment();
                        }
                    }
                    if (identifier.trim().equals("")) {
                        Layer layer = (Layer) layers.iterator().next();
                        if (layer.getId() != null) {
                            identifier = layer.getId();
                        }
                    } else {
                        Layer layer = (Layer) layers.iterator().next();
                        if (layer.getId() != null) {
                            identifier = layer.getId() + " " + identifier;
                        } else {
                            identifier = null;
                        }
                    }
                    if (identifier.trim() == "") {
                        return null;
                    } else {
                        return identifier;
                    }
                }
            }
        }
        return null;
    }

    /**
     * Description of the method.
     *
     * @param object Description of parameter.
     * @param appearance Description of parameter.
     *
     * @return Description of the returned value.
     */
    public boolean modify(AbstractObject object, Appearance appearance) {
        Object identifier = computeIdentifier(object);
        if (identifier != null) {

            // register the identifier (if not registered yet)
            register(identifier);
            AppearanceHelper.enableVertexColors(appearance, false);
            AppearanceHelper.modifyAppearance(appearance,
                computeColor(identifier));
            return true;
        }

        // modify ligand components using the base class method
        return false;
    }

    /**
     * Maps a string to a certain color.
     *
     * @param object Description of parameter.
     *
     * @return <code>Color3f</code> - the color mapped to the specified char.
     */
    public Color3f computeColor(Object object) {
        float parameter = ((Float) indexMap.get(object)).floatValue();
        Color3f color = new Color3f();
        color.set(colorCurve.computePoint(parameter));
        color.scale(getColorScale());
        return color;
    }

    /**
     * Description of the method Registers a string to the static object list.
     *
     * @param object Description of parameter.
     */
    public void register(Object object) {
        if (!indexMap.containsKey(object)) {
            float parameter = 0;
            int numerator = indexMap.size();
            if (numerator != 0) {
                int exp = (int) (Math.log(numerator) / Math.log(2));
                int denominator = (int) Math.pow(2, exp);
                if (numerator != denominator) {
                    exp++;
                    denominator *= 2;
                }
                numerator -= (denominator / 2);
                numerator = 2 * numerator - 1;
                parameter = numerator;
                parameter /= denominator;
            }
            indexMap.put(object, new Float(parameter));
        }
    }
}
