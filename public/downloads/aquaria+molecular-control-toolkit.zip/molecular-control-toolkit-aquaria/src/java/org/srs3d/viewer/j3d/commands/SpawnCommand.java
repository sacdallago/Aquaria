/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.commands;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;

import javax.media.j3d.BranchGroup;

import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.Spawner;
import org.srs3d.viewer.j3d.SpawnerManager;
import org.srs3d.viewer.j3d.attributes.Expanded;
import org.srs3d.viewer.j3d.attributes.Visible;
import org.srs3d.viewer.j3d.creators.GeometryCreator;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.objects.ObjectManager;
import org.srs3d.viewer.objects.State;
import org.srs3d.viewer.objects.StrategyManager;
import org.srs3d.viewer.util.ExceptionHandler;
import org.srs3d.viewer.util.Log;

/**
 * <code>SpawnCommand</code>. <code>SpawnCommand</code> has different properties than the
 * other subclasses of objects command, since it is one command that directly has to
 * deal with Java3D and the scene graph. Therefore the object treatment has to adhere to
 * some guidelines. Executing a <code>SpawnCommand</code> on a objects will
 * automatically propagate the command through the hierarchy. It's not recommended to
 * execute the <code>SpawnCommand</code> on a set of objects that is just a subtree in
 * the hierarchy, since objects will be spawned more than one time. Before spawning a
 * set of objects use the searchSpawners(...) method provided by this class.
 *
 * @author Karsten Klein
 *
 * @created April 03, 2001
 */
public class SpawnCommand extends ObjectCommand {
    private static final Log log = new Log(SpawnCommand.class);

    /** Description of the field. */
    public static boolean isVerbose = false;

    /**
     * this flag inidactes, whether a non spawner geometry will be created (false) or
     * not. The execute() method uses this flag to enable their children that are
     * non-spawners to draw their geometry.
     */
    private boolean directFlag = true;
    private BranchGroup branchGroup = null;

    /**
     * <code>SpawnCommand</code> constructor.
     *
     * @param contextData Description of parameter.
     */
    public SpawnCommand(ContextData contextData) {
        super(contextData);
    }

    /**
     * Sets the <code>BranchGroup</code> attribute of the <code>Spawn</code> object.
     *
     * @param branchGroup The new <code>BranchGroup</code> value.
     */
    public void setBranchGroup(BranchGroup branchGroup) {
        this.branchGroup = branchGroup;
    }

    /**
     * Description of the method.
     */
    public void execute() {
        if (isVerbose) {
            long time = System.currentTimeMillis();
            performExecute(getObject());
            time = System.currentTimeMillis() - time;
            log.debug("spawning object " + getObject());
            log.debug("in context " + getContextData().getContext());
            log.debug("(" + time + "ms)");
            if (!Thread.currentThread().getThreadGroup().getName()
                         .equalsIgnoreCase("Java3D")) {
                log.debug("spawning not from Java 3D thread: " + getObject());
            }
        } else {
            performExecute(getObject());
        }
    }

    /**
     * Description of the method.
     *
     * @return Description of the returned value.
     */
    public boolean canCancel() {
        return true;
    }

    /**
     * Description of the method.
     *
     * @param object Description of parameter.
     */
    private void performExecute(AbstractObject object) {
        try {
            Spawner spawner =
                getContextData().getSpawnerFactory().getSpawner(object);
            State.Immutable state =
                getContextData().getStateManager().getImmutableState(object);
            BranchGroup branchGroup = this.branchGroup;
            if (spawner != null) {

                // remove old geometry
                // :NOTE: this can REALLY only be done for spawners which have no composed
                // geometries (e.g. bonds produce atom geometry)
                getContextData().getShapeManager().remove(object);

                // a object can be spawned when it has the Visible attribute
                if (state.hasAttribute(Visible.class)) {

                    // spawn the objects geometry, but don't finalize the spawned node
                    spawner.spawn(getContextData(), false);
                } else {

                    // built spawner without creating the geometry; object is hidden
                    spawner.deleteInternalBranch(getContextData());
                    spawner.createInternalBranch();
                    if (isVerbose) {
                        log.debug("empty geometry spawner spawned for " +
                            object);
                    }
                }

                // spawn the objects children even if the parent is NOT visible
                // obly objects that are no spawner are attached
                if (state.hasAttribute(Expanded.class)) {
                    spawnChildren(object, spawner);
                }

                // check for orphan spawner
                if (branchGroup == null) {
                    if (getParent() != null) {
                        Collection spawners = new HashSet();
                        spawners.add(getParent());
                        searchSpawners(getContextData(), spawners);
                        if (!spawners.isEmpty()) {
                            SpawnerManager spawnerManager =
                                getContextData().getSpawnerManager();
                            branchGroup =
                                (BranchGroup) spawnerManager.getSpawner((AbstractObject) spawners.iterator()
                                                                                                 .next());
                        }
                    }
                }
                if (branchGroup != null) {

                    // reattach spawner at the provided BranchGroup instance
                    spawner.detach();
                    branchGroup.addChild(spawner);
                } else {

                    // the spawner will not be reattached, in the normal case this
                    // is fine if the spawner was attached before
                }
                if (directFlag) {
                    spawner.compile();
                }

                // become life
                spawner.completeSpawn();
            } else {

                // this is a none spawner object
                if (!directFlag) {
                    if (branchGroup != null) {

                        // :NOTE: recently we used a new local bracnhgroup that had to be
                        // added to the current branchGroup, because the responsibilities
                        // were not resolved correctly. Checkback with version 1.20 in the
                        // cvs repository if problems arise.
                        // a object is spawned when it has the Visible attribute
                        if (state.hasAttribute(Visible.class)) {
                            GeometryCreator geometryCreator =
                                getContextData().getGeometryCreatorFactory()
                                    .getGeometryCreator(object);
                            if (geometryCreator != null) {

                                // this is done by the factory, already
                                // geometryCreator.modifyAttributes( object );
                                geometryCreator.create(object, branchGroup);
                            }
                        }

                        // spawn the objects children even if the parent is NOT visible
                        // only objects that are no spawner are attached
                        if (state.hasAttribute(Expanded.class)) {
                            spawnChildren(object, branchGroup);
                        }
                    } else {

                        // :FIXME: this procedure could respawn already spawned spawners
                        // and thus could produce large overhead.
                        HashSet spawners = new HashSet();
                        spawners.add(object);
                        searchSpawners(getContextData(), spawners);
                        getContextData().getStrategyManager().execute(spawners,
                            this);
                        log.debug("alert: producing spawning overhead.");
                    }
                } else {
                    log.debug("no spawning for " + object);
                }
            }
        } catch (Exception e) {
            ExceptionHandler.handleException(e, ExceptionHandler.SILENT_IN_DEBUG);
        }
    }

    /**
     * Description of the method.
     *
     * @param branchGroup Description of parameter.
     * @param object Description of parameter.
     */
    private void spawnChildren(AbstractObject object, BranchGroup branchGroup) {
        if (branchGroup != null) {
            StrategyManager strategyManager =
                getContextData().getStrategyManager();

            // spawn the objects further down the hierarchy
            Collection set = new ArrayList();
            object.getAllObjects(set);
            Iterator iterator = set.iterator();
            AbstractObject child;
            RegisterCommand register = new RegisterCommand(getContextData());
            register.setParent(object);
            SpawnCommand spawnCommand = new SpawnCommand(getContextData());
            spawnCommand.setParent(object);
            spawnCommand.setBranchGroup(branchGroup);
            spawnCommand.directFlag = false;
            Spawner spawner = null;
            while (iterator.hasNext()) {
                child = (AbstractObject) iterator.next();
                if (child == null) {
                    log.debug("child is null. Check relationships of " +
                        object);
                } else {
                    strategyManager.execute(child, register);
                    strategyManager.execute(child, spawnCommand);
                }
            }
        }
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     * @param objects Description of parameter.
     */
    public static void searchSpawners(ContextData contextData, Collection set) {
        SpawnerManager spawnerManager = contextData.getSpawnerManager();
        ObjectManager objectManager = contextData.getObjectManager();
        Iterator iterator;
        AbstractObject object;
        Spawner spawner;
        if (set.size() > 1) {
            Collection objects = new HashSet(set);
            set.clear();
            objectManager.collapseUpExtended(objects, set);
        }
        Collection parents = null;
        boolean found = true;
        while (found) {
            found = false;
            iterator = set.iterator();
            while (iterator.hasNext()) {
                object = (AbstractObject) iterator.next();
                spawner = contextData.getSpawnerFactory().getSpawner(object);
                if (spawner == null) {
                    if (parents == null) {
                        parents = new HashSet();
                    }
                    objectManager.getDirectUpAssociations(object, parents);
                    iterator.remove();
                    found = true;
                }
            }
            if (found) {
                if (parents != null) {
                    set.addAll(parents);
                    parents.clear();
                }
            }
        }
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public String getDescription() {
        return "spawn command";
    }
}
