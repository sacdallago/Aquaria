/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.annotation.visitors;

import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Vector;

import org.srs3d.viewer.annotation.objects.Alignment;
import org.srs3d.viewer.annotation.objects.AnnotationContainer;
import org.srs3d.viewer.annotation.objects.AnnotationUnit;
import org.srs3d.viewer.annotation.objects.ChainAnnotation;
import org.srs3d.viewer.annotation.objects.FeatureUnit;
import org.srs3d.viewer.bioatlas.objects.Annotation;
import org.srs3d.viewer.bioatlas.objects.Residue;
import org.srs3d.viewer.objects.ObjectContainer;
import org.srs3d.viewer.objects.ObjectManager;
import org.srs3d.viewer.util.SetUtility;

/**
 * Creates and adds all AnnotationUnits to AnnotationContainer
 *
 * @author Christian Zofka
 *
 * @created December 19, 2001
 */
public class AnnotationUnitCreator {
    private AnnotationContainer annotationContainer = null;
    private boolean isExtending = false;

    /**
     * <code>AnnotationUnitCreator</code> constructor.
     *
     * @param container Description of parameter.
     */
    public AnnotationUnitCreator(AnnotationContainer container,
        boolean isExtending) {
        annotationContainer = container;
        this.isExtending = isExtending;
    }

    /**
     * Description of the method.
     *
     * @param objectContainer Description of parameter.
     */
    public void visit(ObjectContainer objectContainer) {
        Iterator iterator;
        Alignment alignment;

        // collect annotations
        Collection annotations = new Vector();
        ObjectManager.extract(objectContainer.getObjects(), annotations,
            org.srs3d.viewer.bioatlas.objects.Annotation.class);
        Iterator annotationIterator;
        Annotation annotation;
        AnnotationUnit annotationUnit;

        // retrieve alignments
        Collection alignments = annotationContainer.getAlignments();
        if (alignments != null) {

            // iterator over all alignments
            iterator = alignments.iterator();
            while (iterator.hasNext()) {
                alignment = (Alignment) iterator.next();

                // iterator over all annotations
                annotationIterator = annotations.iterator();
                while (annotationIterator.hasNext()) {

                    // add all annotations to the alignment (as annotation unit)
                    annotation = (Annotation) annotationIterator.next();
                    annotationUnit = new AnnotationUnit(annotation);
                    alignment.getAnnotationUnits().add(annotationUnit);
                }

                // removes wrong assigned annotation units
                removeInappropriateAnnotations(alignment, annotationContainer,
                    isExtending);
            }

            // organize annotation units
            finalizeAnnotationUnits(annotationContainer);
            org.srs3d.viewer.bioatlas.modules.AnnotationModule.extendAnnotations(annotations,
                annotationContainer);
        }
    }

    /**
     * Optimizes annotationUnits by deleting empty lines, preserves the original order
     *
     * @param annotationContainer Description of parameter.
     */
    public static void finalizeAnnotationUnits(
        AnnotationContainer annotationContainer) {
        if (annotationContainer.getAlignmentCount() > 0) {
            Iterator iterator;
            Alignment alignment;
            AnnotationUnit annotationUnit;
            Vector annotationUnits;
            Vector optimizedAnnotationUnits;
            int[] hits = countAnnotations(annotationContainer);
            iterator = annotationContainer.getAlignments().iterator();
            while (iterator.hasNext()) {

                // stack annotations at bottom
                alignment = (Alignment) iterator.next();
                int lastNullPosition = -1;
                annotationUnits = alignment.getAnnotationUnits();
                for (int i = annotationUnits.size() - 1; i >= 0; i--) {
                    if (hits[i] == 1) {
                        if (annotationUnits.elementAt(i) != null) {
                            if (lastNullPosition != -1) {
                                annotationUnits.setElementAt(annotationUnits.elementAt(
                                        i), lastNullPosition);
                                annotationUnits.setElementAt(null, i);
                                lastNullPosition--;
                            }
                        } else if (lastNullPosition == -1) {
                            lastNullPosition = i;
                        }
                    } else {
                        lastNullPosition = -1;
                    }
                }
            }

            // delete empty lines
            hits = countAnnotations(annotationContainer);
            for (int i = hits.length - 1; i >= 0; i--) {
                if (hits[i] == 0) {
                    iterator = annotationContainer.getAlignments().iterator();
                    while (iterator.hasNext()) {

                        // stack annotations at bottom
                        alignment = (Alignment) iterator.next();
                        annotationUnits = alignment.getAnnotationUnits();
                        annotationUnits.remove(i);
                    }
                }
            }
        }
    }

    /**
     * Removes annotations from the alignment that don't match the alignment residues.
     *
     * @param alignment Aligment to examine.
     */
    public static void removeInappropriateAnnotations(Alignment alignment,
        AnnotationContainer annotationContainer, boolean isExtend) {
        Map annotationMap = alignment.getAnnotationUnitMap();
        HashSet objects = new HashSet();
        Iterator iterator;

        // collect all annotation objects
        AnnotationUnit annotationUnit;
        ChainAnnotation chainAnnotation;
        FeatureUnit featureUnit;
        boolean found;
        Vector annotationUnits = alignment.getAnnotationUnits();
        for (int i = 0; i < annotationUnits.size(); i++) {
            annotationUnit = (AnnotationUnit) annotationUnits.elementAt(i);
            found = false;
            objects.clear();

            // collect all annotation features
            iterator = annotationUnit.getFeatureUnits().iterator();
            while (iterator.hasNext()) {
                featureUnit = (FeatureUnit) iterator.next();
                org.srs3d.viewer.objects.ObjectManager.extract(featureUnit.getFeature()
                                                                          .getObjects(),
                    objects, Residue.class);
            }

            // check for intersections
            iterator = alignment.getChainAnnotations().iterator();
            while (!found && iterator.hasNext()) {
                chainAnnotation = (ChainAnnotation) iterator.next();
                if (chainAnnotation != null) {
                    Vector gapSequence = chainAnnotation.getGapSequence();
                    if (SetUtility.hasIntersection(gapSequence, objects)) {
                        annotationMap.put(annotationUnit, chainAnnotation);
                        found = true;
                    }
                }
            }
            if (!found) {
                if (isExtend) {
                    extendObjects(objects, annotationContainer.getAlignmentMap());

                    // do it again
                    iterator = alignment.getChainAnnotations().iterator();
                    while (!found && iterator.hasNext()) {
                        chainAnnotation = (ChainAnnotation) iterator.next();
                        if (chainAnnotation != null) {
                            Vector gapSequence =
                                chainAnnotation.getGapSequence();
                            if (SetUtility.hasIntersection(gapSequence, objects)) {
                                annotationMap.put(annotationUnit,
                                    chainAnnotation);
                                found = true;
                            }
                        }
                    }
                }
            }

            // replace the annotation with null
            if (!found) {

                // the appropriate part might have been merged wit a structure
                annotationUnits.setElementAt(null, i);
            }
        }
    }

    /**
     * Counts the annotationUnits of all alignments in a (horizontal) row
     *
     * @param annotationContainer Description of parameter.
     *
     * @return array of counts per row
     */
    private static int[] countAnnotations(
        AnnotationContainer annotationContainer) {
        int size =
            ((Alignment) annotationContainer.getAlignments().iterator().next()).getAnnotationUnits()
             .size();
        int[] hits = new int[size];
        Alignment alignment;
        Vector annotationUnits;
        Iterator iterator = annotationContainer.getAlignments().iterator();
        while (iterator.hasNext()) {

            // count the empty slots per (horizontal) line
            alignment = (Alignment) iterator.next();
            annotationUnits = alignment.getAnnotationUnits();
            for (int i = 0; i < annotationUnits.size(); i++) {
                if (annotationUnits.elementAt(i) != null) {
                    hits[i]++;
                }
            }
        }
        return hits;
    }

    private static void extendObjects(Collection objects, Map alignmentMap) {
        HashSet extension = new HashSet(objects.size());
        Iterator iterator = objects.iterator();
        Collection alignedResidues;
        while (iterator.hasNext()) {
            alignedResidues = (Collection) alignmentMap.get(iterator.next());
            if (alignedResidues != null) {
                extension.addAll(alignedResidues);
            }
        }
        objects.addAll(extension);
    }
}
