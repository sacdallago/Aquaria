/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.modules;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collection;
import java.util.StringTokenizer;

import org.srs3d.viewer.bioatlas.Parameter;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.util.ExceptionHandler;
import org.srs3d.viewer.util.Log;

/**
 * Implentation of the abstract RestoreModule class. This special implementation
 * concentrates on writing the current state efficiently as a file. Note that the
 * provided id that sereves as identifier is used as filename.
 *
 * @author Karsten Klein
 *
 * @created February 06, 2002
 */
public class FileRestoreModule extends StreamRestoreModule {
    private static final Log log = new Log(FileRestoreModule.class);

    /**
     * <code>RestoreModule</code> constructor.
     *
     * @param name Description of parameter.
     * @param contextData Description of parameter.
     * @param id Description of parameter.
     */
    public FileRestoreModule(String name, ContextData contextData, String id) {
        super(name, contextData, id);
    }

    /**
     * Part of the RestoreModule imposed live-cycle. Reading an operation store
     * automatically remove redundant operations as long as the RuntimeTestMode was not
     * activated.
     */
    public void read() {
        String filename = getId();
        try {
            Collection operations;
            ArrayList operationXmlTags = new ArrayList(10);
            ArrayList otherXmlTags = new ArrayList(10);
            File file = new File(filename);

            // try to read start script
            String startScriptUrlString =
                getContextData().getAppletStub().getParameter("startScriptUrl");
            log.info("Start script url: " + startScriptUrlString);
            if (startScriptUrlString != null) {
                StringTokenizer tokenizer =
                    new StringTokenizer(startScriptUrlString, "{},; ");
                URL url = null;
                String scriptUrl;
                while (tokenizer.hasMoreTokens()) {
                    scriptUrl = tokenizer.nextToken();
                    try {
                        log.info("Loading script " + scriptUrl);
                        url = Parameter.supplementUrl(getContextData()
                                                          .getAppletStub()
                                                          .getCodeBase(),
                                scriptUrl);
                        InputStream in = url.openStream();
                        read(in);
                        in.close();
                    } catch (Exception e) {
                        log.error(e, e);
                        ExceptionHandler.handleException(e,
                            ExceptionHandler.VISIBLE_IN_RELEASE, this);
                    }
                }
            }
            log.info("Loading user script " + filename);

            // the original start script should be included in the user script
            FileInputStream in = new FileInputStream(filename);
            read(in);
            in.close();
        } catch (Exception e) {
            ExceptionHandler.handleException(e,
                ExceptionHandler.SILENT_IN_RELEASE, this);
        }
    }

    /**
     * Part of the life-cycle of the RestoreModule. The state is to be saved.
     */
    public void save(boolean isConfirm) {
        if (canSave()) {
            if (confirmSave()) {
                try {
                    String filename = getId();
                    try {
                        FileOutputStream outStream =
                            new FileOutputStream(filename);
                        write(outStream);
                        outStream.close();
                    } catch (Exception e) {
                        ExceptionHandler.handleException(e,
                            ExceptionHandler.SILENT_IN_RELEASE, this);
                    }
                    if (isConfirm) {
                        confirmSaved();
                    }
                } catch (Exception e) {
                    ExceptionHandler.handleException(e,
                        ExceptionHandler.SILENT_IN_RELEASE, this);
                }
            }
        }
    }

    /**
     * Checks if the current state can be saved.
     *
     * @return Boolean indicating the ability to save the current state.
     */
    public boolean canSave() {
        return getViewManager().getId() != null;
    }
}
