/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.loaders.pdb;

import org.srs3d.viewer.bioatlas.objects.Chain;
import org.srs3d.viewer.bioatlas.objects.Turn;

/**
 * This class parses strings for pdb TURN tags and tranfers/builts the appropriate
 * datastructure in a <code>ObjectContainer</code> .
 *
 * @author Karsten Klein
 *
 * @created January 20, 2001
 */
public class PdbTurnParser extends PdbSubchainParser {

    /** Description of the field */
    public static final String TAG = new String("TURN  ");

    /** Description of the field */
    private String turnId = null;

    /** Description of the field */
    private int turnSerial = Turn.INVALID_SERIAL;

    /**
     * Description of the method.
     *
     * @param string Description of parameter.
     */
    public void create(String string) {
        clear();
        turnSerial = extractInt(string, 7, 10);
        turnId = extractString(string, 11, 14, true);
        chainId = extractChar(string, 19);
        initialResidueName = extractString(string, 15, 18);
        initialResidueId = extractInt(string, 20, 24);
        initialResidueICode = extractChar(string, 24);
        endResidueName = extractString(string, 26, 29);
        endResidueId = extractInt(string, 31, 35);
        endResidueICode = extractChar(string, 35);
    }

    /**
     * Visits a chain. This method adds a turn subchain to the chain if the turn is
     * defacto part of the chain.
     *
     * @param chain Description of parameter.
     */
    public void visit(Chain chain) {
        super.visit(chain);
        Turn turn = new Turn();
        visit(turn, chain);
    }

    /**
     * Visits the turn and the chain. This method adds a turn subchain to the chain if
     * the turn is defacto part of the chain.
     *
     * @param turn Description of parameter.
     * @param chain Description of parameter.
     */
    public void visit(Turn turn, Chain chain) {
        super.visit(turn, chain);
        turn.setId(turnId);
        turn.setSerial(turnSerial);
    }

    /**
     * Description of the method.
     */
    public void clear() {
        super.clear();
        turnId = null;
        turnSerial = Turn.INVALID_SERIAL;
    }
}
