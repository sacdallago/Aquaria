/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.modules;

import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.HashSet;

import javax.media.j3d.Transform3D;
import javax.vecmath.Matrix3f;
import javax.vecmath.Matrix4f;

import org.srs3d.viewer.bioatlas.Application;
import org.srs3d.viewer.bioatlas.Capture;
import org.srs3d.viewer.bioatlas.styles.Style;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.behaviors.UpdateBehavior;
import org.srs3d.viewer.j3d.behaviors.dispatcher.Dispatch;
import org.srs3d.viewer.objects.Operation;

/**
 * @author Karsten Klein
 *
 * @created May 14, 2001
 */
public class ResetModule extends ProcessModule {
    public static final String RESET_OPERATION = "RESET";
    private String name;
    private Application application;

    /**
     * <code>ResetModule</code> constructor.
     *
     * @param name Description of parameter.
     * @param applet Description of parameter.
     */
    public ResetModule(String name, ContextData contextData,
        Application application) {
        super(name, contextData, false, false);
        this.application = application;

        // register ResetOperationStore operation
        Dispatch dispatch =
            new Dispatch() {
                public void dispatch(ContextData contextData,
                    Operation operation) {
                    reset();
                }
            };
        ArrayList dispatches = new ArrayList(1);
        dispatches.add(dispatch);
        getContextData().getDispatcher().registerDispatches(RESET_OPERATION,
            dispatches);
    }

    /**
     * Description of the method.
     *
     * @param e Description of parameter.
     */
    public void process(ActionEvent e) {
        reset();
    }

    /**
     * Description of the method.
     */
    public void reset() {
        getContextData().getContext().addUpdateCallback(new UpdateBehavior.Callback() {
                public void execute() {
                    HashSet activeAnnotations = new HashSet();
                    AnnotationModule.getActiveAnnotations(getContextData(),
                        activeAnnotations);
                    FeatureModule.deactivateAnnotations(getContextData(),
                        activeAnnotations);

                    // readjust transform
                    Transform3D transform =
                        getContextData().getContext()
                            .getViewingPlatformTransform();
                    Matrix4f oldMatrix = new Matrix4f();
                    transform.get(oldMatrix);
                    Matrix3f matrix = new Matrix3f();
                    matrix.setIdentity();
                    oldMatrix.setRotation(matrix);
                    transform.set(oldMatrix);
                    getContextData().getContext().setViewingPlatformTransform(transform);
                }
            });
        getContextData().getContext().waitForUpdate();
        Operation operation =
            new Operation(getContextData().getContext(), "REQUEST_SELECTION",
                null);
        operation.setSerializable(false);
        getContextData().getDispatcher().runDispatch(operation);

        // readjust position
        operation =
            new Operation(getContextData().getContext(), "ZOOM_RESET", null);
        operation.setSerializable(false);
        getContextData().getDispatcher().runDispatch(operation);

        // reset surface labels and distances
        operation =
            new Operation(getContextData().getContext(),
                "UPDATE-REMOVE_ALL_SURFACES", null);
        operation.setSerializable(false);
        getContextData().getDispatcher().runDispatch(operation);
        operation =
            new Operation(getContextData().getContext(), "REMOVE_ALL_SURFACES",
                null);
        operation.setSerializable(false);
        getContextData().getDispatcher().runDispatch(operation);
        operation =
            new Operation(getContextData().getContext(),
                "UPDATE-REMOVE_ALL_LABELS", null);
        operation.setSerializable(false);
        getContextData().getDispatcher().runDispatch(operation);
        operation =
            new Operation(getContextData().getContext(), "REMOVE_ALL_LABELS",
                null);
        operation.setSerializable(false);
        getContextData().getDispatcher().runDispatch(operation);
        operation =
            new Operation(getContextData().getContext(),
                "UPDATE-REMOVE_ALL_DISTANCES", null);
        operation.setSerializable(false);
        getContextData().getDispatcher().runDispatch(operation);
        operation =
            new Operation(getContextData().getContext(),
                "REMOVE_ALL_DISTANCES", null);
        operation.setSerializable(false);
        getContextData().getDispatcher().runDispatch(operation);

        // apply default style
        Style style = (Style) getContextData().getProperty("DEFAULT-STYLE");
        String styleName = convert("STYLE-" + style.getName());
        operation =
            new Operation(getContextData().getContext(), styleName, null);
        operation.setSerializable(false);
        getContextData().getDispatcher().runDispatch(operation);

        // reset the operation store
        operation =
            new Operation(getContextData().getContext(),
                RestoreModule.RESET_OPERATION, null);
        operation.setSerializable(false);
        getContextData().getDispatcher().runDispatch(operation);
        Capture.updateSelections(getContextData(), true);
        ColorSchemeModule.updateLegendOverlay(getContextData(),
            getContextData().getColorSchemeBucket().getInformation(null));
        operation =
            new Operation(getContextData().getContext(),
                "REMOVE_ALL_USERANNOTATIONS", null);
        operation.setSerializable(false);
        getContextData().getDispatcher().runDispatch(operation);

        // :NOTE: becomes necessary when the SwitchPrintModeModule is integrated
        //    operation = new Operation( getContextData().getContext(), "RESET_CONTEXT_MODE", null );
        //    operation.setSerializable( false );
        //    getContextData().getDispatcher().runDispatch( operation );
        org.srs3d.viewer.bioatlas.Capture.setDefaultFlags(getContextData());
        getContextData().setProperty("COMPUTATION_STATE", null);
    }

    /**
     * Method description.
     */
    public void cleanup() {
        super.cleanup();
        application = null;
    }
}
