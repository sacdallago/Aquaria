/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.behaviors;

import java.awt.AWTEvent;
import java.awt.Event;
import java.awt.Point;
import java.awt.event.MouseEvent;
import java.util.Enumeration;

import javax.media.j3d.WakeupCriterion;
import javax.media.j3d.WakeupOnAWTEvent;
import javax.media.j3d.WakeupOnElapsedTime;
import javax.media.j3d.WakeupOr;
import javax.swing.JToolTip;

import org.srs3d.viewer.j3d.ContextData;

/**
 * @author Karsten Klein, 11/2000
 *
 * @created March 20, 2001
 */
public class ToolTipBehavior extends javax.media.j3d.Behavior {
    public static final int TOOLTIP_DELAY = 1200;
    private ContextData contextData = null;
    private transient boolean isTriggered = false;
    private transient Point mousePosition = null;

    /**
     * Constructor description.
     *
     * @param contextData Parameter description.
     */
    public ToolTipBehavior(ContextData contextData) {
        this.contextData = contextData;
    }

    /**
     * Method description.
     *
     * @param criteria Parameter description.
     */
    public void processStimulus(java.util.Enumeration criteria) {
        WakeupCriterion wakeup = null;
        AWTEvent[] event;
        Event awtEvent;
        if (criteria.hasMoreElements()) {
            wakeup = (WakeupCriterion) criteria.nextElement();
            if (wakeup instanceof WakeupOnAWTEvent) {
                processStimulus(wakeup);
            } else {
                showTooltip();
            }
            wakeup = null;
        }

        // reset wakeup condition
        initialize();
    }

    /**
     * Method description.
     *
     * @param criterion Parameter description.
     */
    public void processStimulus(WakeupCriterion criterion) {
        Object event;
        Enumeration enumer = criterion.allElements();
        isTriggered = false;
        if (enumer.hasMoreElements()) {
            event = enumer.nextElement();
            if (event instanceof WakeupOnAWTEvent) {
                WakeupOnAWTEvent awtEventCriteria = (WakeupOnAWTEvent) event;
                AWTEvent awtEvent = awtEventCriteria.getAWTEvent()[0];
                if (awtEvent.getID() == MouseEvent.MOUSE_MOVED) {
                    isTriggered = true;
                    mousePosition = ((MouseEvent) awtEvent).getPoint();
                }
            }
        }
    }

    /**
     * Method description.
     */
    public void initialize() {
        if (isTriggered) {
            WakeupCriterion[] criterions = new WakeupCriterion[2];
            criterions[1] =
                new WakeupOnAWTEvent(java.awt.event.MouseEvent.MOUSE_MOVED);
            criterions[0] = new WakeupOnElapsedTime(TOOLTIP_DELAY);
            wakeupOn(new WakeupOr(criterions));
        } else {
            wakeupOn(new WakeupOnAWTEvent(java.awt.event.MouseEvent.MOUSE_MOVED));
        }
        isTriggered = false;
    }

    /**
     * Method description.
     */
    public void showTooltip() {
        Object object =
            contextData.getIntersectionManager().pickClosestObject(mousePosition.x,
                mousePosition.y);
        if (object != null) {
            JToolTip toolTip = new JToolTip();
            toolTip.setTipText(object.toString());
            toolTip.setToolTipText(object.toString());
            toolTip.setTipText(object.toString());
            toolTip.setLocation(mousePosition);
            toolTip.setSize(50, 20);
            toolTip.setVisible(true);
        }
    }
}
