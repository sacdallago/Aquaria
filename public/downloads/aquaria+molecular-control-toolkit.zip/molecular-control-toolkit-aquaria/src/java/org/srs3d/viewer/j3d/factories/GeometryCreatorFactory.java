/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.factories;

import java.util.Hashtable;
import java.util.Map;

import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.Contextual;
import org.srs3d.viewer.j3d.creators.GeometryCreator;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.util.Log;

/**
 * The class <code>GeometryCreatorFactory</code> produces <code>GeometryCreators</code>
 * depending on a <code>AbstractObject</code> they shall be applied to. The factory
 * supplies no logic concerning this. Before you can use the factory, you have to
 * register geometry creators to all objects that are to be displayed.
 *
 * @author Karsten Klein
 *
 * @created March 30, 2001
 */
public class GeometryCreatorFactory implements Contextual {
    private static final Log log = new Log(GeometryCreatorFactory.class);

    /** Map of the registered objects/creator pairs. */
    private Map creatorMap = new Hashtable();
    private ContextData contextData;

    /**
     * <code>GeometryCreatorFactory</code> constructor.
     *
     * @param contextData Description of parameter.
     */
    public GeometryCreatorFactory(ContextData contextData) {
        this.contextData = contextData;
    }

    /**
     * Gets the <code>contextData</code> attribute of the
     * <code>GeometryCreatorFactory</code> object.
     *
     * @return The <code>contextData</code> value.
     */
    public final ContextData getContextData() {
        return contextData;
    }

    /**
     * Returns a new instance of <code>GeometryCreator</code> that matches the object.
     *
     * @param object Object identiying which creator to instatiate.
     *
     * @return The new <code>GeometryCreator</code> instance value.
     */
    public GeometryCreator getGeometryCreator(AbstractObject object) {
        Class creatorClass = (Class) creatorMap.get(object.getClass());
        GeometryCreator geometryCreator = null;
        if (creatorClass != null) {
            try {
                geometryCreator = (GeometryCreator) creatorClass.newInstance();
                geometryCreator.modifyAttributes(getContextData(), object);
            } catch (Exception e) {
                log.debug(e, e);
            }
        } else {

            //      log.error("no creator registered for " + object);
        }
        return geometryCreator;
    }

    /**
     * Registers objects to <code>GeometryCreators</code> .
     *
     * @param objectClass Class of the object.
     * @param creatorClass Class of the creator to be instantiated by
     *        <code>getGeometryCreator</code> method.
     */
    public void register(Class objectClass, Class creatorClass) {
        creatorMap.put(objectClass, creatorClass);
    }

    /**
     * Description of the method.
     */
    public void clearRegistry() {
        creatorMap.clear();
    }
}
