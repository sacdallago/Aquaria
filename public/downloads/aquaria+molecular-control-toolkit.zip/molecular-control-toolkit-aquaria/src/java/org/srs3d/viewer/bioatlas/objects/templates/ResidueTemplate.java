/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.objects.templates;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;

/**
 * This class summarizes general properties of a residue. It provides a collection of
 * residue classification methods.
 *
 * @author Karsten Klein, 01/2001
 *
 * @created July 13, 2001
 * @since 1.0
 */
public final class ResidueTemplate {

    /** All amino acid names */
    private static final String[] aminoAcids =
    {
        "ALA", "ARG", "ASN", "ASP", "ASX", "CYS", "GLN", "GLU", "GLX", "GLY",
        "HIS", "ILE", "LEU", "LYS", "MET", "PHE", "PRO", "SER", "THR", "TRP",
        "TYR", "UNK", "VAL"
    };

    /** All possible nuclear acids */
    private static final String[] nucleicAcids =
    {
        "  A", " +A", "  C", " +C", "  G", " +G", "  I", " +I", "  T", " +T",
        "  U", " +U", "ADE", "CYT", "GUA", "THY", "URA", "INO"
    };

    /** Identifiers representing water */
    private static final String[] waterIdentifiers =
    { "HOH", "WAT", "H2O", "OH2" };
    private static final Map singleLetterCodeMap = createCodeMap();
    private static final Map nameMap = createInverseCodeMap();
    private static final Map conservationIndexMap =
        createConservationIndexMap();
    private static final double[][] conservationMap =
    {
        { 2.4 },
        { 0.5, 11.5 },
        { -0.3, -3.2, 4.7 },
        { -0.0, -3.0, 2.7, 3.6 },
        { -2.3, -0.8, -4.5, -3.9, 7.0 },
        { 0.5, -2.0, 0.1, -0.8, -5.2, 6.6 },
        { -0.8, -1.3, 0.4, 0.4, -0.1, -1.4, 6.0 },
        { -0.8, -1.1, -3.8, -2.7, 1.0, -4.5, -2.2, 4.0 },
        { -0.4, -2.8, 0.5, 1.2, -3.3, -1.1, 0.6, -2.1, 3.2 },
        { -1.2, -1.5, -4.0, -2.8, 2.0, -4.4, -1.9, 2.8, -2.1, 4.0 },
        { -0.7, -0.9, -3.0, -2.0, 1.6, -3.5, -1.3, 2.5, -1.4, 2.8, 4.3 },
        { -0.3, -1.8, 2.2, 0.9, -3.1, 0.4, 1.2, -2.8, 0.8, -3.0, -2.2, 3.8 },
        {
            0.3, -3.1, -0.7, -0.5, -3.8, -1.6, -1.1, -2.6, -0.6, -2.3, -2.4,
            -0.9, 7.6
        },
        {
            -0.2, -2.4, 0.9, 1.7, -2.6, -1.0, 1.2, -1.9, 1.5, -1.6, -1.0, 0.7,
            -0.2, 2.7
        },
        {
            -0.6, -2.2, -0.3, 0.4, -3.2, -1.0, 0.6, -2.4, 2.7, -2.2, -1.7, 0.3,
            -0.9, 1.5, 4.7
        },
        {
            1.1, 0.1, 0.5, 0.2, -2.8, 0.4, -0.2, -1.8, 0.1, -2.1, -1.4, 0.9, 0.4,
            0.2, -0.2, 2.2
        },
        {
            0.6, -0.5, -0.0, -0.1, -2.2, -1.1, -0.3, -0.6, 0.1, -1.3, -0.6, 0.5,
            0.1, 0.0, -0.2, 1.5, 2.5
        },
        {
            0.1, -0.0, -2.9, -1.9, 0.1, -3.3, -2.0, 3.1, -1.7, 1.8, 1.6, -2.2,
            -1.8, -1.5, -2.0, -1.0, 0.0, 3.4
        },
        {
            -3.6, -1.0, -5.2, -4.3, 3.6, -4.0, -0.8, -1.8, -3.5, -0.7, -1.0,
            -3.6, -5.0, -2.7, -1.6, -3.3, -3.5, -2.6, 14.2
        },
        {
            -2.2, -0.5, -2.8, -2.7, 5.1, -4.0, 2.2, -0.7, -2.1, -0.0, -0.2, -1.4,
            -3.1, -1.7, -1.8, -1.9, -1.9, -1.1, 4.1, 7.8
        }
    };

    /** Validation flag for the hash sets */
    private static boolean validHashSets = false;

    /** The hash sets are used for a fast classification */
    private static HashSet aminoAcidHash = null;
    private static HashSet nucleicAcidHash = null;
    private static HashSet waterIdentifierHash = null;

    /** The name of the template represents the templates identifier */
    private String name = null;

    /**
     * Constructs a new <code>ResidueTemplate</code> with the specified name Note that
     * you should not instantiate the template yourself. Let the
     * <code>ResidueTemplateFactory</code> do the job. This ensures that a template is
     * allocated only once.
     *
     * @param residueName the residue name represents the <code> residueTemplate </code>
     *        identifier.
     */
    public ResidueTemplate(String residueName) {
        setName(residueName);

        // create static hash sets if not done yet
        createHashSets();
    }

    /**
     * Sets the <code>name</code> attribute of the <code>ResidueTemplate</code> object.
     *
     * @param name The new <code>name</code> value.
     */
    public void setName(String name) {
        this.name = new String(name);
    }

    /**
     * Gets the <code>name</code> attribute of the <code>ResidueTemplate</code> object.
     *
     * @return The <code>name</code> value.
     */
    public String getName() {
        return new String(name);
    }

    /**
     * Gets the <code>aminoAcid</code> attribute of the <code>ResidueTemplate </code>
     * object.
     *
     * @return The <code>aminoAcid</code> value.
     */
    public boolean isAminoAcid() {
        return aminoAcidHash.contains(name);
    }

    /**
     * Gets the <code>nucleicAcid</code> attribute of the <code>ResidueTemplate </code>
     * object.
     *
     * @return The <code>nucleicAcid</code> value.
     */
    public boolean isNucleicAcid() {
        return nucleicAcidHash.contains(name);
    }

    /**
     * Gets the <code>ligand</code> attribute of the <code>ResidueTemplate</code> object.
     *
     * @return The <code>ligand</code> value.
     */
    public boolean isLigand() {
        return (!isNucleicAcid() && !isAminoAcid());
    }

    /**
     * Gets the <code>water</code> attribute of the <code>ResidueTemplate</code> object.
     *
     * @return The <code>water</code> value.
     */
    public boolean isWater() {
        return waterIdentifierHash.contains(name);
    }

    /**
     * Description of the method.
     *
     * @param string Description of parameter.
     *
     * @return Description of the returned value.
     */
    public boolean is(String string) {
        return name.equalsIgnoreCase(string);
    }

    /**
     * Gets the <code>singleLetterCode</code> attribute of the
     * <code>ResidueTemplate</code> class.
     *
     * @return The <code>singleLetterCode</code> value.
     */
    public String getSingleLetterCode() {
        String singleLetterCode = (String) singleLetterCodeMap.get(getName());
        if (singleLetterCode == null) {

            // unknown; no single letter code available
            return "X";
        }
        return singleLetterCode;
    }

    /**
     * Gets the <code>conservation</code> attribute of the <code>ResidueTemplate </code>
     * class.
     *
     * @param templateA Description of parameter.
     * @param templateB Description of parameter.
     *
     * @return The <code>conservation</code> value.
     */
    public static double getConservation(ResidueTemplate templateA,
        ResidueTemplate templateB) {
        int indexA = getConservationMapIndex(templateA.getSingleLetterCode());
        int indexB = getConservationMapIndex(templateB.getSingleLetterCode());
        if (indexA == -1 || indexB == -1) {
            return -10;
        }
        if (indexA > indexB) {
            return conservationMap[indexA][indexB];
        } else {
            return conservationMap[indexB][indexA];
        }
    }

    /**
     * Gets the <code>conservationMapIndex</code> attribute of the
     * <code>ResidueTemplate</code> class.
     *
     * @param singleLetterCode Description of parameter.
     *
     * @return The <code>conservationMapIndex</code> value.
     */
    private static int getConservationMapIndex(String singleLetterCode) {
        Integer integer = (Integer) conservationIndexMap.get(singleLetterCode);
        if (integer != null) {
            return integer.intValue();
        } else {
            return -1;
        }
    }

    /**
     * Creates the hash sets for a fast classification.
     */
    private static void createHashSets() {
        if (!validHashSets) {
            int i;
            aminoAcidHash = new HashSet();
            nucleicAcidHash = new HashSet();
            waterIdentifierHash = new HashSet();
            for (i = 0; i < aminoAcids.length; i++) {
                aminoAcidHash.add(aminoAcids[i]);
            }
            for (i = 0; i < nucleicAcids.length; i++) {
                nucleicAcidHash.add(nucleicAcids[i]);
            }
            for (i = 0; i < waterIdentifiers.length; i++) {
                waterIdentifierHash.add(waterIdentifiers[i]);
            }
            validHashSets = true;
        }
    }

    /**
     * Description of the method.
     *
     * @return Description of the returned value.
     */
    private static Map createCodeMap() {
        Map map = new Hashtable();
        map.put("ALA", "A");
        map.put("CYS", "C");
        map.put("ASP", "D");
        map.put("GLU", "E");
        map.put("PHE", "F");
        map.put("GLY", "G");
        map.put("HIS", "H");
        map.put("ILE", "I");
        map.put("LYS", "K");
        map.put("LEU", "L");
        map.put("MET", "M");
        map.put("ASN", "N");
        map.put("PRO", "P");
        map.put("GLN", "Q");
        map.put("ARG", "R");
        map.put("SER", "S");
        map.put("THR", "T");
        map.put("VAL", "V");
        map.put("TRP", "W");
        map.put("TYR", "Y");
        map.put("  A", "a");
        map.put("  T", "t");
        map.put("  G", "g");
        map.put("  C", "c");
        map.put("  I", "i");
        map.put("  U", "u");
        map.put(" +A=", "a");
        map.put(" +T", "t");
        map.put(" +G", "g");
        map.put(" +C", "c");
        map.put(" +I", "i");
        map.put(" +U", "u");
        map.put("ADE", "a");
        map.put("CYT", "c");
        map.put("GUA", "g");
        map.put("THY", "t");
        map.put("URA", "u");
        map.put("GLX", "Z");
        map.put("ASX", "B");
        return map;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public static Map createInverseCodeMap() {
        Iterator iterator = singleLetterCodeMap.keySet().iterator();
        String name;
        String letter;
        Map map = new HashMap();
        while (iterator.hasNext()) {
            name = (String) iterator.next();
            letter = (String) singleLetterCodeMap.get(name);
            map.put(letter, name);
        }
        return map;
    }

    /**
     * Description of the method.
     *
     * @return Description of the returned value.
     */
    private static Map createConservationIndexMap() {
        Map map = new HashMap();
        int i = 0;
        map.put("A", new Integer(i++));
        map.put("C", new Integer(i++));
        map.put("D", new Integer(i++));
        map.put("E", new Integer(i++));
        map.put("F", new Integer(i++));
        map.put("G", new Integer(i++));
        map.put("H", new Integer(i++));
        map.put("I", new Integer(i++));
        map.put("K", new Integer(i++));
        map.put("L", new Integer(i++));
        map.put("M", new Integer(i++));
        map.put("N", new Integer(i++));
        map.put("P", new Integer(i++));
        map.put("Q", new Integer(i++));
        map.put("R", new Integer(i++));
        map.put("S", new Integer(i++));
        map.put("T", new Integer(i++));
        map.put("V", new Integer(i++));
        map.put("W", new Integer(i++));
        map.put("Y", new Integer(i++));
        return map;
    }

    /**
     * Method description.
     *
     * @param singleLetterCode Parameter description.
     *
     * @return Return description.
     */
    public static String getName(char singleLetterCode) {
        String name = (String) nameMap.get(String.valueOf(singleLetterCode));
        if (name == null) {
            return "UNK";
        }
        return name;
    }
}
