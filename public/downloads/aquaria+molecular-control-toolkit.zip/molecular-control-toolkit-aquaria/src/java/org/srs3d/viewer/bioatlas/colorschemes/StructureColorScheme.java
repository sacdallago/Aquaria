/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.colorschemes;

import java.util.Collection;
import java.util.HashSet;
import java.util.Map;

import javax.media.j3d.Appearance;

import org.srs3d.viewer.bioatlas.objects.Layer;
import org.srs3d.viewer.j3d.AppearanceHelper;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.objects.ObjectManager;

/**
 * @author Karsten Klein
 *
 * @created March 20, 2001
 */
public class StructureColorScheme extends ChainColorScheme {

    /**
     * Constructor description.
     *
     * @param contextData Parameter description.
     */
    public StructureColorScheme(ContextData contextData) {
        super(contextData);
        setComplete(true);
    }

    /**
     * Method description.
     *
     * @param object Parameter description.
     *
     * @return Return description.
     */
    public Object computeIdentifier(AbstractObject object) {
        return computeIdentifier(getContextData(), object);
    }

    /**
     * Description of the method.
     *
     * @param object Description of parameter.
     * @param appearance Description of parameter.
     *
     * @return Description of the returned value.
     */
    public boolean modify(AbstractObject object, Appearance appearance) {
        Object identifier = computeIdentifier(object);
        if (identifier != null) {

            // register the identifier (if not registered yet)
            register(identifier);
            AppearanceHelper.enableVertexColors(appearance, false);
            AppearanceHelper.modifyAppearance(appearance,
                computeColor(identifier));
            return true;
        }

        // modify ligand components using the base class method
        return super.modify(object, appearance);
    }

    /**
     * Method description.
     *
     * @param map Parameter description.
     *
     * @return Return description.
     */
    public Map getInformation(Map map) {
        map = super.getInformation(map);
        map.put("NAME", "Layer");
        return map;
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     * @param object Parameter description.
     *
     * @return Return description.
     */
    public static Object computeIdentifier(ContextData contextData,
        AbstractObject object) {
        String identifier = "<invalid-id>";

        // the scheme applies for chains and residues (in chain representation)
        ObjectManager objectManager = contextData.getObjectManager();
        Collection set = new HashSet();
        objectManager.getUpAssociations(object, set);
        set.add(object);
        Collection layers = new HashSet();
        ObjectManager.extract(set, layers, Layer.class);
        if (!layers.isEmpty()) {
            Layer layer = (Layer) layers.iterator().next();
            identifier = layer.getId();
            if (layer.getDescription() != null) {
                if (!layer.getDescription().equals(identifier)) {
                    identifier += layer.getDescription();
                }
            }
        }
        return identifier;
    }
}
