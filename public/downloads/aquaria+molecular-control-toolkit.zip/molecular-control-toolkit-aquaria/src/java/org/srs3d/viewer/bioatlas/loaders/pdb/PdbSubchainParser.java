/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.loaders.pdb;

import org.srs3d.viewer.bioatlas.objects.Chain;
import org.srs3d.viewer.bioatlas.objects.Residue;
import org.srs3d.viewer.bioatlas.objects.Subchain;

/**
 * Abstract baseclass of all subchain parsers.
 *
 * @author Karsten Klein, 01/2001
 *
 * @created May 18, 2001
 * @since 1.0
 */
public abstract class PdbSubchainParser extends PdbChainParser {

    /** Residue name of initial residue */
    protected String initialResidueName = null;

    /** Residue identifier of the initial resdiue */
    protected int initialResidueId = Residue.INVALID_ID;

    /** Residue insertion code of the initial resdiue */
    protected char initialResidueICode = Residue.INVALID_ICODE;

    /** Residue name of end residue */
    protected String endResidueName = null;

    /** Residue identifier of the end resdiue */
    protected int endResidueId = Residue.INVALID_ID;

    /** Residue insertion code of the end resdiue */
    protected char endResidueICode = Residue.INVALID_ICODE;

    /**
     * Gets the <code>retained</code> attribute of the <code>PdbSubchainParser </code>
     * object.
     *
     * @return The <code>retained</code> value.
     */
    public boolean isRetained() {
        return true;
    }

    /**
     * Description of the method.
     *
     * @param subchain Description of parameter.
     * @param chain Description of parameter.
     */
    public void visit(Subchain subchain, Chain chain) {
        boolean success = true;
        Residue residue =
            computeResidue(chain, subchain, initialResidueName,
                initialResidueId, initialResidueICode);
        if (residue != null) {
            subchain.setInitialResidue(residue);
        } else {
            success = false;
        }
        residue =
            computeResidue(chain, subchain, endResidueName, endResidueId,
                endResidueICode);
        if (residue != null) {
            subchain.setEndResidue(residue);
        } else {
            success = false;
        }
        if (success) {
            chain.addSubchain(subchain);
            setSuccess(true);
        }
    }

    /**
     * Description of the method.
     */
    public void clear() {
        super.clear();
        initialResidueName = null;
        initialResidueId = Residue.INVALID_ID;
        initialResidueICode = Residue.INVALID_ICODE;
        endResidueName = null;
        endResidueId = Residue.INVALID_ID;
        endResidueICode = Residue.INVALID_ICODE;
    }

    /**
     * Description of the method.
     *
     * @param chain Description of parameter.
     * @param subchain Description of parameter.
     * @param residueName Description of parameter.
     * @param residueId Description of parameter.
     * @param residueICode Description of parameter.
     *
     * @return Description of the returned value.
     */
    private static Residue computeResidue(Chain chain, Subchain subchain,
        String residueName, int residueId, char residueICode) {
        Residue residue =
            chain.getResidue(residueName, residueId, residueICode);
        return residue;
    }
}
