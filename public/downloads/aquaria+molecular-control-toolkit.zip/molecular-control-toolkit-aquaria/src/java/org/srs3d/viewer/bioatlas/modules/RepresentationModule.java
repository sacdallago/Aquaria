/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.modules;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;

import javax.swing.JCheckBoxMenuItem;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;

import org.srs3d.viewer.bioatlas.styles.Style;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.ProcessedSelection;
import org.srs3d.viewer.j3d.Selection;
import org.srs3d.viewer.j3d.commands.ColorCommand;
import org.srs3d.viewer.j3d.commands.CommandCollection;
import org.srs3d.viewer.j3d.commands.SpawnCommand;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.objects.Command;
import org.srs3d.viewer.objects.ObjectManager;
import org.srs3d.viewer.objects.Operation;
import org.srs3d.viewer.objects.StrategyManager;

/**
 * Menu module for executing <code>Command</code> s on the current selection.
 *
 * @author Karsten Klein
 *
 * @created May 14, 2001
 * @reviewed April 04, 2002
 */
public class RepresentationModule extends ProcessModule {
    private JCheckBoxMenuItem component = null;
    private int checkResult = 0;
    private Collection onCommands;
    private Collection offCommands;
    private RepresentationCheck check;
    private boolean isChecked = false;
    private boolean isEnabled = false;
    private boolean isSpawning = true;

    /**
     * <code>CommandModule</code> constructor.
     *
     * @param name Description of parameter.
     * @param contextData Description of parameter.
     * @param onCommands Description of parameter.
     * @param offCommands Description of parameter.
     * @param check Description of parameter.
     */
    public RepresentationModule(String name, ContextData contextData,
        Collection onCommands, Collection offCommands, RepresentationCheck check) {
        super(name, contextData, true, true);
        this.onCommands = onCommands;
        this.offCommands = offCommands;
        this.check = check;
    }

    /**
     * Sets the <code>spawing</code> attribute of the <code>RepresentationModule</code>
     * object.
     *
     * @param isSpawing The new <code>spawing</code> value.
     */
    public void setSpawing(boolean isSpawing) {
        this.isSpawning = isSpawing;
    }

    /**
     * Sets the <code>checked</code> attribute of the <code>RepresentationModule</code>
     * object.
     *
     * @param isChecked The new <code>checked</code> value.
     */
    public void setChecked(boolean isChecked) {
        this.isChecked = isChecked;
        if (component != null) {
            component.setState(isChecked);
        }
    }

    /**
     * Sets the <code>enabled</code> attribute of the <code>RepresentationModule</code>
     * object.
     *
     * @param isEnabled The new <code>enabled</code> value.
     */
    public void setEnabled(boolean isEnabled) {
        this.isEnabled = isEnabled;
        if (component != null) {
            component.setEnabled(isEnabled);
        }
    }

    /**
     * Gets the <code>component</code> attribute of the <code>SolidRenderingModule</code>
     * object.
     *
     * @return The <code>component</code> value.
     */
    public Component getComponent() {
        if (component == null) {
            component = new JCheckBoxMenuItem(getName(), false);
            component.addActionListener(this);
            KeyStroke keyStroke = getAccelerator();
            if (keyStroke != null) {
                component.setAccelerator(keyStroke);
            }
        }
        return component;
    }

    /**
     * Gets the <code>checked</code> attribute of the <code>RepresentationModule</code>
     * object.
     *
     * @return The <code>checked</code> value.
     */
    public boolean isChecked() {
        return this.isChecked;
    }

    /**
     * Gets the <code>moduleIdPrefix</code> attribute of the
     * <code>RepresentationModule</code> object.
     *
     * @return The <code>moduleIdPrefix</code> value.
     */
    public String getModuleIdPrefix() {
        return "REPRESENT-";
    }

    /**
     * Gets the <code>enabled</code> attribute of the <code>RepresentationModule</code>
     * object.
     *
     * @return The <code>enabled</code> value.
     */
    public boolean isEnabled() {
        return isEnabled;
    }

    /**
     * Description of the method.
     *
     * @param e Description of parameter.
     */
    public void process(ActionEvent e) {
        changeRepresentation();
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public boolean canProcess() {
        if (isEnabled) {
            if (!IS_THREADED) {
                return true;
            }
            if ((checkResult & RepresentationCheck.CHECK_LIMIT) != 0) {
                int result =
                    org.srs3d.viewer.swing.ComponentFactory.confirmDialog(getContextData()
                                                                              .getContext(),
                        "This operation requires much memory and may cause the Java Virtual Machine to stall.\n" +
                        "Press OK to continue anyway.", "Warning",
                        JOptionPane.ERROR_MESSAGE, null);
                if (result == JOptionPane.CANCEL_OPTION) {
                    return false;
                }
            }
            return true;
        }
        return false;
    }

    /**
     * Description of the method.
     */
    public void changeRepresentation() {
        if (isEnabled()) {
            final ContextData contextData = getContextData();
            contextData.getContext().addUpdateCallback(new org.srs3d.viewer.j3d.behaviors.UpdateBehavior.Callback() {
                    public void execute() {
                        final ObjectManager objectManager =
                            contextData.getObjectManager();
                        final StrategyManager strategyManager =
                            contextData.getStrategyManager();
                        final Selection selection =
                            contextData.getSelectionManager().getSelection();

                        // use the strategy manager for computation display/canceling
                        getComputation().setComputation(strategyManager);
                        boolean isSelectionBased = !selection.isEmpty();
                        Collection collapsedSelection = null;
                        if (isSelectionBased) {
                            collapsedSelection = new HashSet();
                            objectManager.collapseUp(selection,
                                collapsedSelection);
                        }
                        final Collection objects = collectObjects(contextData);
                        HashSet spawners = new HashSet(objects);
                        SpawnCommand.searchSpawners(contextData, spawners);
                        if (!isChecked()) {
                            executeCommands(onCommands, objects);
                        } else {
                            executeCommands(offCommands, objects);
                        }
                        if (isSpawning) {
                            SpawnCommand spawnCommand =
                                new SpawnCommand(contextData);
                            strategyManager.execute(spawners, spawnCommand);
                        }
                        boolean isCanceled = getComputation().isCanceled();
                        contextData.getSelectionManager()
                                   .invalidateProcessedSelection(selection);
                        if (!isCanceled) {
                            if (isSelectionBased) {
                                Operation transferOperation =
                                    new Operation(contextData.getContext(),
                                        "TRANSFER_SELECTION", null);
                                transferOperation.setObjects(collapsedSelection);
                                transferOperation.setSerializable(false);
                                contextData.getDispatcher().runDispatch(transferOperation);

                                // :NOTE: here we need no coloring, since the selection will be colored anyway
                            } else {

                                // :FIXME: this should be normally not necessary, if the
                                // AppearanceManager would color the object fully the first time, the
                                // color is requested
                                ColorCommand colorCommand =
                                    new ColorCommand(contextData);
                                colorCommand.propagate(contextData.getObjectContainer());
                            }
                        }
                        strategyManager.resetComputation();
                        getComputation().setComputation(null);
                        if (isCanceled) {
                            selection.clear(false);
                            Style style =
                                (Style) getContextData().getProperty("STYLE");
                            String styleName =
                                AbstractModule.convert("STYLE-" +
                                    style.getName());
                            final Operation operation =
                                new Operation(getContextData().getContext(),
                                    styleName, null);
                            operation.setSerializable(true);
                            getContextData().getDispatcher().runDispatch(operation);
                        }
                    }
                });
        }
    }

    /**
     * Description of the method.
     */
    public void cleanup() {
        super.cleanup();
        if (onCommands != null) {
            onCommands.clear();
            onCommands = null;
        }
        if (offCommands != null) {
            offCommands.clear();
            offCommands = null;
        }
    }

    /**
     * Description of the method.
     */
    public void updateIntern() {
        Collection objects = collectObjects(getContextData());
        checkResult = check.check(getContextData(), objects);
        setChecked((checkResult & RepresentationCheck.CHECK_YES) != 0);
        boolean enable = !(checkResult == 0 || check.checkFailed(checkResult));

        // disable when limit is reached on empty selection (global repesentation application)
        if (enable) {
            if (getContextData().getSelectionManager().getSelection().isEmpty()) {
                if ((checkResult & RepresentationCheck.CHECK_LIMIT) != 0) {
                    enable = false;
                }
            }
        }
        setEnabled(enable);
    }

    /**
     * Executes a list of commands on the specified objects.
     *
     * @param commands List of commands.
     * @param objects List of objects.
     */
    private void executeCommands(Collection commands, Collection objects) {
        if (commands != null && !commands.isEmpty()) {
            float progressPerCommand =
                100.0f / (commands.size() * objects.size());
            float progress = 0;
            ContextData contextData = getContextData();
            StrategyManager strategyManager = contextData.getStrategyManager();
            Iterator iterator = objects.iterator();
            AbstractObject object;
            Command command = new CommandCollection(contextData, commands);
            while (iterator.hasNext()) {
                object = (AbstractObject) iterator.next();
                getComputation().setDescription("Changing " + object +
                    " state");
                getComputation().setProgress((int) progress);
                strategyManager.execute(object, command);
                progress += progressPerCommand;
            }
        }
    }

    /**
     * Collects all objects that are relevant for the representation check. The
     * collection mechansim is base don the current selection. The method uses the
     * ProcessedSelection cache mechanism for reuse by other modules. The key for the
     * cached collection is "RepresentationModule:collectObjects()".
     *
     * @param contextData Description of parameter.
     *
     * @return Description of the returned value.
     */
    public static Collection collectObjects(ContextData contextData) {
        Selection selection = contextData.getSelectionManager().getSelection();
        ProcessedSelection processedSelection =
            contextData.getSelectionManager().getProcessedSelection(selection);
        Collection objects =
            processedSelection.getObjectCollection(
                "RepresentationModule:collectObjects()");
        if (objects == null) {
            objects = new HashSet();
            if (selection.isEmpty()) {
                Iterator iterator;
                Collection set;

                // :FIXME: use object collector with appropriate LayerFilter
                ObjectManager.extract(contextData.getObjectContainer()
                                                 .getObjects(), objects,
                    org.srs3d.viewer.bioatlas.objects.Layer.class);
            } else {
                contextData.getObjectManager().collapseUpExtended(selection,
                    objects);
            }
            LabelModule.excludeObjects(contextData, objects);
            processedSelection.setObjectCollection("RepresentationModule:collectObjects()",
                objects);
        }
        return objects;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public String createReport() {
        String report = super.createReport();
        if (component != null) {
            report += "|";
            report += component.getState() ? "C" : "U";
        }
        return report;
    }
}
