/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.visitors;

import javax.vecmath.Point3f;

import org.srs3d.viewer.bioatlas.objects.Residue;

/**
 * Description of the class.
 *
 * @author Karsten Klein
 *
 * @created May 21, 2001
 */
public class StrandPathCreator extends PathCreator {

    /**
     * This path creator visit method implements in a first instance the priesley
     * algorithm. The proposed smoothing is done only in the first step.
     *
     * @param start Description of parameter.
     * @param end Description of parameter.
     */
    public void visit(Residue start, Residue end) {
        Point3f point = null;
        Residue residue = start;
        Residue intermediate;
        Residue next;
        Residue limit = end.getPreceeding();
        int i = 0;

        // insert initial point
        if (residue != null) {
            path.add(getResidueCoordinate(residue));
        }

        // insert intermediate residues
        while (residue != null && residue != limit) {
            intermediate = residue.getProceeding();
            if (intermediate != null) {
                next = intermediate.getProceeding();
                if (next != null) {
                    point = getResidueCoordinate(intermediate);
                    point.add(point);
                    point.add(getResidueCoordinate(residue));
                    point.add(getResidueCoordinate(next));
                    point.scale(0.25f);
                    path.add(point);
                }
            }
            residue = residue.getProceeding();
        }

        // add last ca position
        residue = end;
        if (residue != null) {
            path.add(getResidueCoordinate(residue));
        }

        // if no path was extracted yet just take the initial and end residues
        // CA positions
        if (path.size() < 2) {
            Point3f point0;
            Point3f point1;

            // forget all added coordinates
            path.clear();
            residue = start;
            point0 = getResidueCoordinate(residue);
            residue = end;
            point1 = getResidueCoordinate(residue);
            point = new Point3f(point0);
            point.scale(10);
            point.add(point1);
            point.scale(1.0f / 11);
            path.add(point);
            point = new Point3f(point1);
            point.scale(10);
            point.add(point0);
            point.scale(1.0f / 11);
            path.add(point);
        }
    }
}
