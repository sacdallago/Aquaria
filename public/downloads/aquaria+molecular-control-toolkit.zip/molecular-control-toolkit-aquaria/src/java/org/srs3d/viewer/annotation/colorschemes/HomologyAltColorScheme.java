/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.annotation.colorschemes;

import java.util.Map;

import javax.vecmath.Color3f;

import org.srs3d.viewer.j3d.ContextData;

/**
 * This <code>HomologyAltColorScheme</code> colors residues by conservation. It uses the
 * conservation matrix that can be found in the ResidueTemplate class. Residue
 * subobjects are mapped to the residue and a avarage computation is performed for
 * higher level objects that include residues.
 *
 * @author Karsten Klein
 *
 * @created March 20, 2001
 */
public class HomologyAltColorScheme extends AlignmentColorScheme {

    // works 02 (choice)
    private Color3f identicalColor = new Color3f(0.1f, 0.8f, 0.1f);
    private Color3f conservedColor = new Color3f(0.6f, 0.6f, 0.9f);
    private Color3f unconservedColor = new Color3f(0.1f, 0.1f, 0.8f);
    private Color3f maxDeviationColor = new Color3f(0.3f, 0.3f, 0.3f);

    /**
     * <code>HomologyColorAltScheme</code> constructor.
     *
     * @param contextData Description of parameter.
     */
    public HomologyAltColorScheme(ContextData contextData) {
        super(contextData);
        initialize();
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public final Color3f getConservedColor() {
        return conservedColor;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public final Color3f getIdenticalColor() {
        return identicalColor;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public final Color3f getMaxDeviationColor() {
        return maxDeviationColor;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public final Color3f getUnconservedColor() {
        return unconservedColor;
    }

    /**
     * Method description.
     *
     * @param map Parameter description.
     *
     * @return Return description.
     */
    public Map getInformation(Map map) {
        map = super.getInformation(map);
        map.put("NAME", "Sequence Similarity (alt.)");
        return map;
    }
}
