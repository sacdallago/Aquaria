/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.behaviors;

import java.awt.event.MouseEvent;

import javax.media.j3d.WakeupCriterion;
import javax.media.j3d.WakeupOnAWTEvent;
import javax.media.j3d.WakeupOr;

import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.operations.IntersectOperation;

/**
 * @author Karsten Klein, 11/2000
 *
 * @created March 20, 2001
 */
public class MouseOverBehavior extends MouseBehavior {

    /**
     * Constructor description.
     *
     * @param contextData Parameter description.
     */
    public MouseOverBehavior(ContextData contextData) {
        super(contextData);
    }

    /**
     * Method description.
     *
     * @param event Parameter description.
     */
    public void processStimulus(MouseEvent event) {
        if (!org.srs3d.viewer.j3d.ContextManager.hasLock()) {
            produceOperation(event);
        }
    }

    /**
     * Method description.
     */
    public void initialize() {
        WakeupCriterion[] criterions = new WakeupCriterion[2];
        criterions[1] =
            new WakeupOnAWTEvent(java.awt.event.MouseEvent.MOUSE_EXITED);
        criterions[0] =
            new WakeupOnAWTEvent(java.awt.event.MouseEvent.MOUSE_MOVED);
        wakeupOn(new WakeupOr(criterions));
    }

    /**
     * Method description.
     *
     * @param mouseEvent Parameter description.
     */
    public void produceOperation(MouseEvent mouseEvent) {
        IntersectOperation operation =
            new IntersectOperation(getContextData().getContext(), "INTERSECT",
                null);
        operation.setTriggerId("MOUSEOVER");
        operation.setCoordinate(mouseEvent.getPoint());
        operation.setTriggerEvent(mouseEvent);
        getContextData().getDispatcher().dispatch(operation);
    }
}
