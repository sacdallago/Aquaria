/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.annotation.visitors;

import java.util.Iterator;

import org.srs3d.viewer.annotation.objects.Alignment;
import org.srs3d.viewer.annotation.objects.AnnotationContainer;
import org.srs3d.viewer.bioatlas.objects.Layer;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.objects.ObjectContainer;
import org.srs3d.viewer.objects.visitors.AbstractVisitor;

/**
 * builds the annotation from the objectContainer with all layers
 *
 * @author Christian Zofka
 *
 * @created May 18, 2001
 */
public class AnnotationContainerCreator extends AbstractVisitor {
    private AnnotationContainer annotationContainer = null;

    /**
     * Sets the <code>annotation</code> attribute of the <code>AnnotationCreator</code>
     * object.
     *
     * @param annotation The new <code>annotation</code> value.
     */
    public void setAnnotation(AnnotationContainer annotationContainer) {
        this.annotationContainer = annotationContainer;
    }

    /**
     * Gets the <code>annotation</code> attribute of the <code>AnnotationCreator</code>
     * object.
     *
     * @return The <code>annotation</code> value.
     */
    public AnnotationContainer getAnnotationContainer() {
        return annotationContainer;
    }

    /**
     * Description of the method.
     *
     * @param object Description of parameter.
     */
    public void visit(AbstractObject object) {
        if (object instanceof Layer) {
            visit((Layer) object);
        } else if (object instanceof ObjectContainer) {
            super.visit((ObjectContainer) object);
        }
    }

    /**
     * creates the sequence annotation of the layer and adds it to the existing
     * annotation; notice that no sequenceAlignment or gapcreation is done
     *
     * @param layer contains proteinsequence
     */
    public void visit(Layer layer) {
        if (getAnnotationContainer() == null) {
            annotationContainer = new AnnotationContainer();
        }
        Iterator objectIterator = layer.getIterator();
        AlignmentCreator alignmentCreator;
        Alignment alignment;
        while (objectIterator.hasNext()) {
            alignmentCreator = new AlignmentCreator();
            alignmentCreator.visit((AbstractObject) objectIterator.next());
            alignment = alignmentCreator.getAlignment();
            if (!alignment.isEmpty()) {
                getAnnotationContainer().add(alignment);
            }
        }
    }
}
