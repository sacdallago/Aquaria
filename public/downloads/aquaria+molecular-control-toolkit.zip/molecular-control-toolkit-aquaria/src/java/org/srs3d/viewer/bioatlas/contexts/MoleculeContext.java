/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.contexts;

import java.awt.GraphicsConfiguration;
import java.awt.event.MouseEvent;

import javax.media.j3d.Alpha;
import javax.media.j3d.BoundingSphere;
import javax.media.j3d.BranchGroup;
import javax.media.j3d.ModelClip;
import javax.media.j3d.RotationInterpolator;
import javax.media.j3d.Transform3D;
import javax.media.j3d.TransformGroup;
import javax.media.j3d.View;
import javax.vecmath.AxisAngle4f;
import javax.vecmath.Point3d;
import javax.vecmath.Tuple3f;
import javax.vecmath.Vector3d;
import javax.vecmath.Vector4d;

import org.srs3d.viewer.j3d.AppearanceHelper;
import org.srs3d.viewer.j3d.BranchGroupHelper;
import org.srs3d.viewer.j3d.Context;
import org.srs3d.viewer.j3d.behaviors.AutoLookAtXYBehavior;
import org.srs3d.viewer.j3d.behaviors.ClippingPlaneBehavior;
import org.srs3d.viewer.j3d.behaviors.InteractivePanXYBehavior;
import org.srs3d.viewer.j3d.behaviors.InteractiveZoomBehavior;
import org.srs3d.viewer.j3d.behaviors.LookAtBehavior;
import org.srs3d.viewer.j3d.behaviors.LookAtXYBehavior;
import org.srs3d.viewer.j3d.behaviors.PanXYBehavior;
import org.srs3d.viewer.j3d.behaviors.SelectZoomBehavior;
import org.srs3d.viewer.j3d.behaviors.UpdateBehavior;
import org.srs3d.viewer.j3d.behaviors.ZoomBehavior;
import org.srs3d.viewer.j3d.constraints.SphereConstraint;
import org.srs3d.viewer.util.ExceptionHandler;

/**
 * This class collects all context unique attributes to enable fast access (at least
 * using the <code>ContextManager</code> class). It additionally provides setup methods
 * to ease context creation. Note that this class is actually tightly coupled with the
 * <code>ContextManager</code> providing accurate active context control tracking the
 * mouse events.
 *
 * @author Karsten Klein
 *
 * @created November 03, 2000
 */
public class MoleculeContext extends Context {

    /** The <code>ModelClip</code> defines the slabs clipping planes. */
    private ModelClip modelClip = null;

    /** <code>BranchBroup</code> that hold the slabs <code>ModelClip</code> */
    private BranchGroup modelClipBranch = null;
    private boolean isModelClip = false;
    private TransformGroup modelClipTransformGroup = null;
    private Transform3D modelClipTransform = null;
    private AutoLookAtXYBehavior autoLookAtBehavior = null;
    private boolean isAnimated = false;

    /**
     * Constructs a context with the appropriate <code>GraphicsContext</code>
     *
     * @param graphicsConfiguration Description of parameter
     */
    public MoleculeContext(GraphicsConfiguration graphicsConfiguration) {
        super(graphicsConfiguration, false);
    }

    /**
     * <code>MoleculeContext</code> contructor.
     */
    public MoleculeContext() {
        super();
    }

    /**
     * Constructs a context with the appropriate <code>GraphicsContext</code> and offset
     * screen flag
     *
     * @param graphicsConfiguration <code>GraphicsConfiguration</code> to use.
     * @param offScreen indicates whether it is an offscreen rendering canvas or not.
     */
    public MoleculeContext(GraphicsConfiguration graphicsConfiguration,
        boolean offScreen) {
        super(graphicsConfiguration, offScreen);
    }

    /**
     * Sets the default molecule context setting.
     */
    public void setup() {

        // use the default setup
        super.setup();
        setupLights(true);

        // create a bounding sphere for the whole bunch of behaviors
        BoundingSphere bounds =
            new BoundingSphere(new Point3d(), Double.MAX_VALUE);

        // we use a sperical constraint to limit the users viewing platform movement
        SphereConstraint constraint = new SphereConstraint(new Point3d(), 1000);
        getConstraints().add(constraint);
        PanXYBehavior panner = new PanXYBehavior(getContextData());
        getBehaviorLevel().addChild(panner);
        panner.setSchedulingBounds(bounds);
        SelectZoomBehavior zoomer = new SelectZoomBehavior(getContextData());
        zoomer.setSchedulingBounds(bounds);
        getBehaviorLevel().addChild(zoomer);
        ZoomBehavior zoom = new ZoomBehavior(getContextData());
        zoom.setSchedulingBounds(bounds);
        getBehaviorLevel().addChild(zoom);

        InteractiveZoomBehavior kinectZoom = new InteractiveZoomBehavior(getContextData());
        kinectZoom.setSchedulingBounds(bounds);
        getBehaviorLevel().addChild(kinectZoom);

        InteractivePanXYBehavior kinectPan = new InteractivePanXYBehavior(getContextData());
        kinectPan.setSchedulingBounds(bounds);
        getBehaviorLevel().addChild(kinectPan);


        // setup animation behavior
        autoLookAtBehavior = new AutoLookAtXYBehavior(getContextData());
        autoLookAtBehavior.setEnable(false);
        autoLookAtBehavior.setSchedulingBounds(new BoundingSphere(
                new Point3d(), Double.MAX_VALUE));
        getBehaviorLevel().addChild(autoLookAtBehavior);
        AppearanceHelper.initialize();
        try {
            getView().setTransparencySortingPolicy(View.TRANSPARENCY_SORT_NONE);
        } catch (NoSuchMethodError e) {
            ExceptionHandler.handleException(e,
                ExceptionHandler.SILENT_IN_DEBUG, this);
        }
    }

    /**
     * Sets up the animation environment of the context.
     */
    public void setupAnimation() {
        BoundingSphere bounds =
            new BoundingSphere(new Point3d(0.0, 0.0, 0.0), Double.MAX_VALUE);
        AxisAngle4f axisAngle =
            new AxisAngle4f(1.0f, 1.0f, 1.0f, -(float) Math.PI / 2.0f);
        Transform3D yAxis = new Transform3D();
        yAxis.set(axisAngle);
        Alpha rotationAlpha =
            new Alpha(-1, Alpha.INCREASING_ENABLE, 0, 0, 500000, 0, 0, 0, 0, 0);
        RotationInterpolator rotator =
            new RotationInterpolator(rotationAlpha, getSceneTransform(), yAxis,
                0.1f, (float) Math.PI * 2.0f);
        rotator.setSchedulingBounds(bounds);
        getBehaviorLevel().addChild(rotator);
    }

    /**
     * Gets the <code>animated</code> attribute of the <code>MoleculeContext</code>
     * object.
     *
     * @return The <code>animated</code> value.
     */
    public boolean isAnimated() {
        return isAnimated;
    }

    /**
     * Initializes the model clip used for the slab.
     */
    public void initializeModelClip() {
        modelClipBranch = new BranchGroup();
        BranchGroupHelper.setDefaultCapabilities(modelClipBranch);
        modelClipBranch.setCapability(BranchGroup.ALLOW_CHILDREN_READ);
        modelClipTransformGroup = new TransformGroup();
        modelClipTransformGroup.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
        modelClipTransformGroup.setCapability(TransformGroup.ALLOW_TRANSFORM_READ);
        Vector3d vector = new Vector3d(getCenterOfRotation());
        vector.sub(getViewingPlatformPosition());
        modelClipTransform = new Transform3D();
        modelClipTransform.set(vector);
        modelClipTransformGroup.setTransform(modelClipTransform);
        modelClip = new ModelClip();
        modelClip.setCapability(ModelClip.ALLOW_PLANE_READ);
        modelClip.setCapability(ModelClip.ALLOW_PLANE_WRITE);
        modelClip.setCapability(ModelClip.ALLOW_SCOPE_READ);
        modelClip.setCapability(ModelClip.ALLOW_SCOPE_WRITE);
        modelClip.setBounds(new BoundingSphere(new Point3d(), Double.MAX_VALUE));
        modelClip.setInfluencingBounds(new BoundingSphere(new Point3d(),
                Double.MAX_VALUE));
        modelClip.addScope(getSceneLevel());
        modelClip.setEnable(0, false);
        modelClip.setEnable(1, false);
        modelClip.setEnable(2, false);
        modelClip.setEnable(3, false);
        modelClip.setEnable(4, true);
        modelClip.setEnable(5, true);
        Vector4d planeVector = new Vector4d();
        modelClip.getPlane(4, planeVector);
        planeVector.w = -5;
        modelClip.setPlane(4, planeVector);
        modelClip.getPlane(5, planeVector);
        planeVector.w = -5;
        modelClip.setPlane(5, planeVector);
        ClippingPlaneBehavior clippingPlaneBehavior;
        clippingPlaneBehavior = new ClippingPlaneBehavior(getContextData());
        clippingPlaneBehavior.setSchedulingBounds(new BoundingSphere(
                new Point3d(), Double.MAX_VALUE));
        clippingPlaneBehavior.setModelClip(modelClip);
        clippingPlaneBehavior.setPlaneIndex(4);
        clippingPlaneBehavior.setDirection(0.8f);
        clippingPlaneBehavior.setMouseButtonMask(MouseEvent.BUTTON1_MASK);
        modelClipBranch.addChild(clippingPlaneBehavior);
        clippingPlaneBehavior = new ClippingPlaneBehavior(getContextData());
        clippingPlaneBehavior.setSchedulingBounds(new BoundingSphere(
                new Point3d(), Double.MAX_VALUE));
        clippingPlaneBehavior.setModelClip(modelClip);
        clippingPlaneBehavior.setPlaneIndex(5);
        clippingPlaneBehavior.setDirection(0.8f);
        clippingPlaneBehavior.setMouseButtonMask(MouseEvent.BUTTON1_MASK);
        clippingPlaneBehavior.setMode(ClippingPlaneBehavior.VERTICAL);
        modelClipBranch.addChild(clippingPlaneBehavior);
        modelClipTransformGroup.addChild(modelClip);
        modelClipBranch.addChild(modelClipTransformGroup);
    }

    /**
     * Attaches the modelClip node to the avatar
     *
     * @param activate Description of parameter.
     */
    public void activateModelClip(final boolean isActivate) {
        addUpdateCallback(new UpdateBehavior.Callback() {
                public void execute() {
                    isModelClip = isActivate;
                    if (isModelClip) {
                        if (modelClipBranch == null) {
                            initializeModelClip();
                        }
                        getViewerAvatar().addChild(modelClipBranch);
                    } else {
                        if (modelClipBranch != null) {
                            modelClipBranch.detach();
                        }
                    }
                }
            });
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public boolean isModelClip() {
        return isModelClip;
    }

    /**
     * Description of the method.
     *
     * @param speedX Description of parameter.
     * @param speedY Description of parameter.
     * @param speedZ Description of parameter.
     */
    public void startAnimation(float speedX, float speedY, float speedZ) {
        Alpha alpha =
            new Alpha(-1, Alpha.INCREASING_ENABLE, 0, 0, 1000, 0, 0, 0, 0, 0);
        autoLookAtBehavior.setSpeed(speedX, speedY, speedZ);
        autoLookAtBehavior.setAlpha(alpha);
        int max =
            Math.max(LookAtBehavior.deltaZ,
                Math.max(LookAtXYBehavior.deltaX, LookAtXYBehavior.deltaY));
        if (max == 0) {
            LookAtXYBehavior.deltaX = 1;
        }
        autoLookAtBehavior.setEnable(true);
        isAnimated = true;
    }

    /**
     * Description of the method.
     */
    public void stopAnimation() {
        autoLookAtBehavior.setEnable(false);
        isAnimated = false;
    }

    /**
     * Description of the method.
     *
     * @param mouseEvent Description of parameter.
     */
    public void mouseReleased(MouseEvent mouseEvent) {
        super.mouseReleased(mouseEvent);
        if (isAnimated) {
            autoLookAtBehavior.setEnable(true);
        }
    }

    /**
     * <code>MouseListener</code> method implementation
     *
     * @param mouseEvent Description of parameter.
     */
    public void mouseDragged(MouseEvent mouseEvent) {
        super.mouseDragged(mouseEvent);
        autoLookAtBehavior.setEnable(false);
    }

    /**
     * Description of the method.
     *
     * @param destination Description of parameter.
     * @param duration Description of parameter.
     */
    public void interpolatePosition(Tuple3f destination, int duration) {
        autoLookAtBehavior.setEnable(false);
        super.interpolatePosition(destination, duration);
    }

    /**
     * Description of the method.
     */
    public void interpolationStopped() {
        super.interpolationStopped();
        if (isAnimated) {
            autoLookAtBehavior.setEnable(true);
        }
    }
}
