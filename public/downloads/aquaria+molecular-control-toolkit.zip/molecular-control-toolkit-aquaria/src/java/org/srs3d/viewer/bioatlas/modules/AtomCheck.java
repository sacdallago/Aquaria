/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.modules;

import java.util.ArrayList;
import java.util.Collection;

import org.srs3d.viewer.bioatlas.attributes.AtomRepresentation;
import org.srs3d.viewer.bioatlas.attributes.Representation;
import org.srs3d.viewer.bioatlas.attributes.ResidueRepresentation;
import org.srs3d.viewer.bioatlas.attributes.SubchainRepresentation;
import org.srs3d.viewer.bioatlas.objects.Residue;
import org.srs3d.viewer.bioatlas.objects.Subchain;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.commands.CommandCollection;
import org.srs3d.viewer.j3d.commands.ExecuteClassCommand;
import org.srs3d.viewer.j3d.commands.ExpandCommand;
import org.srs3d.viewer.j3d.commands.ParentCommand;
import org.srs3d.viewer.j3d.commands.PreSelectCommand;
import org.srs3d.viewer.j3d.commands.PropagateClassCommand;
import org.srs3d.viewer.j3d.commands.RepresentationCommand;
import org.srs3d.viewer.objects.Attribute;
import org.srs3d.viewer.objects.Command;

/**
 * Common baseclass for all atom representations. provides the default implementation of
 * common methods.
 *
 * @author Karsten Klein
 *
 * @created August 06, 2001
 */
public abstract class AtomCheck extends SubchainToAtomCheck {

    /**
     * Gets the <code>atomOnCommands</code> attribute of the
     * <code>VanDerWaalsCheck</code> class.
     *
     * @param contextData Description of parameter.
     * @param onCommands Description of parameter.
     */
    public void getAtomOnCommands(ContextData contextData, Collection onCommands) {
        RepresentationCommand representationCommand;
        Representation representation;
        representation =
            (Representation) Attribute.getInstance(AtomRepresentation.class);
        representation.setMode(getMode());
        representationCommand = new RepresentationCommand(contextData);
        representationCommand.setRepresentation(representation);
        onCommands.add(representationCommand);
    }

    /**
     * Gets the <code>atomOffCommands</code> attribute of the <code>AtomCheck</code>
     * object.
     *
     * @param contextData Description of parameter.
     * @param offCommands Description of parameter.
     */
    public void getAtomOffCommands(ContextData contextData,
        Collection offCommands) {
        if (getMode() != 0) {
            RepresentationCommand representationCommand;
            AtomRepresentation atomRepresentation;
            atomRepresentation =
                (AtomRepresentation) Attribute.getInstance(AtomRepresentation.class);
            atomRepresentation.setMode(getMode());
            representationCommand =
                new RepresentationCommand(contextData,
                    RepresentationCommand.REMOVE);
            representationCommand.setRepresentation(atomRepresentation);
            offCommands.add(representationCommand);
        }
    }

    /**
     * Gets the <code>residueOnCommands</code> attribute of the
     * <code>VanDerWaalsCheck</code> class.
     *
     * @param contextData Description of parameter.
     * @param onCommands Description of parameter.
     */
    public void getResidueOnCommands(ContextData contextData,
        Collection onCommands) {
        RepresentationCommand representationCommand;
        ResidueRepresentation residueRepresentation;
        if (getMode() != 0) {
            residueRepresentation =
                (ResidueRepresentation) Attribute.getInstance(ResidueRepresentation.class);
            residueRepresentation.setMode(getMode());
            representationCommand =
                new RepresentationCommand(contextData,
                    RepresentationCommand.MERGE);
            representationCommand.setRepresentation(residueRepresentation);
            onCommands.add(representationCommand);
        }
        if (getUndoMode() != 0) {
            residueRepresentation =
                (ResidueRepresentation) Attribute.getInstance(ResidueRepresentation.class);
            residueRepresentation.setMode(getUndoMode());
            representationCommand =
                new RepresentationCommand(contextData,
                    RepresentationCommand.REMOVE);
            representationCommand.setRepresentation(residueRepresentation);
            onCommands.add(representationCommand);
        }
    }

    /**
     * Gets the <code>subchainOnCommands</code> attribute of the
     * <code>VanDerWaalsCheck</code> class.
     *
     * @param contextData Description of parameter.
     * @param onCommands Description of parameter.
     */
    public void getSubchainOnCommands(ContextData contextData,
        Collection onCommands) {
        RepresentationCommand representationCommand;
        SubchainRepresentation subchainRepresentation;
        if (getMode() != 0) {
            subchainRepresentation =
                (SubchainRepresentation) Attribute.getInstance(SubchainRepresentation.class);
            subchainRepresentation.setMode(getMode());
            representationCommand =
                new RepresentationCommand(contextData,
                    RepresentationCommand.MERGE);
            representationCommand.setRepresentation(subchainRepresentation);
            onCommands.add(representationCommand);
        }
        if (getUndoMode() != 0) {
            subchainRepresentation =
                (SubchainRepresentation) Attribute.getInstance(SubchainRepresentation.class);
            subchainRepresentation.setMode(getUndoMode());
            representationCommand =
                new RepresentationCommand(contextData,
                    RepresentationCommand.REMOVE);
            representationCommand.setRepresentation(subchainRepresentation);
            onCommands.add(representationCommand);
        }
    }

    /**
     * Gets the <code>residueOffCommands</code> attribute of the
     * <code>WireframeCheck</code> class.
     *
     * @param contextData Description of parameter.
     * @param offCommands Description of parameter.
     */
    public void getResidueOffCommands(ContextData contextData,
        Collection offCommands) {
        if (getMode() != 0) {
            RepresentationCommand representationCommand;
            ResidueRepresentation residueRepresentation;
            residueRepresentation =
                (ResidueRepresentation) Attribute.getInstance(ResidueRepresentation.class);
            residueRepresentation.setMode(getMode());
            representationCommand =
                new RepresentationCommand(contextData,
                    RepresentationCommand.REMOVE);
            representationCommand.setRepresentation(residueRepresentation);
            offCommands.add(representationCommand);
        }
    }

    /**
     * Gets the <code>subchainOffCommands</code> attribute of the
     * <code>WireframeCheck</code> class.
     *
     * @param contextData Description of parameter.
     * @param offCommands Description of parameter.
     */
    public void getSubchainOffCommands(ContextData contextData,
        Collection offCommands) {
        if (getMode() != 0) {
            RepresentationCommand representationCommand;
            SubchainRepresentation subchainRepresentation;
            subchainRepresentation =
                (SubchainRepresentation) Attribute.getInstance(SubchainRepresentation.class);
            subchainRepresentation.setMode(getMode());
            representationCommand =
                new RepresentationCommand(contextData,
                    RepresentationCommand.REMOVE);
            representationCommand.setRepresentation(subchainRepresentation);
            offCommands.add(representationCommand);
        }
    }

    /**
     * Gets the <code>allOnCommands</code> attribute of the <code>VanDerWaalsCheck</code>
     * class.
     *
     * @param contextData Description of parameter.
     * @param onCommands Description of parameter.
     */
    public void getAllOnCommands(ContextData contextData, Collection onCommands) {
        Collection commands;
        Command command;

        // expand the subchains of the residues
        Command subchainCommand =
            new ExecuteClassCommand(contextData,
                new PreSelectCommand(contextData), Subchain.class);
        onCommands.add(new ExecuteClassCommand(contextData,
                new ParentCommand(contextData, subchainCommand), Residue.class));

        // subchains and residues
        Collection commandCollection = new ArrayList();
        commands = new ArrayList();
        commands.add(new ExpandCommand(contextData));
        getResidueOnCommands(contextData, commands);
        command = new CommandCollection(contextData, commands);
        command = new ExecuteClassCommand(contextData, command, Residue.class);
        commandCollection.add(command);
        commands = new ArrayList();
        commands.add(new ExpandCommand(contextData));
        getSubchainOnCommands(contextData, commands);
        command = new CommandCollection(contextData, commands);
        command = new ExecuteClassCommand(contextData, command, Subchain.class);
        commandCollection.add(command);
        command = new CommandCollection(contextData, commandCollection);
        command =
            new PropagateClassCommand(contextData, command, Residue.class);
        onCommands.add(command);
        commands = new ArrayList();
        getAtomOnCommands(contextData, commands);
        command = new CommandCollection(contextData, commands);
        command = new PropagateClassCommand(contextData, command, null);
        onCommands.add(command);
    }

    /**
     * Gets the <code>residueOnCommands</code> attribute of the
     * <code>VanDerWaalsCheck</code> class.
     *
     * @param contextData Description of parameter.
     * @param commands Description of parameter.
     */
    public void getResidueCommands(ContextData contextData, Collection commands) {
    }

    /**
     * Gets the <code>subchainCommands</code> attribute of the <code>AtomCheck</code>
     * object.
     *
     * @param contextData Description of parameter.
     * @param commands Description of parameter.
     */
    public void getSubchainCommands(ContextData contextData, Collection commands) {
    }

    /**
     * Gets the <code>allCommands</code> attribute of the <code>VanDerWaalsCheck</code>
     * class.
     *
     * @param contextData Description of parameter.
     * @param commands Description of parameter.
     */
    public void getAllCommands(ContextData contextData, Collection commands) {
        commands.add(new PropagateClassCommand(contextData,
                new ExpandCommand(contextData, true), Residue.class));
        getSubchainCommands(contextData, commands);
        getResidueCommands(contextData, commands);
        getAtomOnCommands(contextData, commands);
    }

    /**
     * Gets the <code>allOffCommands</code> attribute of the <code>AtomCheck</code>
     * object.
     *
     * @param contextData Description of parameter.
     * @param offCommands Description of parameter.
     */
    public void getAllOffCommands(ContextData contextData,
        Collection offCommands) {

        // atoms and bonds
        Collection commands = new ArrayList();
        getAtomOffCommands(contextData, commands);
        Command command = new CommandCollection(contextData, commands);
        command = new PropagateClassCommand(contextData, command, null);
        offCommands.add(command);

        // residues and subchains
        commands = new ArrayList();
        getResidueOffCommands(contextData, commands);
        command = new CommandCollection(contextData, commands);
        command = new ExecuteClassCommand(contextData, command, Residue.class);
        command =
            new PropagateClassCommand(contextData, command, Residue.class);
        offCommands.add(command);
        commands = new ArrayList();
        getSubchainOffCommands(contextData, commands);
        command = new CommandCollection(contextData, commands);
        command = new ExecuteClassCommand(contextData, command, Subchain.class);
        command =
            new PropagateClassCommand(contextData, command, Subchain.class);
        offCommands.add(command);

        // collapsing and unregistering
        //    command = new RegisterCommand( contextData, false );
        //    commands = new ArrayList( 2 );
        //    command = new PropagateClassCommand( contextData, command, null );
        //    commands.add( command );
        //    command = new ExpandCommand( contextData, false );
        //    commands.add( command );
        //    command = new CommandCollection( contextData, commands );
        //    command = new ExecuteClassCommand( contextData, command, Residue.class );
        //    command = new PropagateClassCommand( contextData, command, Residue.class );
        //
        //    offCommands.add( command );
    }

    /**
     * Gets the <code>mode</code> attribute of the <code>AtomCheck</code> object.
     *
     * @return The <code>mode</code> value.
     */
    public abstract int getMode();

    /**
     * Gets the <code>undoMode</code> attribute of the <code>AtomCheck</code> object.
     *
     * @return The <code>undoMode</code> value.
     */
    public abstract int getUndoMode();
}
