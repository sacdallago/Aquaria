/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d;

import javax.media.j3d.BranchGroup;
import javax.media.j3d.Node;
import javax.media.j3d.Switch;

/**
 * @author Karsten Klein
 *
 * @created November 14, 2000
 */
public class Junction {
    public static final int ON = 0;
    public static final int OFF = 1;
    public BranchGroup onBranch = null;
    public BranchGroup offBranch = null;
    public Switch switchGroup = null;

    /**
     * Constructor description.
     */
    public Junction() {
        onBranch = new BranchGroup();
        BranchGroupHelper.setDefaultCapabilities(onBranch);
        offBranch = new BranchGroup();
        BranchGroupHelper.setDefaultCapabilities(offBranch);
        switchGroup = new Switch();
        switchGroup.addChild(onBranch);
        switchGroup.addChild(offBranch);
        BranchGroupHelper.setDefaultCapabilities(switchGroup);
        switchGroup.setCapability(Switch.ALLOW_SWITCH_WRITE);
        switchGroup.setCapability(Switch.ALLOW_SWITCH_READ);
        setMode(ON);
    }

    /**
     * Method description.
     *
     * @param mode Parameter description.
     */
    public void setMode(int mode) {
        switchGroup.setWhichChild(mode);
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public int getMode() {
        return switchGroup.getWhichChild();
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public BranchGroup getOnBranch() {
        return onBranch;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public BranchGroup getOffBranch() {
        return offBranch;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public Node getEntry() {
        return switchGroup;
    }
}
