/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.accesscontrol;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.Vector;

import org.srs3d.viewer.util.ExceptionHandler;
import org.srs3d.viewer.util.Log;
import org.srs3d.viewer.util.XmlTag;

/**
 * Class for producing a license key file from lists of names and ips.
 *
 * @author Karsrten Fries, LION bioscience AG
 *
 * @created March 22, 2002
 */
public class Converter {
    private static final Log log = new Log(Converter.class);

    /**
     * Gets the <code>iPs</code> attribute of the <code>IPConverter</code> class.
     *
     * @param string Description of parameter.
     *
     * @return The <code>iPs</code> value.
     */
    public static Collection getIPs(String string) {
        Collection ips = new Vector();
        IP ip;
        String ipsString;
        String ipRange;
        StringTokenizer tokenizer = new StringTokenizer(string, ",");
        while (tokenizer.hasMoreTokens()) {
            ipRange = tokenizer.nextToken().trim();
            ip = new IP(ipRange);
            ips.add(ip);
        }
        return ips;
    }

    /**
     * The main program for the <code>IPConverter</code> class.
     *
     * @param args The command line arguments.
     */
    public static void main(String[] args) {
        Map map = new HashMap();
        long creationDate = System.currentTimeMillis();
        try {
            FileReader r = new FileReader(args[0]);
            BufferedReader reader = new BufferedReader(r);
            XmlTag tag = XmlTag.deserialize(reader);
            tag = tag.findTag("license");

            // version check??
            // set global default
            map.put("ExpirationDate", new Long(creationDate));
            map.put("CreationDate", new Long(creationDate));
            map.put("Version", "1.1");
            String value = tag.getAttribute("expire");
            if (value != null) {
                map.put("ExpirationDate", new Long(getDate(value)));
            } else {
                log.error("no attribute 'expire' specified in license tag!");
            }
            value = tag.getAttribute("version");
            if (value != null) {
                map.put("Version", value);
            } else {
                log.error("no attribute 'version' specified in license tag!");
            }
            Collection checkTags = tag.getTags("check");
            Iterator iterator = checkTags.iterator();
            int type;
            Map localMap;
            Collection checks = new ArrayList();
            map.put("EmbeddedAccessChecks", checks);
            while (iterator.hasNext()) {
                tag = (XmlTag) iterator.next();
                localMap = new HashMap();

                // for each check tag, we create a map of attributes as needed for
                // the respective check types
                // set the defaults
                localMap.put("AccessCheck", new Integer(0));
                localMap.put("CreationDate", new Long(creationDate));
                localMap.put("ExpirationDate", new Long(creationDate));
                value = tag.getAttribute("type");
                if (value != null) {
                    localMap.put("AccessCheck", new Integer(value));
                }
                value = tag.getAttribute("expire");
                if (value != null) {
                    localMap.put("ExpirationDate", new Long(getDate(value)));
                } else {

                    // use global value instead
                    localMap.put("ExpirationDate", map.get("ExpirationDate"));
                }
                Collection poolTags = tag.getTags("pool");
                if (poolTags != null) {
                    Collection identificationPools = new ArrayList();
                    Iterator poolIterator = poolTags.iterator();
                    IdentificationPool identificationPool;
                    XmlTag poolTag;
                    while (poolIterator.hasNext()) {
                        poolTag = (XmlTag) poolIterator.next();
                        identificationPool =
                            getIdentificationPool(poolTag.getAttribute("name"),
                                poolTag.getAttribute("ip"));
                        identificationPools.add(identificationPool.flatten());
                    }
                    localMap.put("IdentificationPools", identificationPools);
                }
                Collection fileTags = tag.getTags("file");
                if (fileTags != null) {
                    Map accessibleFiles = new HashMap();
                    Iterator fileIterator = fileTags.iterator();
                    XmlTag fileTag;
                    String inputName;
                    Long inputSize;
                    while (fileIterator.hasNext()) {
                        fileTag = (XmlTag) fileIterator.next();
                        inputName = fileTag.getAttribute("name");
                        inputSize = new Long(fileTag.getAttribute("size"));
                        accessibleFiles.put(inputName, inputSize);

                        // also drop a lower case version in case it doesn't exist yet
                        if (!accessibleFiles.containsKey(
                                  inputName.toLowerCase())) {
                            accessibleFiles.put(inputName.toLowerCase(),
                                inputSize);
                        }
                    }
                    localMap.put("AccessibleInputFiles", accessibleFiles);
                }
                checks.add(localMap);
            }
        } catch (Exception e) {
            log.error("usage: IPConverter <src-ips.txt> <dest-ips.key>");
            ExceptionHandler.handleException(e);
            return;
        }
        AccessControl accessControl = new AccessControl(map);
        AccessCheck accessCheck;
        AccessControl.save(accessControl, args[1]);
        try {
            AccessControl clonedAccessControl =
                AccessControl.load(new java.net.URL("file", "localhost", args[1]));
            clonedAccessControl.dump();
        } catch (Exception e) {
            ExceptionHandler.handleException(e);
        }
    }

    /**
     * Description of the method.
     *
     * @param names Description of parameter.
     * @param ips Description of parameter.
     *
     * @return Description of the returned value.
     */
    private static IdentificationPool getIdentificationPool(String names,
        String ips) {
        IPPool ipPool = new IPPool();
        ipPool.add(createIPList(ips));
        NamePool namePool;

        // names can be omitted for some checks
        if (names != null) {
            namePool = createNamePool(names);
        } else {

            // create an empty name pool
            namePool = new NamePool();
        }
        IdentificationPool identificationPool =
            new IdentificationPool(namePool, ipPool);
        return identificationPool;
    }

    /**
     * Retrieves the date attribute of the Converter class.
     *
     * @param date Description of parameter.
     *
     * @return The date value.
     */
    private static long getDate(String date) {
        StringTokenizer tokenizer = new StringTokenizer(date, "/");
        int year = Integer.parseInt(tokenizer.nextToken().trim());
        int month = Integer.parseInt(tokenizer.nextToken().trim());
        int day = Integer.parseInt(tokenizer.nextToken().trim());
        Calendar calendar = new GregorianCalendar(year, month - 1, day, 12, 0);
        return calendar.getTime().getTime();
    }

    /**
     * Description of the method.
     *
     * @param names Description of parameter.
     *
     * @return Description of the returned value.
     */
    private static NamePool createNamePool(String names) {
        StringTokenizer tokenizer = new StringTokenizer(names, ",");
        String name;
        int index;
        NamePool namePool = new NamePool();
        while (tokenizer.hasMoreTokens()) {
            name = tokenizer.nextToken().trim().toLowerCase();
            if (name.length() > 0) {
                namePool.add(name);
            }
        }
        return namePool;
    }

    /**
     * Description of the method.
     *
     * @param ipsString Description of parameter.
     *
     * @return Description of the returned value.
     */
    private static IPList createIPList(String ipsString) {
        Collection ips = getIPs(ipsString);
        IPList ipList = new IPList();
        int index = 0;
        Iterator iterator = ips.iterator();
        while (iterator.hasNext()) {
            ipList.add((IP) iterator.next());
        }
        return ipList;
    }
}
