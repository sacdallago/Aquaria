/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d;

import org.srs3d.viewer.j3d.objects.Link;

/**
 * Interfaces objects can have/can produce a link.
 *
 * @author Karsten Klein
 *
 * @created December 11, 2001
 */
public interface Linkable {

    /**
     * Gets the link of the <code>Linkable</code> object.
     *
     * @return The <code>link</code>. <code>null</code> if no link available.
     */
    public Link getLink();

    /**
     * Sets link of the <code>Linkable</code> object. The old links of the objects will
     * be overwritten. To merge links use the link methods.
     *
     * @param link The new <code>link</code>.
     */
    public void setLink(Link link);
}
