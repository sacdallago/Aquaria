/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.modules;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Vector;

import javax.swing.JCheckBoxMenuItem;
import javax.vecmath.Point3f;
import javax.vecmath.Vector3f;

import org.srs3d.viewer.bioatlas.factories.AtomTemplateFactory;
import org.srs3d.viewer.bioatlas.factories.ResidueTemplateFactory;
import org.srs3d.viewer.bioatlas.filters.AtomElementFilter;
import org.srs3d.viewer.bioatlas.filters.AtomTemplateFilter;
import org.srs3d.viewer.bioatlas.filters.ResidueTemplateFilter;
import org.srs3d.viewer.bioatlas.objects.Atom;
import org.srs3d.viewer.bioatlas.objects.Residue;
import org.srs3d.viewer.bioatlas.objects.templates.AtomTemplate;
import org.srs3d.viewer.bioatlas.objects.templates.ResidueTemplate;
import org.srs3d.viewer.bioatlas.visitors.AtomCollector;
import org.srs3d.viewer.bioatlas.visitors.BondCreator;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.commands.ColorCommand;
import org.srs3d.viewer.j3d.commands.RegisterCommand;
import org.srs3d.viewer.j3d.commands.SpawnCommand;
import org.srs3d.viewer.objects.ObjectContainer;
import org.srs3d.viewer.objects.ObjectManager;
import org.srs3d.viewer.objects.StrategyManager;
import org.srs3d.viewer.objects.filters.ObjectClassFilter;
import org.srs3d.viewer.objects.visitors.ObjectCollector;
import org.srs3d.viewer.visualization.AtomVolume;
import org.srs3d.viewer.visualization.Cuboid;
import org.srs3d.viewer.visualization.Subspace;

/**
 * Class description.
 *
 * @author Karsten Klein
 */
public class HydrogenBondsModule extends ProcessModule {
    private static float MAX_DISTANCE_SQUARED = 3.5f * 3.5f;
    private static float MAX_ANGLE = 0.5f;
    private boolean isEnabled = false;
    private JCheckBoxMenuItem checkBoxMenuItem = null;

    /**
     * <code>ProximityModule</code> constructor.
     *
     * @param name Description of parameter.
     * @param radius Description of parameter.
     * @param contextData Description of parameter.
     */
    public HydrogenBondsModule(String name, ContextData contextData) {
        super(name, contextData, true, true);
    }

    private Collection collect(Collection objects,
        ResidueTemplate residueTemplate) {
        ObjectCollector collector =
            new ObjectCollector(new ResidueTemplateFilter(residueTemplate));
        collector.visit(objects);
        return collector.getObjects();
    }

    private Collection collect(Collection objects, AtomTemplate atomTemplate) {
        ObjectCollector collector =
            new ObjectCollector(new AtomTemplateFilter(atomTemplate));
        collector.visit(objects);
        return collector.getObjects();
    }

    private void collect(Collection objects, Collection donors,
        Collection acceptors) {
        getComputation().setDescription("Identifying objects...");
        Collection atoms;
        Collection residues;
        ObjectContainer objectContainer = getContextData().getObjectContainer();
        ObjectCollector objectCollector;
        objectCollector =
            new ObjectCollector(new ObjectClassFilter(Residue.class));
        objectCollector.visit(objects);
        Collection allResidues = objectCollector.getObjects();
        Iterator iterator = allResidues.iterator();
        Residue residue;
        Collection ligandResidues = new HashSet();
        while (iterator.hasNext()) {
            residue = (Residue) iterator.next();
            if (residue.isLigand()) {
                ligandResidues.add(residue);
            }
        }
        allResidues.removeAll(ligandResidues);
        getComputation().setDescription("Identifying donors/acceptors...");
        residues =
            collect(allResidues, ResidueTemplateFactory.getTemplate("PRO"));
        allResidues.removeAll(residues);
        atoms = collect(allResidues, AtomTemplateFactory.getTemplate(" O  "));
        acceptors.addAll(atoms);

        // excelude all PROs
        residues =
            collect(allResidues, ResidueTemplateFactory.getTemplate("PRO"));
        allResidues.removeAll(residues);
        atoms = collect(allResidues, AtomTemplateFactory.getTemplate(" N  "));
        donors.addAll(atoms);
        residues =
            collect(allResidues, ResidueTemplateFactory.getTemplate("TRP"));
        atoms = collect(residues, AtomTemplateFactory.getTemplate(" NE1"));
        donors.addAll(atoms);
        allResidues.removeAll(residues);
        residues =
            collect(allResidues, ResidueTemplateFactory.getTemplate("HIS"));
        atoms = collect(residues, AtomTemplateFactory.getTemplate(" NE1"));
        acceptors.addAll(atoms);
        donors.addAll(atoms);
        atoms = collect(residues, AtomTemplateFactory.getTemplate(" ND1"));
        acceptors.addAll(atoms);
        donors.addAll(atoms);
        allResidues.removeAll(residues);
        residues =
            collect(allResidues, ResidueTemplateFactory.getTemplate("ARG"));
        atoms = collect(residues, AtomTemplateFactory.getTemplate(" NE "));
        acceptors.addAll(atoms);
        donors.addAll(atoms);
        atoms = collect(residues, AtomTemplateFactory.getTemplate(" NH1"));
        acceptors.addAll(atoms);
        donors.addAll(atoms);
        atoms = collect(residues, AtomTemplateFactory.getTemplate(" NH2"));
        acceptors.addAll(atoms);
        donors.addAll(atoms);
        allResidues.removeAll(residues);
        residues =
            collect(allResidues, ResidueTemplateFactory.getTemplate("ASN"));
        atoms = collect(residues, AtomTemplateFactory.getTemplate(" ND2"));
        acceptors.addAll(atoms);
        donors.addAll(atoms);
        atoms = collect(residues, AtomTemplateFactory.getTemplate(" OD1"));
        acceptors.addAll(atoms);
        allResidues.removeAll(residues);
        residues =
            collect(allResidues, ResidueTemplateFactory.getTemplate("ASP"));
        atoms = collect(residues, AtomTemplateFactory.getTemplate(" ND2"));
        acceptors.addAll(atoms);
        donors.addAll(atoms);
        atoms = collect(residues, AtomTemplateFactory.getTemplate(" OD1"));
        acceptors.addAll(atoms);
        residues =
            collect(allResidues, ResidueTemplateFactory.getTemplate("ASN"));
        atoms = collect(residues, AtomTemplateFactory.getTemplate(" ND2"));
        acceptors.addAll(atoms);
        donors.addAll(atoms);
        atoms = collect(residues, AtomTemplateFactory.getTemplate(" OD1"));
        acceptors.addAll(atoms);
        donors.addAll(atoms);
        allResidues.removeAll(residues);
        residues =
            collect(allResidues, ResidueTemplateFactory.getTemplate("GLU"));
        atoms = collect(residues, AtomTemplateFactory.getTemplate(" OE1"));
        acceptors.addAll(atoms);
        donors.addAll(atoms);
        atoms = collect(residues, AtomTemplateFactory.getTemplate(" OE2"));
        acceptors.addAll(atoms);
        donors.addAll(atoms);
        allResidues.removeAll(residues);
        residues =
            collect(allResidues, ResidueTemplateFactory.getTemplate("GLN"));
        atoms = collect(residues, AtomTemplateFactory.getTemplate(" OE1"));
        acceptors.addAll(atoms);
        donors.addAll(atoms);
        atoms = collect(residues, AtomTemplateFactory.getTemplate(" NE2"));
        donors.addAll(atoms);
        allResidues.removeAll(residues);
        residues =
            collect(allResidues, ResidueTemplateFactory.getTemplate("SER"));
        atoms = collect(residues, AtomTemplateFactory.getTemplate(" OG "));
        acceptors.addAll(atoms);
        donors.addAll(atoms);
        allResidues.removeAll(residues);
        residues =
            collect(allResidues, ResidueTemplateFactory.getTemplate("THR"));
        atoms = collect(residues, AtomTemplateFactory.getTemplate(" OD1"));
        acceptors.addAll(atoms);
        donors.addAll(atoms);
        allResidues.removeAll(residues);
        residues =
            collect(allResidues, ResidueTemplateFactory.getTemplate("TYR"));
        atoms = collect(residues, AtomTemplateFactory.getTemplate(" OH "));
        acceptors.addAll(atoms);
        donors.addAll(atoms);
        allResidues.removeAll(residues);
        residues =
            collect(allResidues, ResidueTemplateFactory.getTemplate("LYS"));
        atoms = collect(residues, AtomTemplateFactory.getTemplate(" N2 "));
        acceptors.addAll(atoms);
        donors.addAll(atoms);
        allResidues.removeAll(residues);
        atoms = collect(residues, AtomTemplateFactory.getTemplate(" N2 "));
        acceptors.addAll(atoms);
        donors.addAll(atoms);
        ObjectCollector atomCollector =
            new ObjectCollector(new AtomElementFilter("O"));
        atomCollector.visit(ligandResidues);
        donors.addAll(atomCollector.getObjects());
        acceptors.addAll(atomCollector.getObjects());
        atomCollector = new ObjectCollector(new AtomElementFilter("N"));
        atomCollector.visit(ligandResidues);
        donors.addAll(atomCollector.getObjects());
        acceptors.addAll(atomCollector.getObjects());
    }

    private void createConnectivityMap(Collection objects, Map connectivityMap) {
        ObjectCollector objectCollector =
            new ObjectCollector(new ObjectClassFilter(Atom.class));
        Vector atoms = new Vector(1000);
        objectCollector.setObjects(atoms);
        objectCollector.visit(objects);
        int i;
        int j;
        Atom atomI;
        Atom atomJ;
        HashSet atomISet;
        for (i = 0; i < atoms.size(); i++) {
            atomI = (Atom) atoms.elementAt(i);
            atomISet = null;
            for (j = 0; j < atoms.size(); j++) {
                if (j != i) {
                    atomJ = (Atom) atoms.elementAt(j);
                    if (BondCreator.isConnected(atomI, atomJ)) {
                        if (atomISet == null) {
                            atomISet = new HashSet(5);
                            connectivityMap.put(atomI, atomISet);
                        }
                        atomISet.add(atomJ);
                    }
                }
            }
        }
    }

    private void removeAtom(String element, Collection atoms) {
        Iterator iterator = atoms.iterator();
        Atom atom;
        while (iterator.hasNext()) {
            atom = (Atom) iterator.next();
            if (atom.getTemplate().is(element)) {
                iterator.remove();
            }
        }
    }

    private Vector3f computeHydrogenOffset(Atom donor, Map connectivityMap) {
        Collection connectedAtoms = (Collection) connectivityMap.get(donor);

        // donor must have at least 2 bonds
        if (connectedAtoms != null && connectedAtoms.size() > 1) {
            Vector3f v0 = new Vector3f(donor.getCoordinate());
            Vector3f v1 = new Vector3f();
            Vector3f averaged = new Vector3f();
            Iterator iterator = connectedAtoms.iterator();
            while (iterator.hasNext()) {
                Atom atom = (Atom) iterator.next();
                v1.set(v0);
                v1.sub(atom.getCoordinate());
                v1.normalize();
                averaged.add(v1);
            }
            averaged.normalize();
            return averaged;
        }
        return null;
    }

    private Collection createPairs(Collection donors, Collection acceptors,
        Map connectivityMap) {
        Collection pairs = new HashSet(donors.size());
        Atom donor;
        Atom acceptor;
        Vector3f vector = new Vector3f();
        Vector3f nh = new Vector3f();
        Vector3f h = new Vector3f();
        Pair pair;
        boolean valid;
        boolean hasHydrogen;

        // create subdivision for efficient atom proximity computation (acceptors only)
        AtomCollector allAtomCollector = new AtomCollector();
        allAtomCollector.setObjects(acceptors);
        Cuboid cuboid = new Cuboid();
        Point3f center = allAtomCollector.getCenter();
        Vector3f extend = allAtomCollector.getExtend();
        extend.scale(0.5f);
        center.sub(extend);
        extend.scale(2);
        cuboid.setCoordinate(allAtomCollector.getCenter());
        cuboid.setExtend(Math.max(extend.x, Math.max(extend.y, extend.z)));
        Subspace subspace = new Subspace(cuboid);
        Iterator iterator = acceptors.iterator();
        Atom atom;
        AtomVolume atomVolume;
        HashSet excludedAcceptors = new HashSet();
        while (iterator.hasNext()) {
            atom = (Atom) iterator.next();
            atomVolume = new AtomVolume(atom, 3.5f);
            subspace.addElement(atomVolume);
        }
        subspace.subdivide(7);
        iterator = donors.iterator();
        Iterator acceptorIterator;
        Collection candidates = new HashSet();
        while (iterator.hasNext()) {
            donor = (Atom) iterator.next();
            candidates.clear();
            subspace.collectCandidates(new AtomVolume(donor, 0), candidates);
            acceptorIterator = candidates.iterator();
            nh = computeHydrogenOffset(donor, connectivityMap);
            while (acceptorIterator.hasNext()) {
                acceptor = ((AtomVolume) acceptorIterator.next()).getAtom();
                if (acceptor != donor && !excludedAcceptors.contains(acceptor)) {
                    vector.set(acceptor.getCoordinate());
                    vector.sub(donor.getCoordinate());
                    if (vector.lengthSquared() < MAX_DISTANCE_SQUARED) {
                        valid = nh != null;
                        if (valid) {

                            // estimate H position
                            h.set(donor.getCoordinate());
                            h.add(nh);
                            vector.set(acceptor.getCoordinate());
                            vector.sub(h);
                            if (vector.lengthSquared() < MAX_DISTANCE_SQUARED) {
                                vector.normalize();
                                if (vector.dot(nh) < MAX_ANGLE) {
                                    valid = false;
                                }
                            } else {

                                // distance from projected H atom to the acceptor is to large
                                valid = false;
                            }
                        } else {
                            valid = true;
                        }
                        if (valid) {

                            // :TODO: check connectivity
                            if (!isBonded(donor, acceptor, null, 4,
                                      connectivityMap)) {

                                // pair found
                                pair = new Pair();
                                pair.donor = donor;
                                pair.acceptor = acceptor;
                                pairs.add(pair);

                                // once found a donor, it is not accesible anymore as acceptor
                                excludedAcceptors.add(donor);
                            }
                        }
                    }
                }
            }
        }
        return pairs;
    }

    /**
     * Description of the method.
     *
     * @param e Description of parameter.
     */
    public void process(ActionEvent e) {
        if (isEnabled) {
            final ContextData contextData = getContextData();
            ObjectManager objectManager = contextData.getObjectManager();
            final StrategyManager strategyManager =
                contextData.getStrategyManager();
            Collection objects =
                RepresentationModule.collectObjects(contextData);
            Collection set = new HashSet();
            objectManager.collapseUp(objects, set);
            Collection roots = new HashSet(set);
            objectManager.getUpAssociations(set, roots);
            ObjectManager.extract(roots, ObjectContainer.class);
            if (!roots.isEmpty()) {
                final ObjectContainer root =
                    (ObjectContainer) roots.iterator().next();
                getComputation().setDescription("Collecting protein chains...");
                getComputation().setDescription("Collecting donors and acceptors...");
                Collection donors = new ArrayList();
                Collection acceptors = new ArrayList();
                collect(objects, donors, acceptors);
                getComputation().setProgress(40);
                getComputation().setDescription("Building connectivity map...");

                // build connectivity map
                final Map connectivityMap = new HashMap();
                createConnectivityMap(objects, connectivityMap);
                getComputation().setProgress(70);

                // extract pairs
                getComputation().setDescription("creating hydrogen bonds...");
                final Collection pairs =
                    createPairs(donors, acceptors, connectivityMap);
                getComputation().setProgress(90);
                getContextData().getContext().addUpdateCallback(new org.srs3d.viewer.j3d.behaviors.UpdateBehavior.Callback() {
                        public void execute() {
                            Iterator iterator = pairs.iterator();
                            Pair pair;
                            Collection createdContainers = new ArrayList();
                            while (iterator.hasNext()) {
                                pair = (Pair) iterator.next();
                                org.srs3d.viewer.j3d.objects.Line line =
                                    new org.srs3d.viewer.j3d.objects.Line();
                                line.getCoordinates().setAt(0,
                                    pair.donor.getCoordinate());
                                line.getCoordinates().setAt(1,
                                    pair.acceptor.getCoordinate());
                                ObjectContainer hydrogenContainer =
                                    new ObjectContainer();
                                hydrogenContainer.setName("Hyodrogen Bond " +
                                    pair.donor.getTemplate().getElement() +
                                    "-" +
                                    pair.acceptor.getTemplate().getElement());
                                createdContainers.add(hydrogenContainer);
                                hydrogenContainer.addObject(line);
                                root.addObject(hydrogenContainer);
                            }
                            SpawnCommand spawnCommand =
                                new SpawnCommand(contextData);
                            spawnCommand.setParent(root);
                            strategyManager.execute(createdContainers,
                                spawnCommand);
                            RegisterCommand registerCommand =
                                new RegisterCommand(contextData);
                            registerCommand.setParent(root);
                            strategyManager.propagate(createdContainers,
                                registerCommand, false);
                            ColorCommand colorCommand =
                                new ColorCommand(contextData);
                            strategyManager.propagate(createdContainers,
                                colorCommand, false);

                            //              ProximityModule.expandAtomProximity( contextData, contactAtoms, true );
                            org.srs3d.viewer.bioatlas.Capture.updateSelections(contextData,
                                true);
                        }
                    });
            }
        }
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public Component getCompoenent() {
        if (checkBoxMenuItem == null) {
            checkBoxMenuItem = new JCheckBoxMenuItem();
        }
        return checkBoxMenuItem;
    }

    /**
     * Description of the method.
     */
    public void updateIntern() {
        Collection objects =
            RepresentationModule.collectObjects(getContextData());
        isEnabled = !objects.isEmpty();
        if (getCompoenent() != null) {
            getCompoenent().setEnabled(isEnabled);
        }
    }

    private boolean isBonded(Atom atomA, Atom atomB, Atom exclude, int max,
        Map connectivityMap) {
        if (atomA != atomB) {
            if (max > 0) {
                Collection connectedAtoms =
                    (Collection) connectivityMap.get(atomA);
                if (connectedAtoms != null && !connectedAtoms.isEmpty()) {
                    Iterator iterator = connectedAtoms.iterator();
                    Atom atom;
                    boolean isBonded = false;
                    while (iterator.hasNext()) {
                        atom = (Atom) iterator.next();
                        if (atom != exclude) {
                            isBonded |= isBonded(atom, atomB, atomA, max - 1,
                                connectivityMap);
                        }
                    }
                    return isBonded;
                }
                return false;
            }
            return false;
        }
        return true;
    }

    /**
     * Method description.
     *
     * @param atom1 Parameter description.
     * @param atom2 Parameter description.
     * @param connectivityMap Parameter description.
     *
     * @return Return description.
     */
    public boolean exclude(Atom atom1, Atom atom2, Map connectivityMap) {
        Collection connected = (Collection) connectivityMap.get(atom1);
        if (connected != null && !connected.isEmpty()) {
            Vector3f normal = new Vector3f();
            Vector3f vector = new Vector3f();
            vector.set(atom1.getCoordinate());
            Atom atom = (Atom) connected.iterator().next();
            vector.sub(atom.getCoordinate());
            vector.normalize();
            normal.set(vector);
            vector.scale(-1.91f);
            vector.add(atom1.getCoordinate());

            // vector contains now the anchor of the plane with normal normal
            // project donor acceptor distance onto normal
            Vector3f projection = new Vector3f();
            projection.set(atom2.getCoordinate());
            projection.sub(vector);
            if (projection.dot(normal) < 0) {
                return false;
            }
        }
        return true;
    }

    /**
     * Class description.
     *
     * @author Karsten Klein, LION bioscience AG
     */
    public static class Pair {
        public Atom donor;
        public Atom acceptor;
    }
}
