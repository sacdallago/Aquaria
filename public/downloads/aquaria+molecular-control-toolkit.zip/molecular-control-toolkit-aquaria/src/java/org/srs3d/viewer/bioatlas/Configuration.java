/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas;

import org.srs3d.viewer.annotation.colorschemes.DisplacementColorScheme;
import org.srs3d.viewer.annotation.colorschemes.HomologyAltColorScheme;
import org.srs3d.viewer.annotation.colorschemes.HomologyColorScheme;
import org.srs3d.viewer.bioatlas.attributes.AtomRepresentation;
import org.srs3d.viewer.bioatlas.attributes.Representation;
import org.srs3d.viewer.bioatlas.attributes.ResidueRepresentation;
import org.srs3d.viewer.bioatlas.attributes.SubchainRepresentation;
import org.srs3d.viewer.bioatlas.colorschemes.MeshColorScheme;
import org.srs3d.viewer.bioatlas.colorschemes.StructureColorScheme;
import org.srs3d.viewer.bioatlas.colorschemes.TransparentColorScheme;
import org.srs3d.viewer.bioatlas.creators.AtomGeometryCreator;
import org.srs3d.viewer.bioatlas.creators.BondGeometryCreator;
import org.srs3d.viewer.bioatlas.creators.ChainGeometryCreator;
import org.srs3d.viewer.bioatlas.creators.CoilGeometryCreator;
import org.srs3d.viewer.bioatlas.creators.DnaGeometryCreator;
import org.srs3d.viewer.bioatlas.creators.HelixGeometryCreator;
import org.srs3d.viewer.bioatlas.creators.LayerGeometryCreator;
import org.srs3d.viewer.bioatlas.creators.ResidueGeometryCreator;
import org.srs3d.viewer.bioatlas.creators.StrandGeometryCreator;
import org.srs3d.viewer.bioatlas.creators.TurnGeometryCreator;
import org.srs3d.viewer.bioatlas.objects.Annotation;
import org.srs3d.viewer.bioatlas.objects.Atom;
import org.srs3d.viewer.bioatlas.objects.Bond;
import org.srs3d.viewer.bioatlas.objects.Chain;
import org.srs3d.viewer.bioatlas.objects.ChainFragment;
import org.srs3d.viewer.bioatlas.objects.Coil;
import org.srs3d.viewer.bioatlas.objects.Feature;
import org.srs3d.viewer.bioatlas.objects.Helix;
import org.srs3d.viewer.bioatlas.objects.Layer;
import org.srs3d.viewer.bioatlas.objects.NucleicChain;
import org.srs3d.viewer.bioatlas.objects.Residue;
import org.srs3d.viewer.bioatlas.objects.Section;
import org.srs3d.viewer.bioatlas.objects.Site;
import org.srs3d.viewer.bioatlas.objects.Strand;
import org.srs3d.viewer.bioatlas.objects.Turn;
import org.srs3d.viewer.bioatlas.objects.strategies.AnnotationStrategy;
import org.srs3d.viewer.bioatlas.objects.strategies.AtomStrategy;
import org.srs3d.viewer.bioatlas.objects.strategies.BondStrategy;
import org.srs3d.viewer.bioatlas.objects.strategies.ChainFragmentStrategy;
import org.srs3d.viewer.bioatlas.objects.strategies.ChainStrategy;
import org.srs3d.viewer.bioatlas.objects.strategies.FeatureStrategy;
import org.srs3d.viewer.bioatlas.objects.strategies.LayerStrategy;
import org.srs3d.viewer.bioatlas.objects.strategies.ResidueStrategy;
import org.srs3d.viewer.bioatlas.objects.strategies.SiteStrategy;
import org.srs3d.viewer.bioatlas.objects.strategies.SubchainStrategy;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.attributes.Expanded;
import org.srs3d.viewer.j3d.attributes.Visible;
import org.srs3d.viewer.j3d.creators.BoxGeometryCreator;
import org.srs3d.viewer.j3d.creators.LabelGeometryCreator;
import org.srs3d.viewer.j3d.creators.LineGeometryCreator;
import org.srs3d.viewer.j3d.creators.OverlayGeometryCreator;
import org.srs3d.viewer.j3d.creators.PointGeometryCreator;
import org.srs3d.viewer.j3d.creators.PointSetGeometryCreator;
import org.srs3d.viewer.j3d.creators.RectangleGeometryCreator;
import org.srs3d.viewer.j3d.creators.SurfaceGeometryCreator;
import org.srs3d.viewer.j3d.factories.GeometryCreatorFactory;
import org.srs3d.viewer.j3d.factories.SpawnerFactory;
import org.srs3d.viewer.j3d.objects.Box;
import org.srs3d.viewer.j3d.objects.Label;
import org.srs3d.viewer.j3d.objects.Line;
import org.srs3d.viewer.j3d.objects.Overlay;
import org.srs3d.viewer.j3d.objects.Point;
import org.srs3d.viewer.j3d.objects.PointSet;
import org.srs3d.viewer.j3d.objects.Rectangle;
import org.srs3d.viewer.j3d.objects.Surface;
import org.srs3d.viewer.j3d.objects.strategies.BoxStrategy;
import org.srs3d.viewer.j3d.objects.strategies.LabelStrategy;
import org.srs3d.viewer.j3d.objects.strategies.LineStrategy;
import org.srs3d.viewer.j3d.objects.strategies.ObjectContainerStrategy;
import org.srs3d.viewer.j3d.objects.strategies.PointSetStrategy;
import org.srs3d.viewer.j3d.objects.strategies.PointStrategy;
import org.srs3d.viewer.j3d.objects.strategies.SurfaceStrategy;
import org.srs3d.viewer.objects.Attribute;
import org.srs3d.viewer.objects.ObjectContainer;
import org.srs3d.viewer.objects.State;
import org.srs3d.viewer.objects.StatePrototypeManager;
import org.srs3d.viewer.objects.StrategyManager;

/**
 * Description of the class.
 *
 * @author Karsten Klein
 *
 * @created March 22, 2001
 */
public class Configuration {

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     */
    public static void registerGeometryCreators(ContextData contextData) {
        GeometryCreatorFactory factory =
            contextData.getGeometryCreatorFactory();
        factory.register(Overlay.class, OverlayGeometryCreator.class);
        factory.register(Box.class, BoxGeometryCreator.class);
        factory.register(Line.class, LineGeometryCreator.class);
        factory.register(Rectangle.class, RectangleGeometryCreator.class);
        factory.register(Label.class, LabelGeometryCreator.class);
        factory.register(Surface.class, SurfaceGeometryCreator.class);
        factory.register(Point.class, PointGeometryCreator.class);
        factory.register(PointSet.class, PointSetGeometryCreator.class);
        factory.register(Atom.class, AtomGeometryCreator.class);
        factory.register(Bond.class, BondGeometryCreator.class);
        factory.register(Chain.class, ChainGeometryCreator.class);
        factory.register(ChainFragment.class, ChainGeometryCreator.class);
        factory.register(Coil.class, CoilGeometryCreator.class);
        factory.register(NucleicChain.class, DnaGeometryCreator.class);
        factory.register(Helix.class, HelixGeometryCreator.class);
        factory.register(Layer.class, LayerGeometryCreator.class);
        factory.register(Residue.class, ResidueGeometryCreator.class);
        factory.register(Strand.class, StrandGeometryCreator.class);
        factory.register(Turn.class, TurnGeometryCreator.class);
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     */
    public static void registerSpawners(ContextData contextData) {
        SpawnerFactory factory = contextData.getSpawnerFactory();
        factory.register(Layer.class);
        factory.register(Chain.class);
        factory.register(ChainFragment.class);
        factory.register(Strand.class);
        factory.register(NucleicChain.class);
        factory.register(Helix.class);
        factory.register(Coil.class);
        factory.register(Turn.class);
        factory.register(Residue.class);
        factory.register(Overlay.class);
        factory.register(Box.class);
        factory.register(Line.class);
        factory.register(Rectangle.class);
        factory.register(Label.class);
        factory.register(Surface.class);
        factory.register(Point.class);
        factory.register(PointSet.class);
        factory.register(ObjectContainer.class);
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     */
    public static void registerStrategies(ContextData contextData) {
        StrategyManager manager = contextData.getStrategyManager();
        manager.register(ObjectContainer.class, new ObjectContainerStrategy());
        manager.register(Layer.class, new LayerStrategy());
        manager.register(Chain.class, new ChainStrategy());
        manager.register(ChainFragment.class, new ChainFragmentStrategy());
        manager.register(Site.class, new SiteStrategy());
        manager.register(Residue.class, new ResidueStrategy());
        manager.register(Helix.class, new SubchainStrategy());
        manager.register(Turn.class, new SubchainStrategy());
        manager.register(Strand.class, new SubchainStrategy());
        manager.register(Coil.class, new SubchainStrategy());
        manager.register(Helix.class, new SubchainStrategy());
        manager.register(Section.class, new SubchainStrategy());
        manager.register(NucleicChain.class, new SubchainStrategy());
        manager.register(Atom.class, new AtomStrategy());
        manager.register(Bond.class, new BondStrategy());
        manager.register(Line.class, new LineStrategy());
        manager.register(Label.class, new LabelStrategy());
        manager.register(Surface.class, new SurfaceStrategy());
        manager.register(Point.class, new PointStrategy());
        manager.register(PointSet.class, new PointSetStrategy());
        manager.register(Box.class, new BoxStrategy());
        manager.register(Feature.class, new FeatureStrategy());
        manager.register(Annotation.class, new AnnotationStrategy());
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     */
    public static void registerPrototypes(ContextData contextData) {
        State visibleState = new State();
        visibleState.setAttribute(Attribute.getInstance(Visible.class));
        State expandedState = new State();
        expandedState.setAttribute(Attribute.getInstance(Visible.class));
        expandedState.setAttribute(Attribute.getInstance(Expanded.class));
        StatePrototypeManager manager = contextData.getStatePrototypeManager();
        manager.register(ObjectContainer.class, expandedState);

        // for up navigation behavior
        manager.register(Layer.class, expandedState);
        manager.register(Chain.class, expandedState);
        manager.register(ChainFragment.class, expandedState);
        SubchainRepresentation subchainRepresentation =
            (SubchainRepresentation) Attribute.getInstance(SubchainRepresentation.class);
        subchainRepresentation.setMode(Representation.REPRESENTATION_RIBBON);
        State subchainState = visibleState.copy();
        subchainState.setAttribute(subchainRepresentation);
        manager.register(Helix.class, subchainState);
        manager.register(NucleicChain.class, subchainState);
        manager.register(Strand.class, subchainState);
        manager.register(Turn.class, subchainState);
        manager.register(Coil.class, subchainState);
        manager.register(Box.class, visibleState);
        manager.register(Line.class, visibleState);
        manager.register(Label.class, visibleState);
        manager.register(Rectangle.class, visibleState);
        manager.register(Surface.class, visibleState);
        manager.register(Overlay.class, visibleState);
        manager.register(Point.class, visibleState);
        manager.register(PointSet.class, visibleState);
        ResidueRepresentation residueRepresentation =
            (ResidueRepresentation) Attribute.getInstance(ResidueRepresentation.class);
        residueRepresentation.setMode(Representation.REPRESENTATION_RIBBON);
        State residueState = visibleState.copy();
        residueState.setAttribute(residueRepresentation);
        manager.register(Residue.class, residueState);
        AtomRepresentation atomRepresentation =
            (AtomRepresentation) Attribute.getInstance(AtomRepresentation.class);
        atomRepresentation.setMode(Representation.REPRESENTATION_VAN_DER_WAALS);
        State atomState = visibleState.copy();
        atomState.setAttribute(atomRepresentation);
        manager.register(Atom.class, atomState);

        // needed to do spawning of bond geometry
        State bondState = visibleState.copy();
        manager.register(Bond.class, bondState);
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     */
    public static void configure(ContextData contextData) {
        registerGeometryCreators(contextData);
        registerSpawners(contextData);
        registerPrototypes(contextData);
        registerStrategies(contextData);
        createContextColorSchemes(contextData);
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     */
    public static void createContextColorSchemes(ContextData contextData) {
        contextData.setProperty(TransparentColorScheme.class,
            new TransparentColorScheme(contextData));
        contextData.setProperty(HomologyColorScheme.class,
            new HomologyColorScheme(contextData));
        contextData.setProperty(HomologyAltColorScheme.class,
            new HomologyAltColorScheme(contextData));
        contextData.setProperty(DisplacementColorScheme.class,
            new DisplacementColorScheme(contextData));
        contextData.setProperty(StructureColorScheme.class,
            new StructureColorScheme(contextData));
        contextData.setProperty(MeshColorScheme.class,
            new MeshColorScheme(contextData));
    }
}
