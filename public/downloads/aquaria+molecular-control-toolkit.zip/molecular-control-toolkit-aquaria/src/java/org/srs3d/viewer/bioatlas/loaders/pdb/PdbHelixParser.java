/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.loaders.pdb;

import org.srs3d.viewer.bioatlas.objects.Chain;
import org.srs3d.viewer.bioatlas.objects.Helix;

/**
 * This class parses strings for pdb HELIX tags and tranfers/builts the appropriate
 * datastructure in a <code>ObjectContainer</code>.
 *
 * @author Karsten Klein, 01/2001
 *
 * @created July 27, 2001
 * @since 1.0
 */
public class PdbHelixParser extends PdbSubchainParser {

    /** Description of the field. */
    public static final String TAG = new String("HELIX ");

    /** Description of the field. */
    private String helixId = null;

    /** Description of the field. */
    private int helixSerial = Helix.INVALID_SERIAL;

    /** Description of the field. */
    private String helixClassIdentifier = null;

    /** Description of the field. */
    private String helixComment = null;

    /**
     * Parses the formated pdb string for HELIX data. The data is stored locally and no
     * object is created. Note that the helix length record is NOT read, because it is
     * not included in some pdb files. The length of the helix will be computed at a
     * later stage, while analyzing the secondary structure annotations.
     *
     * @param string Description of parameter.
     */
    public void create(String string) {
        clear();
        helixId = extractString(string, 11, 14, true);
        helixSerial = extractInt(string, 7, 10);
        chainId = extractChar(string, 19);
        initialResidueName = extractString(string, 15, 18);
        initialResidueId = extractInt(string, 21, 25);
        initialResidueICode = extractChar(string, 25);
        endResidueName = extractString(string, 27, 30);
        endResidueId = extractInt(string, 33, 37);
        endResidueICode = extractChar(string, 37);
        helixClassIdentifier = extractString(string, 38, 40, true);
        helixComment = extractString(string, 40, 70, true);
    }

    /**
     * Visits the chain. This method adds a helix subchain to the chain if the helix is
     * defacto part of the chain.
     *
     * @param chain Description of parameter.
     */
    public void visit(Chain chain) {
        super.visit(chain);
        Helix helix = new Helix();
        visit(helix, chain);
    }

    /**
     * Visits the helix and the chain. This method adds a helix subchain to the chain if
     * the helix is defacto part of the chain.
     *
     * @param helix Description of parameter.
     * @param chain Description of parameter.
     */
    public void visit(Helix helix, Chain chain) {
        helix.setId(helixId);
        helix.setSerial(helixSerial);
        super.visit(helix, chain);
    }

    /**
     * Description of the method.
     */
    public void clear() {
        super.clear();
        helixId = null;
        helixSerial = Helix.INVALID_SERIAL;
        helixClassIdentifier = null;
        helixComment = null;
    }
}
