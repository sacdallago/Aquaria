/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.dispatcher;

import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Vector;

import javax.media.j3d.Transform3D;
import javax.swing.KeyStroke;
import javax.vecmath.Color3f;
import javax.vecmath.Matrix3f;
import javax.vecmath.Point3d;
import javax.vecmath.Point3f;
import javax.vecmath.Tuple3f;
import javax.vecmath.Vector3d;
import javax.vecmath.Vector3f;

import org.srs3d.viewer.bioatlas.filters.BaseObjectFilter;
import org.srs3d.viewer.bioatlas.modules.RuntimeTestModule;
import org.srs3d.viewer.bioatlas.objects.Annotation;
import org.srs3d.viewer.bioatlas.objects.Atom;
import org.srs3d.viewer.bioatlas.objects.Bond;
import org.srs3d.viewer.bioatlas.objects.Chain;
import org.srs3d.viewer.bioatlas.objects.ChainFragment;
import org.srs3d.viewer.bioatlas.objects.Feature;
import org.srs3d.viewer.bioatlas.objects.Layer;
import org.srs3d.viewer.bioatlas.objects.Residue;
import org.srs3d.viewer.bioatlas.objects.Site;
import org.srs3d.viewer.bioatlas.objects.Subchain;
import org.srs3d.viewer.bioatlas.visitors.AtomCollector;
import org.srs3d.viewer.j3d.Colorable;
import org.srs3d.viewer.j3d.Context;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.DispatchManager;
import org.srs3d.viewer.j3d.Selection;
import org.srs3d.viewer.j3d.behaviors.UpdateBehavior.Callback;
import org.srs3d.viewer.j3d.behaviors.dispatcher.Dispatch;
import org.srs3d.viewer.j3d.behaviors.dispatcher.OperationDispatch;
import org.srs3d.viewer.j3d.commands.ColorCommand;
import org.srs3d.viewer.j3d.commands.ExpandCommand;
import org.srs3d.viewer.j3d.commands.IntersectCommand;
import org.srs3d.viewer.j3d.commands.SpawnCommand;
import org.srs3d.viewer.j3d.operations.CallbackOperation;
import org.srs3d.viewer.j3d.operations.InputOperation;
import org.srs3d.viewer.j3d.operations.IntersectOperation;
import org.srs3d.viewer.j3d.operations.KeyStrokeOperation;
import org.srs3d.viewer.j3d.operations.ParameterStringOperation;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.objects.ObjectFilter;
import org.srs3d.viewer.objects.ObjectManager;
import org.srs3d.viewer.objects.Operation;
import org.srs3d.viewer.objects.State;
import org.srs3d.viewer.objects.StateManager;
import org.srs3d.viewer.objects.StrategyManager;
import org.srs3d.viewer.objects.filters.ObjectClassFilter;
import org.srs3d.viewer.objects.filters.ObjectSubclassFilter;
import org.srs3d.viewer.objects.visitors.ObjectCollector;
import org.srs3d.viewer.objects.visitors.ObjectLocalizer;
import org.srs3d.viewer.util.Chronometer;
import org.srs3d.viewer.util.ExceptionHandler;
import org.srs3d.viewer.util.SetUtility;

/**
 * @author Karsten Klein, 11/2000
 *
 * @created March 20, 2001
 * @since 1.0
 */
public class NavigateUpDispatcher extends ThreadedDispatcher {
    private Collection previousSelection = new HashSet();
    private Residue rangeAnchor = null;
    private transient Class tabLevel = null;
    private transient ArrayList tabLevelObjects = new ArrayList();
    private transient AbstractObject tabObject = null;

    /**
     * Gets the <code>radians</code> attribute of the <code>NavigateUpDispatcher</code>
     * object.
     *
     * @param keyStroke Description of parameter.
     *
     * @return The <code>radians</code> value.
     */
    public float getRadians(KeyStroke keyStroke) {
        float radians = 3.0f * (float) Math.PI / 180;
        if ((keyStroke.getModifiers() & KeyEvent.CTRL_MASK) != 0) {
            radians = (float) Math.PI / 4;
        }
        return radians;
    }

    /**
     * Gets the <code>delta</code> attribute of the <code>NavigateUpDispatcher</code>
     * object.
     *
     * @param keyStroke Description of parameter.
     *
     * @return The <code>delta</code> value.
     */
    public float getDelta(KeyStroke keyStroke) {
        float delta = 1;
        if ((keyStroke.getModifiers() & KeyEvent.CTRL_MASK) != 0) {
            delta = 10;
        }
        return delta;
    }

    /**
     * Description of the method.
     *
     * @param context Description of parameter.
     * @param operation Description of parameter.
     */
    public void process(final Context context, final Operation operation) {
        final ContextData contextData = context.getContextData();
        final ObjectManager objectManager = contextData.getObjectManager();
        final Selection selection =
            contextData.getSelectionManager().getSelection();
        super.runDispatches(contextData, operation);
        if (operation.isConsumed()) {
            return;
        }
        if (operation.is("MOVE_ZOOMBOX") || operation.is("SWITCH_ALIGNMENT") ||
              operation.getId().startsWith("UPDATE-")) {
            return;
        }
        if (operation.is("UPDATE_COLORING")) {
            processUpdateColoring(context.getContextData(), operation);
            return;
        }
        if (operation.is("LOAD_STRUCTURE")) {
            processLoadStructure(contextData, operation);
            return;
        }
        if (operation.is("LOAD_ANNOTATION")) {
            processLoadAnnotation(contextData, operation);
            return;
        }
        if (operation.is("LOAD_SEQUENCE")) {
            processLoadSequence(contextData, operation);
            return;
        }
        if (operation.is("KEY_INPUT")) {
            processKeyInput(contextData, operation);
            return;
        }
        if (operation.is("KEYSTROKE")) {
            processKeyStroke(contextData, operation);
            return;
        }
        if (operation.is("INTERSECT")) {
            processIntersect(contextData, operation);
            return;
        }
        if (operation.is("COPY")) {
            if (operation.getContext() == context) {
                DispatchManager.runDispatch(context, operation);
            }
            return;
        }
        if (operation.is("PASTE")) {
            if (operation.getContext() == context) {
                DispatchManager.runDispatch(context, operation);
            }
            return;
        }
        if (operation.is("CALLBACK")) {
            processCallback(contextData, operation);
        } else if (operation.is("MOVE_OVERVIEW")) {
            processMoveOverview(contextData, operation);
        } else if (operation.is("ZOOM")) {
            processZoom(contextData, operation);
        } else if (operation.is("ZOOM_OUT")) {
            processZoomOutCallback(contextData, operation, 1000);
        } else if (operation.is("ZOOM_RESET")) {
            processZoomOutCallback(contextData, operation, 0);
        } else {
            if (operation.is("TRANSFER_SELECTION")) {
                setRangeAnchor(contextData,
                    mapObjectToResidue(contextData, operation.getObject()));
                processTransferSelection(contextData, operation);
            } else if (operation.is("REQUEST_SELECTION")) {
                setRangeAnchor(contextData,
                    mapObjectToResidue(contextData, operation.getObject()));
                processTransferSelection(contextData, operation);
            } else {
                if (operation.is("SELECT")) {
                    processSelectBottom(contextData, operation);
                    setRangeAnchor(contextData,
                        mapObjectToResidue(contextData, operation.getObject()));
                } else if (operation.is("SELECT_CONTROL")) {
                    processSelectHierarchy(contextData, operation);
                    setRangeAnchor(contextData,
                        mapObjectToResidue(contextData, operation.getObject()));
                } else if (operation.is("SELECT_SHIFT")) {
                    processSelectRange(contextData, operation);
                } else if (operation.is("SELECT_SHIFT_CONTROL")) {
                    processDeselectHierarchy(contextData, operation);
                    setRangeAnchor(contextData,
                        mapObjectToResidue(contextData, operation.getObject()));
                } else if (operation.is("SELECT_ALT")) {
                    processSelectTop(contextData, operation, false);
                    setRangeAnchor(contextData,
                        mapObjectToResidue(contextData, operation.getObject()));
                } else if (operation.is("SELECT_ALT_CTRL")) {
                    processSelectTop(contextData, operation, true);
                    setRangeAnchor(contextData,
                        mapObjectToResidue(contextData, operation.getObject()));
                } else if (operation.is("DESELECT")) {
                    processSelectBottom(contextData, operation);
                    setRangeAnchor(contextData,
                        mapObjectToResidue(contextData, operation.getObject()));
                } else if (operation.is("SELECT_ADD_FEATURES")) {
                    processSelectFeatures(contextData, operation, true);
                    setRangeAnchor(contextData, null);
                } else if (operation.is("SELECT_FEATURES")) {
                    processSelectFeatures(contextData, operation, false);
                    setRangeAnchor(contextData, null);
                } else if (operation.is("DESELECT_FEATURES")) {
                    processDeselectFeatures(contextData, operation);
                    setRangeAnchor(contextData, null);
                }
            }

            // :FIXME: use the strategy or rather chain of responsibility pattern to
            // perform more convienient message mechanism.
            if (context == operation.getContext() ||
                  operation.is("REQUEST_SELECTION")) {

                // we try do this in the same thread that performs the actual selection
                contextData.getContext().addUpdateCallback(new Callback() {
                        public void execute() {
                            Operation newOperation;
                            if (operation.is("REQUEST_SELECTION")) {
                                newOperation =
                                    new Operation(operation.getContext(),
                                        "FORWARD_SELECTION",
                                        operation.getObject());
                            } else {
                                newOperation =
                                    new Operation(context,
                                        "TRANSFER_SELECTION",
                                        operation.getObject());
                            }
                            newOperation.setSerializable(false);
                            newOperation.setObjects(selection);
                            DispatchManager.runDispatch(context, newOperation);
                        }
                    });
            }
        }
        if (!operation.is("MOVE_OVERVIEW") && !operation.is("MOVE_ZOOMBOX")) {

            // we try do this in the same thread that performs the actual selection
            contextData.getContext().addUpdateCallback(new Callback() {
                    public void execute() {
                        showSelectionMessage(contextData, selection);
                        updateDescriptionOverlay(contextData, null);
                    }
                });
        }
    }

    /**
     * Refine a existing selection according to the specified object.
     *
     * @param selection Current selection.
     * @param object Object that was selected.
     * @param collection New selection.
     * @param contextData Description of parameter.
     *
     * @return Rooting object in terms of the object hierarchy.
     */
    public void refineSelection(ContextData contextData, Selection selection,
        AbstractObject object, Collection collection) {
        object =
            findSelectionSubroot(object, selection,
                contextData.getObjectManager());
        collection.add(object);
    }

    /**
     * Collects all objects that are related to the objects in the specified collection
     * and extracts those that root the whole collection.
     *
     * @param collection Objects to be rooted.
     * @param objectManager Description of parameter.
     *
     * @return Set of objects that can be found in the root path of the object in the
     *         specified selection.
     */
    public Collection findRootObjects(ObjectManager objectManager,
        Collection collection) {
        Collection roots = new HashSet();
        objectManager.getRoots(collection, roots);
        roots.addAll(collection);
        return roots;
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     * @param operation Description of parameter.
     */
    public void processMoveOverview(ContextData contextData, Operation operation) {
        Point3d point = contextData.getContext().getViewingPlatformPosition();
        double z = point.z;
        point.set(((org.srs3d.viewer.j3d.objects.Rectangle) operation.getObject()).getCoordinate());
        org.srs3d.viewer.bioatlas.contexts.CellContext context =
            (org.srs3d.viewer.bioatlas.contexts.CellContext) contextData.getContext();
        point.z = z;
        Transform3D transform = context.getViewingPlatformTransform();
        transform.setTranslation(new Vector3d(point));

        // :FIXME: execute in callback
        context.setViewingPlatformTransform(transform, true);
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     * @param operation Description of parameter.
     */
    public void processKeyInput(ContextData contextData, Operation operation) {
        Context context = contextData.getContext();
        KeyEvent e = (KeyEvent) ((InputOperation) operation).getInputEvent();

        // dispatch the keystroke (generated by getKeyEncoding())
        super.runDispatches(contextData, getKeyEncoding(e), e,
            operation.getContext().getContextData());
        if (context == operation.getContext()) {
            DispatchManager.dispatch(context, operation);
        }
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     */
    public void registerKeys(final ContextData contextData) {
        Context context = contextData.getContext();
        Dispatch dispatch;
        ArrayList dispatches;

        // :FIXME: move to zoom module
        dispatches = new ArrayList(1);
        dispatches.add(new OperationDispatch("ZOOM", false));
        registerDispatches(getKeyEncoding(KeyEvent.VK_ENTER, 0), dispatches);
        dispatches = new ArrayList(1);
        dispatches.add(new OperationDispatch("ZOOM_OUT", false));
        registerDispatches(getKeyEncoding(KeyEvent.VK_ENTER, KeyEvent.SHIFT_MASK),
            dispatches);
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     * @param operation Description of parameter.
     */
    public void processCallback(ContextData contextData, Operation operation) {
        CallbackOperation op = (CallbackOperation) operation;
        op.getCallback().execute();
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     * @param operation Description of parameter.
     */
    public void processLoadStructure(ContextData contextData,
        Operation operation) {
        org.srs3d.viewer.bioatlas.modules.StructureModule module =
            new org.srs3d.viewer.bioatlas.modules.StructureModule("",
                contextData);
        ParameterStringOperation op = (ParameterStringOperation) operation;
        module.loadStructure(op.getParameterString());
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     * @param operation Description of parameter.
     */
    public void processLoadAnnotation(ContextData contextData,
        Operation operation) {
        org.srs3d.viewer.bioatlas.modules.AnnotationModule module =
            new org.srs3d.viewer.bioatlas.modules.AnnotationModule("",
                contextData, null);
        ParameterStringOperation op = (ParameterStringOperation) operation;
        module.loadAnnotation(op.getParameterString());
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     * @param operation Description of parameter.
     */
    public void processLoadSequence(ContextData contextData, Operation operation) {
        org.srs3d.viewer.annotation.modules.AnnotationModule module =
            new org.srs3d.viewer.annotation.modules.AnnotationModule("",
                contextData.getContext(), null, null);
        ParameterStringOperation op = (ParameterStringOperation) operation;
        module.loadSequence(op.getParameterString());
    }

    /**
     * Description of the method.
     *
     * @param operation Description of parameter.
     * @param contextData Description of parameter.
     */
    protected void processSelectHierarchy(final ContextData contextData,
        final Operation operation) {
        final Selection selection =
            contextData.getSelectionManager().getSelection();
        contextData.getContext().addUpdateCallback(new Callback() {
                public void execute() {
                    Chronometer c =
                        Chronometer.getChronometer(
                            "NavigateUpDispatcher:ProcessSelectionHierarchy");
                    if (operation.getObject() != null) {
                        selection.setColoringLocked(true);
                        selection.setColoringRemoveLocked(true);

                        // get next level in the hierarchy
                        c.start();
                        Collection newSelection =
                            getNextHierarchyLevel(contextData, operation);
                        c.stop("getNextHierarchyLevel()");
                        c.start();
                        HashSet newCollapsed = new HashSet();

                        // despite it's only one object this helps to speed up the collapsing
                        // (step from chain fragment to chain is done without the legacy of
                        // the rest of the selection)
                        contextData.getObjectManager().collapseUpExtended(newSelection,
                            newCollapsed);
                        newCollapsed.addAll(selection);
                        selection.clear();
                        contextData.getObjectManager().collapseUpExtended(newCollapsed,
                            selection);
                        c.stop("assembling");
                        c.start();
                        selection.setColoringLocked(false);
                        selection.setColoringRemoveLocked(false);
                        selection.reapplyColorScheme(true);
                        c.stop("coloring");
                    }
                }
            });
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     * @param operation Description of parameter.
     */
    protected void processDeselectHierarchy(final ContextData contextData,
        final Operation operation) {
        final Selection selection =
            contextData.getSelectionManager().getSelection();
        contextData.getContext().addUpdateCallback(new Callback() {
                public void execute() {
                    Chronometer c =
                        Chronometer.getChronometer(
                            "NavigateUpDispatcher:ProcessDeselectHiearchy");
                    if (operation.getObject() != null) {

                        //            selection.setColoringLocked( true );
                        c.start();
                        processDeselection(contextData, operation);
                        c.stop("processDeselection");

                        //            c.start();
                        //            selection.setColoringLocked( false );
                        //            selection.reapplyColorScheme( true );
                        //            c.stop( "coloring" );
                    }
                }
            });
    }

    /**
     * Description of the method.
     *
     * @param object Description of parameter.
     * @param contextData Description of parameter.
     * @param isDescendantCheck Description of parameter.
     *
     * @return Description of the returned value.
     */
    protected boolean intersectsSelection(ContextData contextData,
        AbstractObject object) {
        Selection selection = contextData.getSelectionManager().getSelection();
        if (selection.contains(object)) {
            return true;
        }

        // here we have the need to step up from the object and check inclusion
        // of any upper object
        HashSet upper = new HashSet();
        contextData.getObjectManager().getUpAssociations(object, upper);
        return SetUtility.hasIntersection(selection, upper);
    }

    /**
     * Description of the method.
     *
     * @param operation Description of parameter.
     * @param contextData Description of parameter.
     *
     * @return Description of the returned value.
     */
    protected Collection getNextHierarchyLevel(ContextData contextData,
        Operation operation) {
        Collection newSelection = new HashSet();
        Selection selection = contextData.getSelectionManager().getSelection();

        // look for overlaps in the old selection and the object associates
        if (intersectsSelection(contextData, operation.getObject())) {

            // refine selection
            refineSelection(contextData, selection, operation.getObject(),
                newSelection);
        } else {

            // create a new selection (that is independent from the previous one)
            newSelection.add(operation.getObject());
        }
        return newSelection;
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     * @param operation Description of parameter.
     *
     * @return Description of the returned value.
     */
    protected void processDeselection(ContextData contextData,
        Operation operation) {
        Selection selection = contextData.getSelectionManager().getSelection();
        Chronometer c =
            Chronometer.getChronometer(
                "NavigateUpDispatcher:ProcessDeselection(local)");
        if (!selection.isEmpty()) {
            c.start();

            // look for overlaps in the old selection and the object associates
            if (intersectsSelection(contextData, operation.getObject())) {
                c.stop("intersectsSelection");
                c.start();

                // lock coloring, because we directly modify the selection
                selection.setColoringLocked(true);
                Collection associates =
                    contextData.getObjectManager().getAssociations(operation.getObject());
                HashSet down = new HashSet(selection);
                contextData.getObjectManager().getDownAssociations(selection,
                    down);
                associates.add(operation.getObject());
                down.removeAll(associates);

                // disable color propagating, because the objects are removed explicitly
                selection.setPropagatingColoring(false);
                selection.removeAll(associates);
                selection.setPropagatingColoring(true);

                // lock coloring during removes from the seleciton
                selection.setColoringRemoveLocked(true);
                selection.clear();
                contextData.getObjectManager().collapseUp(down, selection);
                selection.setColoringRemoveLocked(false);
                selection.setColoringLocked(false);

                // :NOTE: no recoloring needed, since the down associated are colored
                // correctly, anyway. the deselection only removes objects from the seleciton
                c.stop("assembling");
            } else {
                c.stop("intersectsSelection");
                c.start();

                // lock coloring, because we're addressing the selection directly
                selection.setColoringLocked(true);
                Collection set = new HashSet();
                set.add(operation.getObject());
                findDeselectionSubroot(set, selection,
                    contextData.getObjectManager());
                Collection children = new HashSet();
                contextData.getObjectManager().getDownAssociations(set, children);

                // since we remove the object explicitly the selection doesm't have to
                // propagate the coloring
                selection.setPropagatingColoring(false);
                selection.removeAll(set);
                selection.removeAll(children);
                selection.setColoringLocked(false);

                // here we have to keep the reapplication in, however we don't have to
                // propagate the coloring yet (recolor direct down associates??)
                selection.reapplyColorScheme(true);
                selection.setPropagatingColoring(true);
                c.stop("else branch");
            }
        }
    }

    /**
     * Description of the method.
     *
     * @param set Description of parameter.
     * @param selection Description of parameter.
     * @param objectManager Description of parameter.
     */
    protected void findDeselectionSubroot(Collection set, Collection selection,
        ObjectManager objectManager) {
        boolean extended = true;
        Collection parents = new HashSet();
        Collection previousParents = new HashSet(set);
        Collection dummy;
        Collection coveredObjects = new HashSet();
        while (extended &&
              !SetUtility.hasIntersection(selection, coveredObjects)) {
            objectManager.getDirectUpAssociations(previousParents, parents);
            extended = !parents.isEmpty();
            set.addAll(parents);
            dummy = previousParents;
            previousParents = parents;
            parents = dummy;
            parents.clear();
            coveredObjects.clear();
            objectManager.getDownAssociations(previousParents, coveredObjects);
        }
    }

    /**
     * Processes the transfered selection. The intention of this method is to detect
     * higher level object selections. That means parents, where all children are in the
     * transfered selection will replace their offsprings. Example: all residues of a
     * helix are transfered leads to the selection of the helix plus all downward
     * associated objects. Before the actual processing the object set is collapse up.
     *
     * @param contextData Context information.
     * @param operation operation that triggered the method invokation. Note that the
     *        method operates on the getObjects() method of the operation interface.
     */
    protected void processTransferSelection(final ContextData contextData,
        final Operation operation) {
        contextData.getContext().addUpdateCallback(new Callback() {
                public void execute() {
                    processTransferSelection(contextData,
                        operation.getObjects(), false);
                }
            });
    }

    protected void processZoomOutCallback(final ContextData contextData,
        final Operation operation, final int duration) {
        contextData.getContext().addUpdateCallback(new Callback() {
                public void execute() {
                    processZoomOut(contextData, operation, duration);
                }
            });
    }

    /**
     * Description of the method.
     *
     * @param operation Description of parameter.
     * @param contextData Description of parameter.
     */
    protected void processZoom(final ContextData contextData,
        final Operation operation) {
        contextData.getContext().addUpdateCallback(new Callback() {
                public void execute() {
                    Selection selection =
                        contextData.getSelectionManager().getSelection();
                    if (selection.isEmpty()) {
                        processZoomOut(contextData, operation, 1000);
                    } else {

                        // zoom in to previous selection
                        ObjectFilter filter = new BaseObjectFilter(Atom.class);
                        AtomCollector atomCollector = new AtomCollector(filter);
                        Point3f center = new Point3f();
                        Vector3f extend = new Vector3f();
                        if (computeCenter(contextData, selection, center, extend)) {
                            processZoom(contextData, center, extend, 1000);
                        }
                    }
                }
            });
    }

    /**
     * Description of the method.
     *
     * @param operation Description of parameter.
     * @param contextData Description of parameter.
     */
    protected void processSelectRange(final ContextData contextData,
        final Operation operation) {
        if (operation.getObject() != null) {
            contextData.getContext().addUpdateCallback(new Callback() {
                    public void execute() {
                        Selection selection =
                            contextData.getSelectionManager().getSelection();

                        //            selection.setColoringLocked( true );
                        Residue residue =
                            mapObjectToResidue(contextData,
                                operation.getObject());
                        if (rangeAnchor == null) {
                            setRangeAnchor(contextData, residue);

                            // create snapshot of the current selection
                            previousSelection.addAll(selection);
                        } else {
                            if (!previousSelection.isEmpty()) {
                                selection.clear();
                                selection.addAll(previousSelection);
                            } else {
                                previousSelection.addAll(selection);
                            }
                        }
                        processSelectResidueRange(contextData, residue);

                        //            selection.setColoringLocked( false );
                        //            selection.reapplyColorScheme( true );
                    }
                });
        }
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     * @param object Description of parameter.
     *
     * @return Description of the returned value.
     */
    protected Residue mapObjectToResidue(ContextData contextData,
        AbstractObject object) {
        if (object != null) {
            if (object instanceof Residue) {
                return (Residue) object;
            } else {
                ArrayList set = new ArrayList();
                contextData.getObjectManager().getAssociations(object, set);
                ObjectManager.extract(set, Residue.class);
                if (set.isEmpty()) {
                    return null;
                } else {
                    return (Residue) set.get(0);
                }
            }
        }
        return null;
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     * @param object Description of parameter.
     *
     * @return Description of the returned value.
     */
    protected Chain mapObjectToChain(ContextData contextData,
        AbstractObject object) {
        Chain chain = null;
        if (object instanceof Chain) {
            chain = (Chain) object;
        } else {
            Collection set = new HashSet();

            // try the fast way, using the associations
            contextData.getObjectManager().getAssociations(object, set);
            set.add(object);
            ObjectManager.extract(set, Chain.class);
            if (set.size() == 1) {
                chain = (Chain) set.iterator().next();
            }
            if (chain == null) {
                ObjectLocalizer objectLocalizer = new ObjectLocalizer();
                objectLocalizer.setSearchObject(object);
                objectLocalizer.visit((AbstractObject) contextData.getObjectContainer());
                set = objectLocalizer.getObjects();
                ObjectManager.extract(set, Chain.class);
                if (set.size() == 1) {
                    chain = (Chain) set.iterator().next();
                }
            }
        }
        return chain;
    }

    /**
     * Description of the method.
     *
     * @param operation Description of parameter.
     * @param contextData Description of parameter.
     * @param isAdd Description of parameter.
     */
    protected void processSelectTop(final ContextData contextData,
        final Operation operation, final boolean isAdd) {
        contextData.getContext().addUpdateCallback(new Callback() {
                public void execute() {
                    Selection selection =
                        contextData.getSelectionManager().getSelection();
                    if (!isAdd) {
                        selection.clear();
                    }
                    if (operation.getObject() != null) {
                        Collection objects = new HashSet();
                        contextData.getObjectManager().getUpAssociations(operation.getObject(),
                            objects);
                        ObjectManager.extract(objects, Chain.class);
                        selection.addAll(objects);
                    }
                }
            });
    }

    /**
     * Description of the method.
     *
     * @param operation Description of parameter.
     * @param contextData Description of parameter.
     */
    protected void processSelectBottom(final ContextData contextData,
        final Operation operation) {
        contextData.getContext().addUpdateCallback(new Callback() {
                public void execute() {
                    Selection selection =
                        contextData.getSelectionManager().getSelection();
                    selection.clear();
                    if (operation.getObject() != null) {
                        selection.add(operation.getObject());
                    }
                }
            });
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     * @param operation Description of parameter.
     */
    protected void processIntersect(final ContextData contextData,
        final Operation operation) {
        contextData.getContext().addUpdateCallback(new Callback() {
                public void execute() {
                    IntersectOperation intersectOperation =
                        (IntersectOperation) operation;

                    // create new intersect operation using the operation trigger id
                    // it has to be a intersect command, since it potetially needed to
                    // access the additional attributes;
                    // the new operation is made serializable (not a default for intersect
                    // operations)
                    IntersectOperation newOperation =
                        new IntersectOperation(contextData.getContext(),
                            intersectOperation.getTriggerId(),
                            intersectOperation.getObject());
                    newOperation.setPickResult(intersectOperation.getPickResult());
                    newOperation.setCoordinate(intersectOperation.getCoordinate());
                    newOperation.setTriggerEvent(intersectOperation.getTriggerEvent());
                    newOperation.setTriggerId(intersectOperation.getTriggerId());
                    newOperation.setSerializable(true);

                    // create intersection command
                    IntersectCommand intersectCommand =
                        new IntersectCommand(contextData);
                    intersectCommand.setCoordinate(intersectOperation.getCoordinate());
                    newOperation.setObject(intersectCommand.intersect());

                    // execute intersection command
                    if (newOperation.getObject() != null) {
                        if (newOperation.getTriggerId().startsWith("SELECT_ALT")) {
                            intersectCommand.setMode(IntersectCommand.MODE_TOPLEVEL);
                        }
                        contextData.getStrategyManager().execute(newOperation.getObject(),
                            intersectCommand);
                        newOperation.setObject(intersectCommand.getObject());
                    }

                    // process new operation (trigger operation id)
                    runDispatch(newOperation);
                }

                public String toString() {
                    return "NavigateUpDispatcher:processIntersect";
                }
            });
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     * @param operation Description of parameter.
     * @param isUp Description of parameter.
     */
    protected void processSelectNextLevel(final ContextData contextData,
        final Operation operation, final boolean isUp) {
        contextData.getContext().addUpdateCallback(new Callback() {
                public void execute() {
                    Collection selection =
                        contextData.getSelectionManager().getSelection();
                    if (selection.isEmpty()) {
                        processSelectResidue(contextData, operation);
                    } else {
                        Collection objects;
                        if (isUp) {
                            objects = new HashSet(selection);
                            contextData.getObjectManager()
                                       .getDirectUpAssociations(selection,
                                objects);
                        } else {
                            objects = new HashSet();
                            if (rangeAnchor != null) {
                                objects.add(rangeAnchor);
                            }
                        }
                        Operation op =
                            new Operation(contextData.getContext(),
                                "REQUEST_SELECTION", null);
                        op.setObjects(objects);
                        op.setSerializable(true);
                        runDispatch(op);
                    }
                }
            });
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     * @param operation Description of parameter.
     * @param isRight Description of parameter.
     * @param isShift Description of parameter.
     */
    protected void processSelectNextResidue(final ContextData contextData,
        final Operation operation, final boolean isRight, final boolean isShift) {
        contextData.getContext().addUpdateCallback(new Callback() {
                public void execute() {
                    Residue residue = null;
                    Residue nextResidue = null;
                    Collection selection =
                        contextData.getSelectionManager().getSelection();
                    Collection residues = new HashSet(selection);
                    contextData.getObjectManager().getDownAssociations(selection,
                        residues);
                    ObjectManager.extract(residues, Residue.class);
                    Collection nextResidues = new HashSet(residues.size());
                    Iterator iterator = residues.iterator();

                    // determine most left/right residues
                    while (iterator.hasNext()) {
                        residue = (Residue) iterator.next();
                        if (isRight) {
                            nextResidue = residue.getProceeding();
                        } else {
                            nextResidue = residue.getPreceeding();
                        }
                        if (nextResidue != null) {
                            nextResidues.add(nextResidue);
                        } else {
                            nextResidues.add(residue);
                        }
                    }
                    if (!nextResidues.isEmpty()) {
                        if (isShift) {
                            nextResidues.addAll(residues);
                        } else {
                            nextResidues.removeAll(residues);
                            if (nextResidues.isEmpty()) {
                                nextResidues = residues;
                            }
                            if (!nextResidues.isEmpty()) {
                                residue =
                                    (Residue) nextResidues.iterator().next();
                                setRangeAnchor(contextData, residue);
                            } else {
                                setRangeAnchor(contextData, null);
                            }
                        }
                        Operation op =
                            new Operation(contextData.getContext(),
                                "REQUEST_SELECTION", null);
                        op.setObjects(nextResidues);
                        op.setSerializable(true);
                        runDispatch(op);
                    }
                }
            });
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     * @param operation Description of parameter.
     * @param isShift Description of parameter.
     */
    protected void processSelectNext(ContextData contextData,
        Operation operation, boolean isShift) {
        Selection selection = contextData.getSelectionManager().getSelection();
        Collection intermediateObjects = new HashSet();
        ArrayList objects = new ArrayList(selection.size());
        if (selection.size() > 1) {
            contextData.getObjectManager().collapseUpExtended(selection, objects);
        } else {
            objects.addAll(selection);
        }

        // :FIXME: this should not be necessary
        ObjectManager.filter(objects, Bond.class);
        if (!objects.isEmpty()) {
            Object object = objects.get(objects.size() - 1);
            objects.clear();
            Class objectClass = object.getClass();
            ObjectFilter filter = null;
            if (object instanceof Subchain) {
                objectClass = Subchain.class;
                filter = new ObjectSubclassFilter(objectClass);
            } else {
                filter = new ObjectClassFilter(objectClass);
            }
            ArrayList candidates = tabLevelObjects;
            if (tabLevel == null) {
                tabObject = (AbstractObject) object;
                tabLevel = objectClass;
                ObjectCollector objectCollector = new ObjectCollector(filter);
                objectCollector.setObjects(candidates);
                objectCollector.visit(contextData.getObjectContainer()
                                                 .getObjects());
            } else {
                object = tabObject;
            }
            boolean isFound = false;
            int i;
            for (i = 0; i < candidates.size() && !isFound; i++) {
                if (candidates.get(i) == object) {
                    isFound = true;
                }
            }
            if (isShift) {
                i -= 2;
            }
            i = i < 0 ? candidates.size() + i : i;
            i = i < candidates.size() ? i : i - candidates.size();
            AbstractObject candidate = (AbstractObject) candidates.get(i);
            tabObject = candidate;
            objects.add(candidate);

            // BF 010702:
            // need this when tabbing into unexpanded regions
            processSelectionExpand(contextData, objects);
            Operation op =
                new Operation(contextData.getContext(), "REQUEST_SELECTION",
                    null);
            op.setObjects(objects);
            op.setSerializable(true);
            runDispatch(op);
        }
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     * @param objects Parameter description.
     *
     * @return Return description.
     */
    public static boolean processSelectionExpand(ContextData contextData,
        Collection objects) {
        HashSet filtered = new HashSet();
        ObjectManager.extract(objects, filtered, Atom.class);
        if (!filtered.isEmpty()) {
            HashSet associated = new HashSet();
            contextData.getObjectManager().getUpAssociations(filtered,
                associated);

            // need this when tabbing in to unexpanded regions
            ExpandCommand expandCommand = new ExpandCommand(contextData, true);
            expandCommand.setModifiedObjects(new HashSet());
            contextData.getStrategyManager().execute(associated, expandCommand);
            if (expandCommand.hasModified()) {
                HashSet spawners =
                    new HashSet(expandCommand.getModifiedObjects());
                SpawnCommand.searchSpawners(contextData, spawners);
                contextData.getStrategyManager().execute(spawners,
                    new SpawnCommand(contextData));
                return true;
            }
        }
        return false;
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     * @param operation Description of parameter.
     */
    protected void processUpdateColoring(final ContextData contextData,
        final Operation operation) {
        contextData.getContext().addUpdateCallback(new Callback() {
                public void execute() {
                    processUpdateColoring(contextData);
                }
            });
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     * @param operation Description of parameter.
     * @param isAdd Description of parameter.
     */
    protected void processSelectFeatures(final ContextData contextData,
        final Operation operation, final boolean isAdd) {

        // take features into the selection
        // take feature objects into the selection (collapsed)
        final Collection objects = new HashSet(operation.getObjects());
        Iterator iterator = operation.getObjects().iterator();
        Feature feature;
        while (iterator.hasNext()) {
            feature = (Feature) iterator.next();
            objects.addAll(feature.getObjects());
        }
        contextData.getContext().addUpdateCallback(new Callback() {
                public void execute() {
                    processTransferSelection(contextData, objects, isAdd);
                }
            });
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     * @param operation Description of parameter.
     */
    protected void processDeselectFeatures(final ContextData contextData,
        final Operation operation) {
        final Collection objects = new HashSet();
        objects.addAll(operation.getObjects());
        Iterator iterator = operation.getObjects().iterator();
        Feature feature;
        while (iterator.hasNext()) {
            feature = (Feature) iterator.next();
            objects.addAll(feature.getObjects());
        }
        final Collection associated = new HashSet(objects);
        contextData.getObjectManager().getAssociations(objects, associated);

        // no collapsing is performed (performance of sequence residue collapsing too bad)
        contextData.getContext().addUpdateCallback(new Callback() {
                public void execute() {
                    Selection selection =
                        contextData.getSelectionManager().getSelection();
                    selection.removeAll(associated);
                    selection.reapplyColorScheme();

                    // propagate update coloring is performed by a subsequent TRANSFER_SELECTION
                }
            });
    }

    /**
     * Sets the <code>rangeAnchor</code> attribute of the
     * <code>NavigateUpDispatcher</code> object.
     *
     * @param contextData The new <code>rangeAnchor</code> value.
     * @param residue The new <code>rangeAnchor</code> value.
     */
    private void setRangeAnchor(ContextData contextData, Residue residue) {
        rangeAnchor = residue;
        previousSelection.clear();
        tabLevel = null;
        tabObject = null;
        tabLevelObjects.clear();
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     * @param operation Description of parameter.
     */
    private void processKeyStroke(ContextData contextData, Operation operation) {
        KeyStrokeOperation keyStrokeOperation = (KeyStrokeOperation) operation;
        Context context = contextData.getContext();
        KeyStroke keyStroke = keyStrokeOperation.getKeyStroke();
        KeyEvent keyEvent = (KeyEvent) keyStrokeOperation.getInputEvent();
        if (keyEvent != null) {
            int keyCode = keyEvent.getKeyCode();
            System.out.println("the keycode is: " + keyCode);
            char keyChar = keyEvent.getKeyChar();
            int keyModifiers = keyEvent.getModifiers();
            boolean isAltDown = (keyModifiers & KeyEvent.ALT_MASK) != 0;
            boolean isShiftDown = (keyModifiers & KeyEvent.SHIFT_MASK) != 0;
            boolean isControlDown = (keyModifiers & KeyEvent.CTRL_MASK) != 0;
            boolean isConsumed = false;
            if (isAltDown) {
                if (keyCode == KeyEvent.VK_4 || keyCode == KeyEvent.VK_NUMPAD4) {
                    org.srs3d.viewer.j3d.behaviors.PanXYBehavior.pan(context,
                        getDelta(keyStroke), 0);
                    isConsumed = true;
                } else if (keyCode == KeyEvent.VK_6 ||
                      keyCode == KeyEvent.VK_NUMPAD6) {
                    org.srs3d.viewer.j3d.behaviors.PanXYBehavior.pan(context,
                        -getDelta(keyStroke), 0);
                    isConsumed = true;
                } else if (keyCode == KeyEvent.VK_8 ||
                      keyCode == KeyEvent.VK_NUMPAD8) {
                    org.srs3d.viewer.j3d.behaviors.PanXYBehavior.pan(context,
                        0, -getDelta(keyStroke));
                    isConsumed = true;
                } else if (keyCode == KeyEvent.VK_2 ||
                      keyCode == KeyEvent.VK_NUMPAD2) {
                    org.srs3d.viewer.j3d.behaviors.PanXYBehavior.pan(context,
                        0, getDelta(keyStroke));
                    isConsumed = true;
                } else if (keyCode == KeyEvent.VK_5 ||
                      keyCode == KeyEvent.VK_NUMPAD5) {
                    try {
                        org.srs3d.viewer.bioatlas.modules.CaptureModule.dumpImage(context,
                            false);
                    } catch (NoClassDefFoundError e) {

                        // :SILENT-EXCEPTION:
                        ExceptionHandler.handleException(e,
                            ExceptionHandler.SILENT_IN_DEBUG, this);
                    }
                    isConsumed = true;
                }
            } else {
                if (keyCode == KeyEvent.VK_4 || keyCode == KeyEvent.VK_NUMPAD4) {
                    org.srs3d.viewer.j3d.behaviors.LookAtXYBehavior.rotate(contextData,
                        -getRadians(keyStroke), 0);
                    isConsumed = true;
                } else if (keyCode == KeyEvent.VK_6 ||
                      keyCode == KeyEvent.VK_NUMPAD6) {
                    org.srs3d.viewer.j3d.behaviors.LookAtXYBehavior.rotate(contextData,
                        getRadians(keyStroke), 0);
                    isConsumed = true;
                } else if (keyCode == KeyEvent.VK_8 ||
                      keyCode == KeyEvent.VK_NUMPAD8) {
                    org.srs3d.viewer.j3d.behaviors.LookAtXYBehavior.rotate(contextData,
                        0, -getRadians(keyStroke));
                    isConsumed = true;
                } else if (keyCode == KeyEvent.VK_2 ||
                      keyCode == KeyEvent.VK_NUMPAD2) {
                    org.srs3d.viewer.j3d.behaviors.LookAtXYBehavior.rotate(contextData,
                        0, getRadians(keyStroke));
                    isConsumed = true;
                } else if (keyCode == KeyEvent.VK_5 ||
                      keyCode == KeyEvent.VK_NUMPAD5) {
                    try {
                        org.srs3d.viewer.bioatlas.modules.CaptureModule.dumpImage(context,
                            false);
                    } catch (NoClassDefFoundError e) {

                        // :SILENT-EXCEPTION:
                        ExceptionHandler.handleException(e,
                            ExceptionHandler.SILENT_IN_DEBUG, this);
                    }
                    isConsumed = true;
                } else if (keyCode == KeyEvent.VK_F5) {
                    Operation op =
                        RuntimeTestModule.createTestOperation(contextData, false);
                    contextData.getDispatcher().runDispatch(op);
                } else if (keyCode == KeyEvent.VK_F6) {
                    Operation op =
                        RuntimeTestModule.createTestOperation(contextData, true);
                    contextData.getDispatcher().runDispatch(op);
                }
            }
            if (keyCode == KeyEvent.VK_LEFT) {
                processSelectNextResidue(contextData, operation, false,
                    isShiftDown);
                isConsumed = true;
            } else if (keyCode == KeyEvent.VK_RIGHT) {
                processSelectNextResidue(contextData, operation, true,
                    isShiftDown);
                isConsumed = true;
            } else if (keyCode == KeyEvent.VK_UP) {
                processSelectNextLevel(contextData, operation, true);
                isConsumed = true;
            } else if (keyCode == KeyEvent.VK_DOWN) {

                // :VERSION: 1.0 removed for version 1.0
                //        processSelectNextLevel( contextData, operation, false );
                processSelectResidue(contextData, operation);
                isConsumed = true;
            }
            //      else if ( keyCode == KeyEvent.VK_SPACE ) {
            //
            //        processMapResidues( contextData, operation );
            //        isConsumed = true;
            //
            //      }
            else if (keyCode == KeyEvent.VK_TAB) {
                processSelectNext(contextData, operation, isShiftDown);
                isConsumed = true;
            }
            if (keyChar == '-' || keyCode == KeyEvent.VK_MINUS) {
                org.srs3d.viewer.j3d.behaviors.ZoomBehavior.pan(context,
                    10 * getDelta(keyStroke));
                isConsumed = true;
            } else if (keyChar == '+' || keyCode == KeyEvent.VK_PLUS) {
                org.srs3d.viewer.j3d.behaviors.ZoomBehavior.pan(context,
                    -10 * getDelta(keyStroke));
                isConsumed = true;
            } else if (keyChar == KeyEvent.VK_F11 ||
                  keyCode == KeyEvent.VK_F11) {
                double offset = 0.25f;
                if (keyEvent.isShiftDown()) {
                    offset = -offset;
                }
                context.setStereoEyeOffset(context.getStereoEyeOffset() +
                    offset);
                isConsumed = true;
            } else if (keyChar == KeyEvent.VK_F12 ||
                  keyCode == KeyEvent.VK_F12) {
                double offset = 0.5f;
                if (keyEvent.isShiftDown()) {
                    offset = -offset;
                }
                context.setStereoRotationAngle(context.getStereoRotationAngle() +
                    offset);
                isConsumed = true;
            }
        }
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     * @param objects Description of parameter.
     * @param isAdd Description of parameter.
     */
    private void processTransferSelection(ContextData contextData,
        Collection objects, boolean isAdd) {
        Selection selection = contextData.getSelectionManager().getSelection();
        if (!isAdd) {
            selection.clear();
        }
        if (objects != null) {
            selection.addAll(objects);
        }

        // issue update coloring operation for the other contexts
        Operation op =
            new Operation(contextData.getContext(), "UPDATE_COLORING", null);
        DispatchManager.runDispatch(op.getContext(), op);
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     * @param rangeResidue Description of parameter.
     */
    private void processSelectResidueRange(ContextData contextData,
        Residue rangeResidue) {
        if (rangeResidue != null) {
            ObjectManager objectManager = contextData.getObjectManager();
            Chain chain = mapObjectToChain(contextData, rangeAnchor);
            if (chain != null) {
                Selection selection =
                    contextData.getSelectionManager().getSelection();
                Residue residue = rangeAnchor;
                Collection frontSet = new Vector();
                while (residue != null && residue != rangeResidue) {
                    frontSet.add(residue);
                    residue = residue.getProceeding();
                }
                if (residue == rangeResidue) {
                    frontSet.add(rangeResidue);
                } else {
                    frontSet.clear();
                }
                Collection backSet = new Vector();
                residue = rangeAnchor;
                while (residue != null && residue != rangeResidue) {
                    backSet.add(residue);
                    residue = residue.getPreceeding();
                }
                if (residue == rangeResidue) {
                    backSet.add(rangeResidue);
                } else {
                    backSet.clear();
                }
                if (!frontSet.isEmpty() && !backSet.isEmpty()) {
                    if (frontSet.size() <= backSet.size()) {
                        selectResidues(contextData, chain, frontSet);
                    } else {
                        selectResidues(contextData, chain, backSet);
                    }
                } else {
                    frontSet.addAll(backSet);
                    selectResidues(contextData, chain, frontSet);
                }
            }
        }
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     * @param chain Description of parameter.
     * @param residues Description of parameter.
     */
    private void selectResidues(ContextData contextData, Chain chain,
        Collection residues) {
        Collection processedResidues = new HashSet();
        Collection subchainResidues = new HashSet();
        ObjectManager objectManager = contextData.getObjectManager();
        StrategyManager strategyManager = contextData.getStrategyManager();
        StateManager stateManager = contextData.getStateManager();
        Iterator residueIterator = residues.iterator();
        Iterator iterator;
        Residue residue;
        State.Immutable state;
        HashSet set = new HashSet(2 * residues.size());
        while (residueIterator.hasNext()) {
            residue = (Residue) residueIterator.next();
            if (!processedResidues.contains(residue)) {
                Subchain subchain =
                    mapResidueToSubchain(contextData, chain, residue);
                if (subchain != null) {
                    residue = subchain.getInitialResidue();
                    subchainResidues.clear();
                    while (residue != subchain.getEndResidue().getProceeding()) {
                        subchainResidues.add(residue);
                        residue = residue.getProceeding();
                    }

                    // are all of the residues in the subchain selected
                    if (residues.containsAll(subchainResidues)) {

                        // simply select the full subchain
                        set.add(subchain);

                        // also add the residues
                        set.addAll(subchainResidues);

                        // mark the residues as processed
                        processedResidues.removeAll(subchainResidues);
                    } else {

                        // expand the subchain if not already expanded
                        state = stateManager.getImmutableState(subchain);
                        if (set.contains(subchain)) {
                            objectManager.getDirectDownAssociations(subchain,
                                set);
                        }
                        SetUtility.intersect(subchainResidues, residues);

                        // add the residue to the selection
                        set.addAll(subchainResidues);
                        objectManager.getDirectDownAssociations(subchainResidues,
                            set);
                    }
                } else {

                    // necessary for ligands
                    set.add(residue);
                }
            } else {
                set.add(residue);
            }
        }
        Selection selection = contextData.getSelectionManager().getSelection();
        selection.addAll(set);
    }

    /**
     * Steps up the hierarchy to find the next level for hierarchical selection. Note
     * that the method was slightly optimized.
     *
     * @param set Basis set of what should be in a new selection that includes all the
     *        objects plus the objects of the current selection.
     * @param selection Current selection.
     * @param objectManager This <code>ObjectManager</code> instance provides the
     *        necessary associations.
     */
    private AbstractObject findSelectionSubroot(AbstractObject object,
        Collection selection, ObjectManager objectManager) {
        if (!selection.isEmpty()) {
            ArrayList previousParents = new ArrayList();
            Object currentObject = null;
            Object subroot = null;
            objectManager.getUpAssociations(object, previousParents);
            previousParents.add(object);
            Iterator iterator = previousParents.iterator();
            boolean isFound = false;
            while (!isFound && iterator.hasNext()) {
                subroot = currentObject;
                currentObject = iterator.next();
                if (selection.contains(currentObject)) {
                    isFound = true;
                }
            }
            if (subroot != null) {
                return (AbstractObject) subroot;
            }
        }
        return object;
    }

    /**
     * Gets the <code>keyEncoding</code> attribute of the
     * <code>NavigateUpDispatcher</code> class.
     *
     * @param keyCode Description of parameter.
     * @param keyModifiers Description of parameter.
     *
     * @return The <code>keyEncoding</code> value.
     */
    public static Object getKeyEncoding(int keyCode, int keyModifiers) {
        return KeyStroke.getKeyStroke(keyCode, keyModifiers);
    }

    /**
     * Gets the <code>keyEncoding</code> attribute of the
     * <code>NavigateUpDispatcher</code> class.
     *
     * @param e Description of parameter.
     *
     * @return The <code>keyEncoding</code> value.
     */
    public static Object getKeyEncoding(KeyEvent e) {
        return KeyStroke.getKeyStrokeForEvent(e);
    }

    /**
     * Description of the method.
     *
     * @param operation Description of parameter.
     * @param duration Description of parameter.
     * @param contextData Description of parameter.
     */
    public static void processZoomOut(ContextData contextData,
        Operation operation, int duration) {
        Point3f center = new Point3f();
        Vector3f extend = new Vector3f();
        HashSet objects = new HashSet();
        contextData.getObjectContainer().getAllObjects(objects);
        if (computeCenter(contextData, objects, center, extend)) {
            processZoom(contextData, center, extend, duration);
        }
    }

    /**
     * Description of the method.
     *
     * @param center Description of parameter.
     * @param extend Description of parameter.
     * @param duration Description of parameter.
     * @param contextData Description of parameter.
     */
    public static void processZoom(ContextData contextData, Tuple3f center,
        Vector3f extend, int duration) {
        if (!Float.isInfinite(center.x) && !Float.isNaN(center.x)) {
            Context context = contextData.getContext();
            float max = extend.length() + 10;

            // extract current view direction
            // get the current transformation of the viewing platform
            Transform3D transform = context.getViewingPlatformTransform();
            Vector3f viewDirection = new Vector3f();
            Matrix3f rotation = new Matrix3f();
            transform.get(rotation);
            rotation.getColumn(2, viewDirection);
            float scale;
            if (contextData.getContext().getHeight() > contextData.getContext()
                                                                    .getHeight()) {
                scale =
                    (float) contextData.getContext().getHeight() / contextData.getContext()
                                                                              .getWidth();
            } else {
                scale =
                    (float) contextData.getContext().getWidth() / contextData.getContext()
                                                                             .getHeight();
            }
            scale *= 0.9;
            if (scale < 0.9f) {
                scale = 0.9f;
            }
            viewDirection.scale(max * scale);
            context.setCenterOfRotation(center);
            center.add(viewDirection);
            context.interpolatePosition(center, duration);
        }
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     * @param text Description of parameter.
     */
    public static void updateDescriptionOverlay(final ContextData contextData,
        String text) {
        final org.srs3d.viewer.j3d.objects.Overlay overlay =
            contextData.getOverlayManager().getOverlay("Selection");
        if (overlay != null) {
            if (text == null) {
                overlay.clearText();
                overlay.addTextLine("");
                overlay.addTextLine("Selection", java.awt.Color.white);
                Selection selection =
                    contextData.getSelectionManager().getSelection();
                if (!selection.isEmpty()) {
                    ObjectManager objectManager =
                        contextData.getObjectManager();
                    HashSet objects = new HashSet(selection);

                    // :OPT2:         contextData.getObjectManager().collapseUp( selection, objects );
                    ObjectManager.filter(objects, Site.class);
                    Iterator iterator = objects.iterator();
                    AbstractObject object;
                    Collection residues = new HashSet();
                    Collection associated = new HashSet();
                    Collection extension = new HashSet();
                    while (iterator.hasNext()) {
                        object = (AbstractObject) iterator.next();
                        objectManager.getAssociations(object, associated);
                        associated.add(object);
                        ObjectManager.extract(associated, residues,
                            Residue.class);
                        if (residues.size() == 1) {
                            extension.addAll(residues);
                        }
                        residues.clear();
                    }
                    objects.addAll(extension);
                    Collection indirect = new ArrayList();
                    findAnnotations(contextData, associated, indirect);
                    Map prefixMap = new HashMap();
                    prefixMap.put(Feature.class, "  -");

                    // show object in the respective categories
                    updateDescription(overlay, objects, Layer.class);
                    updateDescription(overlay, objects, Chain.class);
                    updateDescription(overlay, objects, ChainFragment.class);
                    updateDescription(overlay, objects, Subchain.class);
                    updateDescription(overlay, objects, Residue.class);
                    updateDescription(overlay, objects, Atom.class);

                    // remove object that shall not be listed
                    ObjectManager.filter(objects, Bond.class);
                    ObjectManager.filter(objects, Feature.class);
                    ObjectManager.filter(objects, Annotation.class);
                    ObjectManager.filter(objects,
                        org.srs3d.viewer.j3d.objects.Label.class);
                    ObjectManager.filter(objects,
                        org.srs3d.viewer.j3d.objects.Line.class);
                    updateDescription(overlay, objects, (Class) null);
                    updateDescription(overlay, indirect, prefixMap);
                    if (!indirect.isEmpty()) {
                        ObjectManager.extract(indirect, Feature.class);
                        iterator = indirect.iterator();
                        Feature feature;
                        while (iterator.hasNext()) {
                            feature = (Feature) iterator.next();
                            if (!org.srs3d.viewer.bioatlas.modules.FeatureModule.isFeatureActive(
                                      contextData, feature)) {
                                iterator.remove();
                            }
                        }

                        // :FIXME: without selection overlay no linking!!
                        // link to annotation
                        org.srs3d.viewer.bioatlas.modules.LinkModule.link(contextData,
                            indirect);
                    }
                } else {
                    overlay.addTextLine("<empty>");
                }
            } else {
                overlay.clearText();
                overlay.addTextLine("");
                overlay.addTextLine("Initializing", java.awt.Color.white);
                overlay.addTextLine(text);

                // in this case we also like to update the status line
                contextData.getAppletStub().getAppletContext().showStatus(text);
            }
            overlay.setHeight(overlay.getCursorY() * 2 + 20);
            overlay.setWidth(overlay.getMaxPixels());
            overlay.update(contextData);
            overlay.finalizeUpdate();
            SpawnCommand spawnCommand = new SpawnCommand(contextData);
            contextData.getStrategyManager().execute(overlay, spawnCommand);
        }
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     * @param text Description of parameter.
     */
    public static void updateDescription(final ContextData contextData,
        final String text) {
        contextData.getContext().addUpdateCallback(new org.srs3d.viewer.j3d.behaviors.UpdateBehavior.Callback() {
                public void execute() {
                    NavigateUpDispatcher.updateDescriptionOverlay(contextData,
                        text);
                }
            });
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     * @param objects Description of parameter.
     * @param found Description of parameter.
     */
    public static void findAnnotations(ContextData contextData,
        Collection objects, Collection found) {
        Collection annotations = new Vector();
        org.srs3d.viewer.bioatlas.modules.AnnotationModule.getAnnotations(contextData,
            annotations);
        Iterator iterator = annotations.iterator();
        Annotation annotation;
        Collection features = new Vector();
        while (iterator.hasNext()) {
            annotation = (Annotation) iterator.next();
            findFeatures(annotation, objects, features);
            if (!features.isEmpty()) {
                found.add(annotation);
                found.addAll(features);
            }
            features.clear();
        }
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     */
    public static void processUpdateColoring(final ContextData contextData) {
        ColorCommand colorCommand =
            new ColorCommand(contextData, contextData.getColorSchemeBucket());

        // :NOTE: this colors only the objects that have a geometry
        contextData.getStrategyManager().execute(contextData.getShapeManager()
                                                            .getObjects(),
            colorCommand);
        org.srs3d.viewer.bioatlas.Capture.updateSelections(contextData, false);
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     * @param root Description of parameter.
     * @param residue Description of parameter.
     *
     * @return Description of the returned value.
     */
    protected static Subchain mapResidueToSubchain(ContextData contextData,
        AbstractObject root, Residue residue) {
        Subchain subchain = null;
        if (!residue.isLigand()) {
            Collection set = new HashSet();
            contextData.getObjectManager().getUpAssociations(residue, set);
            ObjectManager.extract(set, Subchain.class);
            if (set.size() == 1) {
                subchain = (Subchain) set.iterator().next();
            } else {
                ObjectLocalizer objectLocalizer = new ObjectLocalizer();
                objectLocalizer.setSearchObject(residue);
                objectLocalizer.visit(root);
                set = objectLocalizer.getObjects();
                ObjectManager.extract(set, Subchain.class);
                if (set.size() == 1) {
                    subchain = (Subchain) set.iterator().next();
                }
            }
        }
        return subchain;
    }

    /**
     * Description of the method.
     *
     * @param annotation Description of parameter.
     * @param objects Description of parameter.
     * @param found Description of parameter.
     */
    private static void findFeatures(Annotation annotation, Collection objects,
        Collection found) {
        Iterator iterator = annotation.getFeatures().iterator();
        Feature feature;
        while (iterator.hasNext()) {
            feature = (Feature) iterator.next();
            if (SetUtility.hasIntersection(feature.getObjects(), objects)) {
                found.add(feature);
            }
        }
    }

    /**
     * Description of the method.
     *
     * @param overlay Description of parameter.
     * @param objects Description of parameter.
     * @param objectClass Description of parameter.
     */
    private static void updateDescription(
        org.srs3d.viewer.j3d.objects.Overlay overlay, Collection objects,
        Class objectClass) {
        Collection filtered;
        if (objectClass == null) {
            filtered = objects;
        } else {
            filtered = new HashSet();
            ObjectManager.extract(objects, filtered, objectClass);
            objects.removeAll(filtered);
        }
        String string = new String();
        Iterator iterator = filtered.iterator();
        while (iterator.hasNext()) {
            string += iterator.next().toString().trim();
            if (iterator.hasNext()) {
                string += ", ";
            }
        }
        if (string.length() > 0) {
            overlay.addTextLine(string);
        }
    }

    /**
     * Description of the method.
     *
     * @param overlay Description of parameter.
     * @param objects Description of parameter.
     * @param prefixMap Description of parameter.
     */
    private static void updateDescription(
        org.srs3d.viewer.j3d.objects.Overlay overlay, Collection objects,
        Map prefixMap) {
        String string = new String();
        HashMap colorMap = new HashMap();
        Collection colors;
        Iterator iterator = objects.iterator();
        Object object;
        Class lastObjectClass = null;
        while (iterator.hasNext()) {
            object = iterator.next();
            string = (String) prefixMap.get(object.getClass());
            if (string == null) {
                string = "";
            }
            if (lastObjectClass != object.getClass()) {
                colorMap.clear();
            }
            lastObjectClass = object.getClass();
            string += object.toString();
            boolean addString = true;
            if (object instanceof Colorable) {
                Color3f color = new Color3f(((Colorable) object).getColor());
                color.clamp(0, 1);
                colors = (Collection) colorMap.get(string);
                if (colors != null) {
                    if (colors.contains(color.toString())) {
                        addString = false;
                    }
                } else {
                    colors = new HashSet();
                    colorMap.put(string, colors);
                }
                colors.add(color.toString());
                if (addString) {
                    overlay.addTextLine(string, color.get(), true);
                }
            } else {
                overlay.addTextLine(string);
            }
        }
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     * @param operation Parameter description.
     */
    public void processSelectResidue(final ContextData contextData,
        Operation operation) {
        contextData.getContext().addUpdateCallback(new Callback() {
                public void execute() {
                    Selection selection =
                        contextData.getSelectionManager().getSelection();
                    ObjectCollector objectCollector =
                        new ObjectCollector(new ObjectClassFilter(Residue.class));
                    objectCollector.setMode(ObjectCollector.COLLECT_ONE);
                    if (selection.isEmpty()) {
                        objectCollector.visit(contextData.getObjectContainer()
                                                         .getObjects());
                    } else {
                        objectCollector.visit(selection);
                    }
                    Operation op =
                        new Operation(contextData.getContext(),
                            "REQUEST_SELECTION", null);
                    op.setObjects(objectCollector.getObjects());
                    op.setSerializable(true);
                    runDispatch(op);
                }
            });
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     * @param operation Parameter description.
     */
    public void processMapResidues(final ContextData contextData,
        Operation operation) {
        contextData.getContext().addUpdateCallback(new Callback() {
                public void execute() {
                    Selection selection =
                        contextData.getSelectionManager().getSelection();
                    Collection allAlignedResidues = new HashSet();
                    Collection residues = new HashSet(selection);
                    if (!selection.isEmpty()) {
                        org.srs3d.viewer.annotation.objects.AnnotationContainer annotationContainer =
                            (org.srs3d.viewer.annotation.objects.AnnotationContainer) org.srs3d.viewer.annotation.colorschemes.HomologyColorScheme.getAnnotation(contextData);
                        if (annotationContainer != null) {
                            contextData.getObjectManager().getAssociations(selection,
                                residues);
                            ObjectManager.extract(residues, Residue.class);
                            Iterator iterator = residues.iterator();
                            Collection alignedResidues;
                            while (iterator.hasNext()) {
                                alignedResidues =
                                    annotationContainer.mapResidues((Residue) iterator.next());
                                if (alignedResidues != null) {
                                    allAlignedResidues.addAll(alignedResidues);
                                }
                            }
                        }
                        if (!allAlignedResidues.isEmpty()) {
                            HashSet objects = new HashSet();
                            contextData.getObjectManager().collapseUpExtended(allAlignedResidues,
                                objects);
                            Operation op =
                                new Operation(contextData.getContext(),
                                    "REQUEST_SELECTION", null);
                            op.setObjects(objects);
                            op.setSerializable(true);
                            runDispatch(op);
                        }
                    }
                }
            });
    }
}
