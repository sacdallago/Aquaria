/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.integration.component;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;

import org.srs3d.viewer.integration.event.ComponentEvent;

/**
 * This class implements the EventController interface. It is intended to multplex one
 * event controller to many. This implementation can help to group event controllers.
 * Generic implementations can freely add EventControllers as needed.
 *
 * @author Karsten Klein
 *
 * @created September 23, 2002
 */
public class MultiplexEventController implements EventController {

    // the many event controllers this controller delegates to and received from.
    private ArrayList controllers = new ArrayList();
    private EventController parentEventController = null;

    /**
     * <code>MultiplexEventController</code> constructor.
     *
     * @param parentEventController Description of parameter.
     */
    public MultiplexEventController(EventController parentEventController) {
        this.parentEventController = parentEventController;
    }

    /**
     * Retrieves all the event controller for this event controller. For more information
     * see the EventController interface.
     *
     * @return All event controllers in the full event controller hierarchy starting from
     *         this object.
     */
    public Collection getEventControllers() {
        return Collections.unmodifiableList(controllers);
    }

    /**
     * When adding a component event listener all the controllers down the controller
     * hierarchy will get the listener added. (They might decide to except it or not).
     *
     * @param listener The <code>ComponentEventListener</code> to be added.
     */
    public void addComponentEventListener(ComponentEventListener listener) {
        EventController controller;
        Iterator iterator = controllers.iterator();
        while (iterator.hasNext()) {
            controller = (EventController) iterator.next();
            controller.addComponentEventListener(listener);
        }
    }

    /**
     * Implementation of the ComponentEventListener interface. This implementation
     * delegates the event to the parent event controller;
     *
     * @param event Event for receiving.
     */
    public void receive(ComponentEvent event) {
        parentEventController.receive(event);
    }

    /**
     * Description of the method.
     *
     * @param event Description of parameter.
     */
    public void publish(ComponentEvent event) {
        EventController controller;
        Iterator iterator = controllers.iterator();
        while (iterator.hasNext()) {
            controller = (EventController) iterator.next();
            controller.publish(event);
        }
    }

    /**
     * Adds a <code>EventController</code> object to the
     * <code>MultiplexEventController</code> object.
     *
     * @param eventController The <code>EventController</code> object to be added.
     */
    public void addEventController(EventController eventController) {
        if (!controllers.contains(eventController)) {
            controllers.add(eventController);
        }
    }

    /**
     * Description of the method.
     *
     * @param eventController Description of parameter.
     */
    public void removeEventController(EventController eventController) {
        controllers.remove(eventController);
    }
}
