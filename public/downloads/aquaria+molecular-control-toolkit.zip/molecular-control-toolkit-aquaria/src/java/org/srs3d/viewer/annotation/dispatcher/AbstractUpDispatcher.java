/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.annotation.dispatcher;

import java.util.Collection;
import java.util.HashSet;

import org.srs3d.viewer.annotation.contexts.AnnotationContextData;
import org.srs3d.viewer.bioatlas.dispatcher.NavigateUpDispatcher;
import org.srs3d.viewer.j3d.Context;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.DispatchManager;
import org.srs3d.viewer.j3d.Selection;
import org.srs3d.viewer.j3d.behaviors.UpdateBehavior.Callback;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.objects.Operation;

/**
 * @author Karsten Klein
 *
 * @created September 25, 2001
 */
public abstract class AbstractUpDispatcher extends NavigateUpDispatcher {
    private Collection transferSelection = new HashSet();
    private Collection previousTransferSelection = new HashSet();
    private Collection previousSelection = new HashSet();
    private AbstractObject anchor = null;
    private AbstractObject previousAnchor = null;

    /**
     * Sets the <code>rangeAnchor</code> attribute of the
     * <code>AbstractUpDispatcher</code> object.
     *
     * @param contextData The new <code>rangeAnchor</code> value.
     * @param object The new <code>rangeAnchor</code> value.
     */
    protected abstract void setRangeAnchor(ContextData contextData,
        AbstractObject object);

    /**
     * Sets the <code>anchor</code> attribute of the <code>AbstractUpDispatcher</code>
     * object.
     *
     * @param anchor The new <code>anchor</code> value.
     */
    protected void setAnchor(AbstractObject anchor) {
        this.anchor = anchor;
    }

    /**
     * Gets the <code>transferSelection</code> attribute of the
     * <code>AbstractUpDispatcher</code> object.
     *
     * @return The <code>transferSelection</code> value.
     */
    protected Collection getTransferSelection() {
        return transferSelection;
    }

    /**
     * Gets the <code>previousTransferSelection</code> attribute of the
     * <code>AbstractUpDispatcher</code> object.
     *
     * @return The <code>previousTransferSelection</code> value.
     */
    protected Collection getPreviousTransferSelection() {
        return previousTransferSelection;
    }

    /**
     * Gets the <code>previousSelection</code> attribute of the
     * <code>AbstractUpDispatcher</code> object.
     *
     * @return The <code>previousSelection</code> value.
     */
    protected Collection getPreviousSelection() {
        return previousSelection;
    }

    /**
     * Gets the <code>anchor</code> attribute of the <code>AbstractUpDispatcher</code>
     * object.
     *
     * @return The <code>anchor</code> value.
     */
    protected AbstractObject getAnchor() {
        return anchor;
    }

    /**
     * Description of the method.
     *
     * @param set Description of parameter.
     */
    protected void filterContextObjects(Collection set) {
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     */
    protected void performTransferSelection(ContextData contextData,
        AbstractObject priorityObject) {

        // :NOTE: this method only works in most of the cases. there are problems
        // with the hierarchical selection;
        Context context = contextData.getContext();
        Operation newOperation =
            new Operation(context, "REQUEST_SELECTION", priorityObject);
        newOperation.setSerializable(true);
        Collection set = getTransferSelection();
        Collection objects = new HashSet(set.size());
        ContextData referenceContextData =
            ((AnnotationContextData) contextData).getReferenceContextData();
        referenceContextData.getObjectManager().collapseUpExtended(set, objects);
        filterContextObjects(objects);
        newOperation.setObjects(objects);
        DispatchManager.runDispatch(context, newOperation);
    }

    /**
     * Description of the method.
     *
     * @param operation Description of parameter.
     * @param contextData Description of parameter.
     */
    protected void processSelectRange(final ContextData contextData,
        final Operation operation) {
        contextData.getContext().addUpdateCallback(new Callback() {
                public void execute() {
                    Selection selection =
                        contextData.getSelectionManager().getSelection();

                    //          selection.setColoringLocked( true );
                    if (!selection.contains(anchor)) {
                        setRangeAnchor(contextData, null);
                    }
                    AbstractObject object = operation.getObject();
                    if (object != null) {
                        if (anchor == null) {
                            setRangeAnchor(contextData, object);
                            anchor = object;

                            // create snapshot of the current selection
                            previousSelection.addAll(selection);
                            getPreviousTransferSelection().addAll(getTransferSelection());
                        } else {
                            if (!previousSelection.isEmpty()) {
                                selection.clear();
                                selection.addAll(previousSelection);
                                getTransferSelection().clear();
                                getTransferSelection().addAll(getPreviousTransferSelection());
                            } else {
                                previousSelection.addAll(selection);
                                getPreviousTransferSelection().addAll(getTransferSelection());
                            }
                        }
                        selectRange(contextData, anchor, object);
                    }

                    //          selection.setColoringLocked( false );
                    //          selection.reapplyColorScheme( true );
                }
            });
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     * @param start Description of parameter.
     * @param end Description of parameter.
     */
    protected abstract void selectRange(ContextData contextData,
        AbstractObject start, AbstractObject end);

    /**
     * Simply forwards the operation to another dispatcher. In this case the 3D view
     * dispatcher will process the method.
     *
     * @param contextData ContextData of this dispatcher.
     * @param operation Operation to be forwarded.
     */
    protected void forwardOperation(final ContextData contextData,
        final Operation operation) {

        // make sure the operation needs to be further processed
        if (operation.getContext() == contextData.getContext()) {

            // forward to 3d view
            ContextData referenceContextData =
                ((AnnotationContextData) contextData).getReferenceContextData();
            operation.setContext(referenceContextData.getContext());
            referenceContextData.getDispatcher().runDispatch(operation);
            operation.setConsumed(true);
        }
    }
}
