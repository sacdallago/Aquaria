/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.annotation.dispatcher;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Vector;

import javax.vecmath.Color3f;
import javax.vecmath.Point3f;

import org.srs3d.viewer.annotation.attributes.LayoutPosition;
import org.srs3d.viewer.annotation.contexts.AbstractAnnotationContext;
import org.srs3d.viewer.annotation.contexts.AnnotationContextData;
import org.srs3d.viewer.annotation.objects.Alignment;
import org.srs3d.viewer.annotation.objects.AnnotationContainer;
import org.srs3d.viewer.annotation.objects.AnnotationUnit;
import org.srs3d.viewer.annotation.objects.ChainAnnotation;
import org.srs3d.viewer.annotation.objects.FeatureUnit;
import org.srs3d.viewer.annotation.objects.Referenceable;
import org.srs3d.viewer.annotation.objects.Segment;
import org.srs3d.viewer.bioatlas.Parameter;
import org.srs3d.viewer.bioatlas.objects.Annotation;
import org.srs3d.viewer.bioatlas.objects.Feature;
import org.srs3d.viewer.bioatlas.objects.Subchain;
import org.srs3d.viewer.j3d.Context;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.DispatchManager;
import org.srs3d.viewer.j3d.Selection;
import org.srs3d.viewer.j3d.SensorManager;
import org.srs3d.viewer.j3d.behaviors.KeyHandler;
import org.srs3d.viewer.j3d.behaviors.UpdateBehavior.Callback;
import org.srs3d.viewer.j3d.commands.ColorCommand;
import org.srs3d.viewer.j3d.commands.SpawnCommand;
import org.srs3d.viewer.j3d.objects.Rectangle;
import org.srs3d.viewer.j3d.objects.Sensor;
import org.srs3d.viewer.j3d.operations.IntersectOperation;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.objects.ObjectManager;
import org.srs3d.viewer.objects.Operation;
import org.srs3d.viewer.objects.State;
import org.srs3d.viewer.objects.StateManager;
import org.srs3d.viewer.util.Log;

/**
 * @author Karsten Klein
 * @author Christian Zofka
 * @version November 20, 2000
 *
 * @modified July 08, 2001
 */
public class AnnotationUpDispatcher extends AbstractUpDispatcher {
    private static final Log log = new Log(AnnotationUpDispatcher.class);
    private AnnotationContainer annotationContainer = null;
    private SensorManager sensorManager = null;
    private transient long zoomBoxUpdateTime = -Integer.MAX_VALUE;

    /**
     * Sets the <code>annotationContainer</code> attribute of the
     * <code>AnnotationUpDispatcher</code> object.
     *
     * @param annotationContainer The new <code>annotationContainer</code> value.
     */
    public void setAnnotationContainer(AnnotationContainer annotationContainer) {
        this.annotationContainer = annotationContainer;
    }

    /**
     * Description of the method.
     *
     * @param context Description of parameter.
     * @param operation Description of parameter.
     */
    public void process(final Context context, final Operation operation) {
        final AnnotationContextData contextData =
            (AnnotationContextData) context.getContextData();
        if (operation.is("KEYSTROKE")) {
            return;
        }
        if (operation.is("INTERSECT")) {
            processIntersect(contextData, operation);
            return;
        }
        if (operation.is("MOUSEOVER")) {
            processMouseOver(context.getContextData(), operation);
            return;
        }
        if (operation.is("MOVE_OVERVIEW")) {
            return;
        }
        if (operation.is("UPDATE_COLORING")) {
            processUpdateColoring(context.getContextData(), operation);
            return;
        }
        if (operation.is("UPDATE_ACTIVATION")) {
            processUpdateActivation(context.getContextData(), operation);
            return;
        }
        if (operation.is("ZOOM")) {
            forwardOperation(contextData, operation);
            return;
        }
        if (operation.is("TRANSFER_SELECTION")) {
            processTransferSelection(contextData, operation);
        } else if (operation.is("FORWARD_SELECTION")) {
            processTransferSelection(contextData, operation,
                operation.getContext() == context);
            operation.setConsumed(false);
        } else if (operation.is("KEY_INPUT")) {
            processKeyInput(context.getContextData(), operation);
            return;
        } else if (operation.is("SELECT")) {
            setRangeAnchor(contextData, operation.getObject());
            processSelectBottom(contextData, operation);
        } else if (operation.is("SELECT_CONTROL")) {
            setRangeAnchor(contextData, operation.getObject());
            processSelectHierarchy(context.getContextData(), operation);
        } else if (operation.is("SELECT_SHIFT")) {
            if (operation.getObject() instanceof Segment) {
                processSelectRange(contextData, operation);
            }
        } else if (operation.is("SELECT_SHIFT_CONTROL")) {
            setRangeAnchor(contextData, null);
            processDeselectHierarchy(contextData, operation);
        } else if (operation.is("SELECT_ALT")) {
            setRangeAnchor(contextData, null);
            processSelectTop(contextData, operation, false);
        } else if (operation.is("SELECT_ALT_CTRL")) {
            setRangeAnchor(contextData, null);
            processSelectTop(contextData, operation, true);
        } else if (operation.is("MOVE_ZOOMBOX")) {
            processMoveZoomBox(contextData, operation);
        } else if (operation.is("SWITCH_ALIGNMENT")) {
            processSwitchAlignment(contextData, operation);
        }
        context.addUpdateCallback(new Callback() {
                public void execute() {

                    // communicate current selection/zoom to other contexts
                    if (operation.getContext() == context) {
                        if (operation.getId() == "MOVE_ZOOMBOX") {
                            contextData.getZoomBoxThread().schedule(contextData.getContext(),
                                operation);
                        } else {
                            if (!operation.isConsumed()) {

                                // :NOTE: this is still needed, e.g. for range selection,
                                //   since the 3d view doesn't care about the range selection
                                //   itself
                                if (operation.is("SELECT_SHIFT")) {
                                    if (operation.getObject() instanceof Segment) {
                                        performTransferSelection(contextData,
                                            ((Segment) operation.getObject()).getSubchain());
                                    }
                                }
                            }
                        }
                    }
                    if (!operation.is("MOVE_ZOOMBOX")) {
                        if (!operation.isConsumed()) {
                            Selection selection =
                                contextData.getSelectionManager().getSelection();
                            processSelectionZoom(context, annotationContainer,
                                selection, 1000);
                        }
                    }
                }
            });
    }

    /**
     * From an arbitrary selection, we want to select the associated segments. Since the
     * segments are a concept special to the annotation view�, we have to project the
     * transfered selection onto segment instances.
     *
     * @param contextData Description of parameter.
     * @param operation Description of parameter.
     */
    public void processTransferSelection(ContextData contextData,
        Operation operation) {
        processTransferSelection(contextData, operation, false);
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     * @param operation Description of parameter.
     * @param isAdd Description of parameter.
     */
    public void processTransferSelection(final ContextData contextData,
        final Operation operation, final boolean isAdd) {
        contextData.getContext().addUpdateCallback(new Callback() {
                public void execute() {
                    getTransferSelection().clear();
                    getTransferSelection().addAll(operation.getObjects());
                    ObjectManager objectManager =
                        contextData.getObjectManager();
                    final Selection selection =
                        contextData.getSelectionManager().getSelection();
                    final HashSet segments = new HashSet();
                    HashSet subchains = new HashSet();
                    ContextData referenceContextData =
                        ((AnnotationContextData) contextData).getReferenceContextData();

                    // collect all subchains
                    referenceContextData.getObjectManager().getAssociations(operation.getObjects(),
                        subchains);
                    subchains.addAll(operation.getObjects());
                    ObjectManager.extract(subchains, Subchain.class);

                    // identify segments
                    objectManager.getDirectDownAssociations(subchains, segments);
                    ObjectManager.extract(segments, Segment.class);

                    // keep features in the selection
                    ObjectManager.extract(operation.getObjects(), segments,
                        Feature.class);
                    if (!isAdd) {
                        selection.clear();
                    }
                    selection.addAll(segments);
                    selection.reapplyColorScheme(true);
                }
            });
        contextData.getContext().addUpdateCallback(null);
        contextData.getContext().addUpdateCallback(new Callback() {
                public void execute() {
                    processUpdateColoring(contextData);
                }
            });
    }

    /**
     * Update highlight of the sensors that are associated with the provided annotation.
     *
     * @param contextData ContextData.
     * @param annotation Annotation of interest.
     * @param isActive Annotation activation status.
     */
    public void updateActivation(final ContextData contextData,
        final Annotation annotation, final boolean isActive) {
        contextData.getContext().addUpdateCallback(new Callback() {
                public void execute() {
                    Selection activeSelection =
                        contextData.getSelectionManager().getSelection("Activation" +
                            annotation.toString());
                    if (activeSelection.isEmpty()) {
                        Color3f color = new Color3f(0.4f, 0.4f, 0.4f);
                        activeSelection.setColorScheme(new org.srs3d.viewer.bioatlas.colorschemes.SelectionColorScheme(
                                contextData, color, false));
                    }
                    Collection sensors =
                        contextData.getSensorManager().getSensors(annotation);
                    if (sensors != null) {
                        if (isActive) {
                            activeSelection.addAll(contextData.getSensorManager()
                                                              .getSensors(annotation));
                        } else {
                            activeSelection.removeAll(contextData.getSensorManager()
                                                                 .getSensors(annotation));
                        }
                    }
                    Selection highlight =
                        contextData.getSelectionManager().getSelection("HIGHLIGHT");
                    highlight.resetColoring(true);
                    highlight.clear();
                }
            });
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     * @param operation Description of parameter.
     */
    public void processMouseOver(final ContextData contextData,
        final Operation operation) {
        final AbstractObject object = operation.getObject();
        contextData.getContext().addUpdateCallback(new Callback() {
                public void execute() {
                    Selection selection =
                        contextData.getSelectionManager().getSelection("HIGHLIGHT");
                    selection.resetColoring(true);
                    selection.clear();
                    selection.setColorScheme(new org.srs3d.viewer.bioatlas.colorschemes.SelectionColorScheme(
                            contextData, new Color3f(0.2f, 0.2f, 0.2f), false));
                    boolean isActivateMode = false;
                    if (object != null) {
                        if (object instanceof Sensor) {
                            AnnotationUnit annotationUnit =
                                (AnnotationUnit) ((Sensor) object).getReference();

                            // highlight annotation unit background
                            selection.addAll(contextData.getSensorManager()
                                                        .getSensors(annotationUnit.getAnnotation()));
                            isActivateMode = true;
                            String status =
                                annotationUnit.getAnnotation().toString();
                            showStatus(contextData, status);
                        } else {
                            if (object instanceof org.srs3d.viewer.j3d.objects.Rectangle) {
                                KeyHandler.setCursor(contextData, "PanX", false);
                                return;
                            } else {
                                if (object instanceof Referenceable) {
                                    showStatus(contextData,
                                        ((Referenceable) object).getReference()
                                         .toString());
                                } else {
                                    showStatus(contextData, object.toString());
                                }
                            }
                        }
                    } else {
                        showStatus(contextData, "");
                    }
                    KeyHandler.setCursor(contextData,
                        isActivateMode ? "Activate" : "Select", false);
                    IntersectOperation intersectOperation =
                        (IntersectOperation) operation;

                    // we need the trigger event for determining the mouse cursor
                    KeyHandler.setCursor(contextData,
                        intersectOperation.getTriggerEvent(),
                        isActivateMode ? 1 : 0);
                }
            });
    }

    /**
     * Description of the method.
     *
     * @param set Description of parameter.
     */
    public void filterContextObjects(Collection set) {
        ObjectManager.filter(set, Segment.class);
        ObjectManager.filter(set, FeatureUnit.class);
        ObjectManager.filter(set, AnnotationUnit.class);
        ObjectManager.filter(set, Sensor.class);
        ObjectManager.filter(set, ChainAnnotation.class);
        ObjectManager.filter(set, Alignment.class);
        ObjectManager.filter(set, AnnotationContainer.class);
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     * @param operation Description of parameter.
     */
    public void processUpdateActivation(ContextData contextData,
        Operation operation) {
        Annotation annotation = (Annotation) operation.getObject();
        ContextData referenceContextData =
            ((AnnotationContextData) contextData).getReferenceContextData();
        boolean isActive =
            org.srs3d.viewer.bioatlas.modules.AnnotationModule.isActiveAnnotation(referenceContextData,
                annotation);
        updateActivation(contextData, annotation, isActive);
    }

    /**
     * Sets the range anchor to the specified object (if appropriate) and clears the
     * associates sets.
     *
     * @param contextData The new <code>rangeAnchor</code> value.
     * @param object The new <code>rangeAnchor</code> value.
     */
    protected void setRangeAnchor(ContextData contextData, AbstractObject object) {
        setAnchor(null);
        if (object instanceof Segment) {
            setAnchor(object);
        }
        getPreviousSelection().clear();
        getPreviousTransferSelection().clear();
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     * @param operation Description of parameter.
     */
    protected void processDeselectHierarchy(final ContextData contextData,
        final Operation operation) {
        final AbstractObject object = operation.getObject();
        if (object != null && object.getClass() == Segment.class) {
            operation.setObject(((Segment) object).getSubchain());
            forwardOperation(contextData, operation);
        } else {
            if (object != null && object.getClass() == Feature.class) {
                final Selection selection =
                    contextData.getSelectionManager().getSelection();

                // set contains the active features
                final HashSet set = new HashSet();
                ObjectManager.extract(selection, set, Feature.class);
                super.processDeselectHierarchy(contextData, operation);
                HashSet remaining = new HashSet();
                ObjectManager.extract(selection, remaining, Feature.class);

                // set contains the deacivated features
                set.removeAll(remaining);
                propagateRemoveFeatures(contextData, set);
                propagateSelectFeatures(contextData, true);
            } else {
                super.processDeselectHierarchy(contextData, operation);
            }
        }
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     * @param operation Description of parameter.
     */
    protected void processSelectHierarchy(final ContextData contextData,
        final Operation operation) {
        final AbstractObject object = operation.getObject();
        if (object != null && object.getClass() == Segment.class) {
            operation.setObject(((Segment) object).getSubchain());
            forwardOperation(contextData, operation);
        } else {
            if (object instanceof Sensor) {
                AnnotationUnit annotationUnit =
                    (AnnotationUnit) ((Sensor) object).getReference();
                Operation op =
                    new Operation(contextData.getContext(),
                        "TOGGLE_ACTIVATION", annotationUnit.getAnnotation());
                DispatchManager.runDispatch(contextData.getContext(), op);
            } else {
                if (object != null && object.getClass() == Feature.class) {
                    final Selection selection =
                        contextData.getSelectionManager().getSelection();
                    HashSet set = new HashSet();
                    ObjectManager.extract(selection, set, Feature.class);
                    super.processSelectHierarchy(contextData, operation);
                    contextData.getContext().addUpdateCallback(new Callback() {
                            public void execute() {
                                ObjectManager.filter(selection,
                                    AnnotationUnit.class);
                                propagateSelectFeatures(contextData, true);
                                operation.setConsumed(true);
                            }
                        });
                } else {
                    super.processSelectHierarchy(contextData, operation);
                    operation.setConsumed(true);
                }
            }
        }
    }

    protected void processSelectTop(final ContextData contextData,
        final Operation operation, final boolean isAdd) {
        final AbstractObject object = operation.getObject();
        if (object != null && object.getClass() == Segment.class) {
            operation.setObject(((Segment) object).getSubchain());
            forwardOperation(contextData, operation);

            // :NOTE: do not reset the operations opject; the selection won't work
            //   anymore, because the operation is reused and forwarded to the 3D
            //   context, where it is scheduled
        } else {

            // :TODO: process top selection for feature and annotation units
            if (object instanceof Feature) {
                final Collection features = new HashSet();
                features.add(object);
                contextData.getObjectManager().getAllRelated(object, features);
                ObjectManager.filter(features, AnnotationUnit.class);
                ObjectManager.filter(features, FeatureUnit.class);
                contextData.getContext().addUpdateCallback(new Callback() {
                        public void execute() {
                            contextData.getSelectionManager().getSelection()
                                       .addAll(features);
                            ObjectManager.extract(features, Feature.class);
                            propagateSelectFeatures(contextData, features, isAdd);
                        }
                    });
                operation.setConsumed(true);
            }
        }
    }

    /**
     * Description of the method.
     *
     * @param operation Description of parameter.
     * @param contextData Description of parameter.
     */
    protected void processSelectBottom(final ContextData contextData,
        final Operation operation) {
        final AbstractObject object = operation.getObject();
        if (object == null || object.getClass() == Segment.class) {
            if (object != null) {
                operation.setObject(((Segment) object).getSubchain());
            }
            forwardOperation(contextData, operation);
        } else {
            contextData.getContext().addUpdateCallback(new Callback() {
                    public void execute() {
                        if (!(object instanceof Sensor) &&
                              !(object instanceof Rectangle)) {
                            getTransferSelection().clear();
                            AnnotationUpDispatcher.super.processSelectBottom(contextData,
                                operation);
                        }
                        if (object != null) {
                            if (object instanceof Sensor) {
                                toggleAnnotationEx(contextData, object);
                                getTransferSelection().remove(object);
                            } else if (object instanceof Feature) {
                                getTransferSelection().clear();
                                propagateSelectFeature(contextData, object,
                                    false);
                            }
                        }
                        operation.setConsumed(true);
                    }
                });
        }
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     * @param startObject Description of parameter.
     * @param endObject Description of parameter.
     */
    protected void selectRange(ContextData contextData,
        AbstractObject startObject, AbstractObject endObject) {
        Segment start = (Segment) startObject;
        Segment end = (Segment) endObject;
        Selection selection = contextData.getSelectionManager().getSelection();
        Collection chainFilter = new HashSet();
        ObjectManager objectManager = contextData.getObjectManager();
        ChainAnnotation chainAnnotation;
        Segment segment;
        objectManager.getDirectUpAssociations(start, chainFilter);
        ObjectManager.extract(chainFilter, ChainAnnotation.class);
        if (!chainFilter.isEmpty()) {
            chainAnnotation = (ChainAnnotation) chainFilter.iterator().next();
            chainFilter.clear();
            objectManager.getDirectUpAssociations(end, chainFilter);
            ObjectManager.extract(chainFilter, ChainAnnotation.class);
            if (!chainFilter.isEmpty()) {
                if (chainAnnotation == chainFilter.iterator().next()) {
                    if (start.getStartIndex() > end.getStartIndex()) {
                        Segment temp = start;
                        start = end;
                        end = temp;
                    }
                    Iterator iterator =
                        chainAnnotation.getSegments().iterator();
                    while (iterator.hasNext()) {
                        segment = (Segment) iterator.next();
                        if (segment.getStartIndex() >= start.getStartIndex() &&
                              segment.getStartIndex() <= end.getStartIndex()) {
                            selection.add(segment);
                            if (segment.getSubchain() != null) {
                                getTransferSelection().add(segment.getSubchain());
                            }
                        }
                    }
                }
            } else {
                log.error("no chainAnnotation found for " + end);
                return;
            }
        } else {
            log.error("no chainAnnotation found for " + start);
        }
    }

    private void propagateSelectFeature(ContextData contextData,
        AbstractObject object, boolean isAdd) {
        if (object instanceof Feature) {
            Collection features = new ArrayList();
            features.add(object);
            propagateSelectFeatures(contextData, features, isAdd);
        }
    }

    private void propagateSelectFeatures(ContextData contextData,
        Collection features, boolean isAdd) {
        String operationId = isAdd ? "SELECT_ADD_FEATURES" : "SELECT_FEATURES";
        Operation operation =
            new Operation(contextData.getContext(), operationId, null);
        operation.setObjects(features);
        forwardOperation(contextData, operation);
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     * @param object Description of parameter.
     */
    private void toggleAnnotationEx(ContextData contextData,
        AbstractObject object) {
        AnnotationUnit annotationUnit =
            (AnnotationUnit) ((Sensor) object).getReference();
        Annotation annotation = annotationUnit.getAnnotation();
        ContextData referenceContextData =
            ((AnnotationContextData) contextData).getReferenceContextData();
        boolean isActive =
            org.srs3d.viewer.bioatlas.modules.AnnotationModule.isActiveAnnotation(referenceContextData,
                annotation);
        Operation newOperation =
            new Operation(contextData.getContext(), "TOGGLE_ACTIVATION_EX",
                annotation);
        DispatchManager.runDispatch(contextData.getContext(), newOperation);
        Selection selection = contextData.getSelectionManager().getSelection();
        selection.remove(object);
    }

    /**
     * Searches the alignment on position x.
     *
     * @param contextData Description of parameter.
     * @param x Description of parameter.
     *
     * @return The <code>alignment</code> value.
     */
    private Alignment findAlignment(AnnotationContextData contextData, float x) {
        AnnotationContainer annotationContainer =
            contextData.getAnnotationContainer();
        Collection alignments = annotationContainer.getAlignments();
        Alignment alignment = null;
        Alignment nearestAlignment = null;
        float distance = Float.MAX_VALUE;
        float d1;
        float d2;
        Point3f position = new Point3f(x, 0, 0);
        State.Immutable state;
        LayoutPosition.Immutable layoutPosition;
        boolean isFound = false;
        Iterator iterator = alignments.iterator();
        while (!isFound && iterator.hasNext()) {
            alignment = (Alignment) iterator.next();
            state = contextData.getStateManager().getImmutableState(alignment);
            layoutPosition =
                (LayoutPosition.Immutable) state.getAttribute(LayoutPosition.class);
            if (layoutPosition != null) {
                position = layoutPosition.getPosition();
                d1 = x - position.x;
                d2 = position.x + alignment.getLength() - x;
                if (d1 >= 0 && d2 >= 0) {
                    isFound = true;
                } else {
                    if (d1 < 0) {
                        d1 = -d1;
                    } else {
                        d1 = -d2;
                    }
                    if (d1 < distance) {
                        nearestAlignment = alignment;
                        distance = d1;
                    }
                }
            }
        }
        if (isFound) {
            return alignment;
        } else {
            return nearestAlignment;
        }
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     * @param operation Description of parameter.
     */
    private void processMoveZoomBox(final AnnotationContextData contextData,
        final Operation operation) {
        contextData.getContext().addUpdateCallback(new Callback() {
                public void execute() {
                    Rectangle zoomBox = (Rectangle) operation.getObject();
                    if (zoomBox != null) {
                        float boxCenter = zoomBox.getCoordinate().x;
                        float boxLength = zoomBox.getWidth();
                        float boxHalfWidth = 0.5f * boxLength;
                        Alignment alignment;
                        alignment = findAlignment(contextData, boxCenter);
                        Point3f position = new Point3f();
                        State.Immutable state;
                        LayoutPosition.Immutable layoutPosition;
                        state =
                            contextData.getStateManager().getImmutableState(alignment);
                        layoutPosition =
                            (LayoutPosition.Immutable) state.getAttribute(LayoutPosition.class);
                        if (layoutPosition != null) {
                            position.add(layoutPosition.getPosition());
                        }
                        float min = position.x;
                        float alignmentLength = alignment.getLength();
                        float max = min + alignmentLength;
                        float boxLeftBorder = boxCenter - boxHalfWidth;
                        float boxRightBorder = boxCenter + boxHalfWidth;
                        if (boxLeftBorder < min) {
                            zoomBox.getCoordinate().x = min + boxHalfWidth;
                        } else if (boxRightBorder > max) {
                            zoomBox.getCoordinate().x = max - boxHalfWidth;
                        }
                        if (alignmentLength < boxLength) {
                            zoomBox.getCoordinate().x =
                                position.x + 0.5f * alignmentLength;
                        }
                        SpawnCommand spawn = new SpawnCommand(contextData);
                        contextData.getStrategyManager().execute(zoomBox, spawn);
                        if (alignment != contextData.getActiveBoxAlignment()) {
                            contextData.setActiveBoxAlignment(alignment);
                            Operation switchOperation =
                                new Operation(contextData.getContext(),
                                    "SWITCH_ALIGNMENT", alignment);
                            switchOperation.setSerializable(false);
                            contextData.getZoomBoxThread().schedule(contextData.getContext(),
                                switchOperation);
                        }
                    }
                }
            });
    }

    /**
     * Description of the method.
     *
     * @param operation Description of parameter.
     * @param contextData Description of parameter.
     */
    private void processSwitchAlignment(
        final AnnotationContextData contextData, final Operation operation) {
        contextData.getContext().addUpdateCallback(new Callback() {
                public void execute() {
                    contextData.setActiveBoxAlignment((Alignment) operation.getObject());
                }
            });
    }

    /**
     * checks the viewport center so it can't move over the limits of the annotation;
     * centers it when annotationlength is smaller than viewportlength
     *
     * @param context working context.
     * @param currentX current center x-position of the viewPort.
     * @param centerZ Description of parameter.
     *
     * @return new x position.
     */
    public static float limitXRange(AbstractAnnotationContext context,
        float currentX, float centerZ) {
        float x = currentX;
        ContextData contextData = context.getContextData();
        Collection set = new HashSet();
        contextData.getObjectContainer().getAllObjects(set);
        AnnotationContainer annotationContainer =
            ((AnnotationContextData) context.getContextData()).getAnnotationContainer();
        if (annotationContainer != null) {
            float position = -0.5f * annotationContainer.getLength();
            float annotationLength = annotationContainer.getLength();
            float viewLength =
                centerZ * org.srs3d.viewer.bioatlas.Parameter.aspectScaleX;
            if (annotationLength < viewLength) {
                x = position + 0.5f * annotationLength;
            } else {
                float viewHalf = 0.5f * viewLength;
                float end = position + annotationLength;
                float lowBorder = position + viewHalf;
                if (x < lowBorder) {
                    x = lowBorder;
                } else {
                    float highBorder = end - viewHalf;
                    if (x > highBorder) {
                        x = highBorder;
                    }
                }
            }
        }
        return x;
    }

    /**
     * Description of the method.
     *
     * @param context Description of parameter.
     * @param currentX Description of parameter.
     * @param centerZ Description of parameter.
     *
     * @return Description of the returned value.
     */
    public static float limitXRangeAlignment(
        AbstractAnnotationContext context, float currentX, float centerZ) {
        float x = currentX;
        ContextData contextData = context.getContextData();
        Collection set = new HashSet();
        contextData.getObjectContainer().getAllObjects(set);
        Alignment alignment =
            ((AnnotationContextData) context.getContextData()).getActiveBoxAlignment();
        if (alignment != null) {
            LayoutPosition.Immutable layoutPosition =
                (LayoutPosition.Immutable) contextData.getStateManager()
                                                      .getImmutableState(alignment)
                                                      .getAttribute(LayoutPosition.class);

            //      float position = alignment.getLength() / -2.0f;
            float position = layoutPosition.getPosition().x;
            float annotationLength = alignment.getLength();
            float viewLength =
                centerZ * org.srs3d.viewer.bioatlas.Parameter.aspectScaleX;
            if (annotationLength < viewLength) {
                x = position + 0.5f * annotationLength;
            } else {
                float viewHalf = 0.5f * viewLength;
                float end = position + annotationLength;
                float lowBorder = position + viewHalf;
                if (x < lowBorder) {
                    x = lowBorder;
                } else {
                    float highBorder = end - viewHalf;
                    if (x > highBorder) {
                        x = highBorder;
                    }
                }
            }
        }
        return x;
    }

    /**
     * Description of the method.
     *
     * @param context Description of parameter.
     * @param annotationContainer Description of parameter.
     * @param selection Description of parameter.
     * @param duration Description of parameter.
     */
    public static void processSelectionZoom(Context context,
        AnnotationContainer annotationContainer, Collection selection,
        int duration) {
        boolean limitToAlignment = false;
        ContextData contextData = context.getContextData();
        ContextData refecerenceContextData =
            ((AnnotationContextData) contextData).getReferenceContextData();
        if (selection != null) {
            String autoZoom =
                (String) refecerenceContextData.getProperty("AutoZoom");
            if (autoZoom != null) {
                if (autoZoom.equalsIgnoreCase("OFF")) {
                    return;
                }
            }
        }
        if (annotationContainer != null) {
            float yCenter = 0; // - 0.5f * annotationContainer.getHeight();
            float start = 0.0f;
            float extend = annotationContainer.getLength();
            if (selection != null && !selection.isEmpty()) {
                boolean isDetailEnabled = true;

                // center to associated chains
                ObjectManager objectManager = contextData.getObjectManager();
                HashSet set = new HashSet();
                Collection chainAnnotations = new HashSet();
                objectManager.getUpAssociations(selection, set);
                set.addAll(selection);
                ObjectManager.extract(set, chainAnnotations,
                    ChainAnnotation.class);
                if (!chainAnnotations.isEmpty()) {
                    start = 0.5f * extend;
                    float end = -start;
                    float position = 0;
                    StateManager stateManager = contextData.getStateManager();
                    ChainAnnotation chainAnnotation;

                    // :FIXME: this criteria is not enough; the isDetailEnable should be
                    //   switched one if the selection is residing in only one alignments
                    //   (no matter of in how many ChainAnnotations the Selection resides)
                    isDetailEnabled = chainAnnotations.size() == 1;
                    Iterator iterator = chainAnnotations.iterator();
                    while (iterator.hasNext()) {
                        chainAnnotation = (ChainAnnotation) iterator.next();
                        State.Immutable state =
                            stateManager.getImmutableState(chainAnnotation);
                        LayoutPosition.Immutable layoutPosition =
                            (LayoutPosition.Immutable) state.getAttribute(LayoutPosition.class);
                        if (layoutPosition != null) {
                            position = layoutPosition.getPosition().x;
                        } else {
                            log.error("no layout position found for " +
                                chainAnnotation + ".");
                        }
                        if (position < start) {
                            start = position;
                            Vector gapSequence =
                                chainAnnotation.getGapSequence();
                            Object object = null;
                            int i;
                            for (i = 0;
                                  i < gapSequence.size() && object == null;
                                  i++) {
                                object = gapSequence.elementAt(i);
                            }
                            start += i - 1;
                        }
                        position += chainAnnotation.getLength();
                        if (position > end) {
                            end = position;
                            Vector gapSequence =
                                chainAnnotation.getGapSequence();
                            Object object = null;
                            int i;
                            for (i = gapSequence.size() - 1;
                                  i >= 0 && object == null; i--) {
                                object = gapSequence.elementAt(i);
                            }
                            end -= gapSequence.size() - i;
                        }
                    }
                    extend = end - start;
                    if (isDetailEnabled && extend > 600) {

                        // try to zoom to the selection (also centering it)
                        //            extend = annotationContainer.getLength();
                        //            start = extend / 2;
                        //            end = -start;
                        float alignmentStart = start;
                        float alignmentEnd = end;
                        start = alignmentEnd;
                        end = alignmentStart;
                        Collection segments = new HashSet();
                        ObjectManager.extract(selection, segments, Segment.class);
                        iterator = segments.iterator();
                        Segment segment;
                        while (iterator.hasNext()) {
                            segment = (Segment) iterator.next();
                            State.Immutable state =
                                stateManager.getImmutableState(segment);
                            LayoutPosition.Immutable layoutPosition =
                                (LayoutPosition.Immutable) state.getAttribute(LayoutPosition.class);
                            if (layoutPosition != null) {
                                position = layoutPosition.getPosition().x;
                                position += segment.getStartIndex();
                            } else {
                                log.error("no layout position found for " +
                                    segment);
                            }
                            if (position < start) {
                                start = position;
                            }
                            position += segment.getEndIndex() -
                            segment.getStartIndex();
                            if (position > end) {
                                end = position;
                            }
                        }
                        extend = end - start;
                    }
                    start += 0.5f * (extend - 1.0f);
                    limitToAlignment = true;
                }
            } else {

                // center the whole annotationContainer
            }
            if (extend < Parameter.minimumAnnotationChainLength) {
                extend = Parameter.minimumAnnotationChainLength;
            }
            float size = 1.3f * extend;
            if (limitToAlignment) {
                start =
                    limitXRangeAlignment((AbstractAnnotationContext) context,
                        start, size);
            }
            start =
                limitXRange((AbstractAnnotationContext) context, start, size);
            context.interpolatePosition(new Point3f(start, yCenter, size),
                duration);
        }
    }

    // Adds the objects of all selected features to transfer selection
    public void propagateSelectFeatures(ContextData contextData, boolean isAdd) {
        Selection selection = contextData.getSelectionManager().getSelection();
        Collection set = new HashSet(selection);
        contextData.getObjectManager().getDownAssociations(selection, set);
        ObjectManager.extract(set, Feature.class);
        propagateSelectFeatures(contextData, set, isAdd);
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     * @param features Parameter description.
     */
    public void propagateRemoveFeatures(ContextData contextData,
        Collection features) {
        Operation operation =
            new Operation(contextData.getContext(), "DESELECT_FEATURES", null);
        operation.setObjects(features);
        forwardOperation(contextData, operation);
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     */
    public static void processUpdateColoring(final ContextData contextData) {
        ColorCommand colorCommand =
            new ColorCommand(contextData, contextData.getColorSchemeBucket());

        // :BF 30/06/2003: trying to resolve annotation context coloring problem
        colorCommand.setForceRecoloring(true);

        // :NOTE: this colors only the objects that have a geometry
        contextData.getStrategyManager().execute(contextData.getShapeManager()
                                                            .getObjects(),
            colorCommand);
        org.srs3d.viewer.bioatlas.Capture.updateSelections(contextData, false);
    }

    /**
     * Description of the class.
     *
     * @author Christian Zofka
     *
     * @created August 17, 2001
     */
    private static class SegmentSort implements Comparator {

        /**
         * Description of the method.
         *
         * @param o1 Description of parameter.
         * @param o2 Description of parameter.
         *
         * @return Description of the returned value.
         */
        public int compare(Object o1, Object o2) {
            int result = 0;
            result =
                ((Segment) o1).getStartIndex() -
                ((Segment) o2).getStartIndex();
            return result;
        }

        /**
         * Description of the method.
         *
         * @param obj Description of parameter.
         *
         * @return Description of the returned value.
         */
        public boolean equals(Object obj) {
            return false;
        }
    }
}
