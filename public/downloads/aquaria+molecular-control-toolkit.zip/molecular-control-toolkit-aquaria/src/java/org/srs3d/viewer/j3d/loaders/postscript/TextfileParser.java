/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.loaders.postscript;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.StringTokenizer;
import java.util.Vector;

import javax.media.j3d.Appearance;
import javax.media.j3d.BranchGroup;
import javax.media.j3d.LineArray;
import javax.media.j3d.LineAttributes;
import javax.media.j3d.PointAttributes;
import javax.media.j3d.QuadArray;
import javax.media.j3d.Shape3D;
import javax.vecmath.Color4f;
import javax.vecmath.Point3f;
import javax.vecmath.Vector3f;

import org.srs3d.viewer.j3d.AppearanceHelper;
import org.srs3d.viewer.j3d.ShapeManager;
import org.srs3d.viewer.j3d.geometry.GeometryHelper;
import org.srs3d.viewer.j3d.geometry.primitive.Cylinder;
import org.srs3d.viewer.util.Log;

/**
 * Description of the class
 *
 * @author Karsten Klein
 *
 * @created March 20, 2001
 */
public class TextfileParser extends BufferedReader {
    private static final Log log = new Log(TextfileParser.class);

    /**
     * <code>TextfileParser</code> contructor.
     *
     * @param fileName Description of parameter
     *
     * @exception FileNotFoundException Description of exception
     */
    public TextfileParser(String fileName) throws FileNotFoundException {
        super(new FileReader(fileName));
    }

    /**
     * Constructor description.
     *
     * @param inputStream Parameter description.
     *
     * @throws FileNotFoundException Exception description
     * @throws IOException Exception description
     */
    public TextfileParser(InputStream inputStream)
        throws FileNotFoundException, IOException {
        super(new InputStreamReader(inputStream));
    }

    /**
     * Description of the method
     *
     * @return Description of the returned value
     */
    public BranchGroup readSceneGraph() {
        Vector cylinders = new Vector();
        Vector coordinates = new Vector();
        boolean isPathComplete = false;
        BranchGroup localBranch = new BranchGroup();
        org.srs3d.viewer.j3d.BranchGroupHelper.setDefaultCapabilities(localBranch);
        String token = null;
        String line = null;
        Point3f point = new Point3f();
        try {
            do {
                line = readLine();
                if (line != null) {
                    StringTokenizer tokenizer = new StringTokenizer(line);
                    if (tokenizer.countTokens() == 3) {
                        try {
                            point.x = Float.parseFloat(tokenizer.nextToken());
                            point.y = Float.parseFloat(tokenizer.nextToken());
                            token = tokenizer.nextToken();
                            if (token.equals("L") || token.equals("m")) {

                                // encountering a 'm' token starts new path
                                if (token.equals("m")) {

                                    // finalize current
                                    finalizePath(coordinates, cylinders,
                                        localBranch);
                                    coordinates = new Vector();
                                }
                                coordinates.addElement(new Point3f(point));
                            }
                        } catch (NumberFormatException e) {

                            // catch silently
                        }
                    } else {

                        // look for the path termination
                        isPathComplete = true;

                        // ignore certain tokens (path incompletion)
                        if (tokenizer.countTokens() == 1) {
                            token = tokenizer.nextToken();
                            if (token.equals("Mistroke")) {
                                isPathComplete = false;
                            }
                            if (token.equals("Mfstroke")) {
                                isPathComplete = false;
                            }
                        }

                        // if the path is complete finalize it:
                        if (isPathComplete) {
                            finalizePath(coordinates, cylinders, localBranch);
                            coordinates = new Vector();
                        }
                    }
                }
            } while (line != null);
        } catch (IOException e) {
            log.debug(e, e);
        }
        return localBranch;
    }

    /**
     * Description of the method
     *
     * @param coordinates Description of parameter
     * @param cylinders Description of parameter
     * @param branch Description of parameter
     */
    private void finalizePath(Vector coordinates, Vector cylinders,
        BranchGroup branch) {
        if (coordinates.size() > 1) {
            LineArray lineArray =
                GeometryHelper.getDefaultLineArray(coordinates.size() - 1,
                    LineArray.COLOR_4);
            QuadArray quadArray =
                GeometryHelper.getDefaultQuadArray(coordinates.size() - 1,
                    QuadArray.COLOR_4);
            supplyCylinders(coordinates, cylinders);
            Cylinder cylinder;
            for (int i = 0; i < cylinders.size(); i++) {
                cylinder = (Cylinder) cylinders.elementAt(i);
                Color4f color = new Color4f(0.6f, 0.6f, 1f, 0.7f);
                cylinder.getColors().setUniform(color);
                cylinder.getCoordinates().add(new Vector3f(0, 0, 15));
                cylinder.insertInto(i, lineArray);
            }

            // use for snapshots
            Appearance appearance = new Appearance();
            AppearanceHelper.setDefaults(appearance);
            PointAttributes pointAttributes = new PointAttributes();
            pointAttributes.setPointSize(2);
            appearance.setPointAttributes(pointAttributes);
            LineAttributes lineAttributes = new LineAttributes();
            lineAttributes.setLineWidth(2);
            appearance.setLineAttributes(lineAttributes);
            Shape3D shape = new Shape3D(lineArray, appearance);
            ShapeManager.setCapabilities(shape, null);
            branch.addChild(shape);
            cylinders.clear();
        }
    }

    /**
     * Connects the coordinates of the appropriate vector with cylinders and supplies
     * them to the cylinder vector
     *
     * @param coordinates Description of parameter
     * @param cylinders Description of parameter
     */
    private void supplyCylinders(Vector coordinates, Vector cylinders) {
        Cylinder cylinder;
        Point3f head;
        Point3f tail;
        for (int i = 0; i < coordinates.size() - 1; i++) {
            cylinder = new Cylinder();
            head = (Point3f) coordinates.elementAt(i);
            tail = (Point3f) coordinates.elementAt(i + 1);
            cylinder.getCoordinates().set(head, tail);
            cylinder.setUniformRadius(60);
            cylinders.addElement(cylinder);
        }
    }
}
