/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.constraints;


/**
 * The interface <code>Constraint</code> unifies all constraint classes in this package.
 * The instances of this class can be added to any class implementing the
 * <code>Constrainable</code> interface.
 *
 * @author Karsten Klein, 11/2000
 *
 * @since 1.0
 */
public interface Constraint {

    /**
     * Each instance is processing objects. The subclasses chooses which object types to
     * process and skips objects that are unknown to it.
     *
     * @return The boolean return value is <code>true</code>, if a modification was
     *         applied.
     */
    public boolean process(Object object);
}
