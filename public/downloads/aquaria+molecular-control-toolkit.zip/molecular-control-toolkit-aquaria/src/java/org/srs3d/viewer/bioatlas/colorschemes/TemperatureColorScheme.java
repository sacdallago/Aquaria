/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.colorschemes;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;
import java.util.Vector;

import javax.media.j3d.Appearance;
import javax.vecmath.Color3f;
import javax.vecmath.Tuple3f;

import org.srs3d.viewer.bioatlas.objects.Atom;
import org.srs3d.viewer.bioatlas.objects.Residue;
import org.srs3d.viewer.bioatlas.visitors.AtomCollector;
import org.srs3d.viewer.j3d.AbstractColorScheme;
import org.srs3d.viewer.j3d.AppearanceHelper;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.vecmath.CubicBezierCurve3f;

/**
 * The <code>TemperatureColorScheme</code> represents a special color scheme. For every
 * represented entity it computes the average b-factor of its atoms and maps the onto a
 * certain color.
 *
 * @author Karsten Klein
 *
 * @created March 20, 2001
 */
public class TemperatureColorScheme extends AbstractColorScheme {
    private static Color3f invalidColor = new Color3f(0.3f, 0.3f, 0.3f);

    // :FIXME: this values are not set adaptively.
    // :STATUS: we agreed on having fixed settings, Karsten 13.07.2001
    public float minTemperature = 5;
    public float maxTemperature = 80;

    /** a cubic bezier curve is used for the color interpolation. */
    private CubicBezierCurve3f colorCurve = null;

    /**
     * <code>TemperatureColorScheme</code> contructor.
     */
    public TemperatureColorScheme(ContextData contextData) {
        super(contextData);

        // we use a cubic bezier curve for interpolation of the colors
        colorCurve = new CubicBezierCurve3f();
        ArrayList colors = new ArrayList();

        // interpolate blue, violet to red
        colors.add(new Color3f(0, 0, 1));
        colors.add(new Color3f(1, 0, 1));
        colors.add(new Color3f(1, 0, 0));
        colorCurve.setCoordinates(colors);
        setComplete(true);
    }

    /**
     * Description of the method
     *
     * @param object Description of parameter
     * @param appearance Description of parameter
     */
    public boolean modify(AbstractObject object, Appearance appearance) {
        boolean isModified = false;
        if (isApplicable(object)) {
            AtomCollector atomCollector = new AtomCollector();
            atomCollector.visit(object);
            Collection atoms = null;
            Color3f color;
            if (atomCollector.hasObjects()) {
                Tuple3f temperature = atomCollector.computeTemperature();
                atomCollector = null;
                if (temperature.z > 0) {
                    AppearanceHelper.modifyAppearance(appearance,
                        clampColor(computeColor(temperature.z)));
                } else {
                    AppearanceHelper.modifyAppearance(appearance, invalidColor);
                }

                // we enable vertex colors only for non-atom objects
                AppearanceHelper.enableVertexColors(appearance,
                    isEnableVertexColors(object));
                isModified = true;
            } else {
                AppearanceHelper.modifyAppearance(appearance,
                    new Color3f(0.3f, 0.3f, 0.3f));
                AppearanceHelper.enableVertexColors(appearance, false);
                isModified = true;
            }
        } else {

            // we enable vertex colors only for non-atom objects
            AppearanceHelper.enableVertexColors(appearance,
                isEnableVertexColors(object));
            isModified = true;
        }
        return isModified;
    }

    private final boolean isEnableVertexColors(AbstractObject object) {
        return !(object instanceof Atom);
    }

    /**
     * Maps the temperature to a ceratin color.
     *
     * @param temperature the temperature to be mapped.
     *
     * @return <code>Color3f</code> - the color mapped to the specified temperature.
     */
    private Color3f computeColor(float temperature) {
        float map = temperature / (maxTemperature - minTemperature);
        if (map < 0) {
            map = 0;
        }
        if (map > 1) {
            map = 1;
        }
        Color3f color = new Color3f();
        color.set(colorCurve.computePoint(map));
        color.clamp(0f, 1f);
        return color;
    }

    /**
     * Description of the method
     *
     * @param color Description of parameter
     *
     * @return Description of the returned value
     */
    private Color3f clampColor(Color3f color) {
        color.scale(50);
        color.x = (int) color.x;
        color.x /= 50;
        color.y = (int) color.y;
        color.y /= 50;
        color.z = (int) color.z;
        color.z /= 50;
        color.clamp(0f, 1f);
        return color;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public boolean isVertexBased() {
        return true;
    }

    /**
     * Method description.
     *
     * @param map Parameter description.
     *
     * @return Return description.
     */
    public Map getInformation(Map map) {
        map = super.getInformation(map);
        map.put("NAME", "Temperature");
        map.put("GRADIENT_START", "cold");
        map.put("B-factor <  5", clampColor(computeColor(5)));
        map.put("B-factor = 20", clampColor(computeColor(20)));
        map.put("B-factor = 35", clampColor(computeColor(35)));
        map.put("B-factor = 50", clampColor(computeColor(50)));
        map.put("B-factor = 65", clampColor(computeColor(65)));
        map.put("B-factor > 80", clampColor(computeColor(80)));
        map.put("GRADIENT_END", "hot");
        Vector vector = new Vector();
        vector.add("GRADIENT_START");
        vector.add("B-factor <  5");
        vector.add("B-factor = 20");
        vector.add("B-factor = 35");
        vector.add("B-factor = 50");
        vector.add("B-factor = 65");
        vector.add("B-factor > 80");
        vector.add("GRADIENT_END");
        map.put("ORDER", vector);
        map.put("GRADIENT", colorCurve);
        map.put("GRADIENT_END", "hot");
        return map;
    }

    private boolean isApplicable(AbstractObject object) {
        if (object.getClass() == Atom.class) {
            return true;
        }
        if (object.getClass() == Residue.class) {
            return true;
        }
        return false;
    }
}
