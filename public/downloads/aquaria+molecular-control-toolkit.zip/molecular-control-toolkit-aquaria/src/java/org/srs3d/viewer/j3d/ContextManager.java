/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d;

import java.util.Collection;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.Vector;

import org.srs3d.viewer.j3d.behaviors.Behavior;
import org.srs3d.viewer.util.Log;

/**
 * The <code>ContextManager</code> keeps track of the activated context. Furthermore it
 * provides methods that can resolve the context by attributes. The
 * <code>ContextManager</code> can lock/unlock contexts if it's demanded by the users
 * application.
 *
 * @author Karsten Klein
 *
 * @created November 29, 2000
 *
 * @see Context
 */
public class ContextManager {
    private static final Log log = new Log(ContextManager.class);

    /**
     * The ContextManager class implements the singleton desing pattern. The attribute
     * <code>contextManager</code> therefore references the only instance of the
     * contextManager on the running virtual machine
     */
    private static final ContextManager contextManager = new ContextManager();

    /** Description of the field */
    private static Collection recycledContexts = new Vector();

    /** Collects the <code>contexts</code> */
    private HashSet contexts = new HashSet();

    /** Maps behaviors to their contextData instances */
    private Map behaviorMap = new Hashtable();

    /** References the currently active context */
    private ContextData activeContextData = null;

    /** Lock state of the active context */
    private boolean activeContextLocked = false;

    /**
     * Constructs the <code>ContextManager</code> . Note that the constructur is
     * <code>private</code> , since only the class itself should create a single static
     * instance.
     */
    private ContextManager() {
    }

    /**
     * Explicitly sets the active context. Note that the method can fail of two different
     * reasons. First, the context was not added to the managers context list. The user
     * should assure that. Second, the <code>ContextManager</code> received a lock on
     * another context, due to a mouse drag operation is running e.g.
     *
     * @param context The new <code>Active</code> value.
     *
     * @return Returns <code>true</code> if successful
     */
    public boolean setActive(ContextData contextData) {
        if (!activeContextLocked) {

            // this masks the context if it is not in the managers list
            if (!contexts.contains(contextData)) {
                return false;
            } else {
                activeContextData = contextData;
                return true;
            }
        } else {
            if (activeContextData == contextData) {
                return true;
            }
        }
        return false;
    }

    /**
     * Adds context to the <code>ContextManager</code> .
     *
     * @param context the context to be added.
     */
    private void add(Context context) {
        contexts.add(context.getContextData());
        setActive(context.getContextData());
    }

    /**
     * This method locks a context and does not return before the lock is performed.
     *
     * @param context the context to lock
     */
    private final void lock(Context context) {
        if (activeContextLocked) {
            if (context.getContextData() == activeContextData) {

                // the context to lock is already locked
                return;
            }
        }

        // try to grab the context
        setActive(context.getContextData());

        // if successful grab the lock, else retry
        if (context.getContextData() == activeContextData) {
            activeContextLocked = true;
        }
    }

    /**
     * Unlocks the context if it is locked.
     *
     * @param context the context to be unlocked.
     */
    private final void unlock(Context context) {
        if (activeContextLocked) {
            if (context.getContextData() == activeContextData) {
                activeContextLocked = false;
            }
        }
    }

    /**
     * Sets the active context. This method is only successful if no context is locked.
     *
     * @param context context to activate.
     *
     * @return Description of the returned value.
     */
    public static boolean setActiveContext(Context context) {
        return contextManager.setActive(context.getContextData());
    }

    /**
     * Retrieves the active context
     *
     * @return Returns the current active context or <code>null</code> if no context is
     *         available
     */
    public static Context getActiveContext() {
        return contextManager.activeContextData.getContext();
    }

    /**
     * Returns a context of the give class. Note that this method has to be if you want
     * to reuse removed contexts.
     *
     * @param contextClass Description of parameter.
     *
     * @return <code>Context</code> - a new or recycled context.
     */
    public static Context getNewContext(Class contextClass) {
        Context candidate = null;

        // search for a reuseable context
        if (!recycledContexts.isEmpty()) {
            Iterator iterator = recycledContexts.iterator();
            while (iterator.hasNext()) {
                candidate = (Context) iterator.next();
                if (candidate.getClass().isAssignableFrom(contextClass)) {
                    iterator.remove();
                    candidate.intitialize();
                    return candidate;
                }
            }
        }

        // create a new one with default settings.
        try {
            return (Context) contextClass.newInstance();
        } catch (Exception e) {
            log.debug(e, e);
        }
        return null;
    }

    /**
     * Gets the <code>ContextCount</code> attribute of the <code>ContextManager
     * </code>class.
     *
     * @return The <code>ContextCount</code> value.
     */
    public static int getContextCount() {
        return contextManager.contexts.size();
    }

    /**
     * Gets the <code>Context</code> attribute of the <code>ContextManager </code>class.
     *
     * @param behavior Description of parameter.
     *
     * @return The <code>Context</code> value.
     */
    public static Context getContext(Behavior behavior) {
        return (Context) contextManager.behaviorMap.get(behavior);
    }

    /**
     * Adds a valid (non null) context to the managers list
     *
     * @param context the context to be added.
     */
    public static void addContext(Context context) {
        if (context != null) {
            contextManager.add(context);
        }
    }

    /**
     * This method locks a context and does not return before the lock is performed.
     *
     * @param context the context to lock
     */
    public static final void lockContext(Context context) {
        contextManager.lock(context);
    }

    /**
     * Unlocks the context. To be unlocked, the specified context has to be locked first.
     * The method will do nothing, if the given context is not locked.
     *
     * @param context the context to unlock
     */
    public static final void unlockContext(Context context) {
        contextManager.unlock(context);
    }

    /**
     * Displays information on memory and - in case of memory is almost used up - tries
     * to release as much memory as possible.
     */
    public static void checkMemory() {
        boolean verbose = true;
        Runtime runtime = Runtime.getRuntime();
        long totalMemory = runtime.totalMemory();
        long freeMemory = runtime.freeMemory();
        float fraction = (float) totalMemory / freeMemory;
        if (verbose) {
            log.info("memory status:");
            log.info("  Total memory:  " + totalMemory);
            log.info("  Free memory:   " + freeMemory);
            log.info("  Fraction:      " + fraction);
        }
        if (freeMemory < 5000000) {
            if (verbose) {
                log.info("  running finalization and gc!");
            }

            //      GCThread.runFinalization();
            //      GCThread.gc();
        }
    }

    /**
     * Removes the context from the managers context list. A locked context will still be
     * unlocked.
     *
     * @param context the context to remove.
     */
    public static void removeContext(Context context) {

        // make sure the context is not locked
        unlockContext(context);
        contextManager.contexts.remove(context);

        // assure the context was removed from the dispatch manager
        DispatchManager.removeDispatcher(context);

        // :FIXME: currently we are not recycling context, because of problems with
        //   reinitilialization.
        // we store the context for reuse
        // recycledContexts.add( context );
        cleanupBehaviors(context);
        if (contextManager.contexts.isEmpty()) {

            // get rid of all the junk
            GCThread.runFinalization();
            GCThread.gc();
            log.info("finalization queue emptied. Garbage collected.");
        }
    }

    /**
     * Registers behavior to a context.
     *
     * @param behavior the behavior to register.
     * @param context the context.
     */
    public static void register(Behavior behavior, Context context) {
        contextManager.behaviorMap.put(behavior, context);
    }

    /**
     * Description of the method.
     *
     * @param context Description of parameter.
     */
    public static void cleanupBehaviors(Context context) {
        Iterator keyIterator = contextManager.behaviorMap.keySet().iterator();
        Behavior behavior;
        while (keyIterator.hasNext()) {
            behavior = (Behavior) keyIterator.next();
            if (context == contextManager.behaviorMap.get(behavior)) {
                behavior.cleanup();
                keyIterator.remove();
            }
        }
    }

    /**
     * Description of the method.
     *
     * @return Description of the returned value.
     */
    public static boolean hasLock() {
        return contextManager.activeContextLocked;
    }
}
