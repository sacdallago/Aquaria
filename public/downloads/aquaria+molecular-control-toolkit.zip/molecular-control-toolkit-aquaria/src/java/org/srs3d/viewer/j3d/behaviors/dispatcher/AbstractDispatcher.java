/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.behaviors.dispatcher;

import java.awt.event.InputEvent;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Hashtable;
import java.util.Iterator;

import javax.swing.KeyStroke;

import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.operations.KeyStrokeOperation;
import org.srs3d.viewer.objects.Operation;
import org.srs3d.viewer.util.Log;

/**
 * @author Karsten Klein, 11/2000
 *
 * @created May 18, 2001
 * @since 1.0
 */
public abstract class AbstractDispatcher implements Dispatcher {
    private static final Log log = new Log(AbstractDispatcher.class);

    // stores a object (e.g. operations) to dispatch mapping
    private Hashtable dispatchMap = new Hashtable();

    // stores a list of dispatches that all operations undergo
    private ArrayList generalDispatches = new ArrayList();
    private OperationStorage operationStorage = null;
    private final boolean isVerbose = false;

    /**
     * Gets the <code>dispatches</code> attribute of the <code>AbstractDispatcher</code>
     * object.
     *
     * @param object Description of parameter.
     *
     * @return The <code>dispatches</code> value.
     */
    public Collection getDispatches(Object object) {
        return (Collection) dispatchMap.get(object);
    }

    /**
     * Description of the method.
     *
     * @param object Description of parameter.
     * @param dispatches Description of parameter.
     */
    public void registerDispatches(Object object, Collection dispatches) {
        if (isVerbose) {
            log.info("registering dispatches for " + object);
            log.info(dispatches);
        }
        dispatchMap.put(object, dispatches);
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     * @param object Description of parameter.
     */
    public void runDispatches(ContextData contextData, Object object,
        InputEvent e, ContextData source) {
        Iterator iterator;
        Collection dispatches = getDispatches(object);
        KeyStrokeOperation operation =
            new KeyStrokeOperation(source.getContext(), "KEYSTROKE", null);
        operation.setKeyStroke((KeyStroke) object);
        operation.setInputEvent(e);
        if (dispatches != null) {
            iterator = dispatches.iterator();
            if (isVerbose) {
                log.info("executing: " + object + "-" + dispatches);
            }
            while (iterator.hasNext()) {
                ((Dispatch) iterator.next()).dispatch(contextData, operation);
            }
        }
        if (!operation.isConsumed()) {
            runDispatch(operation);
        }
    }

    protected void serializeOperation(ContextData contextData,
        final Operation operation) {

        // store the (to be consumed) operation is the operation store
        if (operationStorage != null) {

            // since the selection is processed in callbacks only, we have to put the
            // the storing in a callback. synchronizing with the callback queue slows
            // down the application
            contextData.getContext().addUpdateCallback(new org.srs3d.viewer.j3d.behaviors.UpdateBehavior.Callback() {
                    public void execute() {
                        operationStorage.store(operation);
                    }
                });
        }
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     * @param operation Description of parameter.
     */
    public void runDispatches(ContextData contextData, Operation operation) {
        serializeOperation(contextData, operation);
        Collection dispatches = getDispatches(operation.getId());
        if (dispatches != null) {
            Iterator iterator = dispatches.iterator();
            if (isVerbose) {
                log.info("executing " + operation.getId() + "-" + dispatches);
            }
            while (iterator.hasNext()) {
                ((Dispatch) iterator.next()).dispatch(contextData, operation);
            }
            operation.setConsumed(true);
        }
    }

    /**
     * Description of the method.
     */
    public void cleanup() {
        if (dispatchMap != null) {
            dispatchMap.clear();
            dispatchMap = null;
        }
    }

    /**
     * Method description.
     *
     * @param operationStorage Parameter description.
     */
    public void setOperationStorage(OperationStorage operationStorage) {
        this.operationStorage = operationStorage;
    }

    /**
     * Method description.
     *
     * @param dispatch Parameter description.
     */
    public void addGeneralDispatch(Dispatch dispatch) {
        this.generalDispatches.add(dispatch);
    }

    /**
     * Description of the method.
     *
     * @return Return parameter description.
     */
    public final boolean isVerbose() {
        return isVerbose;
    }
}
