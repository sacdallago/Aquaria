/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.loaders.raster3d;

import java.util.StringTokenizer;
import java.util.Vector;

import javax.media.j3d.BranchGroup;
import javax.media.j3d.LineArray;
import javax.media.j3d.Shape3D;
import javax.vecmath.Color4f;
import javax.vecmath.Point3f;

import org.srs3d.viewer.j3d.ShapeManager;
import org.srs3d.viewer.j3d.geometry.GeometryHelper;
import org.srs3d.viewer.j3d.geometry.primitive.Line;

/**
 * Class description.
 *
 * @author Karsten Klein, LION bioscience AG
 */
public class Raster3DLine extends Line implements AbstractRaster3DPrimitive {

    /**
     * Creates a line from a raster3D like string. The string format is "x1 y1 z1 x2 y2
     * z2 r g b".
     */
    public boolean create(String string) {
        StringTokenizer tokenizer = new StringTokenizer(string);
        float f;
        if (tokenizer.countTokens() == 9) {
            Point3f[] coordinates = getCoordinates().getBuffer();
            Color4f color = new Color4f();
            for (int index = 0; index < 9; index++) {
                f = Float.parseFloat(tokenizer.nextToken());
                switch (index) {

                    case 0:
                        coordinates[0].x = f;
                        break;

                    case 1:
                        coordinates[0].y = f;
                        break;

                    case 2:
                        coordinates[0].z = f;
                        break;

                    case 3:
                        coordinates[1].x = f;
                        break;

                    case 4:
                        coordinates[1].y = f;
                        break;

                    case 5:
                        coordinates[1].z = f;
                        break;

                    case 8:
                        color.x = f;
                        break;

                    case 9:
                        color.y = f;
                        break;

                    case 10:
                        color.z = f;
                        break;
                }
            }
            getColors().setUniform(color);
            return true;
        } else {
            return false;
        }
    }

    /**
     * Method description.
     *
     * @param lines Parameter description.
     * @param triangles Parameter description.
     * @param branch Parameter description.
     */
    public void supply(Vector lines, Vector triangles, BranchGroup branch) {
        lines.addElement(this);
    }

    /**
     * Method description.
     *
     * @param lines Parameter description.
     * @param branch Parameter description.
     */
    public static void supply(Vector lines, BranchGroup branch) {
        if (lines.size() > 0) {
            LineArray lineArray =
                GeometryHelper.getDefaultLineArray(lines.size(),
                    LineArray.COLOR_4);
            for (int i = 0; i < lines.size(); i++) {
                ((Line) lines.elementAt(i)).insertInto(i, lineArray);
            }
            Shape3D shape = new Shape3D(lineArray);
            ShapeManager.setCapabilities(shape, null);
            branch.addChild(shape);
        }
    }
}
