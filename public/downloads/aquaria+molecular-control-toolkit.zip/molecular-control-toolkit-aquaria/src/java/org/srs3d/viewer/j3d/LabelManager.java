/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;

import javax.media.j3d.ImageComponent2D;
import javax.vecmath.Color3f;
import javax.vecmath.Color4f;

/**
 * Produces and manages label bitmaps.
 *
 * @author Christian Zofka
 *
 * @created August 1, 2001
 * @modified Karsten Fries, LION bioscience AG
 * @modified January 09, 2002
 * @reviewed January 09, 2002
 */
public class LabelManager {
    private static int outlineWidth = 1;
    private static Font font = new Font("Arial", java.awt.Font.PLAIN, 10);
    private static FontMetrics fontMetrics =
        new BufferedImage(1, 1, BufferedImage.TYPE_4BYTE_ABGR).getGraphics()
                                                              .getFontMetrics(font);
    private Map labelHash = new Hashtable();
    private Color defaultOutlineColor = null;

    /**
     * Gets the <code>label</code> attribute of the <code>LabelManager</code> object.
     *
     * @param object Description of parameter.
     *
     * @return The <code>label</code> value.
     */
    public ImageComponent2D getLabel(Object object) {
        return getLabel(object, new Color(0f, 0f, 0f, 1f));
    }

    /**
     * Gets the <code>label</code> attribute of the <code>LabelManager</code> object.
     *
     * @param object Description of parameter.
     * @param color Description of parameter.
     *
     * @return The <code>label</code> value.
     */
    public ImageComponent2D getLabel(Object object, Color color) {
        String string = object.toString() + color.toString();
        ImageComponent2D image = (ImageComponent2D) labelHash.get(string);
        if (image == null) {
            image = createLabel(object.toString(), color);
            labelHash.put(string, image);
        }
        return image;
    }

    /**
     * Gets the <code>label</code> attribute of the <code>LabelManager</code> object.
     *
     * @param object Description of parameter.
     * @param color Description of parameter.
     * @param isCentered Description of parameter.
     *
     * @return The <code>label</code> value.
     */
    public ImageComponent2D getLabel(Object object, Color color,
        boolean isCentered, Color outlineColor) {
        String string = object.toString() + color.toString() + isCentered;
        ImageComponent2D image = (ImageComponent2D) labelHash.get(string);
        if (image == null) {
            image =
                createLabel(object.toString(), color, isCentered, outlineColor);
            labelHash.put(string, image);
        }
        return image;
    }

    /**
     * Description of the method.
     *
     * @param object Description of parameter.
     */
    public void remove(Object object) {
        labelHash.remove(object);
    }

    /**
     * Description of the method.
     */
    public void clear() {

        // FIXME why so complicated?
        Iterator iterator = labelHash.keySet().iterator();
        while (iterator.hasNext()) {
            iterator.next();
            iterator.remove();
        }
    }

    /**
     * Description of the method.
     *
     * @param string Description of parameter.
     * @param color Description of parameter.
     *
     * @return Description of the returned value.
     */
    private ImageComponent2D createLabel(String string, Color color) {
        int width = fontMetrics.stringWidth(string) + 2 * outlineWidth - 1;
        int height = fontMetrics.getHeight() + 2 * outlineWidth;

        // make width and height the power of 2
        int widthPower2 = ImageHelper.computeNextPowerOf2(width);
        int heightPower2 = ImageHelper.computeNextPowerOf2(height);

        // update buffered image with appropriate size
        BufferedImage image =
            new BufferedImage(widthPower2, heightPower2,
                BufferedImage.TYPE_INT_ARGB);
        Graphics graphics = image.createGraphics();
        graphics.setFont(font);

        // First, erase the background to the text panel - set alpha to 0
        Color fillColor = new Color(0f, 0f, 0f, 0f);
        graphics.setColor(fillColor);
        graphics.fillRect(0, 0, heightPower2, heightPower2);
        drawString(string, 0, 0, graphics, color, defaultOutlineColor);
        ImageComponent2D imageComponent =
            new ImageComponent2D(ImageComponent2D.FORMAT_RGBA, image);
        imageComponent.setCapability(ImageComponent2D.ALLOW_SIZE_READ);
        return imageComponent;
    }

    /**
     * Description of the method.
     *
     * @param string Description of parameter.
     * @param color Description of parameter.
     * @param isCentered Description of parameter.
     *
     * @return Description of the returned value.
     */
    private ImageComponent2D createLabel(String string, Color color,
        boolean isCentered, Color outlineColor) {
        int width = fontMetrics.stringWidth(string) + 2 * outlineWidth - 1;
        int height = fontMetrics.getHeight() + 2 * outlineWidth;
        if (width < 10) {
            width = 10;
        }

        // make width and height the power of 2
        int widthPower2 = ImageHelper.computeNextPowerOf2(width);
        int heightPower2 = ImageHelper.computeNextPowerOf2(height);
        BufferedImage image =
            new BufferedImage(widthPower2, heightPower2,
                BufferedImage.TYPE_INT_ARGB);
        Graphics graphics = image.createGraphics();
        graphics.setFont(font);

        // First, erase the background to the text panel - set alpha to 0
        Color fillColor = new Color(0f, 0f, 0f, 0f);
        graphics.setColor(fillColor);
        graphics.fillRect(0, 0, widthPower2, heightPower2);
        int stringWidth = graphics.getFontMetrics().stringWidth(string);
        int offset = 0;
        if (isCentered) {
            offset = (width - stringWidth) / 2;
        }
        drawString(string, offset, 0, graphics, color, outlineColor);
        ImageComponent2D imageComponent =
            new ImageComponent2D(ImageComponent2D.FORMAT_RGBA, image);
        imageComponent.setCapability(ImageComponent2D.ALLOW_SIZE_READ);
        return imageComponent;
    }

    /**
     * Description of the method.
     *
     * @param string Description of parameter.
     * @param offsetX Horizontal offset in graphics coordinates.
     * @param offsetY Vertical offset in graphics coordinates.
     * @param graphics Description of parameter.
     * @param color Description of parameter.
     */
    public void drawString(String string, int offsetX, int offsetY,
        Graphics graphics, Color color, Color outlineColor) {

        // :FIXME: replace this number with some font property
        int stringOffset = 10 + offsetY;

        //    if ( outlineColor != null ) {
        //    
        ////      graphics.setColor(outlineColor);
        //        graphics.setColor(Color.BLACK);
        //	
        //	    for (int i = -outlineWidth; i <= outlineWidth; i++) {
        //	
        //	      for (int j = -outlineWidth; j <= outlineWidth; j++) {
        //	
        //	        graphics.drawString(string, offsetX + i, stringOffset + j);
        //	
        //	      }
        //	
        //	    }
        //	    
        //    }
        graphics.setColor(color);
        graphics.drawString(string, offsetX, stringOffset);

        //    graphics.drawLine(0,0, 30, 40);
    }

    /**
     * Draws a horizontally centered string.
     *
     * @param string Description of parameter.
     * @param graphics Description of parameter.
     * @param color Description of parameter.
     * @param width Width to base centering on.
     */
    public void drawString(String string, Graphics graphics, Color color,
        int width) {
        int stringWidth = graphics.getFontMetrics().stringWidth(string);
        int offset = (width - stringWidth - 2 * outlineWidth) / 2;
        drawString(string, offset, 0, graphics, color, defaultOutlineColor);
    }

    /**
     * Method description.
     *
     * @param color Parameter description.
     * @param offset Parameter description.
     *
     * @return Return description.
     */
    public static final Color convertColor(Color color, Color offset) {
        color =
            new Color(Math.min(255, color.getRed() + offset.getRed()),
                Math.min(255, color.getGreen() + offset.getGreen()),
                Math.min(255, color.getBlue() + offset.getBlue()),
                Math.min(255, color.getAlpha() + offset.getAlpha()));
        return color;
    }

    /**
     * Method description.
     *
     * @param color Parameter description.
     * @param alpha Parameter description.
     *
     * @return Return description.
     */
    public static final Color convertColor(Color color, float alpha) {
        Color4f c = new Color4f(color);
        c.w = alpha;
        c.clamp(0, 1);
        return c.get();
    }

    /**
     * Method description.
     *
     * @param color Parameter description.
     * @param alpha Parameter description.
     *
     * @return Return description.
     */
    public static final Color convertColor(Color3f color, float alpha) {
        Color4f c = new Color4f(color.x, color.y, color.z, alpha);
        c.clamp(0, 1);
        return c.get();
    }

    /**
     * Method description.
     *
     * @param color Parameter description.
     */
    public void setDefaultOutlineColor(Color color) {
        this.defaultOutlineColor = color;
    }
}
