/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.modules;

import java.awt.Component;
import java.awt.event.ActionEvent;

import javax.swing.JOptionPane;

import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.Contextual;
import org.srs3d.viewer.j3d.behaviors.KeyHandler;
import org.srs3d.viewer.objects.Operation;
import org.srs3d.viewer.swing.ComponentFactory;
import org.srs3d.viewer.util.ExceptionHandler;

/**
 * Abstract <code>Module</code> implementation for <code>Module</code>s that take a
 * longer time to execute.
 *
 * @author Karsten Klein
 *
 * @created May 14, 2001
 */
public abstract class ProcessModule extends AbstractModule implements Runnable,
    Contextual {
    public static final String LOW_MEMORY_WARNING_TITLE =
        "Out of memory exception";
    public static final String LOW_MEMORY_WARNING =
        "This operation requires too much memory. Please contact your\r\n" +
        "system administrator to increase the heap size of your Java Virtual Machine.";

    /** Description of the field. */
    public static boolean IS_THREADED = true;
    private ActionEvent actionEvent = null;
    private boolean isThreaded = true;
    private boolean hasProgressDisplay = true;
    private transient ProcessModuleComputation computation = null;

    /**
     * <code>ProcessModule</code> constructor.
     *
     * @param name Description of parameter.
     * @param contextData Description of parameter.
     */
    public ProcessModule(String name, ContextData contextData) {
        this(name, contextData, true, false);
    }

    /**
     * <code>ProcessModule</code> constructor.
     *
     * @param name Description of parameter.
     * @param contextData Description of parameter.
     * @param threaded Description of parameter.
     * @param hasProgressDisplay Description of parameter.
     */
    public ProcessModule(String name, ContextData contextData,
        boolean threaded, boolean hasProgressDisplay) {
        super(name, contextData);
        this.setThreaded(threaded);
        this.hasProgressDisplay = hasProgressDisplay;
        register(contextData.getDispatcher());
    }

    /**
     * Sets the <code>threaded</code> attribute of the <code>ProcessModule</code> object.
     *
     * @param isThreaded The new <code>threaded</code> value.
     */
    public void setThreaded(boolean isThreaded) {
        this.isThreaded = isThreaded;
    }

    /**
     * Gets the <code>canceled</code> attribute of the <code>ProcessModule</code> object.
     *
     * @return The <code>canceled</code> value.
     */
    public boolean isCanceled() {
        if (computation != null) {
            return computation.isCanceled();
        }
        return false;
    }

    /**
     * Description of the method.
     *
     * @param e Description of parameter.
     */
    public void preActionPerformed(ActionEvent e) {
        KeyHandler.getKeyHandler(getContextData()).setWaitCursor();
    }

    /**
     * Description of the method.
     *
     * @param e Description of parameter.
     */
    public void react(ActionEvent e) {
        KeyHandler.getKeyHandler(getContextData()).reset();
        if (!canProcess()) {
            Operation operation =
                new Operation(getContextData().getContext(), "CANCEL", null);
            operation.setSerializable(true);
            getContextData().getDispatcher().runDispatch(operation);
            return;
        }
        computation = createComputation();
        computation.setFinished(false);
        try {
            this.actionEvent = e;

            // initialize computation before calling the run() method
            computation.setDescription("Processing...");
            if (isThreaded && IS_THREADED) {
                final Thread thread = new Thread(this, this.toString());

                // priority reduction by 0: swing dialog doesn't put up; seems to stall
                //   the system
                // priority reduction by 1: swing dialog pops up, interaction responsive
                // priority reduction by 2: swing dialog pops up, interaction (espectially)
                //   when spinning the structure) not responsive
                // priority reduction to min: JDK 1.4.0 is more responsive
                //        thread.setPriority( Math.max( thread.getPriority() - 1, Thread.MIN_PRIORITY ) );
                thread.setPriority(Thread.MIN_PRIORITY);
                thread.start();
                if (hasProgressDisplay) {
                    org.srs3d.viewer.swing.ComponentFactory.progressDialog("",
                        (Component) getContextData().getProperty("DialogComponent"),
                        computation, getContextData().getContext());
                }
            } else {
                run();
            }
        } catch (Exception ex) {
            ExceptionHandler.handleException(ex, this);
            computation.setFinished(true);
        }
    }

    /**
     * Description of the method.
     *
     * @param e Description of parameter.
     */
    public void postActionPerformed(ActionEvent e) {
        KeyHandler.getKeyHandler(getContextData()).restoreCursor();
    }

    /**
     * Main processing method for the <code>ProcessModule</code> object.
     */
    public void run() {
        try {
            if (isThreaded && IS_THREADED) {
                try {
                    Thread.sleep(50);
                } catch (InterruptedException e) {

                    // :SILENT EXCEPTION:
                }
            }
            getContextData().setProperty("EXCEPTION", null);
            preActionPerformed(actionEvent);
            try {
                process(actionEvent);
            } catch (Exception e) {
                ExceptionHandler.handleException(e,
                    ExceptionHandler.VISIBLE_IN_RELEASE, this);
            }
            postActionPerformed(actionEvent);
            if (isThreaded && IS_THREADED) {
                getContextData().getContext().waitForUpdate();
                Thread.yield();
                Throwable t =
                    (Throwable) getContextData().getProperty("EXCEPTION");
                if (t != null) {
                    ComponentFactory.messageDialog(getContextData().getContext(),
                        LOW_MEMORY_WARNING, LOW_MEMORY_WARNING_TITLE,
                        JOptionPane.WARNING_MESSAGE, null);
                    computation.cancel();
                }
            }
        } catch (Exception e) {
            ExceptionHandler.handleException(e,
                ExceptionHandler.VISIBLE_IN_RELEASE, this);
        }
        getComputation().setFinished(true);
        if (computation.isCanceled()) {
            getContextData().setProperty("COMPUTATION_STATE", "CANCELED");
            Operation operation =
                new Operation(getContextData().getContext(), "CANCEL", null);
            operation.setSerializable(true);
            getContextData().getDispatcher().runDispatch(operation);
        }
    }

    /**
     * Description of the method.
     *
     * @param e Description of parameter.
     */
    public abstract void process(ActionEvent e);

    /**
     * Description of the method.
     *
     * @return Description of the returned value.
     */
    private ProcessModuleComputation createComputation() {
        computation =
            (ProcessModuleComputation) getContextData().getProperty("ProcessModuleComputation");
        if (computation == null) {
            computation = new ProcessModuleComputation();
            getContextData().setProperty("ProcessModuleComputation", computation);
        }
        computation.setDescription("Processing...");
        return computation;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public ProcessModuleComputation getComputation() {
        if (computation == null) {
            createComputation();
        }
        return computation;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public boolean canProcess() {

        // empty defaul impl.
        return true;
    }
}
