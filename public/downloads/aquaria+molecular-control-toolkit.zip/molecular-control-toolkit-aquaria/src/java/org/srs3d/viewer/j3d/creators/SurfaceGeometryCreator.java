/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.creators;

import java.util.Collection;
import java.util.Iterator;

import javax.media.j3d.BranchGroup;
import javax.media.j3d.GeometryArray;
import javax.media.j3d.LineArray;
import javax.media.j3d.Shape3D;
import javax.media.j3d.TriangleArray;

import org.srs3d.viewer.j3d.ShapeManager;
import org.srs3d.viewer.j3d.geometry.GeometryHelper;
import org.srs3d.viewer.j3d.objects.Surface;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.visualization.Point;
import org.srs3d.viewer.visualization.Triangle;

/**
 * Description of the class.
 *
 * @author Karsten Klein
 *
 * @created March 20, 2001
 */
public class SurfaceGeometryCreator extends AbstractGeometryCreator {

    /** Description of the Field */
    public static int GEOMETRY = 1;
    public static int NORMALS = 2;

    /** Description of the Field */
    public int surfaceMode = GEOMETRY;

    /**
     * Description of the method.
     *
     * @param object Description of parameter.
     * @param branchGroup Description of parameter.
     */
    public void create(AbstractObject object, BranchGroup branchGroup) {
        create((Surface) object, branchGroup);
    }

    /**
     * Description of the method.
     *
     * @param surface Description of parameter.
     * @param branchGroup Description of parameter.
     */
    public void create(Surface surface, BranchGroup branchGroup) {
        if ((surfaceMode & GEOMETRY) != 0) {
            createGeometry(surface, branchGroup);
        }
        if ((surfaceMode & NORMALS) != 0) {
            createNormalGeometry(surface, branchGroup);
        }
    }

    /**
     * Description of the method.
     *
     * @param surface Description of parameter.
     * @param branchGroup Description of parameter.
     */
    public void createGeometry(Surface surface, BranchGroup branchGroup) {
        Collection triangles = surface.getTriangles();
        if (triangles != null && !triangles.isEmpty()) {
            TriangleArray triangleArray =
                GeometryHelper.getDefaultTriangleArray(triangles.size(),
                    GeometryArray.COLOR_4);
            Iterator iterator = triangles.iterator();
            Triangle triangle;
            Point[] points;
            int index = 0;
            while (iterator.hasNext()) {
                triangle = (Triangle) iterator.next();
                points = triangle.getPoints();
                triangleArray.setCoordinate(3 * index, points[0].getCoordinate());
                triangleArray.setCoordinate(3 * index + 1,
                    points[1].getCoordinate());
                triangleArray.setCoordinate(3 * index + 2,
                    points[2].getCoordinate());
                triangleArray.setNormal(3 * index, points[0].getNormal());
                triangleArray.setNormal(3 * index + 1, points[1].getNormal());
                triangleArray.setNormal(3 * index + 2, points[2].getNormal());
                triangleArray.setColor(3 * index, points[0].getColor());
                triangleArray.setColor(3 * index + 1, points[1].getColor());
                triangleArray.setColor(3 * index + 2, points[2].getColor());
                index++;

                // :FIXME: replace this by converting the triangles before drawing and
                // using by reference
                //        iterator.remove();
            }
            Shape3D shape = new Shape3D(triangleArray);
            ShapeManager.setCapabilities(shape, surface);
            getContextData().getShapeManager().register(surface, shape);
            branchGroup.addChild(shape);
        }
    }

    /**
     * Method description.
     *
     * @param surface Parameter description.
     * @param branchGroup Parameter description.
     */
    public void createNormalGeometry(Surface surface, BranchGroup branchGroup) {
        Collection triangles = surface.getTriangles();
        if (triangles != null && !triangles.isEmpty()) {
            LineArray lineArray =
                GeometryHelper.getDefaultLineArray(triangles.size() * 3,
                    GeometryArray.COLOR_4);
            Iterator iterator = triangles.iterator();
            Triangle triangle;
            Point[] points;
            javax.vecmath.Point3f p;
            int index = 0;
            while (iterator.hasNext()) {
                triangle = (Triangle) iterator.next();
                points = triangle.getPoints();
                for (int i = 0; i < 3; i++) {
                    p = points[i].getCoordinate();
                    lineArray.setCoordinate(2 * index, p);
                    p = new javax.vecmath.Point3f(p);
                    p.add(points[i].getNormal());
                    lineArray.setCoordinate(2 * index + 1, p);
                    lineArray.setColor(2 * index, points[i].getColor());
                    lineArray.setColor(2 * index + 1, points[i].getColor());
                    index++;
                }
            }
            Shape3D shape = new Shape3D(lineArray);
            ShapeManager.setCapabilities(shape, surface);

            //      getContextData().getShapeManager().register( surface, shape );
            branchGroup.addChild(shape);
        }
    }
}
