/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.annotation.objects;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Vector;

import org.srs3d.viewer.objects.AbstractObject;

/**
 * Alignment object.
 *
 * @author Christian Zofka
 *
 * @created June 26, 2001
 */
public final class Alignment extends AbstractObject {

    /** needed for the layoutdesign: structure, sequence, annotations */
    public static final int DEFAULT = 1;

    /** needed for the layoutdesign: annotations, sequence, structure */
    public static final int FLIPPED = 2;
    private Vector chainAnnotations = new Vector();
    private Vector annotationUnits = new Vector();
    private Vector rulers = new Vector();
    private Vector layers = null;
    private int layout = FLIPPED;

    // contains a mapping from AnnotationUnits to ChainAnnotations
    private Map annotationUnitMap = new HashMap();
    private Map rulersMap = new HashMap();
    private int length = -1;

    /**
     * Sets the <code>layout</code> attribute of the <code>Alignment</code> object.
     *
     * @param nr The new <code>layout</code> value.
     */
    public void setLayoutMode(int nr) {
        layout = nr;
    }

    /**
     * Method description.
     *
     * @param units Parameter description.
     */
    public void setAnnotationUnits(Vector units) {
        annotationUnits = units;
    }

    /**
     * Gets the <code>Length</code> attribute of the <code>Annotation</code> object.
     *
     * @return The <code>Length</code> value.
     */
    public int getLength() {
        return length;
    }

    /**
     * Gets the <code>size</code> attribute of the <code>Alignment</code> object.
     *
     * @return The <code>size</code> value.
     */
    public int getSize() {
        return getLayers().size() + annotationUnits.size();
    }

    /**
     * Gets the <code>ChainCount</code> attribute of the <code>Annotation</code> object.
     *
     * @return The <code>ChainCount</code> value.
     */
    public int getChainAnnotationCount() {
        return chainAnnotations.size();
    }

    /**
     * Gets the <code>layout</code> attribute of the <code>Alignment</code> object.
     *
     * @return The <code>layout</code> value.
     */
    public int getLayoutMode() {
        return layout;
    }

    /**
     * Gets the <code>rulers</code> attribute of the <code>Alignment</code> object.
     *
     * @return The <code>rulers</code> value.
     */
    public Collection getRulers() {
        return rulers;
    }

    /**
     * Gets the <code>rulersMap</code> attribute of the <code>Alignment</code> object.
     *
     * @return The <code>rulersMap</code> value.
     */
    public Map getRulersMap() {
        return rulersMap;
    }

    //  /**
    //   *  Gets the <code>height</code> attribute of the <code>Alignment</code>
    //   *  object.
    //   *
    //   * @return    The <code>height</code> value.
    //   */
    //  public float getHeight2() {
    //
    //    float height = Parameter.chainAnnotationHeight * chainAnnotations.size();
    //    height += Parameter.annotationUnitHeight * annotationUnits.size();
    //
    //    if ( getLayoutMode() == DEFAULT || getLayoutMode() == FLIPPED ) {
    //
    //      if ( annotationUnits.size() > 0 ) {
    //
    //        height += Parameter.voidHeight;
    //
    //      }
    //
    //      height += Parameter.rulerHeight * 2;
    //      height += Parameter.voidHeight;
    //
    //    }
    //
    //    return height;
    //  }

    /**
     * Gets the <code>AllObjects</code> attribute of the <code>Annotation</code> object.
     *
     * @param collection Description of parameter.
     */
    public void getAllObjects(Collection collection) {
        Iterator iterator = chainAnnotations.iterator();
        Object object;
        while (iterator.hasNext()) {
            object = iterator.next();
            if (object != null) {
                collection.add(object);
            }
        }
        iterator = annotationUnits.iterator();
        while (iterator.hasNext()) {
            object = iterator.next();
            if (object != null) {
                collection.add(object);
            }
        }
        collection.addAll(getRulers());
    }

    /**
     * Gets the <code>Chains</code> attribute of the <code>Annotation</code> object.
     *
     * @return The <code>Chains</code> value.
     */
    public Vector getChainAnnotations() {
        return chainAnnotations;
    }

    /**
     * Gets the <code>annotations</code> attribute of the <code>Alignment</code> object.
     *
     * @return The <code>annotations</code> value.
     */
    public Vector getAnnotationUnits() {
        return annotationUnits;
    }

    /**
     * Gets the <code>first</code> attribute of the <code>Alignment</code> object.
     *
     * @return The <code>first</code> value.
     */
    public ChainAnnotation getFirst() {
        ChainAnnotation chainAnnotation;
        Iterator iterator = getChainAnnotations().iterator();
        while (iterator.hasNext()) {
            chainAnnotation = (ChainAnnotation) iterator.next();
            if (chainAnnotation != null) {
                return chainAnnotation;
            }
        }
        return null;
    }

    /**
     * Gets the <code>last</code> attribute of the <code>Alignment</code> object.
     *
     * @return The <code>last</code> value.
     */
    public ChainAnnotation getLast() {
        ChainAnnotation chainAnnotation;
        ChainAnnotation returnChain = null;
        Iterator iterator = getChainAnnotations().iterator();
        while (iterator.hasNext()) {
            chainAnnotation = (ChainAnnotation) iterator.next();
            if (chainAnnotation != null) {
                returnChain = chainAnnotation;
            }
        }
        return returnChain;
    }

    /**
     * Gets the <code>empty</code> attribute of the <code>Alignment</code> object.
     *
     * @return The <code>empty</code> value.
     */
    public boolean isEmpty() {
        return getChainAnnotations().isEmpty();
    }

    /**
     * Gets the <code>Position</code> attribute of the <code>Annotation</code> object.
     *
     * @param chainAnnotation Description of parameter.
     *
     * @return The <code>Position</code> value.
     */
    public int getYPosition(ChainAnnotation chainAnnotation) {
        Iterator iterator = getChainAnnotations().iterator();
        ChainAnnotation candidate;
        int position = 0;
        while (iterator.hasNext()) {
            candidate = (ChainAnnotation) iterator.next();
            if (candidate != chainAnnotation) {
                position += 1;
            } else {
                return position;
            }
        }
        return -1;
    }

    /**
     * Gets the <code>annotationUnitMap</code> attribute of the <code>Alignment</code>
     * object.
     *
     * @return The <code>annotationUnitMap</code> value.
     */
    public Map getAnnotationUnitMap() {
        return annotationUnitMap;
    }

    /**
     * Description of the method.
     */
    public void cleanup() {
        super.cleanup();
        cleanup(chainAnnotations);
        chainAnnotations = null;
        cleanup(annotationUnits);
        annotationUnits = null;
        cleanup(rulers);
        rulers = null;
        cleanup(layers);
        layers = null;
        cleanup(annotationUnitMap);
        annotationUnitMap = null;
        cleanup(rulersMap);
        rulersMap = null;
    }

    /**
     * Description of the method.
     */
    public void update() {

        // find the length of the longest annotated chain
        Iterator iterator = getChainAnnotations().iterator();
        ChainAnnotation chainAnnotation;
        length = 0;
        while (iterator.hasNext()) {
            chainAnnotation = (ChainAnnotation) iterator.next();
            if (chainAnnotation != null) {
                chainAnnotation.update();
                if (length < chainAnnotation.getLength()) {
                    length = chainAnnotation.getLength();
                }
            }
        }
    }

    /**
     * Description of the method.
     *
     * @param chainAnnotation Description of parameter.
     */
    public void addChain(ChainAnnotation chainAnnotation) {
        getChainAnnotations().add(chainAnnotation);
    }

    /**
     * Adds a <code>Annotation</code> object to the <code>Alignment</code> object.
     *
     * @param annotationUnit The <code>Annotation</code> object to be added.
     */
    public void addAnnotationUnit(AnnotationUnit annotationUnit) {
        getAnnotationUnits().add(annotationUnit);
    }

    /**
     * Description of the method.
     *
     * @param annotationUnit Description of parameter.
     *
     * @return Description of the returned value.
     */
    public ChainAnnotation findChainAnnotation(AnnotationUnit annotationUnit) {
        return (ChainAnnotation) annotationUnitMap.get(annotationUnit);
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public Vector getLayers() {
        return layers;
    }

    /**
     * Method description.
     *
     * @param layers Parameter description.
     */
    public void setLayers(Vector layers) {
        this.layers = layers;
    }
}
