/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.annotation.visitors;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Vector;

import org.srs3d.viewer.annotation.objects.Alignment;
import org.srs3d.viewer.annotation.objects.AnnotationContainer;
import org.srs3d.viewer.annotation.objects.ChainAnnotation;
import org.srs3d.viewer.annotation.objects.Segment;
import org.srs3d.viewer.bioatlas.filters.CAResidueFilter;
import org.srs3d.viewer.bioatlas.objects.Chain;
import org.srs3d.viewer.bioatlas.objects.ChainFragment;
import org.srs3d.viewer.bioatlas.objects.Layer;
import org.srs3d.viewer.bioatlas.objects.Residue;
import org.srs3d.viewer.bioatlas.objects.Section;
import org.srs3d.viewer.bioatlas.objects.Subchain;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.objects.ObjectContainer;
import org.srs3d.viewer.objects.ObjectFilter;
import org.srs3d.viewer.objects.ObjectManager;
import org.srs3d.viewer.objects.filters.ObjectClassFilter;
import org.srs3d.viewer.objects.visitors.AbstractVisitor;
import org.srs3d.viewer.objects.visitors.ObjectCollector;
import org.srs3d.viewer.util.Log;
import org.srs3d.viewer.util.SetUtility;

/**
 * creates the aligned annotation (with gaps); it uses the old AnnotationContainerCreator
 * to initialize the reference layer; this annotation will be modified and filled up
 * with the new aligned chains; makes segments, chainAnnotations, Alignments,
 * AnnotationContainer
 *
 * @author Christian Zofka
 *
 * @created June 27, 2001
 * @modified Dec 07, 2001
 *
 * @todo refactore this class, there should be 2-3 instead of 1 big
 * @since 1.0
 */
public class GapAnnotationCreator extends AbstractVisitor {
    private static final Log log = new Log(GapAnnotationCreator.class);
    private AnnotationContainer annotationContainer = null;

    /** Externally provided map with layer alignments */
    private Map layerAlignmentMap = new HashMap();

    /** Set of layer information computed and used during annotation creation. */
    private HashMap layerInformationMap = new HashMap();

    /** all layers: reference + template */
    private Vector layers = new Vector();

    /** Template layer list; produced during creation. */
    private transient Vector templates = null;

    /** Referenc to the reference layer. */
    private Layer referenceLayer = null;

    /** counting the recursionlevel */
    private int iterationLevel = 0;

    /**
     * Sets the <code>layerAlignmentMap</code> attribute of the
     * <code>GapAnnotationCreator</code> object.
     *
     * @param layerAlignmentMap The new <code>layerAlignmentMap</code> value.
     */
    public void setLayerAlignmentMap(Map layerAlignmentMap) {
        this.layerAlignmentMap = layerAlignmentMap;
    }

    /**
     * Sets the <code>iterationLevel</code> attribute of the
     * <code>GapAnnotationCreator</code> object.
     *
     * @param level The new <code>iterationLevel</code> value.
     */
    public void setIterationLevel(int level) {
        iterationLevel = level;
    }

    /**
     * Gets the <code>annotationContainer</code> attribute of the <code>GapCreator</code>
     * object.
     *
     * @return The <code>annotationContainer</code> value.
     */
    public AnnotationContainer getAnnotationContainer() {
        return annotationContainer;
    }

    /**
     * Gets the <code>iterationLevel</code> attribute of the
     * <code>GapAnnotationCreator</code> object.
     *
     * @return The <code>iterationLevel</code> value.
     */
    public int getIterationLevel() {
        return iterationLevel;
    }

    /**
     * keymethod to create the annotationContainer; because of the alignment we perform
     * we need all layers at once to build the annotationContainer; this method also
     * needs the old annotationCreator that now is called AnnotationContainerCreator
     *
     * @param objectContainer contains layers of all proteins/sequences
     */
    public void visit(ObjectContainer objectContainer) {
        if (getAnnotationContainer() == null) {
            initializeReference(objectContainer);
        }
        if (getAnnotationContainer() != null) {
            initializeTemplates(objectContainer);

            // we can release all the ca atom information now
            // at this stage all chains are converted into segment chain annotations
            // and the respective alignment maps are build
            layers.add(referenceLayer);
            int sequenceCount = 0;

            // define ordering (sequences go first; then reference, then aligned)
            if (templates != null) {
                Iterator iterator = templates.iterator();
                Layer templateLayer;
                LayerInformation layerInformation;
                while (iterator.hasNext()) {
                    templateLayer = (Layer) iterator.next();
                    if (templateLayer.isSequenceLayer()) {
                        layers.insertElementAt(templateLayer, sequenceCount++);
                    } else {
                        layerInformation =
                            (LayerInformation) layerInformationMap.get(templateLayer);
                        if (!layerInformation.chainAnnotations.isEmpty()) {
                            layers.add(templateLayer);
                        }
                    }
                }
            }
            annotationContainer.createAlignmentMap();
            Iterator iterator;
            Vector referenceSequence = null;
            Iterator alignmentIterator =
                annotationContainer.getAlignments().iterator();
            Alignment alignment;
            boolean isAnyMerged = false;
            int merged = 0;
            int notMerged = 0;

            // start gapcalculation and gapsegmentcreation for each chain of the reference protein
            while (alignmentIterator.hasNext()) {
                alignment = (Alignment) alignmentIterator.next();
                alignment.setLayers(layers);
                Chain referenceChain = alignment.getFirst().getChain();

                // create sequence for reference chain
                SequenceCreator sequenceCreator = new SequenceCreator();
                sequenceCreator.visit(referenceChain);
                referenceSequence = sequenceCreator.getSequence();

                // create alignment to reference chain
                SequenceAlignmentCreator sequenceAlignmentCreator =
                    new SequenceAlignmentCreator(referenceLayer,
                        referenceSequence, layerAlignmentMap, templates);
                sequenceAlignmentCreator.alignSequences();
                referenceSequence =
                    sequenceAlignmentCreator.getReferenceSequence();

                // debug output (aligned sequences in that alignment)
                //        SequenceAlignmentCreator.dumpSequence( referenceSequence );
                //        sequenceAlignmentCreator.dumpAlignedSequences();
                ChainAnnotation chainAnnotation;
                iterator = alignment.getChainAnnotations().iterator();
                if (iterator.hasNext()) {
                    chainAnnotation = (ChainAnnotation) iterator.next();

                    // create REFERENCE chainAnnotation
                    GapChainAnnotationCreator gapChainAnnotationCreator;
                    LayerInformation information =
                        (LayerInformation) layerInformationMap.get(referenceLayer);
                    Collection referenceSegments =
                        new Vector(information.segments);
                    gapChainAnnotationCreator =
                        new GapChainAnnotationCreator(information.segments);
                    Collection segments =
                        gapChainAnnotationCreator.createSegments(referenceSequence);
                    chainAnnotation.getSegments().clear();
                    chainAnnotation.getSegments().addAll(segments);
                    chainAnnotation.setGapSequence(referenceSequence);
                    chainAnnotation.setName(referenceLayer.getId());

                    // create TEMPLATE chainAnnotations from templateSequences
                    Iterator templateIterator = templates.iterator();
                    Layer templateLayer;
                    Vector sequence;

                    // allow only one pair to be merged in this alignment
                    boolean isMerged = false;
                    boolean isThisMerged = false;
                    Collection templateSegments;
                    while (templateIterator.hasNext()) {
                        templateLayer = (Layer) templateIterator.next();
                        information =
                            (LayerInformation) layerInformationMap.get(templateLayer);
                        isThisMerged = false;
                        sequence =
                            sequenceAlignmentCreator.getSequence(templateLayer);
                        if (sequence != null) {

                            // trying to MERGE
                            if (!isMerged && referenceLayer.isMergeable() &&
                                  templateLayer.isMergeable() &&
                                  mergeSequences(referenceSequence, sequence)) {
                                information.segments.addAll(segments);
                                gapChainAnnotationCreator =
                                    new GapChainAnnotationCreator(information.segments);
                                templateSegments =
                                    gapChainAnnotationCreator.createSegments(sequence);

                                // remove sequence chain annotation
                                alignment.getChainAnnotations().remove(chainAnnotation);
                                isMerged = true;
                                merged++;
                                isAnyMerged = true;
                                isThisMerged = true;
                            } else {
                                gapChainAnnotationCreator =
                                    new GapChainAnnotationCreator(information.segments);
                                templateSegments =
                                    gapChainAnnotationCreator.createSegments(sequence);
                                if (!isMerged) {
                                    notMerged++;
                                }
                            }
                            ChainAnnotation templateChain =
                                new ChainAnnotation(null);
                            templateChain.getSegments().addAll(templateSegments);
                            templateChain.setGapSequence(sequence);

                            //              templateChain.setName( templateLayer );
                            registerChains(templateLayer, templateChain);
                            if (isThisMerged) {
                                templateChain.getChains().addAll(chainAnnotation.getChains());

                                // use this for a safer check
                                // registerChains( referenceLayer, templateChain );
                            }
                            alignment.addChain(templateChain);
                        }
                    }
                }

                // remove reference layer if it's completely merged
                if (merged > 0 && notMerged == 0) {
                    layers.remove(referenceLayer);
                }
                alignment.update();
            }
            LayerInformation information =
                (LayerInformation) layerInformationMap.get(referenceLayer);
            if (!information.segments.isEmpty()) {
                log.error("unused segments in reference chain " +
                    information.segments);
            }

            // add the NONALIGNED chains
            addNonAlignedChains();

            // old_addNonAlignedChains();
            // add ANNOTATIONUNITS
            if (getIterationLevel() == 0) {
                AnnotationUnitCreator annotationUnitCreator =
                    new AnnotationUnitCreator(annotationContainer, isAnyMerged);
                annotationUnitCreator.visit(objectContainer);
            }
        } else {
            log.error("no annotation container for creating geometry.");
        }
    }

    /**
     * Description of the method.
     *
     * @param object abstractObject
     */
    public void visit(AbstractObject object) {
        if (object instanceof ObjectContainer) {
            super.visit((ObjectContainer) object);
        }
    }

    /**
     * performing recursivly subAligning with the nonaligned chains
     */
    private void addNonAlignedChains() {

        // create sub container
        ObjectContainer subObjectContainer = new ObjectContainer();
        LayerInformation information;
        Layer layer;
        Layer newLayer;
        Collection segments;
        Collection objects = new HashSet();
        GapChainAnnotationCreator gapChainAnnotationCreator;

        // copy layers to subcontainer
        Iterator iterator = templates.iterator();
        while (iterator.hasNext()) {
            layer = (Layer) iterator.next();

            // setting newLayer variables
            newLayer = new Layer();
            subObjectContainer.getAllObjects(objects);
            if (objects.isEmpty()) {
                newLayer.setTemplate(false);
            } else {
                newLayer.setTemplate(true);
            }
            newLayer.setSequenceLayer(layer.isSequenceLayer());
            newLayer.setImposed(layer.isImposed());
            newLayer.setMergeable(layer.isMergeable());

            // fill up newLayer with chains
            ChainAnnotation chainAnnotation;
            information = (LayerInformation) layerInformationMap.get(layer);
            Iterator chainAnnotationIterator =
                information.chainAnnotations.iterator();
            while (chainAnnotationIterator.hasNext()) {
                chainAnnotation =
                    (ChainAnnotation) chainAnnotationIterator.next();
                if (SetUtility.hasIntersection(chainAnnotation.getSegments(),
                          information.segments)) {
                    newLayer.addAll(chainAnnotation.getChains());
                }
            }
            objects.clear();
            newLayer.getAllObjects(objects);
            if (!objects.isEmpty()) {
                subObjectContainer.addObject(newLayer);
            }
        }

        // perform subAlignment with a new instance of GapAnnotationCreator
        objects.clear();
        subObjectContainer.getAllObjects(objects);
        if (!objects.isEmpty()) {
            GapAnnotationCreator childCreator = new GapAnnotationCreator();
            childCreator.setIterationLevel(getIterationLevel() + 1);
            childCreator.visit(subObjectContainer);

            // add alignments of the childCreator to the current annotationContainer
            Alignment alignment;
            AnnotationContainer subAnnotationContainer =
                childCreator.getAnnotationContainer();
            Iterator alignmentIterator =
                subAnnotationContainer.getAlignments().iterator();
            while (alignmentIterator.hasNext()) {
                alignment = (Alignment) alignmentIterator.next();
                if (annotationContainer.getAlignments().iterator().hasNext()) {

                    // correct layerlist because childCreator had cutted layers
                    alignment.setLayers(((Alignment) annotationContainer.getAlignments()
                                                                        .iterator()
                                                                        .next()).getLayers());
                }
                annotationContainer.add(alignment);
            }
            annotationContainer.getAlignmentMap().putAll(subAnnotationContainer.getAlignmentMap());
        }
    }

    /**
     * for the reference layer we have to create a plain (without any alignment or gaps)
     * annotationContainer
     *
     * @param objectContainer includes the reference layer
     *
     * @return Description of the returned value.
     */
    private Layer initializeReference(ObjectContainer objectContainer) {
        Layer firstLayer = null;
        Layer layer;
        LayerInformation information;
        Iterator iterator = objectContainer.getIterator();

        // filters the reference protein and creates it
        while (iterator.hasNext() && annotationContainer == null) {
            Object object = iterator.next();
            if (object instanceof Layer) {
                layer = (Layer) object;
                if (firstLayer == null) {
                    firstLayer = layer;
                }
                if (!layer.isTemplate()) {
                    information = new LayerInformation();
                    information.layer = layer;
                    AnnotationContainerCreator annotationContainerCreator =
                        new AnnotationContainerCreator();
                    annotationContainerCreator.visit(layer);

                    // create annotation container (this will be the final one)
                    annotationContainer =
                        annotationContainerCreator.getAnnotationContainer();
                    information.annotationContainer = annotationContainer;
                    annotationContainer.setLayerAlignmentMap(layerAlignmentMap);

                    // collect all created segements
                    ObjectCollector segmentCollector =
                        new ObjectCollector(new ObjectClassFilter(Segment.class));
                    segmentCollector.visit((AbstractObject) information.annotationContainer);
                    information.segments = segmentCollector.getObjects();

                    // collect all chain annotations for that layer
                    ObjectCollector objectCollector =
                        new ObjectCollector(new ObjectClassFilter(
                                ChainAnnotation.class));
                    objectCollector.visit(annotationContainer);
                    information.chainAnnotations = objectCollector.getObjects();

                    // if the reference layer is a structure layer then collect all atoms
                    if (!layer.isSequenceLayer() && layer.isImposed()) {

                        // filter ca - atoms
                        ObjectFilter caFilter = new CAResidueFilter();
                        ObjectCollector caReferenceCollector =
                            new ObjectCollector(caFilter);
                        caReferenceCollector.visit((AbstractObject) layer);
                        information.atoms = caReferenceCollector.getObjects();
                    }
                    referenceLayer = layer;
                    layerInformationMap.put(referenceLayer, information);
                    return layer;
                }
            }
        }

        // no reference layer found --> determin one
        if (firstLayer != null) {
            firstLayer.setTemplate(false);
            return initializeReference(objectContainer);
        }
        return null;
    }

    /**
     * initializes all templateLayers
     *
     * @param objectContainer includes all layers
     *
     * @return collection of templateLayers
     */
    private Vector initializeTemplates(ObjectContainer objectContainer) {
        templates = new Vector();
        Layer layer;
        LayerInformation information;
        Iterator iterator = objectContainer.getIterator();

        // filters all other sequences (templates) and creates them
        while (iterator.hasNext()) {
            Object object = iterator.next();
            if (object instanceof Layer) {
                layer = (Layer) object;
                if (layer.isTemplate()) {
                    information = new LayerInformation();
                    information.layer = layer;

                    // if we already have an alignment for that layer, we don't need
                    // to create one
                    if (layerAlignmentMap.get(layer) != null) {
                        initializeTemplate(information);
                    } else {

                        // create with generation of layer to reference alignment
                        LayerInformation referenceInformation =
                            (LayerInformation) layerInformationMap.get(referenceLayer);
                        initializeTemplate(information,
                            referenceInformation.atoms);
                    }
                    layerInformationMap.put(layer, information);
                    templates.add(layer);
                }
            }
        }
        return templates;
    }

    /**
     * Description of the method.
     *
     * @param information Description of parameter.
     */
    private void prepareInitializeTemplate(LayerInformation information) {

        // create aligned segments
        AnnotationContainerCreator annotationContainerCreator =
            new AnnotationContainerCreator();
        annotationContainerCreator.visit(information.layer);
        information.annotationContainer =
            annotationContainerCreator.getAnnotationContainer();

        // store all layer associated chain annotation
        ObjectCollector objectCollector =
            new ObjectCollector(new ObjectClassFilter(ChainAnnotation.class));
        objectCollector.visit(information.annotationContainer);
        information.chainAnnotations = objectCollector.getObjects();

        // collect all segments of the alignment
        ObjectCollector segmentCollector =
            new ObjectCollector(new ObjectClassFilter(Segment.class));
        segmentCollector.visit((AbstractObject) information.annotationContainer);
        information.segments = segmentCollector.getObjects();
    }

    /**
     * saves the following in the global variables: created annotationContainer, all
     * residues, all segments, computed alignmentUpMap
     *
     * @param caReferenceAtoms needed to compute alignmentMap
     * @param information Description of parameter.
     */
    private void initializeTemplate(LayerInformation information,
        Collection caReferenceAtoms) {
        prepareInitializeTemplate(information);
        if (!referenceLayer.isSequenceLayer() && information.layer.isImposed()) {

            // filter ca - atoms
            ObjectFilter caFilter = new CAResidueFilter();
            ObjectCollector caAlignCollector = new ObjectCollector(caFilter);
            caAlignCollector.visit((AbstractObject) information.layer);

            // initialize residueAlignmentCreator & calculate ca alignments
            ResidueAlignmentCreator residueCreator =
                new ResidueAlignmentCreator();
            residueCreator.visit(caReferenceAtoms, caAlignCollector.getObjects());
            information.alignmentMap = residueCreator.getAlignmentsUp();
            layerAlignmentMap.put(information.layer, information.alignmentMap);
        }
    }

    /**
     * Saves the following in the global variables: created annotationContainer, all
     * residues, all segments, computed alignmentUpMap
     *
     * @param information Description of parameter.
     */
    private void initializeTemplate(LayerInformation information) {
        prepareInitializeTemplate(information);
        information.alignmentMap =
            (Map) layerAlignmentMap.get(information.layer);
    }

    /**
     * checks if the 2 sequences algin 100% and merges at residue/sequence level
     *
     * @param referenceSequence Description of parameter.
     * @param sequence Description of parameter.
     *
     * @return Description of the returned value.
     */
    private boolean mergeSequences(Vector referenceSequence, Vector sequence) {

        // here is perhaps a good point to merge the identical template chains
        // with the sequence reference chain
        Residue residue;
        Residue referenceResidue;
        boolean isMergeable = true;
        for (int i = 0; i < sequence.size(); i++) {
            residue = (Residue) sequence.elementAt(i);
            if (residue != null) {
                referenceResidue = (Residue) referenceSequence.elementAt(i);
                if (referenceResidue != null) {
                    if (residue.getTemplate() != referenceResidue.getTemplate()) {
                        if (residue.getTemplate().isAminoAcid() &&
                              referenceResidue.getTemplate().isAminoAcid()) {
                            isMergeable = false;
                            log.error("failed due to " + residue + " " +
                                referenceResidue);
                        }
                    }
                }
            }
        }
        if (isMergeable) {

            // replace the gaps with residues for the sequence layer
            for (int i = 0; i < sequence.size(); i++) {
                if (sequence.elementAt(i) == null) {
                    sequence.setElementAt(referenceSequence.elementAt(i), i);
                }
            }
            return true;
        }
        return false;
    }

    //  /**
    //   *  Description of the method.
    //   *
    //   * @param  segments      Description of parameter.
    //   * @param  alignmentMap  Description of parameter.
    //   */
    //  private void replaceResidues( Collection segments, Map alignmentMap ) {
    //
    //    Map map = new HashMap();
    //    AnnotationContainer.invertMap( alignmentMap, map );
    //
    //    Iterator iterator = segments.iterator();
    //    Segment segment;
    //    Subchain subchain;
    //
    //    while ( iterator.hasNext() ) {
    //
    //      segment = ( Segment ) iterator.next();
    //
    //      subchain = segment.getSubchain();
    //      subchain.setInitialResidue( ( Residue ) map.get( subchain.getInitialResidue() ) );
    //      subchain.setEndResidue( ( Residue ) map.get( subchain.getEndResidue() ) );
    //
    //    }
    //
    //  }

    /**
     * Description of the method.
     *
     * @param segments Description of parameter.
     */
    private void removeSections(Collection segments) {
        Iterator iterator = segments.iterator();
        while (iterator.hasNext()) {
            if (((Segment) iterator.next()).getSubchain().getCode() == Section.CODE) {
                iterator.remove();
            }
        }
    }

    /**
     * saves all appearing chains of the chainAnnotation in the chainAnnotation
     *
     * @param layer Description of parameter.
     * @param chainAnnotation Description of parameter.
     */
    private static void registerChains(Layer layer,
        ChainAnnotation chainAnnotation) {
        Collection chains = new HashSet();
        ObjectManager.extract(layer.getObjects(), chains, Chain.class);
        Chain chain;
        Subchain subchain;
        Segment segment;
        Iterator segmentIterator = chainAnnotation.getSegments().iterator();
        while (segmentIterator.hasNext()) {
            segment = (Segment) segmentIterator.next();
            subchain = segment.getSubchain();
            if (subchain != null) {
                chain = findChain(chains, subchain);
                if (chain != null) {
                    chainAnnotation.addChain(chain);
                }
            }
        }
    }

    /**
     * find the suitable chain for the subchain of the segment
     *
     * @param chains Description of parameter.
     * @param subchain Description of parameter.
     *
     * @return Description of the returned value.
     */
    private static Chain findChain(Collection chains, Subchain subchain) {
        Chain chain;
        Iterator chainIterator = chains.iterator();
        while (chainIterator.hasNext()) {
            chain = (Chain) chainIterator.next();
            if (chain.getSubchains().contains(subchain)) {
                return chain;
            }
            ChainFragment chainFragment;
            Iterator fragmentIterator = chain.getChainFragments().iterator();
            while (fragmentIterator.hasNext()) {
                chainFragment = (ChainFragment) fragmentIterator.next();
                if (chainFragment.getSubchains().contains(subchain)) {
                    return chain;
                }
            }
        }
        return null;
    }

    /**
     * Description of the class.
     *
     * @author Karsten Klein
     *
     * @created January 23, 2002
     */
    private static final class LayerInformation {

        /** Description of the field. */
        public Layer layer;

        /** Description of the field. */
        public Collection residues = null;

        /** Description of the field. */
        public Collection segments = null;

        /** Description of the field. */
        public Map alignmentMap = null;

        /** Description of the field. */
        public Map chainSequenceMap = new HashMap();

        /** Description of the field. */
        public Collection atoms = null;

        /** Description of the field. */
        public Collection chainAnnotations;

        /** Description of the field. */
        public AnnotationContainer annotationContainer;
    }
}
