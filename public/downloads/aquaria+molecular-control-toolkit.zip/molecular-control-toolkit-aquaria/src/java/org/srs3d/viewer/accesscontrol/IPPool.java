/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.accesscontrol;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

import org.srs3d.viewer.util.ExceptionHandler;

/**
 * Description of the class.
 *
 * @author Karsten Klein
 *
 * @created March 4, 2002
 */
public class IPPool {
    private ArrayList ips = new ArrayList();

    /**
     * Constructor description.
     */
    public IPPool() {
    }

    /**
     * <code>IPPool</code> constructor.
     *
     * @param object Flattened representation of a IPPool.
     */
    public IPPool(Object object) {
        try {
            int[][][] ipsCondensed = (int[][][]) object;
            IP ip;
            ips.clear();
            for (int i = ipsCondensed.length; --i >= 0;) {
                ip = new IP(ipsCondensed[i]);
                ips.add(ip);
            }
        } catch (ClassCastException e) {

            // :COMPATIBILITY: legacy code for reading old license files
            // old license key file
            int[][] ipsOld = (int[][]) object;
            IP ip;
            ips.clear();
            for (int i = ipsOld.length; --i >= 0;) {
                ip = new IP(ipsOld[i]);
                ips.add(ip);
            }
            ExceptionHandler.handleException(e, ExceptionHandler.SILENT_IN_DEBUG);
        }
    }

    /**
     * <code>IPPool</code> constructor.
     *
     * @param ips Collection of ips to create the pool from.
     */
    protected IPPool(Collection ips) {
        this.ips.addAll(ips);
    }

    /**
     * Will be removed soon.
     *
     * @param ipList Description of parameter.
     */
    protected void add(IPList ipList) {
        ips.addAll(ipList.getIPs());
    }

    /**
     * Adds an IP to the pool.
     *
     * @param ip IP to add.
     */
    public void add(IP ip) {
        ips.add(ip);
    }

    /**
     * Checks th pool for inclusion of the ip in string form.
     *
     * @param ipString IP string representation.
     *
     * @return <code>true</code> if IP covered by pool.
     */
    public boolean contains(String ipString) {
        Iterator iterator = ips.iterator();
        IP ip = new IP(ipString);
        while (iterator.hasNext()) {
            if (((IP) iterator.next()).contains(ip)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Creates a flattened representation of the IPPool.
     *
     * @return Flattened representation of the IPPool.
     */
    protected Object flatten() {
        int[][][] ipsCondensed = new int[ips.size()][4][2];
        IP ip;
        for (int i = ips.size(); --i >= 0;) {
            ip = (IP) ips.get(i);
            ipsCondensed[i][0][0] = ip.address[0][0];
            ipsCondensed[i][0][1] = ip.address[0][1];
            ipsCondensed[i][1][0] = ip.address[1][0];
            ipsCondensed[i][1][1] = ip.address[1][1];
            ipsCondensed[i][2][0] = ip.address[2][0];
            ipsCondensed[i][2][1] = ip.address[2][1];
            ipsCondensed[i][3][0] = ip.address[3][0];
            ipsCondensed[i][3][1] = ip.address[3][1];
        }
        return ipsCondensed;
    }

    protected String dump() {
        String string = "";
        Iterator iterator = ips.iterator();
        while (iterator.hasNext()) {
            string += iterator.next();
            if (iterator.hasNext()) {
                string += ", ";
            }
        }
        return string;
    }
}
