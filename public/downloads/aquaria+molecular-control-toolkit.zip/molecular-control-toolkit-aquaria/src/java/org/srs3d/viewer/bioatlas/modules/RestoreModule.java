/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.modules;

import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.JOptionPane;

import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.behaviors.dispatcher.AbstractDispatcher;
import org.srs3d.viewer.j3d.behaviors.dispatcher.Dispatch;
import org.srs3d.viewer.j3d.operations.ParameterStringOperation;
import org.srs3d.viewer.objects.Operation;
import org.srs3d.viewer.objects.StrategyManager;
import org.srs3d.viewer.swing.Menu;
import org.srs3d.viewer.util.ExceptionHandler;
import org.srs3d.viewer.util.Log;

/**
 * Module that enables saving and restoring views. All reset operations will act on a
 * default view, only.
 *
 * @author Karsten Klein
 *
 * @created February 06, 2002
 */
public abstract class RestoreModule extends ProcessModule {
    private static final Log log = new Log(RestoreModule.class);
    public static final String RESET_OPERATION = "RESET_VIEW";
    public static final String SAVE_OPERATION = "SAVE_VIEW";
    public static final String SAVE_AS_OPERATION = "SAVE_VIEW_AS";
    public static final String DELETE_VIEW_OPERATION = "DELETE_VIEW";
    public static final String APPLY_VIEW_OPERATION = "APPLY_VIEW";
    private ViewManager viewManager;
    private String initialViewId;

    /**
     * Constructor description.
     *
     * @param name Parameter description.
     * @param contextData Parameter description.
     * @param id Parameter description.
     */
    public RestoreModule(String name, ContextData contextData, String id) {
        super(name, contextData, true, true);
        viewManager = new ViewManager(contextData, id);
    }

    /**
     * Method description.
     */
    public void initialize() {
        read();
        getContextData().setProperty("VIEW", getInitialViewId());

        // enable the current dispatcher to write operations into the store
        ((AbstractDispatcher) getContextData().getDispatcher()).setOperationStorage(viewManager);

        // register ResetOperationStore operation
        Dispatch dispatch =
            new Dispatch() {
                public void dispatch(ContextData contextData,
                    Operation operation) {
                    reset();
                }
            };
        ArrayList dispatches = new ArrayList(1);
        dispatches.add(dispatch);
        getContextData().getDispatcher().registerDispatches(RESET_OPERATION,
            dispatches);
        dispatch =
            new Dispatch() {
                    public void dispatch(ContextData contextData,
                        Operation operation) {
                        ProcessModule.IS_THREADED = false;
                        viewManager.save();
                        save(true);
                        ProcessModule.IS_THREADED = true;
                    }
                };
        dispatches = new ArrayList(1);
        dispatches.add(dispatch);
        getContextData().getDispatcher().registerDispatches(SAVE_OPERATION,
            dispatches);
        dispatch =
            new Dispatch() {
                    public void dispatch(ContextData contextData,
                        Operation operation) {
                        ProcessModule.IS_THREADED = false;
                        ParameterStringOperation parameterStringOperation =
                            (ParameterStringOperation) operation;
                        String viewId =
                            parameterStringOperation.getParameterString();
                        getViewManager().save(viewId);
                        save(true);
                        ProcessModule.IS_THREADED = true;
                    }
                };
        dispatches = new ArrayList(1);
        dispatches.add(dispatch);
        getContextData().getDispatcher().registerDispatches(SAVE_AS_OPERATION,
            dispatches);
        dispatch =
            new Dispatch() {
                    public void dispatch(ContextData contextData,
                        Operation operation) {
                        ParameterStringOperation parameterStringOperation =
                            (ParameterStringOperation) operation;
                        String viewId =
                            parameterStringOperation.getParameterString();
                        viewManager.processApplyView(viewId);
                    }
                };
        dispatches = new ArrayList(1);
        dispatches.add(dispatch);
        getContextData().getDispatcher().registerDispatches(APPLY_VIEW_OPERATION,
            dispatches);
        dispatch =
            new Dispatch() {
                    public void dispatch(ContextData contextData,
                        Operation operation) {
                        ParameterStringOperation parameterStringOperation =
                            (ParameterStringOperation) operation;
                        String viewId =
                            parameterStringOperation.getParameterString();
                        if (confirmDelete(viewId)) {
                            viewManager.removeView(viewId);
                            viewManager.save();
                            save(false);
                        }
                    }
                };
        dispatches = new ArrayList(1);
        dispatches.add(dispatch);
        getContextData().getDispatcher().registerDispatches(DELETE_VIEW_OPERATION,
            dispatches);
    }

    /**
     * Description of the method.
     *
     * @param e Description of parameter.
     */
    public void process(ActionEvent e) {
        try {
            Thread.sleep(300);
        } catch (InterruptedException ex) {

            // :SILENT EXCEPTION:
        }
        StrategyManager strategyManager = getContextData().getStrategyManager();
        getComputation().setComputation(strategyManager);
        if (getInitialViewId() != null) {
            log.debug("Applying initial view " + getInitialViewId());
            viewManager.processApplyView(getInitialViewId());
        }
        strategyManager.resetComputation();
        getComputation().setComputation(null);
        RuntimeTestModule.finalize(getContextData());
    }

    /**
     * Description of the method.
     */
    public void processApplyView(String viewId) {
        ProcessModule.IS_THREADED = false;
        viewManager.processApplyView(viewId);
        ProcessModule.IS_THREADED = true;
    }

    /**
     * The module is focussed on saving the default view.
     */
    public void updateIntern() {

        // saving only possible if operation store exists and is not empty
        getComponent().setEnabled(viewManager.hasViews());
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public boolean hasViews() {
        return viewManager.hasViews();
    }

    /**
     * Method description.
     */
    public abstract void read();

    /**
     * Method description.
     */
    public void reset() {

        // do nothing
    }

    /**
     * Saves the view information. If isConfirm is true the user will be confirmed that
     * the views were saved.
     */
    public abstract void save(boolean isConfirm);

    /**
     * Method description.
     *
     * @return Return description.
     */
    public abstract boolean canSave();

    /**
     * Method description.
     *
     * @return Return description.
     */
    public String getId() {
        return viewManager.getId();
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    protected ViewManager getViewManager() {
        return viewManager;
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     * @param id Parameter description.
     *
     * @return Return description.
     */
    public static final RestoreModule getInstance(ContextData contextData,
        String id) {
        String applicationMode =
            contextData.getAppletStub().getParameter("applicationMode");
        RestoreModule restoreModule = null;
        if (applicationMode != null && applicationMode.equals("platform")) {

            // :FIXME: this can be done more modular by registration
            // use the platform module
            log.debug("Instantiating platform restore module.");
            try {

                // we use reflection here to have more security in the SRS 3D applet;
                // sometimes i had some class not found errors during the RestoreModule
                // access related to this class (that is not included in the SRS 3D jar
                // file)
                Class restoreClass =
                    Class.forName(
                        "com.lionbioscience.visualization.components.structureviewer.modules.PlatformRestoreModule");
                Object[] parameters = new Object[3];
                parameters[0] = "Restore";
                parameters[1] = contextData;
                parameters[2] = id;
                restoreModule =
                    (RestoreModule) restoreClass.getConstructors()[0].newInstance(parameters);
            } catch (Exception e) {
                log.error("Unable to instantiate RestoreModule.");
                ExceptionHandler.handleException(e);
            }
        } else {

            // compose a filename from the instance id
            String filename = id + ".xml";
            if (contextData.getProperty("RuntimeTestMode") == null) {
                filename = System.getProperty("user.home");
                filename += System.getProperty("file.separator") + ".srs3d";
                new java.io.File(filename).mkdir();
                filename += System.getProperty("file.separator") + id + ".xml";
            }
            log.info("Initializing RestoreModule using " + filename);

            // use the file module
            restoreModule =
                new FileRestoreModule("Restore", contextData, filename);
        }
        if (restoreModule != null) {
            restoreModule.initialize();

            // bind to context data
            contextData.setProperty("RESTORE_MODULE", restoreModule);
        }
        return restoreModule;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public Menu createMenu() {
        Menu menu = new Menu("Preset Views");
        ArrayList views = new ArrayList(getViewManager().getViewMap().keySet());
        Iterator iterator = views.iterator();
        String viewId;
        ViewModule viewModule;
        while (iterator.hasNext()) {
            viewId = (String) iterator.next();
            viewModule = new ViewModule(viewId, getContextData(), viewId);
            menu.add(viewModule);
        }
        return menu;
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     *
     * @return Return description.
     */
    public static Menu createDefaultMenu(ContextData contextData) {
        Menu menu = new Menu("Preset Views");
        return menu;
    }

    /**
     * Method description.
     *
     * @param viewId Parameter description.
     */
    public void setInitialView(String viewId) {
        this.initialViewId = viewId;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public String getInitialViewId() {
        return initialViewId;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public boolean confirmSave() {
        if (getContextData().getProperty("COMPUTATION_STATE") != null) {
            int result =
                org.srs3d.viewer.swing.ComponentFactory.confirmDialog(getContextData()
                                                                          .getContext(),
                    "You are about to save the view after having canceled an operation;\n" +
                    "this view may not be reproduceable. It is recommend that you reset\n" +
                    "the view and reapply the changes before saving.\n" +
                    "Press OK to save anyway.", "Warning",
                    JOptionPane.ERROR_MESSAGE, null);
            if (result == JOptionPane.CANCEL_OPTION) {
                return false;
            }
        }
        return true;
    }

    /**
     * Method description.
     */
    public void confirmSaved() {
        org.srs3d.viewer.swing.ComponentFactory.messageDialog(getContextData()
                                                                  .getContext(),
            "The current state will be restored when you revisit this entry.",
            "Current view state successfully saved",
            JOptionPane.INFORMATION_MESSAGE, null);
    }

    /**
     * Method description.
     *
     * @param viewId Parameter description.
     *
     * @return Return description.
     */
    public boolean confirmDelete(String viewId) {
        int result =
            org.srs3d.viewer.swing.ComponentFactory.confirmDialog(getContextData()
                                                                      .getContext(),
                "You are about to delete the current view " + viewId + ".\n" +
                "Press cancel to abort the operation.", "Warning",
                JOptionPane.ERROR_MESSAGE, null);
        if (result == JOptionPane.CANCEL_OPTION) {
            return false;
        }
        return true;
    }
}
