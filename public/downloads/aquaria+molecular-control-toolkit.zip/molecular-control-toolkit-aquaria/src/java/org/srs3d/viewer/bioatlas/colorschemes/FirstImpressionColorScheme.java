/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.colorschemes;

import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Vector;

import javax.media.j3d.Appearance;
import javax.vecmath.Color3f;

import org.srs3d.viewer.bioatlas.objects.Atom;
import org.srs3d.viewer.bioatlas.objects.Site;
import org.srs3d.viewer.j3d.AbstractColorScheme;
import org.srs3d.viewer.j3d.AppearanceHelper;
import org.srs3d.viewer.j3d.ColorScheme;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.objects.ObjectManager;

/**
 * The <code>FirstImpressionColorScheme</code> highlight only special properties of the
 * structure. A standard entity is presented in a dull unsaturated color, while sites
 * and irregularities are in bright saturated colors. The implementation uses the
 * <code>ChainColorScheme</code> to generate the chain colors.
 *
 * @author Karsten Klein
 *
 * @created March 20, 2001
 */
public class FirstImpressionColorScheme extends AbstractColorScheme {
    public static Color3f siteColor = new Color3f(0.9f, 0.0f, 0.0f);
    public static Color3f disulfideColor = new Color3f(0.8f, 0.8f, 0.0f);
    private ColorScheme baseColorScheme = null;

    /**
     * <code>FirstImpressionColorScheme</code> contructor.
     *
     * @param contextData Description of parameter.
     */
    public FirstImpressionColorScheme(ContextData contextData) {
        super(contextData);
        baseColorScheme = new MoleculeColorScheme(contextData);
        ((MoleculeColorScheme) baseColorScheme).setColorScale(0.7f);
    }

    /**
     * Gets the <code>information</code> attribute of the
     * <code>FirstImpressionColorScheme</code> object.
     *
     * @return The <code>information</code> value.
     */
    public Map getInformation(Map map) {
        map = baseColorScheme.getInformation(map);
        map.put("NAME", "First Impression");
        return map;
    }

    /**
     * Description of the method
     *
     * @param object Description of parameter
     * @param appearance Description of parameter
     *
     * @return Description of the returned value.
     */
    public boolean modify(AbstractObject object, Appearance appearance) {
        Color3f color = null;
        if (object instanceof Atom) {
            Collection collection = new Vector();
            getContextData().getObjectManager().getUpAssociations(object,
                collection);
            ObjectManager.extract(collection, Site.class);
            Iterator iterator = collection.iterator();
            if (iterator.hasNext()) {
                Site site = (Site) iterator.next();
                if (site.getContentType() == Site.ACTIVE_SITE) {
                    color = siteColor;
                } else { //if ( site.getContentType() == Site.DISULFIDEBOND_RESIDUES ) {
                    color = disulfideColor;
                }
            }
        }
        if (color != null) {
            AppearanceHelper.enableVertexColors(appearance, false);
            AppearanceHelper.modifyAppearance(appearance, color);
            return true;
        } else {
            return baseColorScheme.modify(object, appearance);
        }
    }

    /**
     * Method description.
     *
     * @param baseColorScheme Parameter description.
     */
    public void setBaseColorScheme(ColorScheme baseColorScheme) {
        this.baseColorScheme = baseColorScheme;
    }
}
