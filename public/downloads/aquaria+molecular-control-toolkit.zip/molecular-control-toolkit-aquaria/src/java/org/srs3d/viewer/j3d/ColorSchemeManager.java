/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d;

import java.util.Collection;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;

import org.srs3d.viewer.objects.AbstractManager;
import org.srs3d.viewer.objects.AbstractObject;

/**
 * @author Karsten Klein
 *
 * @created May 2, 2001
 */
public class ColorSchemeManager extends AbstractManager {
    private Map bucketMap = new Hashtable();

    /**
     * <code>ColorSchemeManager</code> constructor.
     *
     * @param contextData Description of parameter.
     */
    public ColorSchemeManager(ContextData contextData) {
        super(contextData);
    }

    /**
     * Gets the <code>colorSchemeBucket</code> attribute of the
     * <code>ColorSchemeManager</code> object.
     *
     * @param object Description of parameter.
     *
     * @return The <code>colorSchemeBucket</code> value.
     */
    public ColorSchemeBucket getColorSchemeBucket(AbstractObject object) {
        ColorSchemeBucket bucket = (ColorSchemeBucket) bucketMap.get(object);
        return (ColorSchemeBucket) bucketMap.get(object);
    }

    /**
     * Retrieves all the objects that contain the given ColorScheme in their repective
     * ColorSchemeBuckets.
     *
     * @param colorScheme ColorScheme object to seatch for.
     *
     * @return Found objects colored with the specified ColorScheme.
     */
    public Collection getObjects(ColorScheme colorScheme) {
        Iterator bucketIterator = bucketMap.values().iterator();
        Iterator iterator = bucketMap.keySet().iterator();
        ColorSchemeBucket bucket;
        Object object;
        Collection objects = new HashSet();
        while (iterator.hasNext()) {
            object = iterator.next();
            bucket = (ColorSchemeBucket) bucketIterator.next();
            if (bucket.contains(colorScheme)) {
                objects.add(object);
            }
        }
        return objects;
    }

    /**
     * Description of the method.
     *
     * @param object Description of parameter.
     * @param colorSchemeBucket Description of parameter.
     */
    public void extendColorSchemeBucket(AbstractObject object,
        ColorSchemeBucket colorSchemeBucket) {
        if (colorSchemeBucket != null) {
            ColorSchemeBucket bucket =
                (ColorSchemeBucket) bucketMap.get(object);
            if (bucket == null) {
                bucket = new ColorSchemeBucket();
            }
            bucket.extend(colorSchemeBucket);
            bucketMap.put(object, bucket);
        }
    }

    /**
     * Description of the method.
     *
     * @param object Description of parameter.
     * @param colorSchemeBucket Description of parameter.
     */
    public void register(AbstractObject object,
        ColorSchemeBucket colorSchemeBucket) {
        if (colorSchemeBucket != null && !colorSchemeBucket.isEmpty()) {
            bucketMap.put(object, colorSchemeBucket);
        } else {
            bucketMap.remove(object);
        }
    }

    /**
     * Description of the method.
     */
    public void clear() {
        bucketMap.clear();
    }

    /**
     * Description of the method.
     *
     * @param object Description of parameter.
     */
    public void remove(AbstractObject object) {
        bucketMap.remove(object);
    }
}
