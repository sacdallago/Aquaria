/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.dispatcher;

import javax.vecmath.Point3d;
import javax.vecmath.Point3f;
import javax.vecmath.Vector3f;

import org.srs3d.viewer.j3d.Context;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.DispatchManager;
import org.srs3d.viewer.j3d.Selection;
import org.srs3d.viewer.j3d.commands.SpawnCommand;
import org.srs3d.viewer.j3d.objects.Rectangle;
import org.srs3d.viewer.j3d.operations.ZoomBoxOperation;
import org.srs3d.viewer.objects.ObjectManager;
import org.srs3d.viewer.objects.Operation;

/**
 * @author Karsten Klein, 11/2000
 *
 * @created March 20, 2001
 * @since 1.0
 */
public class OverviewDispatcher extends ThreadedDispatcher {

    /**
     * Description of the method.
     *
     * @param context Description of parameter.
     * @param operation Description of parameter.
     */
    public void process(Context context, Operation operation) {
        ContextData contextData = context.getContextData();
        ObjectManager objectManager = contextData.getObjectManager();
        Selection selection = contextData.getSelectionManager().getSelection();

        // we get this operation from the zoomBoxBehavior
        if (operation.is("MOVE_ZOOMBOX")) {

            // we treat this message as a request for update
            DispatchManager.dispatch(context,
                new Operation(context, "MOVE_OVERVIEW", operation.getObject()));
        } else if (operation.is("MOVE_OVERVIEW")) {
            ZoomBoxOperation zoomBoxOperation = (ZoomBoxOperation) operation;
            Vector3f translation = zoomBoxOperation.getDeltaPosition();
            Vector3f size = zoomBoxOperation.getDeltaSize();
            Rectangle rectangle =
                ((org.srs3d.viewer.annotation.contexts.AnnotationContextData) contextData).getZoomBox();
            rectangle.setHeight(size.y);
            rectangle.setWidth(size.x);
            translation.z = 0;
            rectangle.setCoordinate(translation);
            operation.setObject(rectangle);
            processMoveZoomBox(contextData, operation);
        }
    }

    private void processMoveZoomBox(final ContextData contextData,
        Operation operation) {
        final Rectangle zoomBox = (Rectangle) operation.getObject();
        if (zoomBox != null) {
            Point3d point = new Point3d(zoomBox.getCoordinate());
            point.z = zoomBox.getWidth() * 1.3f;
            point.z *= 1.0f / 1.3f;
            zoomBox.setHeight((int) ((float) zoomBox.getHeight() * point.z / zoomBox.getWidth()));
            zoomBox.setWidth((int) point.z);
            point.z = 0;
            zoomBox.setCoordinate(new Point3f(point));
            contextData.getContext().addUpdateCallback(new org.srs3d.viewer.j3d.behaviors.UpdateBehavior.Callback() {
                    public void execute() {
                        SpawnCommand spawn = new SpawnCommand(contextData);
                        contextData.getStrategyManager().execute(zoomBox, spawn);
                    }
                });
        }
    }
}
