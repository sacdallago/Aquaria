/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.modules;

import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

import javax.vecmath.Color3f;

import org.srs3d.viewer.bioatlas.colorschemes.CPKColorScheme;
import org.srs3d.viewer.bioatlas.colorschemes.MonochromeColorScheme;
import org.srs3d.viewer.bioatlas.objects.Annotation;
import org.srs3d.viewer.j3d.ColorSchemeBucket;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.DispatchManager;
import org.srs3d.viewer.j3d.behaviors.dispatcher.Dispatch;
import org.srs3d.viewer.j3d.commands.ColorCommand;
import org.srs3d.viewer.objects.Operation;

/**
 * Description of the class.
 *
 * @author Karsten Klein
 *
 * @created June 24, 2002
 */
public class AnnotationToggleExModule extends ProcessModule {
    private transient Operation operation;

    /**
     * <code>AnnotationToggleExModule</code> constructor.
     *
     * @param name Description of parameter.
     * @param contextData Description of parameter.
     */
    public AnnotationToggleExModule(String name, ContextData contextData) {
        super(name, contextData, true, true);

        // register TOGGLE_ACTIVATION_EX
        Dispatch dispatch =
            new Dispatch() {
                public void dispatch(final ContextData contextData,
                    final Operation operation) {
                    AnnotationToggleExModule.this.operation = operation;

                    // :FIXME: introduce a method with process( java.lang.Object ) signature
                    //   for general purpose, rather than this (no transient state needed)
                    actionPerformed(null);
                }
            };
        ArrayList dispatches = new ArrayList(1);
        dispatches.add(dispatch);
        contextData.getDispatcher().registerDispatches("TOGGLE_ACTIVATION_EX",
            dispatches);
        setOperationSerializeable(false);
    }

    /**
     * Description of the method.
     *
     * @param e Description of parameter.
     */
    public void process(ActionEvent e) {
        getComputation().setDescription("Toggling Annotation Activation");
        getContextData().getContext().addUpdateCallback(new org.srs3d.viewer.j3d.behaviors.UpdateBehavior.Callback() {
                public void execute() {
                    processToggleActivationEx(getContextData(), operation);
                }
            });
        getContextData().getContext().waitForUpdate();
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     * @param operation Description of parameter.
     */
    public void processToggleActivationEx(ContextData contextData,
        Operation operation) {
        Annotation annotation = (Annotation) operation.getObject();
        ColorSchemeBucket preAnnotationBucket =
            (ColorSchemeBucket) contextData.getProperty("PreAnnotationBucket");
        if (preAnnotationBucket == null) {
            preAnnotationBucket = contextData.getColorSchemeBucket();
        }
        Collection activeAnnotations = new ArrayList(10);
        org.srs3d.viewer.bioatlas.modules.AnnotationModule.getActiveAnnotations(contextData,
            activeAnnotations);

        // deactivate all active annotations
        Iterator iterator = activeAnnotations.iterator();
        Annotation activeAnnotation;
        while (iterator.hasNext()) {
            activeAnnotation = (Annotation) iterator.next();
            org.srs3d.viewer.bioatlas.modules.FeatureModule.deactivateAnnotation(contextData,
                activeAnnotation);
        }
        if (activeAnnotations.contains(annotation)) {
            if (preAnnotationBucket != null) {

                // deactivation already done; apply preColorSchemeBucket
                ColorCommand colorCommand =
                    new ColorCommand(contextData, preAnnotationBucket);

                // :FIXME: version specific code
                // reproduce bug without: activate disulfide annotation of 1mpa; color by
                // molecule; deactivate annotation; select chain consisting of coil only;
                // apply ball and stick representation
                colorCommand.propagate(contextData.getObjectContainer());
                contextData.setColorSchemeBucket(preAnnotationBucket);
            }
        } else {
            if (activeAnnotations.isEmpty()) {

                // store current colorSchemeBucket
                preAnnotationBucket =
                    new ColorSchemeBucket(contextData.getColorSchemeBucket());
                contextData.setProperty("PreAnnotationBucket",
                    preAnnotationBucket);
            }

            // create color scheme with composed annotation names
            MonochromeColorScheme colorScheme =
                new MonochromeColorScheme(contextData,
                    new Color3f(0.3f, 0.3f, 0.3f));
            colorScheme.setComplete(true);
            colorScheme.setName(annotation.getName());
            colorScheme.setDescription("no annotation");

            // apply colorscheme to all objects
            ColorSchemeBucket colorSchemeBucket =
                new ColorSchemeBucket(colorScheme);
            CPKColorScheme cpkColorScheme = new CPKColorScheme(contextData);
            cpkColorScheme.setColorScale(0.5f);
            colorSchemeBucket.extend(cpkColorScheme);
            ColorCommand colorCommand =
                new ColorCommand(contextData, colorSchemeBucket);
            colorCommand.propagate(contextData.getObjectContainer());
            contextData.setColorScheme(colorScheme);

            // activate annotation
            org.srs3d.viewer.bioatlas.modules.FeatureModule.activateAnnotation(contextData,
                annotation);
        }
        org.srs3d.viewer.bioatlas.Capture.updateSelections(contextData, false);

        // propagate update coloring to other contexts
        DispatchManager.runDispatch(contextData.getContext(),
            new Operation(contextData.getContext(), "UPDATE_COLORING", null));
        org.srs3d.viewer.bioatlas.modules.ColorSchemeModule.updateLegendOverlay(contextData);
    }
}
