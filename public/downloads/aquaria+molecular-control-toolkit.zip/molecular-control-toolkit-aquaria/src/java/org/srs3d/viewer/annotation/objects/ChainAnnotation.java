/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.annotation.objects;

import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Vector;

import org.srs3d.viewer.bioatlas.objects.Chain;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.util.Log;

/**
 * ChainAnnotation object.
 *
 * @author Karsten Klein
 * @author Christian Zofka
 *
 * @created March 28, 2001
 * @modified June 27, 2001
 */
public class ChainAnnotation extends AbstractObject {
    private static final Log log = new Log(ChainAnnotation.class);
    private String name = null;
    private int length = 0;
    private Collection chains = new HashSet();
    private Collection segments = new HashSet();

    // stored for use with sequenceDetailView
    private Vector gapSequence = null;

    /**
     * <code>ChainAnnotation</code> constructor.
     *
     * @param chain Description of parameter.
     */
    public ChainAnnotation(Chain chain) {
        if (chain != null) {
            setLength(chain.getLength());
            addChain(chain);
            setName("" + chain.getId());
        }
    }

    /**
     * Sets the <code>Length</code> attribute of the <code>AbstractChain</code> object.
     *
     * @param length The new <code>Length</code> value.
     */
    public void setLength(int length) {
        this.length = length;
    }

    /**
     * Sets the <code>gapSequence</code> attribute of the <code>ChainAnnotation </code>
     * object.
     *
     * @param list The new <code>gapSequence</code> value.
     */
    public void setGapSequence(Vector list) {
        gapSequence = list;
    }

    //  /**
    //   *  Sets the <code>name</code> attribute of the <code>ChainAnnotation</code>
    //   *  object.
    //   *
    //   * @param  layer  The new <code>name</code> value.
    //   */
    //  public void setName( Layer layer ) {
    //
    //    name = layer.getDescription();
    //
    //  }

    /**
     * Sets the <code>name</code> attribute of the <code>ChainAnnotation</code> object.
     *
     * @param string The new <code>name</code> value.
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Gets the <code>chains</code> attribute of the <code>ChainAnnotation</code> object.
     *
     * @return The <code>chains</code> value.
     */
    public Collection getChains() {
        return chains;
    }

    /**
     * Gets the <code>gapSequence</code> attribute of the <code>ChainAnnotation </code>
     * object.
     *
     * @return The <code>gapSequence</code> value.
     */
    public Vector getGapSequence() {
        return gapSequence;
    }

    /**
     * Gets the length of the <code>AbstractChain</code> object.
     *
     * @return Length of the chain.
     */
    public int getLength() {
        return length;
    }

    /**
     * Gets the <code>name</code> attribute of the <code>ChainAnnotation</code> object.
     *
     * @return The <code>name</code> value.
     */
    public String getName() {
        return name;
    }

    /**
     * Gets the first chain of the <code>chains</code> attribute of the
     * <code>ChainAnnotation</code> object. Displays an error if less or more chains are
     * available. Warning: Only use this method if it's clear that you have only 1 chain
     * registered!!!
     *
     * @return The first entry of <code>chains</code> value.
     */
    public Chain getChain() {
        if (getChains().size() == 0) {
            log.error("no chain id found.");
        } else {
            if (getChains().size() > 1) {
                log.error("multiple chain ids found. Don't use this method.");
            }
            return (Chain) getChains().iterator().next();
        }
        return null;
    }

    /**
     * Gets the <code>empty</code> attribute of the <code>ChainAnnotation</code> object.
     *
     * @return The <code>empty</code> value.
     */
    public boolean isEmpty() {
        return segments.isEmpty();
    }

    /**
     * Gets the <code>AllObjects</code> attribute of the <code>Annotation</code> object.
     *
     * @param collection Description of parameter.
     */
    public void getAllObjects(Collection collection) {
        collection.addAll(segments);
    }

    /**
     * Gets the <code>segments</code> attribute of the <code>ChainAnnotation</code>
     * object.
     *
     * @return The <code>segments</code> value.
     */
    public Collection getSegments() {
        return segments;
    }

    /**
     * Adds a <code>Chains</code> object to the <code>ChainAnnotation</code> object.
     *
     * @param chain The <code>Chains</code> object to be added.
     */
    public void addChain(Chain chain) {
        chains.add(chain);
    }

    /**
     * Description of the method.
     *
     * @param chain Description of parameter.
     */
    public void removeChain(Chain chain) {
        chains.remove(chain);
    }

    /**
     * Description of the method.
     *
     * @return Description of the returned value.
     */
    public String toString() {
        if (getChains().isEmpty()) {
            return "Chain Annotation()" + getLength() + " " +
            getSegments().toString();
        } else {
            return "Chain Annotation(" + getChains() + ")";
        }
    }

    /**
     * Description of the method.
     */
    public void cleanup() {
        super.cleanup();
        cleanup(segments);
        segments = null;
        cleanup(chains);
        chains = null;
        cleanup(gapSequence);
        gapSequence = null;
    }

    /**
     * Description of the method.
     *
     * @param segment Description of parameter.
     */
    public void add(Segment segment) {
        Collection segments = getSegments();
        segments.add(segment);
    }

    /**
     * Description of the method.
     */
    public void update() {
        int length = 0;
        Segment segment;
        Iterator iterator = getSegments().iterator();
        while (iterator.hasNext()) {
            segment = (Segment) iterator.next();
            segment.update();
            length += segment.getLength();
        }
        setLength(length);
    }

    // :REMOVE: this inner class is NEVER USED!!
    //  private static class SegmentSort implements Comparator {
    //
    //    /**
    //     *  Description of the method.
    //     *
    //     * @param  o1  Description of parameter.
    //     * @param  o2  Description of parameter.
    //     * @return     Description of the returned value.
    //     */
    //    public int compare( Object o1, Object o2 ) {
    //
    //      int value = 0;
    //
    //      Segment segment1 = ( Segment ) o1;
    //      Segment segment2 = ( Segment ) o2;
    //
    //      value = segment1.getStartIndex() - segment2.getStartIndex();
    //
    //      return value;
    //    }
    //
    //    /**
    //     *  Description of the method.
    //     *
    //     * @param  obj  Description of parameter.
    //     * @return      Description of the returned value.
    //     */
    //    public boolean equals( Object obj ) {
    //
    //      return false;
    //    }
    //
    //  }
}
