/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.modules;

import java.awt.event.ActionEvent;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;

import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.behaviors.UpdateBehavior;
import org.srs3d.viewer.j3d.commands.RegisterCommand;
import org.srs3d.viewer.j3d.objects.Surface;
import org.srs3d.viewer.objects.ObjectContainer;
import org.srs3d.viewer.objects.ObjectManager;
import org.srs3d.viewer.objects.filters.ObjectClassFilter;
import org.srs3d.viewer.objects.visitors.ObjectCollector;

/**
 * Description of the class.
 *
 * @author Karsten Klein
 *
 * @created April 29, 2002
 */
public class RemoveSurfaceModule extends ProcessModule {

    /** Description of the field. */
    public transient Collection objects = null;

    /**
     * <code>CommandModule</code> constructor.
     *
     * @param name Description of parameter.
     * @param contextData Description of parameter.
     */
    public RemoveSurfaceModule(String name, ContextData contextData) {
        super(name, contextData, true, true);
    }

    /**
     * Gets the <code>moduleIdPrefix</code> attribute of the
     * <code>RemoveSurfaceModule</code> object.
     *
     * @return The <code>moduleIdPrefix</code> value.
     */
    public String getModuleIdPrefix() {
        return "";
    }

    /**
     * Gets the <code>moduleId</code> attribute of the <code>RemoveSurfaceModule</code>
     * object.
     *
     * @return The <code>moduleId</code> value.
     */
    public String getModuleId() {
        return "REMOVE_ALL_SURFACES";
    }

    /**
     * Description of the method.
     *
     * @param e Description of parameter.
     */
    public void process(ActionEvent e) {
        getContextData().getContext().addUpdateCallback(new UpdateBehavior.Callback() {
                public void execute() {
                    remove(objects);
                }
            });
    }

    /**
     * Description of the method.
     *
     * @param surfaces Description of parameter.
     */
    public void remove(Collection surfaces) {
        Iterator iterator = surfaces.iterator();
        while (iterator.hasNext()) {
            remove((Surface) iterator.next());
        }
    }

    /**
     * Description of the method.
     */
    public void updateIntern() {

        // filter all surfaces
        ObjectCollector objectCollector =
            new ObjectCollector(new ObjectClassFilter(Surface.class));
        objectCollector.visit(getContextData().getObjectContainer().getObjects());
        objects = objectCollector.getObjects();
        if (getComponent() != null) {
            getComponent().setEnabled(!objects.isEmpty());
        }
    }

    /**
     * Description of the method.
     *
     * @param surface Description of parameter.
     */
    public void remove(Surface surface) {
        Collection containers = new HashSet();
        getContextData().getObjectManager().getUpAssociations(surface,
            containers);
        ObjectManager.extract(containers, ObjectContainer.class);
        Iterator iterator = containers.iterator();
        while (iterator.hasNext()) {
            ((ObjectContainer) iterator.next()).removeObject(surface);
        }
        RegisterCommand registerCommand =
            new RegisterCommand(getContextData(), false);
        getContextData().getStrategyManager().execute(surface, registerCommand);

        // remove branch group items
        getContextData().getSpawnerManager().remove(surface);
        surface.cleanup();
    }
}
