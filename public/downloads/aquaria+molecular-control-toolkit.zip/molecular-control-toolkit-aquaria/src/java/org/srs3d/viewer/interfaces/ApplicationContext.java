/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.interfaces;


/**
 * Application context interface. This interface is used to store information about the
 * application.
 *
 * @author Karsten Klein
 */
public interface ApplicationContext {

    /**
     * Retrieve a parameter identified by the specified key object.
     *
     * @param key Object identifier.
     *
     * @return Return Object that is stored for the specified key.
     */
    public Object get(Object key);

    /**
     * Store an object value for the specified key object.
     *
     * @param key Key object.
     * @param value Value object.
     */
    public void set(Object key, Object value);
}
