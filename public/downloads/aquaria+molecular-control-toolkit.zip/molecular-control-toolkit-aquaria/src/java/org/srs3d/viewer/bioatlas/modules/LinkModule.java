/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.modules;

import java.applet.AppletStub;
import java.awt.event.ActionEvent;
import java.net.URL;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.StringTokenizer;

import javax.swing.JMenuItem;

import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.Linkable;
import org.srs3d.viewer.j3d.Selection;
import org.srs3d.viewer.j3d.objects.Link;
import org.srs3d.viewer.objects.ObjectManager;
import org.srs3d.viewer.util.Log;

/**
 * <code>Module</code> implementation linking <code>Layer</code> objects to a HTML page.
 *
 * @author Karsten Klein
 *
 * @created May 14, 2001
 */
public class LinkModule extends ProcessModule {
    private static final Log log = new Log(LinkModule.class);
    private String databaseId;
    private Collection links = new HashSet();

    /**
     * <code>LinkModule</code> constructor.
     *
     * @param descriptor Description of parameter.
     * @param contextData Description of parameter.
     */
    public LinkModule(String name, LinkTemplate linkTemplate,
        ContextData contextData) {
        super(name, contextData);
        setOperationSerializeable(false);
        databaseId = linkTemplate.databaseId;
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     * @param descriptor Parameter description.
     *
     * @return Return description.
     */
    public static LinkTemplate createLinkTemplate(ContextData contextData,
        String descriptor) {
        LinkTemplate linkTemplate = new LinkTemplate(descriptor);
        contextData.setProperty("LINKTEMPLATE-" + linkTemplate.databaseId,
            linkTemplate);
        return linkTemplate;
    }

    /**
     * Gets the <code>linkTemplate</code> attribute of the <code>LinkModule</code>
     * object.
     *
     * @return The <code>linkTemplate</code> value.
     */
    public static LinkTemplate getLinkTemplate(ContextData contextData,
        String databaseId) {
        return (LinkTemplate) contextData.getProperty("LINKTEMPLATE-" +
            databaseId);
    }

    /**
     * Description of the method.
     */
    public void cleanup() {
        super.cleanup();
        databaseId = null;
    }

    /**
     * Description of the method.
     *
     * @param e Description of parameter.
     */
    public void process(ActionEvent e) {
        openLink(getContextData(), links, databaseId);
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     * @param links Parameter description.
     * @param databaseId Parameter description.
     */
    public static void openLink(ContextData contextData, Collection links,
        String databaseId) {
        Iterator iterator = links.iterator();
        Link link;
        boolean isSingle = true;
        HashSet strings = new HashSet();
        String linkString;
        while (iterator.hasNext()) {
            link = (Link) iterator.next();
            linkString = link.getLink(databaseId);
            strings.add(linkString);
        }
        String string = "";
        iterator = strings.iterator();
        while (iterator.hasNext()) {
            linkString = (String) iterator.next();
            string += linkString;
            if (iterator.hasNext()) {
                string += "|";
                isSingle = false;
            }
        }
        String composedUrl =
            createSrsUrl(contextData, databaseId, string, isSingle);
        if (composedUrl != null) {
            AppletStub appletStub = contextData.getAppletStub();
            URL url =
                org.srs3d.viewer.bioatlas.Parameter.supplementUrl(appletStub.getDocumentBase(),
                    composedUrl);
            appletStub.getAppletContext().showDocument(url,
                org.srs3d.viewer.bioatlas.Parameter.applicationName);
        } else {
            log.error("invalid url: " + composedUrl);
        }
    }

    /**
     * Description of the method.
     */
    public void updateIntern() {
        JMenuItem menuItem = (JMenuItem) getComponent();
        HashSet linkables = new HashSet();
        Selection selection =
            getContextData().getSelectionManager().getSelection();
        HashSet objects = new HashSet();
        getContextData().getObjectManager().getAssociations(selection, objects);
        objects.addAll(selection);

        // the linkables are layers, chains, annotations and features
        org.srs3d.viewer.bioatlas.dispatcher.NavigateUpDispatcher.findAnnotations(getContextData(),
            objects, linkables);
        ObjectManager.extract(objects, linkables, Linkable.class);
        Iterator iterator = linkables.iterator();
        Linkable linkable;
        Link link;
        links.clear();
        while (iterator.hasNext()) {
            linkable = (Linkable) iterator.next();
            link = linkable.getLink();
            if (link != null) {
                if (link.getLink(getDatabaseId()) != null) {
                    links.add(link);
                }
            }
        }
        menuItem.setEnabled(!links.isEmpty());
    }

    /**
     * Description of the method.
     *
     * @param identifier Description of parameter.
     * @param isSingle Description of parameter.
     *
     * @return Description of the returned value.
     */
    public static String createSrsUrl(ContextData contextData,
        String databaseId, String identifier, boolean isSingle) {
        LinkTemplate linkTemplate = getLinkTemplate(contextData, databaseId);
        if (linkTemplate != null) {
            String template = linkTemplate.template;
            if (!isSingle) {

                // replace +-e+ in SRS query by simple +
                int index = template.indexOf("+-e+");
                if (index != -1) {
                    template =
                        template.substring(0, index) +
                        template.substring(index + 3);
                }
            }
            int substituteIndex = template.indexOf("###");

            // prefix
            String composedUrl = template.substring(0, substituteIndex);
            composedUrl += identifier;

            // suffix
            composedUrl += template.substring(substituteIndex + 3);
            return composedUrl;
        } else {
            log.error("no link template available for " + databaseId);
            return null;
        }
    }

    /**
     * Gets the <code>databaseId</code> attribute of the <code>LinkModule</code> object.
     *
     * @return The <code>databaseId</code> value.
     */
    protected String getDatabaseId() {
        return databaseId;
    }

    /**
     * Gets the <code>databaseId</code> attribute of the <code>LinkModule</code> class.
     *
     * @param descriptor Description of parameter.
     *
     * @return The <code>databaseId</code> value.
     */
    public static String getDatabaseId(String descriptor) {
        String databaseId = null;
        int index = descriptor.indexOf(":");
        if (index != -1) {
            String identifier = descriptor.substring(0, index);
            StringTokenizer stringTokenizer =
                new StringTokenizer(identifier, ",");

            // the identifier part can provide an id and a name
            if (stringTokenizer.countTokens() == 2) {
                stringTokenizer.nextToken();
                databaseId = stringTokenizer.nextToken();
            } else {
                databaseId = identifier;
            }
        }
        return databaseId;
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     * @param linkables Description of parameter.
     */
    public static void link(ContextData contextData, Collection linkables) {
        Iterator iterator = linkables.iterator();
        Linkable linkable;
        Link link;
        Map idLinkMap = new HashMap();
        Collection links;
        String id;
        while (iterator.hasNext()) {
            linkable = (Linkable) iterator.next();
            link = linkable.getLink();
            if (link != null) {
                Iterator idIterator = link.getIds().iterator();
                while (idIterator.hasNext()) {
                    id = (String) idIterator.next();
                    links = (Collection) idLinkMap.get(id);
                    if (links == null) {
                        links = new HashSet();
                        idLinkMap.put(id, links);
                    }
                    links.add(link);
                }
            }
        }
        iterator = idLinkMap.keySet().iterator();
        while (iterator.hasNext()) {
            id = (String) iterator.next();
            openLink(contextData, (Collection) idLinkMap.get(id), id);
        }
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public String getModuleIdPrefix() {
        return "LINK-";
    }

    /**
     * Class description.
     *
     * @author Karsten Klein, LION bioscience AG
     */
    public static class LinkTemplate {
        public String databaseId;
        public String name;
        public String template;

        /**
         * Constructor description.
         *
         * @param descriptor Parameter description.
         */
        public LinkTemplate(String descriptor) {
            create(descriptor);
        }

        /**
         * Method description.
         *
         * @param descriptor Parameter description.
         */
        public void create(String descriptor) {

            // parse link for name
            int index = descriptor.indexOf(":");
            if (index != -1) {
                String identifier = descriptor.substring(0, index);
                template = descriptor.substring(index + 1);
                StringTokenizer stringTokenizer =
                    new StringTokenizer(identifier, ",");

                // the identifier part can provide an id and a name
                if (stringTokenizer.countTokens() == 2) {
                    name = stringTokenizer.nextToken();
                    databaseId = stringTokenizer.nextToken();
                } else {
                    name = identifier;
                    databaseId = identifier;
                }
            } else {
                databaseId = "HTTP";
                name = "HTTP";
                template = "###";
            }
        }
    }
}
