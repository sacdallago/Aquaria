/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.annotation.creators;

import java.awt.Color;
import java.util.HashSet;
import java.util.Iterator;

import javax.media.j3d.Appearance;
import javax.media.j3d.BranchGroup;
import javax.media.j3d.ImageComponent2D;
import javax.media.j3d.Shape3D;
import javax.media.j3d.TransparencyAttributes;
import javax.vecmath.Point3f;

import org.srs3d.viewer.annotation.attributes.LayoutPosition;
import org.srs3d.viewer.annotation.contexts.AnnotationContextData;
import org.srs3d.viewer.annotation.objects.ChainAnnotation;
import org.srs3d.viewer.annotation.objects.Segment;
import org.srs3d.viewer.bioatlas.Parameter;
import org.srs3d.viewer.bioatlas.objects.Chain;
import org.srs3d.viewer.bioatlas.objects.Layer;
import org.srs3d.viewer.j3d.AppearanceHelper;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.creators.AbstractGeometryCreator;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.objects.Attribute;
import org.srs3d.viewer.objects.ObjectManager;
import org.srs3d.viewer.objects.State;
import org.srs3d.viewer.util.Log;

/**
 * Does the layout for the ChainAnnotation content. Explicit registrations are performed.
 *
 * @author Karsten Klein
 * @author Christian Zofka
 *
 * @created March 20, 2001
 * @modified July 08, 2001
 * @reviewed September 21, 2001
 */
public class ChainAnnotationGeometryCreator extends AbstractGeometryCreator {
    private static final Log log =
        new Log(ChainAnnotationGeometryCreator.class);

    /**
     * Description of the method
     *
     * @param object Description of parameter
     * @param branchGroup Description of parameter
     */
    public void create(AbstractObject object, BranchGroup branchGroup) {
        create((ChainAnnotation) object, branchGroup);
    }

    /**
     * Description of the method
     *
     * @param branchGroup Description of parameter
     * @param chainAnnotation Description of parameter.
     */
    public void create(ChainAnnotation chainAnnotation, BranchGroup branchGroup) {
        if (chainAnnotation != null) {
            Point3f position = new Point3f();
            Iterator iterator;
            State.Immutable immutableState;
            LayoutPosition.Immutable immutableLayoutPosition;
            State state;
            LayoutPosition layoutPosition;
            immutableState =
                getContextData().getStateManager().getImmutableState(chainAnnotation);
            immutableLayoutPosition =
                (LayoutPosition.Immutable) immutableState.getAttribute(LayoutPosition.class);
            if (immutableLayoutPosition != null) {
                position.set(immutableLayoutPosition.getPosition());
            }
            position.y -= 0.5f * Parameter.chainAnnotationHeight;

            // iterate over segments annotations and do layout stuff
            iterator = chainAnnotation.getSegments().iterator();
            Segment segment;
            while (iterator.hasNext()) {
                segment = (Segment) iterator.next();

                // modify layout position attribute of chain annotation state
                state = getContextData().getStateManager().getState(segment);
                layoutPosition =
                    (LayoutPosition) Attribute.getInstance(LayoutPosition.class);
                layoutPosition.setPosition(position);
                state.setAttribute(layoutPosition);
                getContextData().getStateManager().register(segment, state);
            }
            drawLabel(chainAnnotation, position, branchGroup);
        } else {
            log.error("chain annotation is null. No geometry created.");
        }
    }

    /**
     * Description of the method.
     *
     * @param chainAnnotation Description of parameter.
     * @param position Description of parameter.
     * @param branchGroup Description of parameter.
     */
    private void drawLabel(ChainAnnotation chainAnnotation, Point3f position,
        BranchGroup branchGroup) {
        String string = new String();
        Chain chain;
        Iterator iterator = chainAnnotation.getChains().iterator();
        while (iterator.hasNext()) {
            chain = (Chain) iterator.next();
            string += composeChainName(chain);
            if (iterator.hasNext()) {
                string += "|";
            }
        }
        if (string != "") {
            chainAnnotation.setName(string);
            if (string.length() > 20) {
                string = string.substring(0, 20) + "...";
            }
            ImageComponent2D image =
                getContextData().getLabelManager().getLabel(string,
                    new Color(240, 240, 240));
            javax.media.j3d.Raster raster = new javax.media.j3d.Raster();
            raster.setImage(image);
            raster.setSize(image.getWidth(), image.getHeight());

            //      Point3f textPosition = new Point3f( position.x, position.y + 5.8f, 0 );
            Point3f textPosition =
                new Point3f(position.x, position.y + 5.6f, 0);
            raster.setPosition(textPosition);
            Appearance appearance = new Appearance();
            AppearanceHelper.setDefaults(appearance);
            TransparencyAttributes transparencyAttributes =
                new TransparencyAttributes(TransparencyAttributes.BLENDED, 0.0f);
            appearance.setTransparencyAttributes(transparencyAttributes);
            Shape3D shape = new Shape3D(raster, appearance);
            shape.setPickable(false);
            branchGroup.addChild(shape);
        } else {

            // no label
        }
    }

    private String composeChainName(Chain chain) {
        String chainName = "";
        ContextData contextData =
            ((AnnotationContextData) getContextData()).getReferenceContextData();
        HashSet layers = new HashSet();
        contextData.getObjectManager().getUpAssociations(chain, layers);
        ObjectManager.extract(layers, Layer.class);
        if (layers.size() != 0) {
            Layer layer = (Layer) layers.iterator().next();
            if (!layer.isSequenceLayer()) {
                chainName += layer.getId().toUpperCase();
            }
        }
        if (chain.getCompound() != null && chain.getId() == Chain.INVALID_ID) {
            if (chainName.length() > 0) {
                chainName += ": ";
            }
            chainName += chain.getCompound().getMolecule();
        } else if (chain.getId() != Chain.INVALID_ID && chain.getId() != ' ') {
            if (chainName.length() > 0) {
                chainName += "-";
            }
            chainName += chain.getId();
        } else {
            if (chainName.length() == 0) {
                chainName = "noname";
            }
        }
        return chainName;
    }
}
