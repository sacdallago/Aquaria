/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.objects;

import java.util.Collection;
import java.util.HashSet;

import org.srs3d.viewer.objects.AbstractObject;

/**
 * Special <code>AbstractObject</code> implementation defining a <code>Site </code>. The
 * implementation contains only the intrinsic data of the object.
 *
 * @author Karsten Klein
 *
 * @created May 18, 2001
 */
public final class Site extends AbstractObject {

    /** Description of the field. */
    public static final int INVALID_ID = -1;

    /** Description of the field. */
    public static final int UNSPECIFIED_CONTENT = -1;

    /** Description of the field. */
    public static final int ACTIVE_SITE = 1;

    /** Description of the field. */
    public static final int DISULFIDEBOND_RESIDUES = 2;

    /** Description of the field. */
    public static final int EXCEPTIONAL_RESIDUES = 4;
    private int id = INVALID_ID;
    private String name = null;
    private int contentType = UNSPECIFIED_CONTENT;
    private HashSet residues = new HashSet();

    /**
     * Sets the <code>id</code> attribute of the <code>Site</code> object.
     *
     * @param id The new <code>id</code> value.
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Sets the <code>name</code> attribute of the <code>Site</code> object.
     *
     * @param name The new <code>name</code> value.
     */
    public void setName(String name) {
        this.name = new String(name);
    }

    /**
     * Sets the <code>contentType</code> attribute of the <code>Site</code> object.
     *
     * @param contentType The new <code>contentType</code> value.
     */
    public void setContentType(int contentType) {
        this.contentType = contentType;
    }

    /**
     * Gets the <code>id</code> attribute of the <code>Site</code> object.
     *
     * @return The <code>id</code> value.
     */
    public int getId() {
        return id;
    }

    /**
     * Gets the <code>name</code> attribute of the <code>Site</code> object.
     *
     * @return The <code>name</code> value.
     */
    public String getName() {
        return new String(name);
    }

    /**
     * Gets the <code>residues</code> attribute of the <code>Site</code> object.
     *
     * @return The <code>residues</code> value.
     */
    public Collection getResidues() {
        return residues;
    }

    /**
     * Gets the <code>allObjects</code> attribute of the <code>Site</code> object.
     *
     * @param collection Description of parameter.
     */
    public void getAllObjects(Collection collection) {
        collection.addAll(residues);
    }

    /**
     * Gets the <code>contentType</code> attribute of the <code>Site</code> object.
     *
     * @return The <code>contentType</code> value.
     */
    public int getContentType() {
        return contentType;
    }

    /**
     * Adds a <code>Residue</code> object to the <code>Site</code> object.
     *
     * @param residue The <code>Residue</code> object to be added.
     */
    public void addResidue(Residue residue) {
        if (residue != null) {
            residues.add(residue);
        }
    }

    /**
     * Description of the method.
     */
    public void cleanup() {
        super.cleanup();
        cleanup(residues);
        residues = null;
        id = INVALID_ID;
        name = null;
    }

    /**
     * Description of the method.
     *
     * @return Description of the returned value.
     */
    public String toString() {
        if (getName() != null) {
            return new String("Site " + getName());
        }
        return new String("Site <no name>");
    }
}
