/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.filters;

import org.srs3d.viewer.bioatlas.factories.AtomTemplateFactory;
import org.srs3d.viewer.bioatlas.objects.Atom;
import org.srs3d.viewer.bioatlas.objects.templates.AtomTemplate;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.objects.filters.ObjectClassFilter;

/**
 * Filter for extraction of backbone atoms. Backbone atoms are characterized by their
 * <code>AtomTemplate</code> s.
 *
 * @author Karsten Klein
 *
 * @created May 10, 2001
 */
public final class BackboneAtomFilter extends ObjectClassFilter {
    private AtomTemplate caTemplate = AtomTemplateFactory.getTemplate(" CA ");
    private AtomTemplate nTemplate = AtomTemplateFactory.getTemplate(" N  ");
    private AtomTemplate cTemplate = AtomTemplateFactory.getTemplate(" C  ");
    private AtomTemplate pTemplate = AtomTemplateFactory.getTemplate(" P  ");

    /**
     * <code>BackboneAtomFilter</code> constructor.
     */
    public BackboneAtomFilter() {
        super(Atom.class);
    }

    /**
     * Description of the method.
     *
     * @param object Description of parameter.
     *
     * @return Description of the returned value.
     */
    public boolean filter(AbstractObject object) {
        if (super.filter(object)) {
            AtomTemplate template = ((Atom) object).getTemplate();

            // ordered by frequency of occurence
            if (template == caTemplate) {
                return true;
            }
            if (template == nTemplate) {
                return true;
            }
            if (template == cTemplate) {
                return true;
            }
            if (template == pTemplate) {
                return true;
            }
        }
        return false;
    }
}
