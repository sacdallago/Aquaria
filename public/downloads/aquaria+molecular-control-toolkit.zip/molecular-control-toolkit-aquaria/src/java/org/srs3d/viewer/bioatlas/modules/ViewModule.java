/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.modules;

import java.awt.event.ActionEvent;

import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.operations.ParameterStringOperation;
import org.srs3d.viewer.objects.Operation;

/**
 * Applies a specified view.
 *
 * @author Karsten Klein
 *
 * @created August 18, 2003
 */
public class ViewModule extends ProcessModule {
    private String viewId;

    /**
     * Constructor description.
     *
     * @param name Parameter description.
     * @param contextData Parameter description.
     * @param viewId Parameter description.
     */
    public ViewModule(String name, ContextData contextData, String viewId) {
        super(name, contextData, true, true);
        this.viewId = viewId;
        setOperationSerializeable(false);
    }

    /**
     * Description of the method.
     *
     * @param e Description of parameter.
     */
    public void process(ActionEvent e) {
        Operation operation =
            new Operation(getContextData().getContext(),
                ResetModule.RESET_OPERATION, null);
        getContextData().getDispatcher().runDispatch(operation);
        operation =
            new ParameterStringOperation(getContextData().getContext(),
                RestoreModule.APPLY_VIEW_OPERATION, viewId);
        operation.setSerializable(false);
        getContextData().getDispatcher().runDispatch(operation);
    }

    /**
     * Description of the method.
     */
    public void cleanup() {
        super.cleanup();
        viewId = null;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public String getModuleIdPrefix() {
        return "VIEW-";
    }
}
