/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.behaviors;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

import javax.media.j3d.WakeupCriterion;

import org.srs3d.viewer.j3d.ContextData;

/**
 * This abstract class intends to achive more lightweight mouse behaviors as subclasses.
 * The processStimulus is specialized on mouseEvent handling.
 *
 * @author Karsten Klein
 *
 * @created March 20, 2001
 */
public abstract class MouseBehavior extends AwtBehavior
    implements MouseMotionListener, MouseListener {
    public static final int MAX_DELTA = 20;

    /**
     * <code>MouseBehavior</code> contructor.
     *
     * @param context the context the behavior operates in.
     */
    public MouseBehavior(ContextData contextData) {
        setContextData(contextData);
        contextData.getContext().addMouseListener(this);
        contextData.getContext().addMouseMotionListener(this);
    }

    /**
     * The processStimulus method is the only method override from the AwtBehavior. It
     * processes the criteria down to a <code>MouseEvent</code> instance (if possible).
     * Subclasses therefore have to implement the method <code>public void
     * processStimulus( java.awt.event.MouseEvent )</code> .
     *
     * @param wakeup criterion to process.
     */
    public void processStimulus(WakeupCriterion wakeup) {

        // :NOTE: this was replaced by the mouse listener processing
        //    MouseEvent mouseEvent;
        //    AWTEvent[] event;
        //
        //    event = ( ( WakeupOnAWTEvent ) wakeup ).getAWTEvent();
        //
        //    // process all events
        //    for ( int i = 0; i < event.length; i++ ) {
        //
        //      mouseEvent = ( MouseEvent ) event[i];
        //
        //      if ( !mouseEvent.isConsumed() ) {
        //
        //        processStimulus( mouseEvent );
        //
        //      }
        //
        //    }
    }

    /**
     * Method description.
     *
     * @param mouseEvent Parameter description.
     */
    public abstract void processStimulus(java.awt.event.MouseEvent mouseEvent);

    /**
     * Method description.
     *
     * @param mouseEvent Parameter description.
     */
    public void mouseMoved(MouseEvent mouseEvent) {
        processStimulus(mouseEvent);
    }

    /**
     * Method description.
     *
     * @param mouseEvent Parameter description.
     */
    public void mouseDragged(MouseEvent mouseEvent) {
        processStimulus(mouseEvent);
        processConstraints();
    }

    /**
     * Method description.
     *
     * @param mouseEvent Parameter description.
     */
    public void mouseClicked(MouseEvent mouseEvent) {
        processStimulus(mouseEvent);
        processConstraints();
    }

    /**
     * Method description.
     *
     * @param mouseEvent Parameter description.
     */
    public void mouseEntered(MouseEvent mouseEvent) {
        processStimulus(mouseEvent);
    }

    /**
     * Method description.
     *
     * @param mouseEvent Parameter description.
     */
    public void mouseExited(MouseEvent mouseEvent) {
        processStimulus(mouseEvent);
    }

    /**
     * Method description.
     *
     * @param mouseEvent Parameter description.
     */
    public void mousePressed(MouseEvent mouseEvent) {
    	Runnable runnable = (Runnable) getContextData().getProperty("mousePressed");
    	if (runnable != null) {
    		runnable.run();
    	}
        processStimulus(mouseEvent);
        processConstraints();
    }

    /**
     * Method description.
     *
     * @param mouseEvent Parameter description.
     */
    public void mouseReleased(final MouseEvent mouseEvent) {
    	Runnable runnable = (Runnable) getContextData().getProperty("mouseReleased");
    	if (runnable != null) {
    		runnable.run();
    	}
        processStimulus(mouseEvent);
        processConstraints();
    }
}
