/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.modules;

import java.awt.event.ActionEvent;
import java.util.Iterator;

import org.srs3d.viewer.bioatlas.objects.Layer;
import org.srs3d.viewer.bioatlas.styles.Style;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.DispatchManager;
import org.srs3d.viewer.j3d.commands.SpawnCommand;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.objects.ObjectContainer;
import org.srs3d.viewer.objects.Operation;
import org.srs3d.viewer.objects.StrategyManager;
import org.srs3d.viewer.objects.filters.ObjectClassFilter;
import org.srs3d.viewer.objects.visitors.ObjectCollector;

/**
 * Applies a give <code>Style</code> style to the specified container.
 *
 * @author Karsten Klein
 *
 * @created July 11, 2001
 */
public class StyleModule extends ProcessModule {
    private Style style;

    /**
     * <code>CommandModule</code> constructor.
     *
     * @param name Description of parameter.
     * @param context Description of parameter.
     * @param style Description of parameter.
     */
    public StyleModule(String name, ContextData contextData, Style style) {
        super(name, contextData, true, true);
        this.style = style;
    }

    /**
     * Description of the method.
     *
     * @param e Description of parameter.
     */
    public void process(ActionEvent e) {
        getContextData().getContext().addUpdateCallback(new org.srs3d.viewer.j3d.behaviors.UpdateBehavior.Callback() {
                public void execute() {
                    ContextData contextData = getContextData();
                    ObjectContainer objectContainer =
                        contextData.getObjectContainer();
                    ObjectCollector objectCollector =
                        new ObjectCollector(new ObjectClassFilter(Layer.class));
                    objectCollector.visit((AbstractObject) objectContainer);
                    Iterator iterator = objectCollector.getObjects().iterator();
                    Layer layer;
                    StrategyManager strategyManager =
                        contextData.getStrategyManager();
                    SpawnCommand spawnCommand = new SpawnCommand(contextData);
                    getComputation().setComputation(strategyManager);
                    while (iterator.hasNext()) {
                        layer = (Layer) iterator.next();
                        strategyManager.setCancelEnable(false);
                        style.applyStateChange(layer);
                        strategyManager.execute(layer, spawnCommand);
                        style.applyColorScheme(layer);
                    }
                    getContextData().setProperty("STYLE", style);
                    org.srs3d.viewer.bioatlas.Capture.updateSelections(getContextData(),
                        true);
                    ColorSchemeModule.updateLegendOverlay(contextData,
                        contextData.getColorSchemeBucket().getInformation(null));
                    strategyManager.resetComputation();
                    DispatchManager.dispatch(contextData.getContext(),
                        new Operation(contextData.getContext(),
                            "UPDATE_COLORING", null));
                    strategyManager.setCancelEnable(true);
                    getComputation().setComputation(null);
                }
            });
        getContextData().getContext().waitForUpdate();

        // overwrite preannotationbucket of annotation activation module
        getContextData().setProperty("PreAnnotationBucket", null);
    }

    /**
     * Description of the method.
     */
    public void cleanup() {
        super.cleanup();
        style = null;
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     * @param style Parameter description.
     */
    public static void applyStateChange(ContextData contextData, Style style) {
        ObjectContainer objectContainer = contextData.getObjectContainer();
        ObjectCollector objectCollector =
            new ObjectCollector(new ObjectClassFilter(Layer.class));
        objectCollector.visit((AbstractObject) objectContainer);
        Iterator iterator = objectCollector.getObjects().iterator();
        Layer layer;
        StrategyManager strategyManager = contextData.getStrategyManager();
        while (iterator.hasNext()) {
            layer = (Layer) iterator.next();
            style.applyStateChange(layer);
        }
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     * @param style Parameter description.
     */
    public static void applyColorScheme(ContextData contextData, Style style) {
        ObjectContainer objectContainer = contextData.getObjectContainer();
        ObjectCollector objectCollector =
            new ObjectCollector(new ObjectClassFilter(Layer.class));
        objectCollector.visit((AbstractObject) objectContainer);
        Iterator iterator = objectCollector.getObjects().iterator();
        Layer layer;
        StrategyManager strategyManager = contextData.getStrategyManager();
        while (iterator.hasNext()) {
            layer = (Layer) iterator.next();
            style.applyColorScheme(layer);
        }
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public String getModuleIdPrefix() {
        return "STYLE-";
    }
}
