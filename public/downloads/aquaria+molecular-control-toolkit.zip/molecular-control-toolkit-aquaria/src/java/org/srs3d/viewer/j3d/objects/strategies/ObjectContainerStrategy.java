/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.objects.strategies;

import org.srs3d.viewer.j3d.Reaction;
import org.srs3d.viewer.j3d.commands.ComputeCenterCommand;
import org.srs3d.viewer.j3d.commands.IdentificationCommand;
import org.srs3d.viewer.objects.Command;
import org.srs3d.viewer.objects.ObjectContainer;

/**
 * @author Karsten Klein
 *
 * @created April 03, 2001
 */
public class ObjectContainerStrategy extends AbstractStrategy {

    /**
     * Constructor description.
     */
    public ObjectContainerStrategy() {
        register(ComputeCenterCommand.class, new ComputeCenterReaction());
        register(IdentificationCommand.class, new IdentificationReaction());
    }

    /**
     * Class description.
     *
     * @author Karsten Klein, LION bioscience AG
     */
    public static class ComputeCenterReaction implements Reaction {

        /**
         * Method description.
         *
         * @param command Parameter description.
         */
        public void execute(Command command) {
            ObjectContainer objectContainer =
                (ObjectContainer) command.getObject();
            ComputeCenterCommand computeCenterCommand =
                (ComputeCenterCommand) command;
            computeCenterCommand.getContextData().getStrategyManager().execute(objectContainer.getObjects(),
                command);
        }
    }

    /**
     * Reaction for retrieving the object identification.
     *
     * @author Karsten Klein
     *
     * @created March 26, 2002
     */
    public static class IdentificationReaction implements Reaction {

        /**
         * Execute implementation of the reaction interface.
         *
         * @param command Command to react to.
         */
        public void execute(Command command) {
            IdentificationCommand idCommand = (IdentificationCommand) command;
            ObjectContainer object = (ObjectContainer) command.getObject();

            //      ArrayList containers = new ArrayList();
            //      ObjectManager.extract( idCommand.getObjects(), containers, ObjectContainer.class );
            //      if ( !containers.isEmpty() ) {
            //        ObjectContainer parent = null;
            //        int index;
            //
            //        for ( int i = containers.size(); --i >= 0; ) {
            //
            //          parent = (ObjectContainer) containers.get( i );
            //          containers.clear();
            //
            //          ObjectManager.extract( parent.getObjects(), containers, ObjectContainer.class );
            //          index = containers.indexOf( object );
            //
            //          if ( index != -1 ) {
            //
            //            idCommand.setObjectId( "OC:" + object.getName() + "#" + index );
            //
            //            i = 0;
            //
            //          }
            //
            //        }
            //
            //      }
            idCommand.setObjectId("OC:" + object.getName());
            idCommand.execute();
        }
    }
}
