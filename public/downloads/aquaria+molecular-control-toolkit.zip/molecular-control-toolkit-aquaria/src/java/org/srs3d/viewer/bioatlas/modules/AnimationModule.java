/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.modules;

import java.awt.event.ActionEvent;

import javax.swing.JCheckBoxMenuItem;

import org.srs3d.viewer.bioatlas.contexts.MoleculeContext;
import org.srs3d.viewer.j3d.ContextData;

/**
 * @author Karsten Klein
 *
 * @created May 14, 2001
 */
public class AnimationModule extends CheckModule {
    public static boolean isEnabledOverwrite = true;

    /**
     * <code>ResetModule</code> constructor.
     *
     * @param name Description of parameter.
     * @param context Description of parameter.
     */
    public AnimationModule(String name, ContextData contextData) {
        super(name, contextData);
    }

    /**
     * Description of the method.
     */
    public void updateIntern() {
        JCheckBoxMenuItem component = getCheckComponent();
        if (component != null) {
            if (getContextData().getContext().getClass() == MoleculeContext.class) {
                MoleculeContext context =
                    (MoleculeContext) getContextData().getContext();
                component.setState(context.isAnimated());
                component.setEnabled(true);
            } else {
                component.setEnabled(false);
                component.setState(false);
            }
        }
    }

    /**
     * Description of the method.
     *
     * @param e Description of parameter.
     */
    public void react(ActionEvent e) {
        MoleculeContext context =
            (MoleculeContext) getContextData().getContext();
        if (context.isAnimated()) {
            context.stopAnimation();
        } else {
            if (getContextData().getProperty("ANIMATE-DISABLE-RESET") == null) {
            	if (getName().equals("GoCrazy")) {
	                org.srs3d.viewer.j3d.behaviors.LookAtXYBehavior.deltaX = 40;
	                org.srs3d.viewer.j3d.behaviors.LookAtXYBehavior.deltaY = 50;
	                org.srs3d.viewer.j3d.behaviors.LookAtBehavior.deltaZ =30;
            	}
            	else {
            		
	                org.srs3d.viewer.j3d.behaviors.LookAtXYBehavior.deltaX = 1;
	                org.srs3d.viewer.j3d.behaviors.LookAtXYBehavior.deltaY = 0;
	                org.srs3d.viewer.j3d.behaviors.LookAtBehavior.deltaZ = 0;
            	}
            }
            context.startAnimation(1.0f / 180, 1.0f / 180, 1.0f / 180);
        }
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     * @param isDisableReset Parameter description.
     */
    public static void setDisableReset(ContextData contextData,
        boolean isDisableReset) {
        contextData.setProperty("ANIMATE-DISABLE-RESET",
            isDisableReset ? "on" : null);
    }
}
