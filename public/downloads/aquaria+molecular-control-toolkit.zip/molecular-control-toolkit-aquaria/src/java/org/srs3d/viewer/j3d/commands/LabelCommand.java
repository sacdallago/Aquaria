/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.commands;

import java.util.Iterator;

import javax.vecmath.Point3f;
import javax.vecmath.Vector3f;

import org.srs3d.viewer.bioatlas.attributes.Labeled;
import org.srs3d.viewer.j3d.Colorable;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.objects.Label;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.objects.Attribute;
import org.srs3d.viewer.objects.ObjectContainer;
import org.srs3d.viewer.objects.ObjectManager;
import org.srs3d.viewer.objects.State;
import org.srs3d.viewer.objects.StateManager;
import org.srs3d.viewer.objects.StrategyManager;
import org.srs3d.viewer.objects.visitors.ObjectLocalizer;

/**
 * Label command.
 *
 * @author Karsten Klein
 *
 * @created April 03, 2001
 */
public class LabelCommand extends ObjectCommand {
    private String labelString = null;
    private boolean isLabel = true;
    private ObjectContainer objectContainer = null;

    /**
     * <code>LabelCommand</code> constructor.
     *
     * @param contextData Description of parameter.
     * @param labelString Description of parameter.
     * @param isLabel Description of parameter.
     */
    public LabelCommand(ContextData contextData, String labelString,
        boolean isLabel) {
        super(contextData);
        this.labelString = labelString;
        this.isLabel = isLabel;
    }

    /**
     * Sets the <code>labelContainer</code> attribute of the <code>LabelCommand</code>
     * object.
     *
     * @param objectContainer The new <code>labelContainer</code> value.
     */
    public void setLabelContainer(ObjectContainer objectContainer) {
        this.objectContainer = objectContainer;
    }

    /**
     * Sets the <code>labelString</code> attribute of the <code>LabelCommand</code>
     * object.
     *
     * @param labelString The new <code>labelString</code> value.
     */
    public void setLabelString(String labelString) {
        this.labelString = labelString;
    }

    /**
     * Gets the <code>labelString</code> attribute of the <code>LabelCommand</code>
     * object.
     *
     * @return The <code>labelString</code> value.
     */
    public String getLabelString() {
        return labelString;
    }

    /**
     * Excecutes the <code>LabelCommand</code>.
     */
    public void execute() {
        StateManager stateManager = getContextData().getStateManager();
        State.Immutable immutabelState =
            stateManager.getImmutableState(getObject());
        if (isLabel) {
            if (!immutabelState.hasAttribute(Labeled.class)) {

                // label the objects
                Labeled labeled =
                    (Labeled) Attribute.getInstance(Labeled.class);
                Label label = labelObject();
                labeled.setLabel(label);
                State state = immutabelState.getCopy();
                state.setAttribute(labeled);
                stateManager.register(getObject(), state);
            }
        } else {
            Labeled.Immutable labeled =
                (Labeled.Immutable) immutabelState.getAttribute(Labeled.class);
            if (labeled != null) {
                State state = immutabelState.getCopy();
                state.removeAttribute(Labeled.class);
                stateManager.register(getObject(), state);
                if (labeled.getLabel() != null) {
                    ObjectLocalizer localizer = new ObjectLocalizer();
                    localizer.setSearchObject(labeled.getLabel());
                    localizer.visit((AbstractObject) getContextData()
                                                         .getObjectContainer());
                    ObjectManager.extract(localizer.getObjects(),
                        ObjectContainer.class);
                    Iterator iterator = localizer.getObjects().iterator();
                    ObjectContainer objectContainer;
                    while (iterator.hasNext()) {
                        objectContainer = (ObjectContainer) iterator.next();
                        objectContainer.removeObject(labeled.getLabel());
                    }

                    // remove label
                    getContextData().getSpawnerManager().remove(labeled.getLabel());
                    getContextData().getShapeManager().remove(labeled.getLabel());
                }
            }
        }
    }

    /**
     * Description of the method.
     *
     * @return Description of the returned value.
     */
    private Label labelObject() {
        ContextData contextData = getContextData();
        AbstractObject object = getObject();
        StrategyManager strategyManager = contextData.getStrategyManager();
        ComputeCenterCommand computeCenterCommand =
            new ComputeCenterCommand(contextData);
        strategyManager.execute(object, computeCenterCommand);
        Point3f center = computeCenterCommand.getCenter();
        Vector3f extend = computeCenterCommand.getExtend();
        float offset = extend.length();
        Vector3f alignment = new Vector3f(0, 0, 0);
        Label label = new org.srs3d.viewer.j3d.objects.Label();
        if (getLabelString() != null) {
            label.setString(getLabelString());
        } else {
            label.setString(object.toString());
        }
        label.getCoordinate().set(center);
        label.setAlignment(alignment);
        if (object instanceof Colorable) {
            label.setColor(((Colorable) object).getColor());
        }
        RegisterCommand registerCommand = new RegisterCommand(contextData);
        registerCommand.setParent(objectContainer);
        registerCommand.setMode(RegisterCommand.UP);
        strategyManager.execute(label, registerCommand);
        SpawnCommand spawnCommand = new SpawnCommand(contextData);
        spawnCommand.setParent(objectContainer);
        strategyManager.execute(label, spawnCommand);
        objectContainer.addObject(label);
        return label;
    }
}
