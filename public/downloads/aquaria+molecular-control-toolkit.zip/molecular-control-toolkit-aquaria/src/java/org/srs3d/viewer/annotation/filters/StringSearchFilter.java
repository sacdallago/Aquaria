/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.annotation.filters;

import java.util.Collection;
import java.util.Vector;

import org.srs3d.viewer.bioatlas.objects.Residue;

/**
 * performs stringsearch over a sequence of residues
 *
 * @author Christian Zofka
 *
 * @created September 13, 2001
 * @modified February 07, 2002
 */
public final class StringSearchFilter {

    // indicies for the loop
    private int stringIndex;
    private int sequenceIndex;
    private String searchString;

    // collection of all matches
    private Collection finalResult = new Vector();

    /**
     * <code>StringSearchFilter</code> constructor.
     *
     * @param string Description of parameter.
     */
    public StringSearchFilter(String string) {
        searchString = string;
    }

    /**
     * Sets the <code>searchString</code> attribute of the
     * <code>StringSearchFilter</code> object.
     *
     * @param string The new <code>searchString</code> value.
     */
    public void setSearchString(String string) {
        searchString = string;
    }

    /**
     * searches in a gapSequence of residues for the preset searchString; handles ? (any
     * possible residue but not null) and  (any possible collection of residues,
     * including 0); notice: residues that are standing for  are not selected
     *
     * @param sequence gapSequence
     *
     * @return Collection of search hits
     */
    public Collection filter(Vector sequence) {
        if (searchString.length() > 0) {
            Collection result = new Vector();
            finalResult.clear();
            stringIndex = 0;
            Residue residue;
            for (sequenceIndex = 0; sequenceIndex < sequence.size();
                  sequenceIndex++) {
                residue = (Residue) sequence.elementAt(sequenceIndex);
                if (residue != null) {
                    if ((searchString.charAt(stringIndex) == '?') ||
                          (searchString.toLowerCase().charAt(stringIndex) == 'x')) {
                        stringIndex++;
                        result.add(residue);
                    } else if ((searchString.charAt(stringIndex) == '*')) {
                        stringIndex++;
                        Vector subSequence = new Vector();
                        subSequence.addAll(sequence.subList(sequenceIndex,
                                sequence.size() - 1));
                        if (stringIndex < searchString.length()) {
                            String subSearchString =
                                searchString.substring(stringIndex,
                                    searchString.length());
                            StringSearchFilter subFilter =
                                new StringSearchFilter(subSearchString);
                            Collection subResult =
                                subFilter.filter(subSequence);
                            if (subResult.isEmpty()) {
                                return finalResult;
                            } else {
                                result.addAll(subResult);

                                // if u want only the 1. hit:
                                // return result;
                                finalizeMatch(result);
                            }
                        } else {

                            // we do have a xxxxxxx* searchString
                            // if u want only the 1. hit:
                            // return result;
                            finalizeMatch(result);
                        }
                    } else if (residue.getTemplate().getSingleLetterCode()
                                        .toLowerCase().charAt(0) == searchString.toLowerCase()
                                                                                  .charAt(stringIndex)) {
                        stringIndex++;
                        result.add(residue);
                    } else if (stringIndex > 0) {

                        // not a full match -> reseting search variables, starting 1 pos after last beginning of hit
                        sequenceIndex -= stringIndex;
                        stringIndex = 0;
                        result.clear();
                    }
                    if (stringIndex == searchString.length()) {

                        // if u want only the 1. hit:
                        // return result;
                        finalizeMatch(result);
                    }
                }
            }
        }
        return finalResult;
    }

    /**
     * add result to all matches, resets local variables
     *
     * @param result recent match
     */
    private void finalizeMatch(Collection result) {
        finalResult.addAll(result);
        result.clear();
        sequenceIndex -= stringIndex - 1;
        stringIndex = 0;
    }
}
