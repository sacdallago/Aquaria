/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.visitors;

import java.util.Collection;
import java.util.Iterator;
import java.util.Vector;

import org.srs3d.viewer.bioatlas.objects.ChainFragment;
import org.srs3d.viewer.bioatlas.objects.Coil;
import org.srs3d.viewer.bioatlas.objects.Helix;
import org.srs3d.viewer.bioatlas.objects.NucleicChain;
import org.srs3d.viewer.bioatlas.objects.Residue;
import org.srs3d.viewer.bioatlas.objects.Section;
import org.srs3d.viewer.bioatlas.objects.Strand;
import org.srs3d.viewer.bioatlas.objects.Subchain;
import org.srs3d.viewer.bioatlas.objects.Turn;
import org.srs3d.viewer.util.Log;

/**
 * This class checks the secondary structure annotations of chains. It searches for
 * multiple annotations and deletes them.
 *
 * @author Karsten Klein, 01/2001
 *
 * @created March 22, 2001
 * @since 1.0
 */
public class SubchainAnalyser {
    private static final Log log = new Log(SubchainAnalyser.class);

    /**
     * Method description.
     *
     * @param chainFragments Parameter description.
     */
    public void visit(Collection chainFragments) {
        Iterator iterator = chainFragments.iterator();
        while (iterator.hasNext()) {
            visit((ChainFragment) iterator.next());
        }
    }

    /**
     * Checks the chain associated subchains for multiple annotation.
     *
     * @param chain the chain to visit
     */
    public void visit(ChainFragment chain) {
        boolean criteria = !chain.isLigand();

        // we allow single residue chains with certain properties (check 1byt)
        if (!criteria && chain.getLength() == 1) {
            if (chain.getInitialResidue().refCA != null) {
                criteria = true;
            }

            // this captures ligands with a ca atom (check 6mht)
            if (chain.getInitialResidue().getPreceeding() == null &&
                  chain.getInitialResidue().getPreceeding() == null) {
                criteria = false;
            }
        }
        if (criteria) {
            int chainLength = chain.getLength();
            int i;
            int j;

            // compute a residue to secondary structure map
            Residue[] residues = new Residue[chainLength];
            char[] residueSubchainCodes = new char[chainLength];
            int[] residueSubchainSerials = new int[chainLength];

            // index all residues in the chain and preclassify to coil
            Residue residue;
            Residue limit;
            residue = chain.getInitialResidue();
            for (i = 0; i < chainLength; i++) {
                residues[i] = residue;
                residueSubchainCodes[i] = Coil.CODE;
                residueSubchainSerials[i] = Subchain.INVALID_SERIAL;
                residue = residue.getProceeding();
            }
            Vector subchains = chain.getSubchains();
            int subchainCount = subchains.size();
            Subchain subchain;
            char subchainCode = Coil.CODE;
            j = 0;

            // the residues are supposed to be ordered, same with the subchains
            // :NOTE: the assumption may be violated and a violation will be detected
            //   and resolved in the subsequent code.
            //   Unhandled other violations will result in a error message.
            // iterate through all subchains of the chain
            for (i = 0; i < subchainCount; i++) {
                subchain = (Subchain) subchains.elementAt(i);
                residue = subchain.getInitialResidue();
                limit = subchain.getEndResidue();

                // check initial and end residue
                if (residue == null || limit == null) {
                    log.error("subchain starting residue is null!");
                    log.error(chain);
                    log.error(subchain);
                }

                // iterate over subchain residues
                limit = limit.getProceeding();
                while (residue != null && residue != limit) {

                    // detect ordering assumption violation/find appropriate index
                    if (j < 0 || j >= residues.length ||
                          residues[j] != residue) {

                        // restart search in chain residue list
                        j = chain.computeResidueIndex(residue);
                    }
                    if (j >= 0 && j < residues.length) {
                        subchainCode = subchain.getCode();
                        if (subchainCode != residueSubchainCodes[j]) {
                            if (residueSubchainCodes[j] == Coil.CODE) {

                                // overwrite coils only
                                residueSubchainCodes[j] = subchainCode;
                                residueSubchainSerials[j] =
                                    subchain.getSerial();
                            } else {

                                // set unspecified in case of a conflict
                                residueSubchainCodes[j] = Subchain.CODE;
                                residueSubchainSerials[j] =
                                    Subchain.INVALID_SERIAL;

                                // this replaces the current code by the new one
                                // residueSubchainCodes[ j ] = subchainCode;
                            }
                        }
                    } else {

                        // this occurs mostly when the chain was splitted by the ChainAnalyzer
                        // just ignore it.
                        // the residue is in the subchain but not in the chain
                    }
                    residue = residue.getProceeding();
                    j++;
                }
            }

            // built full secondary structure data structure
            builtSecondaryStructure(chain, residueSubchainCodes,
                residueSubchainSerials);
            numberSubchains(chain);
        } else {
            chain.getSubchains().clear();
        }
    }

    /**
     * Builts the resulting valid secondary structure annotation.
     *
     * @param chain the chain receives new subchain instances that suit the new
     *        annotation.
     * @param residueSubchainCodes residue to secondary structure map to extract the new
     *        annotation from.
     * @param residueSubchainSerials Description of parameter.
     */
    public void builtSecondaryStructure(ChainFragment chain,
        char[] residueSubchainCodes, int[] residueSubchainSerials) {
        Vector subchains = chain.getSubchains();
        Subchain subchain = null;
        int i = 0;
        Residue residue = chain.getInitialResidue();
        Residue limit = chain.getEndResidue().getProceeding();
        subchains.clear();

        // make unspecified residues to coil residues
        for (i = 0; i < residueSubchainCodes.length; i++) {
            if (residueSubchainCodes[i] == Subchain.CODE) {
                residueSubchainCodes[i] = Coil.CODE;
            }
        }
        i = 0;
        while (residue != limit) {
            if (subchain == null) {

                // start new chain
                subchain =
                    startSubchain(residueSubchainCodes[i],
                        residueSubchainSerials[i], residue);
                residue = residue.getProceeding();
                i++;
            } else {
                if (residueSubchainCodes[i] != subchain.getCode()) {

                    //        if ( residueSubchainCodes[i] != subchain.getCode() || subchain.getCode() == Section.CODE ) {
                    subchain =
                        finalizeSubchain(chain, subchain, residue, true,
                            residueSubchainCodes[i], residueSubchainSerials[i]);
                } else {
                    if (residueSubchainSerials[i] != subchain.getSerial()) {
                        subchain =
                            finalizeSubchain(chain, subchain, residue, true,
                                residueSubchainCodes[i],
                                residueSubchainSerials[i]);
                    } else {
                        subchain.setEndResidue(residue);
                    }
                }
                if (subchain != null) {

                    // detect conflict in serials
                    if (subchain.getSerial() != Subchain.INVALID_SERIAL) {
                        if (residueSubchainCodes[i] != subchain.getSerial()) {

                            // invalidate serial
                            //              subchain.setSerial( Subchain.INVALID_SERIAL );
                        }
                    }
                    residue = residue.getProceeding();
                    i++;
                }
            }
        }

        // finalize last pending subchain:
        subchain =
            finalizeSubchain(chain, subchain, residue, false, Subchain.CODE,
                Subchain.INVALID_SERIAL);
    }

    /**
     * Finalizes a subchain. This method is part of the
     * <code>builtSecondaryStructure()</code> algorithm.
     *
     * @param chain identifies the chain to add the finalized subchain to.
     * @param subchain the subchain to finalize.
     * @param residue the last residue to end the current subchain or to start a new
     *        subchain with.
     * @param startNew flag to indicate if a new subchain should be started.
     * @param code Description of parameter.
     * @param serial Description of parameter.
     *
     * @return <code>Subchain</code> - In case of a finalization a none-coil subchain we
     *         need to start a coil with the residue that finished the subchain.
     */
    private Subchain finalizeSubchain(ChainFragment chain, Subchain subchain,
        Residue residue, boolean startNew, char code, int serial) {

        // check whether chain and subchain are present
        if (chain != null && subchain != null) {

            // finalize (nucleic test) subchain and add it to the chains subchain list
            if (chain.isNucleic()) {
                NucleicChain nucleicChain = new NucleicChain();
                nucleicChain.setInitialResidue(subchain.getInitialResidue());
                nucleicChain.setEndResidue(subchain.getEndResidue());
                nucleicChain.setSerial(subchain.getSerial());
                chain.addSubchain(nucleicChain);
                subchain = nucleicChain;
            } else {
                chain.addSubchain(subchain);
            }
            if (subchain.getCode() != code && startNew) {

                // start a new coil with same residue as the none-coil subchain ended
                return startSubchain(code, serial, residue);
            }
        }
        return null;
    }

    /**
     * Starts a new subchain. This method is part of the
     * <code>builtSecondaryStructure()</code> algorithm.
     *
     * @param subchainCode the subchain identification code. It's used to instantiate the
     *        appropriate subchain type.
     * @param residue initial residue of the new subchain.
     * @param serial Description of parameter.
     *
     * @return <code>Subchain</code> - the new started subchain instance.
     */
    private Subchain startSubchain(char subchainCode, int serial,
        Residue residue) {
        Subchain subchain = Subchain.getNewInstance(subchainCode);
        subchain.setInitialResidue(residue);
        subchain.setEndResidue(residue);
        subchain.setSerial(serial);
        return subchain;
    }

    /**
     * Description of the method.
     *
     * @param chain Description of parameter.
     */
    private void numberSubchains(ChainFragment chain) {
        int helixIndex = 1;
        int strandIndex = 1;
        int turnIndex = 1;
        int coilIndex = 1;
        int sectionIndex = 1;
        Iterator iterator = chain.getSubchains().iterator();
        Subchain subchain;
        while (iterator.hasNext()) {
            subchain = (Subchain) iterator.next();
            switch (subchain.getCode()) {

                case Helix.CODE:
                    subchain.setId(new Integer(helixIndex).toString());
                    helixIndex++;
                    break;

                case Strand.CODE:
                    subchain.setId(new Integer(strandIndex).toString());
                    strandIndex++;
                    break;

                case Turn.CODE:
                    subchain.setId(new Integer(turnIndex).toString());
                    turnIndex++;
                    break;

                case Coil.CODE:
                    subchain.setId(new Integer(coilIndex).toString());
                    coilIndex++;
                    break;

                case Section.CODE:
                    subchain.setId(new Integer(sectionIndex).toString());
                    sectionIndex++;
                    break;

                default:}
        }
    }
}
