/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.modules;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.util.Collection;
import java.util.Iterator;

import javax.swing.JCheckBoxMenuItem;

import org.srs3d.viewer.j3d.ColorScheme;
import org.srs3d.viewer.j3d.ColorSchemeBucket;
import org.srs3d.viewer.j3d.ColorSchemeManager;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.commands.ColorCommand;
import org.srs3d.viewer.objects.AbstractObject;

/**
 * Special implementation of the ColorSchemeModule for applying colorschemes. This Module
 * implementation provides a checkbox rather than a simple menu item. The provided
 * colorschemes are added to the object buckets when switching on and removed when
 * switching off.
 *
 * @author Karsten Klein
 *
 * @created May 14, 2001
 * @reviewed February 06, 2002
 */
public class ColorSchemeCheckModule extends ColorSchemeModule {
    private JCheckBoxMenuItem component = null;
    private boolean isChecked = false;
    private boolean isEnabled = false;

    /**
     * <code>ColorSchemeCheckModule</code> constructor.
     *
     * @param name Name of the menu entry.
     * @param contextData ContextData the module operates on.
     * @param colorScheme Colorscheme to use for switching on/off.
     */
    public ColorSchemeCheckModule(String name, ContextData contextData,
        ColorScheme colorScheme) {
        super(name, contextData, colorScheme);
    }

    /**
     * <code>ColorSchemeCheckModule</code> constructor.
     *
     * @param name Name of the menu entry.
     * @param contextData ContextData of the module.
     * @param colorSchemeBucket ColorSchemeBucket for switching on/off.
     */
    public ColorSchemeCheckModule(String name, ContextData contextData,
        ColorSchemeBucket colorSchemeBucket) {
        super(name, contextData, colorSchemeBucket);
    }

    /**
     * Module interface implementation. We have to override it to have a checkbox menu
     * item.
     *
     * @return The AWT component for putting in the menu.
     */
    public Component getComponent() {
        if (component == null) {
            component = new JCheckBoxMenuItem(getName(), false);
            component.addActionListener(this);
        }
        return component;
    }

    /**
     * Processes the event (e.g. the menu item was chosen).
     *
     * @param e Event instance.
     */
    public void process(ActionEvent e) {
        if (isEnabled) {
            ColorCommand colorCommand =
                new ColorCommand(getContextData(), getColorSchemeBucket());
            colorCommand.setRemoving(isChecked);
            colorCommand.setForceRecoloring(!isChecked);
            process(colorCommand);
            getContextData().getContext().addUpdateCallback(new org.srs3d.viewer.j3d.behaviors.UpdateBehavior.Callback() {
                    public void execute() {
                        updateIntern();
                    }
                });
        }
    }

    /**
     * Method description.
     */
    public void updateIntern() {
        isChecked = false;
        isEnabled = true;
        Collection candidates =
            RepresentationModule.collectObjects(getContextData());
        if (!candidates.isEmpty()) {

            // check high level
            isChecked = check(candidates);
            if (!isChecked) {

                // check in detail
                candidates =
                    RepresentationCheck.extractDownAssociated(getContextData(),
                        candidates);
                isChecked = check(candidates);
            }
        }
        if (component != null) {
            component.setState(isChecked);
            component.setEnabled(isEnabled);
        }
    }

    /**
     * Checks the provided bucket for inclusion of the module bucket color schemes.
     *
     * @param bucket Bucket for checking.
     *
     * @return <code>true</code> if the module bucket is contained in the specified
     *         bucket.
     */
    private boolean check(ColorSchemeBucket bucket) {
        if (bucket != null) {
            if (bucket.isEmpty()) {
                return false;
            } else {
                return bucket.containsAll(getColorSchemeBucket());
            }
        }
        return false;
    }

    private boolean check(Collection objects) {
        ColorSchemeManager colorSchemeManager =
            getContextData().getColorSchemeManager();
        Iterator iterator = objects.iterator();
        ColorSchemeBucket bucket;
        Object object;
        while (iterator.hasNext()) {
            object = iterator.next();
            bucket =
                colorSchemeManager.getColorSchemeBucket((AbstractObject) object);
            if (check(bucket)) {
                return true;
            }
        }
        return false;
    }
}
