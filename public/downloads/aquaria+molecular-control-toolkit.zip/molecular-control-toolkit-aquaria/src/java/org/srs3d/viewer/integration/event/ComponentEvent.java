/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.integration.event;

import java.util.EventObject;

/**
 * Components can exchange events. This interface provides a base class for all component
 * events. Note that the sourceId that is needed for constructing the component should
 * enable to identify components in the systems.
 *
 * @author Karsten Klein
 *
 * @created September 23, 2002
 */
public class ComponentEvent extends EventObject {

    /**
     * Creates a new ComponentEvent object.
     */
    public ComponentEvent() {
        super("");
    }

    /**
     * Retrieves the sourceId attribute of the ComponentEvent object.
     *
     * @return The sourceId value.
     */
    public String getSourceId() {
        return (String) getSource();
    }

    /**
     * Description of the method.
     *
     * @param sourceId Parameter description.
     */
    public void setSourceId(String sourceId) {
        source = sourceId;
    }
}
