/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.loaders;

import java.io.InputStream;
import java.net.URL;

import javax.media.j3d.BranchGroup;

import org.srs3d.viewer.j3d.loaders.postscript.TextfileParser;

import com.sun.j3d.loaders.IncorrectFormatException;
import com.sun.j3d.loaders.ParsingErrorException;
import com.sun.j3d.loaders.Scene;
import com.sun.j3d.loaders.SceneBase;

/**
 * @author Karsten Klein, 11/2000
 *
 * @created September 6, 2001
 * @since 1.0
 */
public class Postscript extends GenericLoader {

    /**
     * Description of the method.
     *
     * @param url Description of parameter.
     *
     * @return Description of the returned value.
     */
    public Scene load(URL url)
        throws java.io.FileNotFoundException, IncorrectFormatException, 
            ParsingErrorException {
        try {
            InputStream in = url.openStream();
            TextfileParser parser = new TextfileParser(in);
            Scene scene = loadScene(parser);
            in.close();
            return scene;
        } catch (java.io.IOException e) {

            //      throw new RuntimeException( e.toString() );
        }
        return null;
    }

    /**
     * Description of the method.
     *
     * @param filename Description of parameter.
     *
     * @return Description of the returned value.
     *
     * @exception java.io.FileNotFoundException Description of exception.
     * @exception IncorrectFormatException Description of exception.
     * @exception ParsingErrorException Description of exception.
     */
    public Scene load(String filename)
        throws java.io.FileNotFoundException, IncorrectFormatException, 
            ParsingErrorException {
        TextfileParser parser = new TextfileParser(filename);
        return loadScene(parser);
    }

    /**
     * Description of the method.
     *
     * @param parser Description of parameter.
     *
     * @return Description of the returned value.
     */
    private Scene loadScene(TextfileParser parser) {
        BranchGroup branch = parser.readSceneGraph();
        SceneBase scene = new SceneBase();
        scene.setSceneGroup(branch);
        return scene;
    }
}
