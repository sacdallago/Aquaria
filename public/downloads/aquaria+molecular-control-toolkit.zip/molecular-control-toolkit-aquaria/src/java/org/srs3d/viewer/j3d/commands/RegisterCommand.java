/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.commands;

import java.util.HashSet;

import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.objects.ObjectManager;

/**
 * Register command.
 *
 * @author Karsten Klein
 *
 * @created April 03, 2001
 */
public class RegisterCommand extends ObjectCommand {

    /** direction qualifier */
    public static final int UP = 1;

    /** direction qualifier */
    public static final int DOWN = 2;
    private int mode = UP + DOWN;
    private int applicationMode = mode;
    private boolean isRegister = true;

    /**
     * <code>RegisterCommand</code> constructor.
     *
     * @param contextData Description of parameter.
     * @param isRegister Description of parameter.
     */
    public RegisterCommand(ContextData contextData, boolean isRegister) {
        super(contextData);
        this.isRegister = isRegister;
    }

    /**
     * <code>RegisterCommand</code> constructor.
     *
     * @param contextData Description of parameter.
     */
    public RegisterCommand(ContextData contextData) {
        this(contextData, true);
    }

    /**
     * Sets the <code>Mode</code> attribute of the <code>RegisterCommand</code> object.
     *
     * @param mode The new <code>Mode</code> value.
     */
    public void setMode(int mode) {
        this.mode = mode;
        this.applicationMode = mode;
    }

    /**
     * Sets the <code>applicationMode</code> attribute of the
     * <code>RegisterCommand</code> object.
     *
     * @param applicationMode The new <code>applicationMode</code> value.
     */
    public void setApplicationMode(int applicationMode) {
        this.applicationMode = applicationMode;
    }

    /**
     * Method description.
     */
    public void resetApplicationMode() {
        this.applicationMode = mode;
    }

    /**
     * Gets the <code>register</code> attribute of the <code>RegisterCommand</code>
     * object.
     *
     * @return The <code>register</code> value.
     */
    public boolean isRegister() {
        return isRegister;
    }

    /**
     * Gets the <code>Mode</code> attribute of the <code>RegisterCommand</code> object.
     *
     * @return The <code>Mode</code> value.
     */
    public int getMode() {
        return mode;
    }

    /**
     * Gets the <code>applicationMode</code> attribute of the
     * <code>RegisterCommand</code> object.
     *
     * @return The <code>applicationMode</code> value.
     */
    public int getApplicationMode() {
        return applicationMode;
    }

    /**
     * Gets the <code>direction</code> attribute of the <code>RegisterCommand</code>
     * object.
     *
     * @return The <code>direction</code> value.
     */
    public String getDirection() {
        String direction = null;
        if ((applicationMode & UP) != 0 && (applicationMode & DOWN) != 0) {
            direction = "" + getParent() + "<->" + getObject();
        } else {
            if ((applicationMode & UP) != 0) {
                direction = "" + getParent() + "<--" + getObject();
            }
            if ((applicationMode & UP) != 0) {
                direction = "" + getParent() + "-->" + getObject();
            }
        }
        return direction;
    }

    /**
     * Description of the method.
     */
    public void execute() {
        ContextData contextData = getContextData();
        ObjectManager objectManager = contextData.getObjectManager();
        if (getParent() != null && getObject() != null) {
            if (isRegister()) {
                switch (applicationMode) {

                    case UP:
                        objectManager.registerUp(getParent(), getObject());
                        break;

                    case DOWN:
                        objectManager.registerDown(getParent(), getObject());
                        break;

                    case UP + DOWN:
                        objectManager.register(getParent(), getObject());
                        break;
                }
            } else {
                switch (applicationMode) {

                    case UP:
                        objectManager.removeUp(getParent(), getObject());
                        break;

                    case DOWN:
                        objectManager.removeDown(getParent(), getObject());
                        break;

                    case UP + DOWN:
                        objectManager.remove(getParent(), getObject());
                        break;
                }

                // additionally remove state
                HashSet set = new HashSet();
                objectManager.getDirectUpAssociations(getObject(), set);
                objectManager.getDirectDownAssociations(getObject(), set);
                if (set.isEmpty()) {

                    //          getContextData().getStateManager().remove( getObject() );
                    getContextData().getSpawnerManager().remove(getObject());
                    getContextData().getShapeManager().remove(getObject());
                }
            }
        }
        resetApplicationMode();
    }
}
