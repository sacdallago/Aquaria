/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.loaders.pdb;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.InterruptedIOException;
import java.util.ArrayList;
import java.util.Iterator;

import org.srs3d.viewer.bioatlas.loaders.AbstractParser;
import org.srs3d.viewer.bioatlas.visitors.ChainAnalyser;
import org.srs3d.viewer.objects.ObjectContainer;
import org.srs3d.viewer.objects.visitors.ObjectUpdater;
import org.srs3d.viewer.util.Chronometer;
import org.srs3d.viewer.util.ExceptionHandler;

/**
 * This class implements a parser reading pdb files/urls. The method <code>parse</code>
 * files all extracted data in a database. The parser utilizes the
 * <code>AbstractPdbParserFactory</code> and the different
 * <code>AbstractPdbParser</code> subclasses to read and interpret the pdb file/url.
 *
 * @author Karsten Klein
 *
 * @created January 22, 2001
 */
public class PdbParser extends BufferedReader implements AbstractParser {
    private static final boolean isVerbose = false;

    /**
     * <code>PdbParser</code> contructor.
     *
     * @param filename Description of parameter.
     *
     * @exception FileNotFoundException Description of exception.
     */
    public PdbParser(String filename) throws FileNotFoundException {
        super(new FileReader(filename));
    }

    /**
     * <code>PdbParser</code> contructor.
     *
     * @param inputStream Description of parameter.
     */
    public PdbParser(InputStream inputStream) {
        super(new InputStreamReader(inputStream));
    }

    /**
     * Description of the method.
     *
     * @return Description of the returned value.
     */
    public ObjectContainer parse() {
        Chronometer method = Chronometer.getChronometer("PdbParser");
        method.start();
        Chronometer c = Chronometer.getChronometer("PdbParsers");
        ObjectContainer objectContainer = new ObjectContainer();
        AbstractParserFactory parserFactory = new AbstractParserFactory();
        String line;
        ArrayList retainedParsers = new ArrayList();
        AbstractPdbParser parser = null;
        try {
            do {
                line = null;
                try {
                    line = readLine();
                } catch (InterruptedIOException e) {
                    ExceptionHandler.handleException(e,
                        ExceptionHandler.SILENT_IN_RELEASE, this);

                    // :NOTE: SOLARIS specific exception handling
                    line = readLine();
                }
                if (line != null) {
                    try {
                        parser = parserFactory.getInstance(line);
                        if (parser != null) {
                            c.start();
                            parser.create(line);
                            c.stop(parser.getClass().toString() + "(create)");
                            if (parser.isRetained()) {

                                // add parser to retained list
                                retainedParsers.add(parser);
                            } else {
                                c.start();
                                parser.visit(objectContainer);
                                c.stop(parser.getClass().toString() +
                                    "(visit)");
                            }
                        }
                    } catch (Exception e) {
                        ExceptionHandler.handleException(e,
                            ExceptionHandler.SILENT_IN_RELEASE, this);
                    }
                }
                if (parser != null) {
                    if (parser.isTerminal()) {
                        line = null;
                    }
                }
                parser = null;
            } while (line != null);
            close();
        } catch (Exception e) {
            ExceptionHandler.handleException(e,
                ExceptionHandler.SILENT_IN_RELEASE, this);
        }

        // execute retained parsers
        Iterator iterator = retainedParsers.iterator();
        while (iterator.hasNext()) {
            parser = (AbstractPdbParser) iterator.next();
            c.start();
            parser.visit(objectContainer);
            c.stop(parser.getClass().toString() + "(visit)");
            parser = null;
        }
        retainedParsers.clear();
        retainedParsers = null;
        c.start();

        // run chain split
        ChainAnalyser chainAnalyser = new ChainAnalyser();
        chainAnalyser.visit(objectContainer);
        c.stop("chain analyser");
        c.start();

        // run object update (deep)
        ObjectUpdater objectUpdater = new ObjectUpdater();
        objectUpdater.visit(objectContainer);
        c.stop("update");
        method.stop();
        return objectContainer;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public static final boolean isVerbose() {
        return isVerbose;
    }
}
