/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.creators;

import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.objects.AbstractObject;

/**
 * Description of the class
 *
 * @author Karsten Klein
 *
 * @created March 30, 2001
 */
public abstract class AbstractGeometryCreator implements GeometryCreator {
    private ContextData contextData = null;

    /**
     * Gets the <code>contextData</code> attribute of the
     * <code>AbstractGeometryCreator</code> object.
     *
     * @return The <code>contextData</code> value.
     */
    public final ContextData getContextData() {
        return contextData;
    }

    /**
     * Description of the method.
     *
     * @param object Description of parameter.
     */
    public void modifyAttributes(ContextData contextData, AbstractObject object) {
        this.contextData = contextData;
    }
}
