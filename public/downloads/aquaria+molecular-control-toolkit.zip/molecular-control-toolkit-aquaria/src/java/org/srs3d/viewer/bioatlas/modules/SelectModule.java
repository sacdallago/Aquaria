/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.modules;

import java.awt.event.ActionEvent;
import java.util.Collection;
import java.util.HashSet;

import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.objects.ObjectContainer;
import org.srs3d.viewer.objects.ObjectFilter;
import org.srs3d.viewer.objects.Operation;
import org.srs3d.viewer.objects.visitors.ObjectCollector;

/**
 * <code>Module</code> implementation selecting a set of objects defined by a provided
 * filter.
 *
 * @author Karsten Klein
 *
 * @created May 14, 2001
 */
public class SelectModule extends ProcessModule {
    private ObjectFilter objectFilter = null;
    private transient Collection objects = null;

    /**
     * <code>SelectModule</code> constructor.
     *
     * @param name Description of parameter.
     * @param contextData Description of parameter.
     * @param filter Description of parameter.
     */
    public SelectModule(String name, ContextData contextData,
        ObjectFilter filter) {
        super(name, contextData, true, true);
        this.objectFilter = filter;
    }

    /**
     * Gets the <code>moduleIdPrefix</code> attribute of the <code>SelectModule</code>
     * object.
     *
     * @return The <code>moduleIdPrefix</code> value.
     */
    public String getModuleIdPrefix() {
        return "SELECT-";
    }

    /**
     * Description of the method.
     */
    public void collectObjects() {
        ContextData contextData = getContextData();
        ObjectContainer objectContainer = contextData.getObjectContainer();
        ObjectCollector objectCollector = new ObjectCollector(objectFilter);
        objectCollector.visit((AbstractObject) objectContainer);
        objects = new HashSet(objectCollector.getObjects().size());
        contextData.getObjectManager().collapseUpExtended(objectCollector.getObjects(),
            objects);
    }

    /**
     * Description of the method.
     *
     * @param e Description of parameter.
     */
    public void process(ActionEvent e) {
        ContextData contextData = getContextData();
        Operation operation =
            new Operation(contextData.getContext(), "TRANSFER_SELECTION", null);
        operation.setObjects(objects);
        operation.setSerializable(false);
        contextData.getDispatcher().runDispatch(operation);
    }

    /**
     * Description of the method.
     */
    public void updateIntern() {
        collectObjects();
        if (getComponent() != null) {
            getComponent().setEnabled(!objects.isEmpty());
        }
    }
}
