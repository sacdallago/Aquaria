/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.filters;

import org.srs3d.viewer.bioatlas.objects.Atom;
import org.srs3d.viewer.objects.AbstractObject;

/**
 * <code>ObjectFilter</code> implementation filtering <code>Atom</code> of a specific
 * element.
 *
 * @author Karsten Klein
 *
 * @created May 14, 2001
 */
public final class AtomElementFilter extends BaseObjectFilter {
    private String elementString = null;

    /**
     * <code>AtomElementFilter</code> constructor.
     *
     * @param elementString Description of parameter.
     */
    public AtomElementFilter(String elementString) {
        super(Atom.class);
        setElementString(elementString);
    }

    /**
     * Sets the <code>elementString</code> attribute of the
     * <code>AtomElementFilter</code> object.
     *
     * @param elementString The new <code>elementString</code> value.
     */
    public void setElementString(String elementString) {
        this.elementString = elementString;
    }

    /**
     * Description of the method.
     *
     * @param object Description of parameter.
     *
     * @return Description of the returned value.
     */
    public boolean filter(AbstractObject object) {
        if (super.filter(object)) {
            if (((Atom) object).getTemplate().isElement(elementString)) {
                return true;
            }
        }
        return false;
    }
}
