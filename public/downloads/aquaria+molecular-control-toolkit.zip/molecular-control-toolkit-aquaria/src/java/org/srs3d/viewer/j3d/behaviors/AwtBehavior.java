/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.behaviors;

import java.awt.AWTEvent;
import java.awt.Event;

import javax.media.j3d.WakeupCriterion;
import javax.media.j3d.WakeupOnAWTEvent;
import javax.vecmath.Point3d;

import org.srs3d.viewer.j3d.Context;

/**
 * This abstract class intends to achive more lightweight awt behaviors as subclasses in
 * terms of duplicate code. The processStimulus is specialized on awt event handling.
 *
 * @author Karsten Klein, 11/2000
 *
 * @created March 20, 2001
 */
public abstract class AwtBehavior extends AbstractBehavior {

    /**
     * The processStimulus method is the only method override from the com.sun... class
     * Behavior. It processes the criteria down to a awt event instance (if possible).
     * Subclasses therefore have to implement the method <code>public void
     * processStimulus( java.awt.Event )</code> .
     *
     * @param criteria Description of parameter
     */
    public void processStimulus(java.util.Enumeration criteria) {
        WakeupCriterion wakeup = null;
        AWTEvent[] event;
        Event awtEvent;
        while (criteria.hasMoreElements()) {
            wakeup = (WakeupCriterion) criteria.nextElement();
            if (wakeup instanceof WakeupOnAWTEvent) {
                schedule(wakeup);
            }
            wakeup = null;
        }

        // reset wakeup condition
        initialize();
    }

    /**
     * Method of the Behavior interface
     *
     * @param xpos Description of parameter
     * @param ypos Description of parameter
     */
    public void updateScene(int xpos, int ypos) {
    }

    /**
     * The higher level processStimulus dispatches the awt event instance
     *
     * @param wakeup Description of parameter
     */
    public abstract void processStimulus(WakeupCriterion wakeup);

    /**
     * Description of the method.
     */
    public void cleanup() {
        super.cleanup();
    }

    /**
     * Description of the method.
     *
     * @param stimulus Description of parameter.
     */
    public void process(WakeupCriterion stimulus) {
        processStimulus(stimulus);
        processConstraints();
    }

    /**
     * Schedules the processing of the stimulus. This default execution directly executes
     * the process. Overwrite this method if a specific scheduling is needed.
     *
     * @param stimulus Description of parameter.
     */
    public void schedule(WakeupCriterion stimulus) {
        process(stimulus);
    }

    /**
     * Method description.
     */
    public void processConstraints() {

        // in addition check the behavior constraints
        Context context = getContextData().getContext();
        if (context != null) {

            // check constraints for viewing platform
            Point3d position = context.getViewingPlatformPosition();
            if (context.hasViewingPlatformChanged()) {
                if (processConstraints(position)) {

                    // apply modification
                    context.setViewingPlatformPosition(position);
                }
            }
        }
    }
}
