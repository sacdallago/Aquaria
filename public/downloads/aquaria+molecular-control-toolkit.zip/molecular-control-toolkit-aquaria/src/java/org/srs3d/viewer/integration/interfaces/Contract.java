/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.integration.interfaces;

import java.util.Collection;

/**
 * Contract interface. Contracts are used to check and communicate the content of
 * GenericObjectProvider instances.
 *
 * @author Karsten Klein
 *
 * @created September 11, 2002
 */
public interface Contract {

    /**
     * Checks the Contract against the passed GenericObjectProvider.
     *
     * @param provider The conent of the passed GenericObjectProvider will be checked.
     *
     * @return <code>true</code> if the provider passed the contract check successfully.
     */
    public boolean check(GenericDataProvider provider);

    /**
     * Gets the <code>keys</code> attribute of the <code>Contract</code> object.
     *
     * @return Collection og key specified by the contract.
     */
    public Collection getKeys();

    /**
     * Gets the <code>contractQualifier</code> attribute of the <code>Contract</code>
     * object.
     *
     * @param key Description of parameter.
     *
     * @return The <code>contractQualifier</code> value.
     */
    public ContractQualifier getContractQualifier(Object key);
}
