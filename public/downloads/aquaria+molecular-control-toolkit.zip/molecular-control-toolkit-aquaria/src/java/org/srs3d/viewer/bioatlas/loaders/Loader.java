/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.loaders;

import java.io.IOException;
import java.net.URL;

import org.srs3d.viewer.objects.ObjectContainer;

/**
 * The loader interface provides the general interface for all bioatlas loaders.
 *
 * @author Karsten Klein, 01/2001
 *
 * @created March 20, 2001
 */
public interface Loader {

    /**
     * Loads the file with the speciafied <code>url</code> . The found data is
     * accumulated in a <code>ObjectContainer</code> instance.
     *
     * @param url url of the file to be loaded.
     *
     * @return containes the read data.
     *
     * @exception IOException Description of exception.
     */
    public ObjectContainer load(java.io.InputStream inputStream)
        throws IOException;

    /**
     * Method description.
     *
     * @param url Parameter description.
     *
     * @return Return description.
     *
     * @throws IOException Exception description.
     */
    public ObjectContainer load(URL url) throws IOException;

    /**
     * Method description.
     *
     * @param parameterObject Parameter description.
     */
    public void setParameterObject(Object parameterObject);
}
