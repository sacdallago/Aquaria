/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.modules;

import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;

import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.vecmath.Color3f;
import javax.vecmath.Point3f;
import javax.vecmath.Vector3f;

import org.srs3d.viewer.bioatlas.colorschemes.CPKColorScheme;
import org.srs3d.viewer.bioatlas.colorschemes.MonochromeColorScheme;
import org.srs3d.viewer.bioatlas.objects.Atom;
import org.srs3d.viewer.bioatlas.visitors.AtomCollector;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.ProcessedSelection;
import org.srs3d.viewer.j3d.Selection;
import org.srs3d.viewer.j3d.SelectionManager;
import org.srs3d.viewer.j3d.commands.ColorCommand;
import org.srs3d.viewer.j3d.commands.RegisterCommand;
import org.srs3d.viewer.j3d.commands.SpawnCommand;
import org.srs3d.viewer.j3d.objects.Surface;
import org.srs3d.viewer.objects.ObjectContainer;
import org.srs3d.viewer.objects.ObjectManager;
import org.srs3d.viewer.objects.StrategyManager;
import org.srs3d.viewer.util.Chronometer;
import org.srs3d.viewer.util.Log;
import org.srs3d.viewer.visualization.AtomDistanceProperty;
import org.srs3d.viewer.visualization.AtomVolume;
import org.srs3d.viewer.visualization.ColorProperty;
import org.srs3d.viewer.visualization.Cuboid;
import org.srs3d.viewer.visualization.GradientProperty;
import org.srs3d.viewer.visualization.MarchingCube;
import org.srs3d.viewer.visualization.Subspace;
import org.srs3d.viewer.visualization.VolumeFilterProperty;

/**
 * <code>Module</code> implementation calculating an atomic surface.
 *
 * @author Karsten Klein
 *
 * @created May 14, 2001
 */
public class AtomSurfaceModule extends ProcessModule {
    private static final Log log = new Log(AtomSurfaceModule.class);
    private static final int MAX_RESOLUTION = 80;
    public static final int MAX_ATOM_COUNT = 200;
    private static final float SAMPLES_PER_ANGSTROEM = 1.0f;
    private float radius;
    private AtomDistanceProperty scalarProperty;
    private ColorProperty colorProperty;
    private GradientProperty gradientProperty;
    private float threshold;
    private boolean isVerbose = false;

    /**
     * <code>AtomSurfaceModule</code> constructor.
     *
     * @param name Name of the module.
     * @param radius Radius.
     * @param contextData Description of parameter.
     */
    public AtomSurfaceModule(String name, ContextData contextData, float radius) {
        super(name, contextData, true, true);
        this.radius = radius;
    }

    /**
     * Sets the <code>properties</code> attribute of the <code>AtomSurfaceModule</code>
     * object.
     *
     * @param scalarProperty The new <code>properties</code> value.
     * @param colorProperty The new <code>properties</code> value.
     * @param gradientProperty The new <code>properties</code> value.
     * @param threshold The new <code>properties</code> value.
     */
    public void setProperties(AtomDistanceProperty scalarProperty,
        ColorProperty colorProperty, GradientProperty gradientProperty,
        float threshold) {
        this.scalarProperty = scalarProperty;
        this.colorProperty = colorProperty;
        this.gradientProperty = gradientProperty;
        this.threshold = threshold;
    }

    /**
     * Gets the <code>radius</code> attribute of the <code>AtomSurfaceModule </code>
     * object.
     *
     * @return The <code>radius</code> value.
     */
    public float getRadius() {
        return radius;
    }

    /**
     * Gets the <code>moduleIdPrefix</code> attribute of the
     * <code>AtomSurfaceModule</code> object.
     *
     * @return The <code>moduleIdPrefix</code> value.
     */
    public String getModuleIdPrefix() {
        return "SURFACE-";
    }

    /**
     * Description of the method.
     *
     * @param objects Description of parameter.
     */
    public void displaySurface(Collection objects) {
        Chronometer c = Chronometer.getChronometer(AtomSurfaceModule.class);
        c.start();
        final ContextData contextData = getContextData();
        ObjectManager objectManager = contextData.getObjectManager();
        final StrategyManager strategyManager =
            contextData.getStrategyManager();
        Collection collapsed = new HashSet(objects.size());
        objectManager.collapseUp(objects, collapsed);
        Collection roots = new ArrayList(collapsed);
        objectManager.getUpAssociations(collapsed, roots);
        ObjectManager.extract(roots, ObjectContainer.class);
        StructureModule.filterSequenceLayers(roots);
        if (!roots.isEmpty()) {
            final ObjectContainer root =
                (ObjectContainer) roots.iterator().next();
            final Surface surface = createSurface(roots, objects);
            if (surface != null && !isCanceled()) {
                contextData.getContext().addUpdateCallback(new org.srs3d.viewer.j3d.behaviors.UpdateBehavior.Callback() {
                        public void execute() {
                            root.addObject(surface);
                            RegisterCommand registerCommand =
                                new RegisterCommand(contextData);
                            registerCommand.setParent(root);
                            registerCommand.setMode(RegisterCommand.UP);
                            strategyManager.execute(surface, registerCommand);
                            SpawnCommand spawnCommand =
                                new SpawnCommand(contextData);
                            spawnCommand.setParent(root);
                            strategyManager.execute(surface, spawnCommand);
                            ColorCommand colorCommand =
                                new ColorCommand(contextData,
                                    new MonochromeColorScheme(contextData,
                                        new Color3f(1, 1, 1)));
                            strategyManager.execute(surface, colorCommand);
                            colorCommand =
                                new ColorCommand(contextData,
                                    new CPKColorScheme(contextData));
                            strategyManager.execute(surface, colorCommand);
                        }
                    });
            }
        } else {

            // :TODO: display message box, and give a reason why no surface will be
            // displayed
            log.error("no root container found for displaying surface.");
        }
        c.stop("process()");
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public boolean canProcess() {
        Selection selection =
            getContextData().getSelectionManager().getSelection();
        Collection atoms = collectAtoms(selection);
        if (!atoms.isEmpty()) {
            if (!IS_THREADED) {
                return true;
            }
            if (atoms.size() > MAX_ATOM_COUNT) {
                int result =
                    org.srs3d.viewer.swing.ComponentFactory.confirmDialog(getContextData()
                                                                              .getContext(),
                        "This operation requires much memory and may cause the Java Virtual Machine to stall.\n" +
                        "Press OK to continue anyway.", "Warning",
                        JOptionPane.ERROR_MESSAGE, null);
                if (result == JOptionPane.CANCEL_OPTION) {
                    return false;
                }
            }
            return true;
        }
        return false;
    }

    /**
     * Description of the method.
     *
     * @param e Description of parameter.
     */
    public void process(ActionEvent e) {
        Selection selection =
            getContextData().getSelectionManager().getSelection();
        if (!selection.isEmpty()) {
            Collection atoms = collectAtoms(selection);
            AtomDistanceProperty property = new AtomDistanceProperty();
            setProperties(property, property, property, getRadius());
            displaySurface(selection);
        }
    }

    /**
     * Description of the method.
     */
    public void updateIntern() {
        JMenuItem menuItem = (JMenuItem) getComponent();
        Selection selection =
            getContextData().getSelectionManager().getSelection();
        Collection atoms = collectAtoms(selection);
        menuItem.setEnabled(atoms.size() > 0);

        //    menuItem.setEnabled( atoms.size() > 0 && atoms.size() < MAX_ATOM_COUNT );
    }

    /**
     * Description of the method.
     *
     * @param objects Description of parameter.
     * @param roots Description of parameter.
     *
     * @return Description of the returned value.
     */
    public Surface createSurface(Collection roots, Collection objects) {
        getComputation().setDescription("Identifying objects...");
        Collection atoms = collectAtoms(objects);
        if (!atoms.isEmpty()) {
            AtomCollector atomCollector = new AtomCollector();
            atomCollector.setObjects(atoms);
            Point3f center = atomCollector.getCenter();
            Vector3f extend = atomCollector.getExtend();

            // buffer zone (should also do without)
            extend.add(new Point3f(1, 1, 1));
            final Vector3f modifiedExtend = new Vector3f(extend);
            final Point3f modifiedCenter = new Point3f(center);
            modifiedExtend.scale(0.5f);
            modifiedCenter.sub(modifiedExtend);
            getComputation().setDescription("Identifying buffer objects...");
            int subdivisions = (int) (SAMPLES_PER_ANGSTROEM * extend.length());
            if (subdivisions > MAX_RESOLUTION) {
                subdivisions = MAX_RESOLUTION;
            }
            AtomCollector bufferAtomCollector =
                new AtomCollector(new org.srs3d.viewer.bioatlas.filters.NoneLigandAtomFilter());
            bufferAtomCollector.visit(roots);
            if (isVerbose) {
                log.info("found " + bufferAtomCollector.getObjects().size() +
                    " buffer atoms.");
            }
            Cuboid cuboid = new Cuboid();
            cuboid.setCoordinate(center);
            float maxSideLength =
                Math.max(extend.x, Math.max(extend.y, extend.z));
            cuboid.setExtend(maxSideLength);
            Subspace subspace = new Subspace(cuboid);
            Subspace bufferSubspace = new Subspace(cuboid);
            Iterator iterator = bufferAtomCollector.getObjects().iterator();
            Atom atom;
            AtomVolume atomVolume;
            int counter = 0;
            getComputation().setDescription("Extracting buffer objects...");
            while (iterator.hasNext()) {
                atom = (Atom) iterator.next();
                atomVolume = new AtomVolume(atom, 0f);
                if (!atomVolume.intersects(cuboid)) {
                    iterator.remove();
                } else {
                    if (!atomCollector.getObjects().contains(atom)) {
                        bufferSubspace.addElement(atomVolume);
                        counter++;
                    }
                }
            }
            if (isVerbose) {
                log.info("found " + bufferAtomCollector.getObjects().size() +
                    "(" + counter + ") final buffer atoms.");
            }
            getComputation().setDescription("Building spacial subdivision...");
            scalarProperty.setSubspace(subspace);
            scalarProperty.addAtoms(atomCollector.getObjects());
            scalarProperty.computeSubdivision();
            if (colorProperty != scalarProperty) {
                if (colorProperty instanceof AtomDistanceProperty) {
                    getComputation().setDescription("Building additional spacial subdivision...");
                    Subspace colorSubspace = new Subspace(cuboid);
                    ((AtomDistanceProperty) colorProperty).setSubspace(colorSubspace);
                    ((AtomDistanceProperty) colorProperty).addAtoms(atomCollector.getObjects());
                    ((AtomDistanceProperty) colorProperty).computeSubdivision();
                }
            }
            getComputation().setDescription("Building buffer spacial subdivision...");
            VolumeFilterProperty filterProperty =
                new VolumeFilterProperty(bufferSubspace, 0.001f);
            bufferSubspace.subdivide(5);

            // extract surface and display it
            MarchingCube mc = new MarchingCube();
            getComputation().setComputation(mc);
            getComputation().setDescription("Computing surface...");
            mc.createSurface(modifiedCenter, extend, threshold, subdivisions,
                scalarProperty, filterProperty);
            getComputation().setDescription("Mapping colors onto surface...");
            if (!isCanceled()) {
                mc.mapColors(colorProperty);
            }
            if (!isCanceled() && gradientProperty != null) {
                getComputation().setDescription("Mapping normals onto surface...");
                mc.mapGradient(gradientProperty);
            }
            if (!isCanceled()) {
                finalizeComputation(mc);
            }
            if (isVerbose) {
                log.info("subspace cache hits: " + scalarProperty.cacheHits);
                log.info("subspace cache misses: " +
                    scalarProperty.cacheMisses);
                log.info("subspace cache fills: " + scalarProperty.cacheFilled);
            }

            // reset sub computation
            getComputation().setComputation(null);
            if (mc.getTriangles() != null && !isCanceled()) {
                getComputation().setDescription("Converting surface for display...");
                org.srs3d.viewer.j3d.objects.Surface surface =
                    new org.srs3d.viewer.j3d.objects.Surface();
                surface.setTriangles(mc.getTriangles());
                surface.getCenter().set(center);
                surface.getExtend().set(extend);
                return surface;
            }
        }
        return null;
    }

    /**
     * Description of the method.
     *
     * @param mc Description of parameter.
     */
    public void finalizeComputation(MarchingCube mc) {
        mc.smoothColor(1);
        mc.smoothNormals(1);
    }

    /**
     * Description of the method.
     *
     * @param objects Description of parameter.
     *
     * @return Description of the returned value.
     */
    protected Collection collectAtoms(Collection objects) {
        SelectionManager selectionManager =
            getContextData().getSelectionManager();
        ProcessedSelection processedSelection =
            selectionManager.getProcessedSelection(selectionManager.getSelection());
        Collection set = processedSelection.getObjectCollection("AllAtoms");
        if (set == null) {
            AtomCollector atomCollector = new AtomCollector();
            atomCollector.visit(objects);
            set = atomCollector.getObjects();
            processedSelection.setObjectCollection("AllAtoms", set);
        }
        return set;
    }
}
