/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.colorschemes;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;

import javax.media.j3d.Appearance;
import javax.vecmath.Color3f;

import org.srs3d.viewer.bioatlas.objects.Chain;
import org.srs3d.viewer.j3d.AppearanceHelper;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.objects.ObjectManager;
import org.srs3d.viewer.vecmath.CubicBezierCurve3f;

/**
 * The <code>ChainIdColorScheme</code> represents a special color scheme. Every chain is
 * meant to receive its own color in order to be distinguishable. The implementation
 * uses a by chain identifier mapping to compute a color. Thereby all chains with the
 * same identifier appear in the same color. And, the color doesn't change with the
 * amount of displayed chains. The color scheme inherits additional behavior from its
 * base class CPKColorScheme which applies for ligands, atoms and bonds.
 *
 * @author Karsten Klein
 *
 * @created March 20, 2001
 */
public class ChainIdColorScheme extends CPKColorScheme {

    /** Restrict the possible mapping interval for the chain identifiers. */
    public static char minValue = 0;

    /** Restrict the possible mapping interval for the chain identifiers. */
    public static char maxValue = 7;

    /** The cubic bezier curve is utilized for color interpolation. */
    protected CubicBezierCurve3f colorCurve = null;

    /**
     * <code>ChainColorScheme</code> contructor.
     *
     * @param contextData Description of parameter.
     */
    public ChainIdColorScheme(ContextData contextData) {
        super(contextData);

        // we use a cubic bezier curve for interpolation of the colors
        colorCurve = new CubicBezierCurve3f();
        ArrayList colors = new ArrayList();
        float max = 0.9f;
        float max2 = 0.9f;
        float min = 0.2f;
        float min2 = 0.2f;
        colors.add(new Color3f(max, min2, min2));
        colors.add(new Color3f(max2, max2, min));
        colors.add(new Color3f(min2, max, min2));
        colors.add(new Color3f(min, max2, max2));
        colors.add(new Color3f(min2, min2, max));
        colors.add(new Color3f(max, min2, min2));
        colorCurve.setCoordinates(colors);
    }

    /**
     * Description of the method
     *
     * @param object Description of parameter
     * @param appearance Description of parameter
     *
     * @return Description of the returned value.
     */
    public boolean modify(AbstractObject object, Appearance appearance) {
        ObjectManager objectManager = getContextData().getObjectManager();

        // get the set of associated chains
        Collection collection = new HashSet();
        objectManager.getUpAssociations(object, collection);
        ObjectManager.extract(collection, Chain.class);
        Chain chain;
        if (!collection.isEmpty()) {
            chain = (Chain) collection.iterator().next();
            if (!chain.isLigand()) {
                Color3f color = computeColor(chain.getId());
                AppearanceHelper.enableVertexColors(appearance, false);
                AppearanceHelper.modifyAppearance(appearance, color);
                return true;
            }
        }

        // color ligand components using the base class modify() method
        return super.modify(object, appearance);
    }

    /**
     * Maps a chain index to a certain color.
     *
     * @param index <code>char</code> to be mapped.
     *
     * @return <code>Color3f</code> - the color mapped to the specified char.
     */
    private Color3f computeColor(char index) {
        char width = (char) (maxValue - minValue);
        float factor = 1.0f / width;
        int value = index - minValue;
        int div = value / width;
        if (value < 0) {
            value -= div * width;
            div *= -1;
        }
        int mod = value % width;
        div %= width;
        float map = ((float) mod + factor * div) * factor;

        // read color at specified parameter from interpolation curve
        Color3f color = new Color3f(colorCurve.computePoint(map));
        return color;
    }
}
