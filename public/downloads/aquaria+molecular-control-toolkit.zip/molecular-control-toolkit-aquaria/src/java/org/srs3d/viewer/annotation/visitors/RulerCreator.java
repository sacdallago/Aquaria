/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.annotation.visitors;

import java.util.Collection;
import java.util.Vector;

import org.srs3d.viewer.annotation.objects.ChainAnnotation;
import org.srs3d.viewer.annotation.objects.Ruler;
import org.srs3d.viewer.bioatlas.objects.Residue;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.objects.visitors.AbstractVisitor;

/**
 * Creates a ruler for the visited object. The current implementation only supports
 * Rulers created for ChainAnnotations.
 *
 * @author Christian Zofka
 *
 * @created October 17, 2001
 * @rewritten Karsten Fries, LION bioscience AG
 * @rewritten January 09, 2002
 */
public class RulerCreator extends AbstractVisitor {
    private Collection rulers = new Vector();
    private float rulerHeight = 1;
    private boolean isRulerLabeled = true;
    private boolean isDetailRuler = true;

    /**
     * Constructor description.
     *
     * @param rulerHeight Parameter description.
     * @param isRulerLabeled Parameter description.
     * @param isDetailRuler Parameter description.
     */
    public RulerCreator(float rulerHeight, boolean isRulerLabeled,
        boolean isDetailRuler) {
        this.rulerHeight = rulerHeight;
        this.isRulerLabeled = isRulerLabeled;
        this.isDetailRuler = isDetailRuler;
    }

    /**
     * Gets the procudes list of rulers that were accumulated during the visiting
     * procedure.
     *
     * @return Collection of <code>Ruler</code> instances.
     */
    public Collection getRulers() {
        return rulers;
    }

    /**
     * Visits an <code>AbstractObject</code> in order to produre a ruler. Note that the
     * current implementation only supports rulers for ChainAnnotations.
     *
     * @param object Description of parameter.
     */
    public void visit(AbstractObject object) {
        if (object instanceof ChainAnnotation) {
            visit((ChainAnnotation) object);
        }
    }

    /**
     * Creates a ruler for a ChainAnnotation.
     *
     * @param chainAnnotation ChainAnnotation instance used for creating a ruler.
     */
    public void visit(ChainAnnotation chainAnnotation) {
        if (chainAnnotation != null) {
            Ruler ruler = createRuler(chainAnnotation.getGapSequence());
            rulers.add(ruler);
        }
    }

    /**
     * Creates a ruler for a specified residue sequence.
     *
     * @param sequence Description of parameter.
     *
     * @return Created ruler.
     */
    private Ruler createRuler(Vector sequence) {
        Ruler ruler = new Ruler();
        ruler.setHeight(rulerHeight);
        ruler.setLabeled(isRulerLabeled);
        ruler.addHorizontal(new Ruler.Horizontal(0, sequence.size()));
        if (isDetailRuler) {
            createRulerVerticals(ruler, sequence, 10, 0.75f, false, false);
        }
        createRulerVerticals(ruler, sequence, 50, 1, true, true);
        createRulerVerticals(ruler, sequence, 100, 1.5f, true, false);
        int distance = 40;
        int verticalsAt5 = 0;
        if (ruler.getVerticals().isEmpty()) {
            createRulerVerticals(ruler, sequence, 5, 1, false, true);
            verticalsAt5 = ruler.getVerticals().size();
        }
        while (ruler.getVerticals().size() == verticalsAt5 && distance > 0) {
            createRulerVerticals(ruler, sequence, distance, 2, true, false);
            distance -= 10;
        }
        return ruler;
    }

    /**
     * Creates the verticals of a residue sequence ruler.
     *
     * @param gapSequence Underlying sequence.
     * @param distance Distance between two vertical.
     * @param verticalLength Vertical length.
     * @param verticalIsLabeled Indicates whether the vertical is labeled.
     * @param prevent Indicates the prevention of verticals of distances of higher
     *        multipliers.
     * @param ruler Ruler to create verticals for.
     */
    private void createRulerVerticals(Ruler ruler, Vector gapSequence,
        int distance, float verticalLength, boolean verticalIsLabeled,
        boolean prevent) {
        Residue residue;
        int number;
        int i;
        int index = -1;
        int last = 1;
        int now = 0;
        int preventCheck = 0;

        //    float offset = org.srs3d.viewer.bioatlas.Parameter.residueSequenceWidth / 2;
        float offset = 0f;
        Ruler.Vertical vertical;
        for (i = 0; i < gapSequence.size(); i++) {
            residue = (Residue) gapSequence.elementAt(i);
            if (residue != null) {
                number = residue.getId();
                now = number % distance;
                preventCheck = (number - now) / distance;
                if (!prevent || preventCheck % 2 == 1) {
                    if (now < last) {
                        if (verticalIsLabeled) {

                            // create labeled vertical
                            vertical =
                                new Ruler.LabeledVertical(i + offset,
                                    verticalLength, Integer.toString(number));
                        } else {

                            // create unlabeled vertical
                            vertical =
                                new Ruler.Vertical(i + offset, verticalLength);
                        }
                        ruler.addVertical(vertical);
                    }
                }
                last = now;
            }
        }
    }
}
