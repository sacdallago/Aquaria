/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.accesscontrol.checks;

import java.applet.AppletStub;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;

import org.srs3d.viewer.accesscontrol.IdentificationPool;
import org.srs3d.viewer.util.ExceptionHandler;
import org.srs3d.viewer.util.Log;
import org.srs3d.viewer.util.XmlTag;

/**
 * @author Karsten Klein
 *
 * @created March 22, 2002
 */
public class ServerClientCheck extends ExpirationCheck {
    private static final Log log = new Log(ServerClientCheck.class);
    private transient ArrayList identificationPools = new ArrayList(50);

    /**
     * Method description.
     *
     * @return Return description.
     */
    public String getName() {
        return "ServerClientCheck-1.0";
    }

    /**
     * Method description.
     *
     * @param appletStub Parameter description.
     *
     * @return Return description.
     */
    public boolean check(AppletStub appletStub) {
        if (super.check(appletStub)) {
            String serverHost = appletStub.getCodeBase().getHost();
            if (checkServer(serverHost)) {
                if (checkClient()) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Method description.
     *
     * @param object Parameter description.
     */
    public void read(Object object) {
        super.read(object);
        Map map = (Map) object;

        // read identification pools
        Collection pools = (Collection) map.get("IdentificationPools");
        Iterator iterator = pools.iterator();
        IdentificationPool identificationPool;
        identificationPools = new ArrayList(pools.size());
        while (iterator.hasNext()) {
            identificationPool = new IdentificationPool(iterator.next());
            identificationPools.add(identificationPool);
        }
    }

    /**
     * Method description.
     *
     * @param object Parameter description.
     */
    public void write(Object object) {
        super.write(object);
        Map map = (Map) object;

        // write pools
        Iterator iterator = identificationPools.iterator();
        IdentificationPool identificationPool;
        ArrayList pools = new ArrayList(identificationPools.size());
        while (iterator.hasNext()) {
            identificationPool = (IdentificationPool) iterator.next();
            pools.add(identificationPool.flatten());
        }
        map.put("IdentificationPools", pools);
    }

    /**
     * More abstract level for checking the access. This method checks for inclusion of
     * the server in the identification pools and retrieves the client name and ip for
     * checking.
     *
     * @param serverHost Name of the server in the network.
     *
     * @return <code>true</code> if both computes (server and client) are included in the
     *         identification pool..
     */
    public boolean checkServer(String serverHost) {
        boolean isSuccess = false;
        if (serverHost.trim().length() == 0) {
            serverHost = "localhost";
        }
        try {
            if (serverHost.equalsIgnoreCase("localhost")) {

                // we allow localhost since the client is checked explicitly by name in
                // this type of check
                isSuccess = true;
            } else {
                InetAddress ip = InetAddress.getByName(serverHost);
                String machineName = ip.getHostName();
                int index = machineName.indexOf(".");
                if (machineName.indexOf(".") != -1) {
                    machineName = machineName.substring(0, index).trim();
                }
                log.info("Checking " + machineName + " " + ip.getHostAddress());
                isSuccess = contains(machineName, ip.getHostAddress());
            }
        } catch (java.net.UnknownHostException e) {
            log.error("Cannot resolve server host " + serverHost);
            isSuccess = contains(serverHost);
            if (!isSuccess) {
                log.info("Server name " + serverHost +
                    " has no access permission!");
            }
            ExceptionHandler.handleException(e,
                ExceptionHandler.SILENT_IN_DEBUG, this);
        }
        return isSuccess;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public boolean checkClient() {
        boolean isSuccess = false;
        try {
            InetAddress ip = InetAddress.getLocalHost();
            if (!ip.getHostName().equalsIgnoreCase("localhost")) {
                String machineName = ip.getHostName();
                int index = machineName.indexOf(".");
                if (machineName.indexOf(".") != -1) {
                    machineName = machineName.substring(0, index);
                }
                log.info("Checking " + machineName + " " + ip.getHostAddress());

                // check all: ip plus name
                isSuccess = contains(machineName, ip.getHostAddress());
            } else {
                isSuccess = false;
                log.error("Client host invalid.");
            }
        } catch (java.net.UnknownHostException e) {
            log.error("Cannot resolve local host!");
            ExceptionHandler.handleException(e,
                ExceptionHandler.SILENT_IN_RELEASE, this);
        }
        return isSuccess;
    }

    /**
     * Add an identification pool to the access control instance.
     *
     * @param identificationPool IdentificationPool to add.
     */
    protected void add(IdentificationPool identificationPool) {
        identificationPools.add(identificationPool);
    }

    /**
     * Check method. The name ip pair is checked agains all identification pools.
     *
     * @param name Name of the computer in the network.
     * @param ip IP of the computer in the network.
     *
     * @return <code>true</code> when pair is included.
     */
    protected boolean contains(String name, String ip) {
        Iterator iterator = identificationPools.iterator();
        IdentificationPool identifcationPool;
        while (iterator.hasNext()) {
            identifcationPool = (IdentificationPool) iterator.next();
            if (identifcationPool.contains(name, ip)) {
                return true;
            }
        }
        return false;
    }

    protected boolean contains(String name) {
        Iterator iterator = identificationPools.iterator();
        IdentificationPool identifcationPool;
        while (iterator.hasNext()) {
            identifcationPool = (IdentificationPool) iterator.next();
            if (identifcationPool.contains(name)) {
                return true;
            }
        }
        return false;
    }

    protected boolean containsIP(String ip) {
        Iterator iterator = identificationPools.iterator();
        IdentificationPool identifcationPool;
        while (iterator.hasNext()) {
            identifcationPool = (IdentificationPool) iterator.next();
            if (identifcationPool.containsIP(ip)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public XmlTag createXmlTag() {
        XmlTag xmlTag = super.createXmlTag();
        Iterator iterator = identificationPools.iterator();
        int counter = 0;
        XmlTag subtag;
        while (iterator.hasNext()) {
            subtag = ((IdentificationPool) iterator.next()).createXmlTag();
            xmlTag.getSubtags().add(subtag);
        }
        return xmlTag;
    }
}
