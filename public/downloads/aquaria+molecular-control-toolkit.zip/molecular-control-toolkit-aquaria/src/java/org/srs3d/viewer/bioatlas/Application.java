/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas;

import java.awt.Component;
import java.awt.Graphics;

import org.srs3d.viewer.integration.component.ComponentController;
import org.srs3d.viewer.integration.interfaces.Accessor;

/**
 * @author Karsten Klein
 *
 * @created July 13, 2001
 */
public interface Application extends ComponentController, Accessor {

    /**
     * Initialize the application.
     */
    public void init();

    /**
     * Start the application.
     */
    public void start();

    /**
     * Start visualization.
     */
    public void startVisualization();

    /**
     * Stop application.
     */
    public void stop();

    /**
     * Destroy application.
     */
    public void destroy();

    /**
     * Update application. Refresh.
     */
    public void update();

    /**
     * Check whether application is ready or not.
     *
     * @return The <code>ready</code> value.
     */
    public boolean isReady();

    /**
     * Retrieve the application context for this application
     *
     * @return Application context.
     */
    public ApplicationContext getApplicationContext();

    /**
     * Method description.
     *
     * @param component Parameter description.
     * @param g Parameter description.
     */
    public void printContexts(Component component, Graphics g);
}
