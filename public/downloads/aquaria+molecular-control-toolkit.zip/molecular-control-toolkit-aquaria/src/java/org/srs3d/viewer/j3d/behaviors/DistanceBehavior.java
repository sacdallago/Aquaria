/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.behaviors;

import javax.media.j3d.BoundingSphere;
import javax.media.j3d.Bounds;
import javax.media.j3d.WakeupCriterion;
import javax.media.j3d.WakeupOnViewPlatformEntry;
import javax.media.j3d.WakeupOnViewPlatformExit;
import javax.media.j3d.WakeupOr;
import javax.vecmath.Point3d;
import javax.vecmath.Tuple3d;
import javax.vecmath.Vector3d;

import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.Spawner;
import org.srs3d.viewer.objects.Command;

/**
 * The class <code>DistanceBehavior</code> is very similar to the LOD behavior from the
 * sun utility package.
 *
 * @author Karsten Klein, 11/2000
 *
 * @created March 20, 2001
 *
 * @see Spawner
 * @since 1.0
 */
public class DistanceBehavior extends AbstractBehavior {

    /** Description of the field */
    private double objectSize = 0;

    /** Description of the field */
    private Point3d objectCenter = null;

    /** This vector consists of distances that define rings of different representations */
    private double[] distances = null;

    /**
     * The <code>Command</code> s vector associates a distance ring with the according
     * representation. Note that the <code>Commands</code> s vector should be 1 entry
     * bigger than the <code>distance</code> vector
     */
    private Command[] commands = null;

    /** Description of the field */
    private double distance = 0;

    /**
     * <code>DistanceBehavior</code> contructor.
     *
     * @param objectCenter Description of parameter
     * @param distances Description of parameter
     * @param commands Description of parameter.
     * @param context Description of parameter.
     */
    public DistanceBehavior(ContextData contextData, Tuple3d objectCenter,
        double[] distances, Command[] commands) {
        super();
        setContextData(contextData);
        this.distances = distances;
        this.commands = commands;
        this.objectCenter = new Point3d(objectCenter);
        computeDistance();
        setSchedulingBounds();
    }

    /**
     * Description of the method
     */
    public void initialize() {
        computeDistance();
        int index = getRingIndex();
        Bounds entryBounds = getEntryBounds(index);
        Bounds exitBounds = getExitBounds(index);
        if (entryBounds != null && exitBounds != null) {
            WakeupCriterion[] conditions = new WakeupCriterion[2];
            conditions[0] = new WakeupOnViewPlatformEntry(entryBounds);
            conditions[1] = new WakeupOnViewPlatformExit(exitBounds);
            wakeupOn(new WakeupOr(conditions));
        } else {
            WakeupCriterion condition;
            if (entryBounds != null) {
                condition = new WakeupOnViewPlatformEntry(entryBounds);
                wakeupOn(condition);
            } else if (exitBounds != null) {
                condition = new WakeupOnViewPlatformExit(exitBounds);
                wakeupOn(condition);
            }
        }
    }

    /**
     * Processes the behavior.
     *
     * @param criteria Criteria that triggered the behavior.
     */
    public void processStimulus(java.util.Enumeration criteria) {
        computeDistance();
        int index = getRingIndex();

        // read according command from command vector
        Command command = commands[index];

        // execute the command
        getContextData().getStrategyManager().execute(command.getObject(),
            command);

        // reinitialize criteria
        initialize();
    }

    /**
     * This methods sets the scheduling bounds appropriate to the current state of the
     * DistanceBehavior instance. The scheduling bound is twice as big as the first
     * distance in the distance vector to assure proper funtionality.
     */
    private void setSchedulingBounds() {
        BoundingSphere bounds = new BoundingSphere();
        bounds.setCenter(objectCenter);
        bounds.setRadius(distances[0] + 1);
        this.setSchedulingBounds(bounds);
    }

    /**
     * Gets the <code>EntryBounds</code> attribute of the <code>DistanceBehavior
     * </code>object
     *
     * @param index Description of parameter
     *
     * @return The <code>EntryBounds</code> value
     */
    private Bounds getEntryBounds(int index) {
        if (index < distances.length) {
            BoundingSphere bounds = new BoundingSphere();
            bounds.setCenter(objectCenter);
            bounds.setRadius(distances[index]);
            return bounds;
        } else {
            return null;
        }
    }

    /**
     * Gets the <code>ExitBounds</code> attribute of the <code>DistanceBehavior
     * </code>object
     *
     * @param index Description of parameter
     *
     * @return The <code>ExitBounds</code> value
     */
    private Bounds getExitBounds(int index) {
        if (index > 0) {
            BoundingSphere bounds = new BoundingSphere();
            bounds.setCenter(objectCenter);
            bounds.setRadius(distances[index - 1]);
            return bounds;
        } else {
            return null;
        }
    }

    /**
     * Gets the <code>RingIndex</code> attribute of the <code>DistanceBehavior
     * </code>object
     *
     * @return The <code>RingIndex</code> value
     */
    private int getRingIndex() {
        int i = 0;
        while (i < distances.length) {
            if (distance > distances[i]) {
                return i;
            }
            i++;
        }
        return i;
    }

    /**
     * Description of the method
     *
     * @return Description of the returned value
     */
    private double computeDistance() {

        // get current translation of the ViewingPlatform
        Vector3d translation =
            new Vector3d(getContextData().getContext()
                             .getViewingPlatformPosition());
        translation.sub(new Vector3d(objectCenter));
        distance = translation.length();
        return distance;
    }
}
