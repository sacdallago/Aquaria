/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.behaviors;

import javax.media.j3d.Transform3D;
import javax.media.j3d.WakeupCriterion;
import javax.vecmath.AxisAngle4f;
import javax.vecmath.Matrix3f;
import javax.vecmath.Vector3f;

import org.srs3d.viewer.j3d.ContextData;

/**
 * The class <code>RotateBehavior</code> represents a specialized
 * <code>MouseBehavior</code> .
 *
 * @author Karsten Klein, 11/2000
 *
 * @created March 20, 2001
 * @since 1.0
 */
public class InteractiveRotateBehavior extends AwtBehavior implements InteractiveRotate {
    private Vector3f axis = new Vector3f(0, 0, 1);

    /** Description of the field */
    private float speedX = 1f / 180;
    private float speedY = 1f / 180;
//    private float speedX = 0.15f / 180;
//    private float speedY = 0.15f / 180;
    private float speedZ = 1.0f / 180;


    /**
     * <code>RotateBehavior</code> contructor.
     *
     * @param context Description of parameter.
     * @param object Description of parameter.
     */
    public InteractiveRotateBehavior(ContextData contextData) {
        setContextData(contextData);
        
    }

    public void processStimulus(WakeupCriterion wakeup) {
    	// TODO Auto-generated method stub
    	
    }
    
    /**
     * Initializes the wakeup conditions for the behavior.
     */
    public void initialize() {
    	AquariaInteractiveDispatcher.setRotate(this);
    }

    /* (non-Javadoc)
	 * @see org.srs3d.viewer.j3d.behaviors.InteractiveRotate#processStimulus(int, int, int)
	 */
    @Override
	public void processStimulus(int rotationX, int rotationY, int rotationZ) {
        rotate(getContextData(), speedX * rotationX, speedY * rotationY, speedZ * rotationZ);
    }

    /* (non-Javadoc)
	 * @see org.srs3d.viewer.j3d.behaviors.InteractiveRotate#processStimulus(javax.vecmath.Matrix3f)
	 */
    @Override
	public void processStimulus(Matrix3f matrix) {
        rotate(getContextData(), matrix);
    }

    /**
     * Description of the method.
     *
     * @param context Description of parameter.
     * @param deltaX Description of parameter.
     * @param deltaZ Description of parameter.
     */
    public static void rotate(ContextData contextData, float deltaX, float deltaY,
        float deltaZ) {

        // read viewing platform transform
        Transform3D transform =
            contextData.getContext().getViewingPlatformTransform();
        Matrix3f matrix = new Matrix3f();
        Vector3f vector = new Vector3f();
        transform.get(matrix);
        matrix.getColumn(0, vector);
        
        AxisAngle4f axisAngleX = new AxisAngle4f(vector, -deltaX);
        matrix.getColumn(1, vector);
        AxisAngle4f axisAngleY = new AxisAngle4f(vector, -deltaY);
        matrix.getColumn(2, vector);
        AxisAngle4f axisAngleZ = new AxisAngle4f(vector, -deltaZ);
        matrix.set(axisAngleX);
        Matrix3f dummy = new Matrix3f();
        dummy.set(axisAngleY);
        matrix.mul(dummy);
        dummy.set(axisAngleZ);
        matrix.mul(dummy);
        
//        rotate(contextData, matrix);

        // extract rotation and translation parts
        Vector3f translation = new Vector3f();
        Matrix3f rotation = new Matrix3f();
        transform.get(rotation);
        transform.get(translation);

        // modify translation and rotation
        translation.sub(contextData.getContext().getCenterOfRotation());
        rotation.mul(matrix, rotation);
        matrix.transform(translation);
        translation.add(contextData.getContext().getCenterOfRotation());
        transform.setRotation(rotation);
        transform.setTranslation(translation);
        transform.normalize();
        contextData.getContext().setViewingPlatformTransform(transform);
    }

    /**
     * Description of the method.
     *
     * @param context Description of parameter.
     * @param deltaX Description of parameter.
     * @param deltaZ Description of parameter.
     */
    public static void rotate(ContextData contextData, Matrix3f matrix) {

        // read viewing platform transform
        Transform3D transform =
            contextData.getContext().getViewingPlatformTransform();
//        Matrix3f oldMatrix = new Matrix3f();
        Vector3f vector = new Vector3f();
//        transform.get(oldMatrix);
//        matrix.mul(oldMatrix);

        // extract rotation and translation parts
        Vector3f translation = new Vector3f();
        Matrix3f rotation = new Matrix3f();
        transform.get(rotation);
        transform.get(translation);

        // modify translation and rotation
        translation.sub(contextData.getContext().getCenterOfRotation());
        rotation.mul(rotation, matrix );
        matrix.transform(translation);
        translation.add(contextData.getContext().getCenterOfRotation());
        transform.setRotation(rotation);
        transform.setTranslation(translation);
        transform.normalize();
        contextData.getContext().setViewingPlatformTransform(transform);
    }

}
