/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.styles;

import java.util.Collection;
import java.util.Vector;

import org.srs3d.viewer.annotation.colorschemes.HomologyColorScheme;
import org.srs3d.viewer.bioatlas.colorschemes.TransparentColorScheme;
import org.srs3d.viewer.bioatlas.filters.SubchainFilter;
import org.srs3d.viewer.bioatlas.modules.CoilCheck;
import org.srs3d.viewer.bioatlas.objects.Layer;
import org.srs3d.viewer.j3d.AbstractColorScheme;
import org.srs3d.viewer.j3d.ColorSchemeBucket;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.commands.ColorCommand;
import org.srs3d.viewer.j3d.commands.ExpandCommand;
import org.srs3d.viewer.j3d.commands.PropagateClassCommand;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.objects.StrategyManager;
import org.srs3d.viewer.objects.visitors.ObjectCollector;

/**
 * @author Karsten Klein
 *
 * @created July 11, 2001
 */
public class HomologyStyle extends FirstImpressionStyle {

    /**
     * <code>HomologyStyle</code> constructor.
     *
     * @param contextData Description of parameter.
     */
    public HomologyStyle(ContextData contextData) {
        super(contextData);
    }

    /**
     * Description of the method.
     *
     * @param layer Description of parameter.
     */
    public void applyColorScheme(Layer layer) {
        ColorSchemeBucket colorSchemeBucket = new ColorSchemeBucket();
        AbstractColorScheme colorScheme =
            (AbstractColorScheme) getColorScheme(HomologyColorScheme.class);
        colorScheme.setComplete(true);
        colorSchemeBucket.add(colorScheme);
        getContextData().setColorScheme(colorScheme);
        if (layer.isMaster() && layer.isImposed()) {
            colorSchemeBucket.add(getColorScheme(TransparentColorScheme.class));
        }
        ColorCommand colorCommand =
            new ColorCommand(getContextData(), colorSchemeBucket);
        colorCommand.setForceRecoloring(true);
        colorCommand.propagate(layer);
    }

    /**
     * Set the subchain mode.
     *
     * @param layer Description of parameter.
     */
    public void processSubchains(Layer layer) {
        super.processSubchains(layer);
        if (!layer.isSequenceLayer()) {
            ContextData contextData = getContextData();
            ObjectCollector objectCollector =
                new ObjectCollector(new SubchainFilter());
            objectCollector.visit((AbstractObject) layer);
            Collection commands = new Vector();
            commands.add(new PropagateClassCommand(contextData,
                    new ExpandCommand(contextData, false), null));
            if (!layer.isMaster()) {
                CoilCheck.sharedInstance.getAllOnCommands(contextData, commands);
                StrategyManager strategyManager =
                    contextData.getStrategyManager();
                strategyManager.execute(objectCollector.getObjects(), commands);
            }
        }
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public String getName() {
        return "Homology";
    }
}
