/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.annotation.creators;

import java.util.Iterator;

import javax.media.j3d.BranchGroup;
import javax.vecmath.Point3f;

import org.srs3d.viewer.annotation.attributes.LayoutPosition;
import org.srs3d.viewer.annotation.objects.Alignment;
import org.srs3d.viewer.annotation.objects.AnnotationContainer;
import org.srs3d.viewer.bioatlas.Parameter;
import org.srs3d.viewer.j3d.creators.AbstractGeometryCreator;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.objects.Attribute;
import org.srs3d.viewer.objects.State;

/**
 * Produces the layout for is components.
 *
 * @author Karsten Klein
 * @author Christian Zofka
 *
 * @created March 20, 2001
 * @modified July 08, 2001
 */
public class AnnotationContainerGeometryCreator extends AbstractGeometryCreator {

    /**
     * Description of the method
     *
     * @param object Description of parameter
     * @param branchGroup Description of parameter
     */
    public void create(AbstractObject object, BranchGroup branchGroup) {
        create((AnnotationContainer) object, branchGroup);
    }

    /**
     * Description of the method
     *
     * @param annotationContainer Description of parameter
     * @param branchGroup Description of parameter
     */
    public void create(AnnotationContainer annotationContainer,
        BranchGroup branchGroup) {
        Point3f position = new Point3f();
        position.x = -0.5f * annotationContainer.getLength();

        // iterate over alignments and do layout stuff
        Iterator iterator = annotationContainer.getAlignments().iterator();
        Alignment alignment;
        State state;
        LayoutPosition layoutPosition;
        while (iterator.hasNext()) {
            alignment = (Alignment) iterator.next();

            // modify layout position attribute of alignment state
            state = getContextData().getStateManager().getState(alignment);
            layoutPosition =
                (LayoutPosition) Attribute.getInstance(LayoutPosition.class);
            layoutPosition.setPosition(position);
            state.setAttribute(layoutPosition);
            getContextData().getStateManager().register(alignment, state);
            position.x += alignment.getLength() + Parameter.alignmentDistance;
        }
    }
}
