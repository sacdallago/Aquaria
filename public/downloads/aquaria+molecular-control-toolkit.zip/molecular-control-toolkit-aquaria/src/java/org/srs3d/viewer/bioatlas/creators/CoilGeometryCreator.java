/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.creators;

import java.util.ArrayList;

import javax.media.j3d.BranchGroup;
import javax.vecmath.Matrix3f;
import javax.vecmath.Point3f;
import javax.vecmath.TexCoord2f;
import javax.vecmath.Tuple3f;
import javax.vecmath.Vector3f;

import org.srs3d.viewer.bioatlas.objects.AbstractChain;
import org.srs3d.viewer.bioatlas.objects.Residue;
import org.srs3d.viewer.bioatlas.objects.Subchain;
import org.srs3d.viewer.bioatlas.visitors.PathCreator;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.vecmath.CubicBezierCurve3f;
import org.srs3d.viewer.vecmath.SweepingSurface;

/**
 * Special geometry creator implementation concentrating on <code>Coil</code> objects.
 *
 * @author Karsten Klein
 *
 * @created March 28, 2001
 */
public class CoilGeometryCreator extends SubchainGeometryCreator {
    private Vector3f scale = new Vector3f(1, 0.17f, 1);

    /**
     * Method description.
     *
     * @param object Parameter description.
     * @param branchGroup Parameter description.
     */
    public void create(AbstractObject object, BranchGroup branchGroup) {
        createGeometry((Subchain) object, branchGroup);
    }

    /**
     * Description of the Method
     *
     * @param chain Description of Parameter
     * @param branchGroup Description of Parameter
     */
    public void createSubchainGeometry(AbstractChain chain,
        BranchGroup branchGroup) {
        SweepingSurface sweepingSurface = createSweepingSurface(chain);
        createSubchainGeometry(chain, branchGroup, sweepingSurface);

        // release sweeping surface
        sweepingSurface = null;
    }

    /**
     * Description of the Method
     *
     * @param chain Description of Parameter
     * @param branchGroup Description of Parameter
     */
    public void createResidueGeometry(AbstractChain chain,
        BranchGroup branchGroup) {
        SweepingSurface sweepingSurface = createSweepingSurface(chain);
        createResidueGeometry(chain, 0, 0, branchGroup, sweepingSurface);

        // release sweeping surface
        sweepingSurface = null;
    }

    /**
     * Description of the Method
     *
     * @param chain Description of Parameter
     *
     * @return Description of the Returned Value
     */
    public SweepingSurface createSweepingSurface(AbstractChain chain) {
        Residue start = computeStartResidue(chain);
        Residue end = computeEndResidue(chain);
        int steps = chain.getLength() * (framesPerResidue - 1) + 1;
        int frames = steps;
        SweepingSurface sweepingSurface =
            new SweepingSurface(getSurfaceContour());
        float deltaT = 1.0f / (steps - 1);
        float t = 0;
        Point3f point;
        Point3f computed;
        Vector3f vector0 = new Vector3f();
        Vector3f vector1 = new Vector3f(1, 0, 0);
        Vector3f vector2 = new Vector3f();
        PathCreator caPathCreator = new PathCreator();
        caPathCreator.visit(start, end);

        // create ca interpolation curve and plug in the created path
        CubicBezierCurve3f caCurve = new CubicBezierCurve3f();
        caCurve.tangentScale = 1.0f / 4;
        caCurve.setCoordinates(caPathCreator.path);
        caCurve.postPoint = caPathCreator.postPoint;
        caCurve.prePoint = caPathCreator.prePoint;

        // create tangent and normal path first:
        ArrayList normalPre = new ArrayList();
        ArrayList normalPath = new ArrayList();
        Vector3f initialNormal = new Vector3f(1, 0, 0);
        Vector3f finalNormal = new Vector3f(1, 0, 0);
        Matrix3f frameMatrix = null;
        Residue residue = null;

        // in case we find other tangents and normals int the frameHash use them
        frameMatrix = getFrame(chain.getInitialResidue().getPreceeding());
        if (frameMatrix != null) {
            frameMatrix.getColumn(1, initialNormal);
            frameMatrix.getColumn(2, vector2);

            // reduce the speed a little bit
            vector2.scale(0.33f);
            caCurve.initialTangent = new Vector3f(vector2);
        }
        if (initialNormal.dot(finalNormal) < 0) {
            finalNormal.negate();
        }
        normalPre.add(initialNormal);
        normalPre.add(finalNormal);

        // create interpolation curve for y axis
        CubicBezierCurve3f normalCurve = new CubicBezierCurve3f();
        normalCurve.tangentScale = 1.0f / 4;
        normalCurve.setCoordinates(normalPre);
        Vector3f dummy = new Vector3f();
        Vector3f previous = new Vector3f();
        vector1.set(initialNormal);
        float projection = 0;
        float width = chain.getLength();
        float widthPowerOf2 =
            org.srs3d.viewer.vecmath.Constants.computeNextHigherPowerOf2(width);
        float deltaTexture = width / widthPowerOf2 * deltaT;
        TexCoord2f textureCoordinate = new TexCoord2f();
        sweepingSurface.setTextured(true);
        for (int i = 0; i < steps - 1; i++) {
            t = i * deltaT;
            vector2.set(caCurve.computeTangent(t));
            vector2.normalize();
            vector1.normalize();
            vector0.cross(vector2, vector1);
            vector0.normalize();
            vector1.cross(vector0, vector2);
            vector1.normalize();
            normalPath.add(new Vector3f(vector1));
        }
        if (Math.abs(vector1.dot(finalNormal)) > Math.abs(vector0.dot(
                      finalNormal))) {
            dummy.set(finalNormal);
        } else {
            dummy.cross(finalNormal, vector2);
        }
        if (dummy.dot(vector1) < 0) {
            dummy.negate();
        }
        normalPath.add(new Vector3f(dummy));
        for (int i = 1; i < steps - 1; i += 2) {
            dummy = (Vector3f) normalPath.get(i);
            dummy.add((Tuple3f) normalPath.get(i - 1));
            dummy.add((Tuple3f) normalPath.get(i + 1));
            dummy.scale(1.0f / 3);
        }
        normalCurve.setCoordinates(normalPath);
        Matrix3f rotation = new Matrix3f();
        Vector3f scale = getScale();
        float scaleFactor = 1.0f / framesPerResidue;
        int frameIndex = 0;
        float initialSize = 0.17f;
        float endSize = 0.17f;
        for (int i = 0; i < steps; i++) {
            t = i * deltaT;
            vector2.set(caCurve.computeTangent(t));
            vector2.normalize();
            vector1.set(normalCurve.computePoint(t));
            vector1.normalize();
            vector0.cross(vector2, vector1);
            vector0.normalize();
            vector1.cross(vector0, vector2);
            vector1.normalize();
            point = caCurve.computePoint(t);
            rotation.setColumn(0, vector0);
            rotation.setColumn(1, vector1);
            rotation.setColumn(2, vector2);
            scale = getScale();
            if (i < framesPerResidue) {
                scale.x =
                    (float) Math.max(initialSize, scale.x * scaleFactor * i);
            }
            if (i >= steps - framesPerResidue) {
                scale.x =
                    (float) Math.max(endSize,
                        scale.x * scaleFactor * (steps - i - 1));
            }
            scale.y = scale.x;
            sweepingSurface.addFrame(rotation, point, scale,
                i == 0 || i == steps - 1, textureCoordinate);
            textureCoordinate.x += deltaTexture;
        }
        return sweepingSurface;
    }

    /**
     * Description of the method.
     *
     * @param object Description of parameter.
     */
    public void modifyAttributes(ContextData contextData, AbstractObject object) {
        super.modifyAttributes(contextData, object);
        useCircleContour =
            org.srs3d.viewer.bioatlas.Parameter.coilUseCircleContour;
        framesPerResidue =
            org.srs3d.viewer.bioatlas.Parameter.coilFramesPerResidue;
        divisionsPerFrame =
            org.srs3d.viewer.bioatlas.Parameter.coilDivisionsPerFrame;
    }
}
