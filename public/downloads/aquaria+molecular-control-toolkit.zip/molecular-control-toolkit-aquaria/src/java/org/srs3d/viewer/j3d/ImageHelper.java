/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d;


/**
 * Class description.
 *
 * @author $author$
 */
public class ImageHelper {

    /**
     * Computes the next (or equal) number that is a power of 2.
     *
     * @param i The integer to compute the next power of 2 for.
     *
     * @return An integer j that satisfies j &gt;= i, j = 2^x; j &lt; 2^(x+1) i > 0 and j
     *         = 0 for i = 0.
     */
    public static int computeNextPowerOf2(int i) {
        if (i == 0) {
            return 0;
        }

        // optimization for reducing the number of iterations
        int j = (i >= 64) ? 64 : 1;
        while (j <= i) {
            j = j << 1;
        }
        return j;
    }
}
