/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.commands;

import java.util.HashSet;

import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.attributes.Expanded;
import org.srs3d.viewer.objects.Attribute;
import org.srs3d.viewer.objects.State;
import org.srs3d.viewer.objects.StateManager;
import org.srs3d.viewer.objects.StrategyManager;

/**
 * Expand command.
 *
 * @author Karsten Klein
 *
 * @created April 03, 2001
 */
public class ExpandCommand extends ModificationCommand {
    private boolean isExpand;
    private boolean isColoringChildren = true;

    /**
     * <code>ExpandCommand</code> constructor.
     *
     * @param contextData Description of parameter.
     */
    public ExpandCommand(ContextData contextData) {
        this(contextData, true);
    }

    /**
     * <code>ExpandCommand</code> constructor.
     *
     * @param contextData Description of parameter.
     * @param isExpand Description of parameter.
     */
    public ExpandCommand(ContextData contextData, boolean isExpand) {
        super(contextData);
        this.isExpand = isExpand;
    }

    /**
     * Constructor description.
     *
     * @param contextData Parameter description.
     * @param isExpand Parameter description.
     * @param isColoringChildren Parameter description.
     */
    public ExpandCommand(ContextData contextData, boolean isExpand,
        boolean isColoringChildren) {
        super(contextData);
        this.isExpand = isExpand;
        this.isColoringChildren = isColoringChildren;
    }

    /**
     * Gets the <code>expand</code> attribute of the <code>ExpandCommand</code> object.
     *
     * @return The <code>expand</code> value.
     */
    public boolean isExpand() {
        return isExpand;
    }

    /**
     * Executes the expand command.
     */
    public void execute() {
        if (getObject() != null) {
            ContextData contextData = getContextData();
            StateManager stateManager = contextData.getStateManager();
            StrategyManager strategyManager = contextData.getStrategyManager();
            State.Immutable immutableState =
                stateManager.getImmutableState(getObject());
            if (isExpand()) {

                // don't do anything, when object is already expanded
                if (!immutableState.hasAttribute(Expanded.class)) {
                    State state = immutableState.getCopy();

                    // set expanded attribute and register back
                    state.setAttribute(Attribute.getInstance(Expanded.class));
                    stateManager.register(getObject(), state);
                    registerModifiedObject(getObject());

                    // execute show command on children and object
                    HashSet objects = new HashSet();
                    getObject().getAllObjects(objects);
                    objects.add(getObject());
                    if (isColoringChildren()) {

                        // propagate parents color settings
                        // :NOTE: this was taken out of the responsibilty for the expand command
                        //   since we introduced residue color textures.
                        ColorCommand.propagateColorSchemeBucket(contextData,
                            getObject());
                    }
                }
            } else {

                // don't do anything, when object is not expanded
                if (immutableState.hasAttribute(Expanded.class)) {
                    State state = immutableState.getCopy();

                    // set expanded attribute and register back
                    state.removeAttribute(Expanded.class);
                    stateManager.register(getObject(), state);
                    registerModifiedObject(getObject());
                }
            }
        }
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public boolean isColoringChildren() {
        return isColoringChildren;
    }

    /**
     * Method description.
     *
     * @param isColoringChildren Parameter description.
     */
    public void setColorChildren(boolean isColoringChildren) {
        this.isColoringChildren = isColoringChildren;
    }
}
