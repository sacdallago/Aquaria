/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.annotation.constraints;

import javax.vecmath.Point3d;
import javax.vecmath.Point3f;
import javax.vecmath.Tuple3d;
import javax.vecmath.Vector3d;

import org.srs3d.viewer.annotation.contexts.AbstractAnnotationContext;
import org.srs3d.viewer.annotation.contexts.AnnotationContextData;
import org.srs3d.viewer.annotation.objects.AnnotationContainer;
import org.srs3d.viewer.j3d.Context;
import org.srs3d.viewer.j3d.constraints.Constraint;
import org.srs3d.viewer.j3d.constraints.PlaneConstraint;

/**
 * Limits the sequenceview to the current alignmentlength.
 *
 * @author Christian Zofka
 *
 * @created August 17, 2001
 * @reviewed Karsten Fries, LION bioscience AG
 * @reviewed September 21, 2001
 */
public class PlaneAnnotationConstraint implements Constraint {
    private AbstractAnnotationContext context;
    private PlaneConstraint left = null;
    private PlaneConstraint right = null;

    // stores values for optimization
    private float currentViewLength = 0.0f;

    /**
     * <code>PlaneAnnotationConstraint</code> constructor.
     *
     * @param context Description of parameter.
     */
    public PlaneAnnotationConstraint(AbstractAnnotationContext context) {
        setContext(context);
    }

    /**
     * Implementation of the <code>Constraint</code> interface. The processed objects are
     * limitied to <code>Point3d</code> instances.
     *
     * @param object the object to be processed in place. Only <code>Point3d</code>
     *        instances are processed.
     *
     * @return <code>boolean</code> - <Code>true</code> if object was modified.
     */
    public boolean process(Object object) {
        update();
        boolean isModified = false;
        if (object instanceof Tuple3d) {
            Tuple3d point = (Tuple3d) object;
            if (right != null) {
                isModified |= right.process(point);
            }
            if (left != null) {
                isModified |= left.process(point);
            }
        } else {

            // the object couldn't be processed by the constraint.
            // :FIXME: we can throw an exception (should be a special
            //         class e.g. ConstraintNotHandledException)
            // :NOTE: this would have to comply with the Constraint
            //        interface that currenly assumes unknown object to be
            //        skipped
        }
        return isModified;
    }

    /**
     * Sets the <code>contextData</code> attribute of the
     * <code>PlaneAnnotationConstraint</code> object.
     *
     * @param context The new <code>context</code> value.
     */
    private void setContext(AbstractAnnotationContext context) {
        this.context = context;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public final Context getContext() {
        return context;
    }

    /**
     * Sets the <code>left</code> attribute of the <code>PlaneAnnotationConstraint</code>
     * object.
     *
     * @param anchor The new <code>left</code> value.
     * @param normal The new <code>left</code> value.
     */
    protected void setLeft(Tuple3d anchor, Vector3d normal) {
        if (left == null) {
            left = new PlaneConstraint(normal, anchor);
        } else {
            left.setAnchor(anchor);
            left.setNormal(normal);
        }
    }

    /**
     * Sets the <code>right</code> attribute of the
     * <code>PlaneAnnotationConstraint</code> object.
     *
     * @param anchor The new <code>right</code> value.
     * @param normal The new <code>right</code> value.
     */
    protected void setRight(Tuple3d anchor, Vector3d normal) {
        if (right == null) {
            right = new PlaneConstraint(normal, anchor);
        } else {
            right.setAnchor(anchor);
            right.setNormal(normal);
        }
    }

    /**
     * sets the contraints if the alignment or windowsize(viewdistance) have changed
     */
    public void update() {
        AnnotationContextData contextData =
            (AnnotationContextData) getContext().getContextData();
        AnnotationContainer annotationContainer =
            contextData.getAnnotationContainer();
        Point3f center = new Point3f(context.getViewingPlatformPosition());
        float viewLength =
            center.z * org.srs3d.viewer.bioatlas.Parameter.aspectScaleX;
        if (viewLength != currentViewLength) {
            currentViewLength = viewLength;
            float annotationLength = annotationContainer.getLength();
            float positionX = 0.5f * annotationLength;
            float leftLimit;
            float rightLimit;
            if (annotationLength < viewLength) {

                // fixedposition at center of annotation
                float x = 0;
                leftLimit = x;
                rightLimit = x;
            } else {

                // scroll to leftLimit & rightLimit allowed
                leftLimit = -1.0f * positionX + 0.5f * viewLength;
                rightLimit = positionX - 0.5f * viewLength;

                // pdb entry text
                // :TODO: remove when implemented as overlay
                //        leftLimit -= 50;
            }
            Point3d leftAnchor = new Point3d(leftLimit, 0, 0);
            Vector3d leftNormal = new Vector3d(-1, 0, 0);
            Point3d rightAnchor = new Point3d(rightLimit, 0, 0);
            Vector3d rightNormal = new Vector3d(1, 0, 0);
            setLeft(leftAnchor, leftNormal);
            setRight(rightAnchor, rightNormal);
        }
    }
}
