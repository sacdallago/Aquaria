/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.annotation.visitors;

import java.util.Collection;
import java.util.Iterator;

import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.objects.ObjectContainer;
import org.srs3d.viewer.objects.visitors.Visitor;

/**
 * This class provides methods to visit Objects.
 *
 * @author Christian Zofka, 06/2001
 *
 * @created June 27, 2001
 * @since 1.91
 */
public abstract class AbstractCreator implements Visitor {

    /**
     * Description of the method.
     *
     * @param ObjectContainer Description of parameter.
     */
    public void visit(ObjectContainer objectContainer) {
        Iterator iterator = objectContainer.getIterator();
        while (iterator.hasNext()) {
            visit(((AbstractObject) iterator.next()));
        }
    }

    /**
     * Description of the method.
     *
     * @param ObjectContainer Description of parameter.
     */
    public void visit(Collection collection) {
        Iterator iterator = collection.iterator();
        while (iterator.hasNext()) {
            visit(((AbstractObject) iterator.next()));
        }
    }
}
