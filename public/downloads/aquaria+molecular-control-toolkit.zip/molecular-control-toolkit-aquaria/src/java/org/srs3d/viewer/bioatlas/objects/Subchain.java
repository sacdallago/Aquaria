/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.objects;

import java.util.Collection;

/**
 * Special <code>AbstractObject</code> implementation defining a base class for all
 * secondary structure objects.
 *
 * @author Karsten Klein
 *
 * @created May 18, 2001
 */
public abstract class Subchain extends AbstractChain {

    /** Description of the field. */
    public static final int INVALID_SERIAL = -1;

    /** Description of the field. */
    public static final char CODE = ' ';
    private String id = null;
    private int serial = INVALID_SERIAL;
    private int length = 0;

    /**
     * Sets the <code>serial</code> attribute of the <code>Subchain</code> object.
     *
     * @param serial The new <code>serial</code> value.
     */
    public void setSerial(int serial) {
        this.serial = serial;
    }

    /**
     * Sets the <code>id</code> attribute of the <code>Subchain</code> object.
     *
     * @param id The new <code>id</code> value.
     */
    public void setId(String id) {
        this.id = new String(id);
    }

    /**
     * Gets the <code>serial</code> attribute of the <code>Subchain</code> object.
     *
     * @return The <code>serial</code> value.
     */
    public int getSerial() {
        return serial;
    }

    /**
     * Gets the <code>id</code> attribute of the <code>Subchain</code> object.
     *
     * @return The <code>id</code> value.
     */
    public String getId() {
        return id;
    }

    /**
     * Gets the <code>code</code> attribute of the <code>Subchain</code> object.
     *
     * @return The <code>code</code> value.
     */
    public abstract char getCode();

    /**
     * Gets the <code>allObjects</code> attribute of the <code>Subchain</code> object.
     *
     * @param collection Description of parameter.
     */
    public void getAllObjects(Collection collection) {
        Residue residue = getInitialResidue();
        Residue limit = getEndResidue();
        if (limit != null) {
            limit = limit.getProceeding();
        }
        while (residue != null && residue != limit) {
            collection.add(residue);
            residue = residue.getProceeding();
        }
    }

    /**
     * Description of the method.
     *
     * @return Description of the returned value.
     */
    public String toString() {

        //    String string = new String();
        if (getId() != null) {
            return getId().toString();
        } else {
            return "";
        }

        //    if ( getSerial() != Subchain.INVALID_SERIAL ) {
        //
        //      string += "(" + getSerial() + ")";
        //
        //    }
        //    if ( getInitialResidue() != null && getEndResidue() != null ) {
        //
        //      String description = getInitialResidue().getTemplate().getName();
        //      description += getInitialResidue().getId() + "-";
        //      description += getEndResidue().getTemplate().getName();
        //      description += getEndResidue().getId();
        //
        //      string += "(" + getInitialResidue() + "-" + getEndResidue() + ")";
        //
        //    }
        //    return string;
    }

    /**
     * Gets the <code>newInstance</code> attribute of the <code>Subchain</code> class.
     *
     * @param code Description of parameter.
     *
     * @return The <code>newInstance</code> value.
     */
    public static Subchain getNewInstance(char code) {
        switch (code) {

            case Helix.CODE:
                return new Helix();

            case Strand.CODE:
                return new Strand();

            case Turn.CODE:
                return new Turn();

            case Coil.CODE:
                return new Coil();

            case NucleicChain.CODE:
                return new NucleicChain();

            case Section.CODE:
                return new Section();
        }
        return null;
    }
}
