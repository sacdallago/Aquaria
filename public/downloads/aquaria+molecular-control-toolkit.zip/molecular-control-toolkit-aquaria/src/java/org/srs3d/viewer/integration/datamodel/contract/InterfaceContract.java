/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.integration.datamodel.contract;

import java.lang.reflect.Method;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Description of the class.
 *
 * @author Karsten Klein
 *
 * @created January 30, 2003
 */
public class InterfaceContract extends GenericContract {
    private static final Log log = LogFactory.getLog(InterfaceContract.class);

    /**
     * InterfaceContract constructor.
     *
     * @param objectClass Description of parameter.
     * @param serviceUrnPrefix Description of parameter.
     * @param serviceName Description of parameter.
     * @param methodName Description of parameter.
     */
    public InterfaceContract(Class objectClass, String serviceUrnPrefix,
        String serviceName, String methodName) {
        this(objectClass, serviceUrnPrefix, serviceName, methodName, null);
    }

    /**
     * InterfaceContract constructor.
     *
     * @param serviceUrnPrefix Description of parameter.
     * @param serviceName Description of parameter.
     * @param methodName Description of parameter.
     * @param object Description of parameter.
     */
    public InterfaceContract(String serviceUrnPrefix, String serviceName,
        String methodName, Object object) {
        GenericContractQualifier qualifier;
        String urn = serviceUrnPrefix + ":" + serviceName + ":" + methodName;
        qualifier = new GenericContractQualifier();
        if (object != null) {
            Class[] classes = { object.getClass() };
            qualifier.setAttribute(new DefaultObjectAttribute(classes));
            setContractQualifier(urn + ":classes", qualifier);
            setContractQualifier(urn,
                new GenericContractQualifier(new MandatoryAttribute()));
            qualifier = new GenericContractQualifier();
            Object[] objects = { object };
            qualifier.setAttribute(new DefaultObjectAttribute(objects));
            setContractQualifier(urn + ":args", qualifier);
        }
    }

    /**
     * InterfaceContract constructor.
     *
     * @param objectClass Description of parameter.
     * @param serviceUrnPrefix Description of parameter.
     * @param serviceName Description of parameter.
     * @param methodName Description of parameter.
     * @param object Description of parameter.
     */
    public InterfaceContract(Class objectClass, String serviceUrnPrefix,
        String serviceName, String methodName, Object object) {
        Method[] methods = objectClass.getMethods();
        Collection filteredMethods = new HashSet();
        for (int i = 0; i < methods.length; i++) {
            if (methods[i].getName().equals(methodName)) {
                filteredMethods.add(methods[i]);
            }
        }
        Iterator iterator = filteredMethods.iterator();
        Method method;
        GenericContractQualifier qualifier;
        String urn = serviceUrnPrefix + ":" + serviceName + ":" + methodName;
        if (iterator.hasNext()) {
            method = (Method) iterator.next();
            qualifier = new GenericContractQualifier();
            qualifier.setAttribute(new DefaultObjectAttribute(
                    method.getParameterTypes()));
            setContractQualifier(urn + ":classes", qualifier);
            setContractQualifier(urn,
                new GenericContractQualifier(new MandatoryAttribute()));
            qualifier = new GenericContractQualifier();
            Object[] objects = { object };
            qualifier.setAttribute(new DefaultObjectAttribute(objects));
            setContractQualifier(urn + ":args", qualifier);
        } else {
            log.debug("no method " + methodName + " found");
        }
    }
}
