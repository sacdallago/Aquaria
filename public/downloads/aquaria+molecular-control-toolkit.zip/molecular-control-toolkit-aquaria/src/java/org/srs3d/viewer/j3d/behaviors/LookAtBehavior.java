/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.behaviors;

import java.awt.event.MouseEvent;

import javax.media.j3d.Transform3D;
import javax.media.j3d.WakeupOnAWTEvent;
import javax.media.j3d.WakeupOr;
import javax.vecmath.AxisAngle4f;
import javax.vecmath.Matrix3f;
import javax.vecmath.Vector3f;

import org.srs3d.viewer.j3d.Context;
import org.srs3d.viewer.j3d.ContextData;

/**
 * The class <code>LookAtBehavior</code> represents a specialized
 * <code>MouseBehavior</code>. It acts on the current viewport of the context
 *
 * @author Karsten Klein
 *
 * @created November 20, 2000
 */
public class LookAtBehavior extends MouseBehavior {
    public static int deltaZ = 0;
    private float speed = 5.0f / 180;

    /** Integers used for saving the mouse positions */
    private int lastX;

    /** Integers used for saving the mouse positions */
    private int x;
    private int lastY;
    private int y;

    /**
     * <code>RotateBehavior</code> contructor.
     *
     * @param context Description of parameter.
     */
    public LookAtBehavior(ContextData contextData) {
        super(contextData);
    }

    /**
     * Sets the speed of the behavior. The speed is measured in readians per pixel of
     * mouse the movement.
     *
     * @param speed The new <code>Speed</code> value.
     */
    public void setSpeed(float speed) {
        this.speed = speed;
    }

    /**
     * Initializes the wakeup conditions for the behavior.
     */
    public void initialize() {
        WakeupOnAWTEvent[] conditions = new WakeupOnAWTEvent[2];

        // set wakeup condition (waiting for further dragging events)
        conditions[0] = new WakeupOnAWTEvent(MouseEvent.MOUSE_DRAGGED);

        // set wakeup condition (waiting first click)
        conditions[1] = new WakeupOnAWTEvent(MouseEvent.MOUSE_PRESSED);
        wakeupOn(new WakeupOr(conditions));
    }

    /**
     * Processes the mouseEvent. This will directly result in a modification of the
     * viewingPlatform in the activated <code>Context</code> , if the according
     * conditions are met by the mouse event.
     *
     * @param mouseEvent Description of parameter.
     */
    public void processStimulus(MouseEvent mouseEvent) {
        lastX = x;
        lastY = y;
        x = mouseEvent.getX();
        y = mouseEvent.getY();
        if (checkCriteria(mouseEvent)) {
            KeyHandler.setCursor(getContextData(), "RotateZ", true);
            deltaZ = x - lastX;
            deltaZ = Math.min(deltaZ, MAX_DELTA);
            deltaZ = Math.max(deltaZ, -MAX_DELTA);
            rotate(getContextData(), speed * deltaZ);
        }
    }

    /**
     * This method checks the mouseEvent (fail early, fail fast)
     *
     * @param mouseEvent Description of parameter.
     *
     * @return Description of the returned value.
     */
    protected boolean checkCriteria(MouseEvent mouseEvent) {
        if (mouseEvent.getID() != MouseEvent.MOUSE_DRAGGED) {
            return false;
        }
        if (mouseEvent.isAltGraphDown()) {
            return false;
        }
        if ((mouseEvent.getModifiers() & MouseEvent.BUTTON3_MASK) != 0) {
            if (!mouseEvent.isShiftDown()) {
                return false;
            }
        }
        if ((mouseEvent.getModifiers() & MouseEvent.BUTTON1_MASK) != 0) {
            if (!mouseEvent.isControlDown()) {
                return false;
            }
        }
        return true;
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     * @param deltaZ Parameter description.
     */
    public static void rotate(ContextData contextData, float deltaZ) {
        Context context = contextData.getContext();

        // read viewing platform transform
        Transform3D transform = context.getViewingPlatformTransform();
        Matrix3f matrix = new Matrix3f();
        Vector3f vector = new Vector3f();
        transform.get(matrix);
        matrix.getColumn(2, vector);
        AxisAngle4f axisAngleX = new AxisAngle4f(vector, deltaZ);
        matrix.set(axisAngleX);

        // extract rotation and translation parts
        Vector3f translation = new Vector3f();
        Matrix3f rotation = new Matrix3f();
        transform.get(rotation);
        transform.get(translation);

        // modify translation and rotation
        translation.sub(context.getCenterOfRotation());
        rotation.mul(matrix, rotation);
        matrix.transform(translation);
        translation.add(context.getCenterOfRotation());
        transform.setRotation(rotation);
        transform.setTranslation(translation);
        context.setViewingPlatformTransform(transform);
    }
}
