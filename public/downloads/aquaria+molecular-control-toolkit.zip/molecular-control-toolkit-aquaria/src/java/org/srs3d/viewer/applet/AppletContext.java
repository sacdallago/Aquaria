/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.applet;

import org.srs3d.viewer.swing.StatusDisplay;
import org.srs3d.viewer.util.Log;

/**
 * Implementation of the applet context for use without any applet.
 *
 * @author Karsten Klein
 *
 * @created March 20, 2001
 */
public class AppletContext implements java.applet.AppletContext {
    private static final Log log = new Log(AppletContext.class);
    private StatusDisplay statusDisplay = null;

    /**
     * Method description.
     *
     * @param name Parameter description.
     *
     * @return Return description.
     */
    public java.applet.Applet getApplet(String name) {
        return null;
    }

    /**
     * Method description.
     *
     * @param statusDisplay Parameter description.
     */
    public void setStatusDisplay(StatusDisplay statusDisplay) {
        this.statusDisplay = statusDisplay;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public java.util.Enumeration getApplets() {
        return null;
    }

    /**
     * Method description.
     *
     * @param url Parameter description.
     *
     * @return Return description.
     */
    public java.applet.AudioClip getAudioClip(java.net.URL url) {
        return null;
    }

    /**
     * Method description.
     *
     * @param url Parameter description.
     *
     * @return Return description.
     */
    public java.awt.Image getImage(java.net.URL url) {
        return null;
    }

    /**
     * Method description.
     *
     * @param url Parameter description.
     */
    public void showDocument(java.net.URL url) {
        log.info("supposed to show " + url);
    }

    /**
     * Method description.
     *
     * @param url Parameter description.
     * @param target Parameter description.
     */
    public void showDocument(java.net.URL url, String target) {
        log.info("supposed to show " + url + " in " + target);
    }

    /**
     * Method description.
     *
     * @param status Parameter description.
     */
    public void showStatus(String status) {
        if (statusDisplay == null) {
            log.info(status);
        } else {
            statusDisplay.setStatus(status);
        }
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public java.util.Iterator getStreamKeys() {
        return null;
    }

    /**
     * Method description.
     *
     * @param string Parameter description.
     *
     * @return Return description.
     */
    public java.io.InputStream getStream(String string) {
        return null;
    }

    /**
     * Method description.
     *
     * @param stream Parameter description.
     */
    public void setStream(java.io.InputStream stream) {
    }

    /**
     * Method description.
     *
     * @param string Parameter description.
     * @param stream Parameter description.
     */
    public void setStream(String string, java.io.InputStream stream) {
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public String toString() {
        return "Status";
    }
}
