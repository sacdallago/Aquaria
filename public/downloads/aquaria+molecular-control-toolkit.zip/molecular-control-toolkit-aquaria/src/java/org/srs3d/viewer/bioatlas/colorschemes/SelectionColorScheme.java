/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.colorschemes;

import javax.media.j3d.Appearance;
import javax.vecmath.Color3f;

import org.srs3d.viewer.j3d.AbstractColorScheme;
import org.srs3d.viewer.j3d.AppearanceHelper;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.objects.AbstractObject;

/**
 * The <code>SelectionColorScheme</code> is used by <code>Selection</code> instances to
 * highlight the current selection.
 *
 * @author Karsten Klein
 *
 * @created March 20, 2001
 */
public class SelectionColorScheme extends AbstractColorScheme {
    private boolean isVolatile = true;

    /**
     * The <code>SelectionColorScheme</code> brightens the current color of an object by
     * the specifed values.
     */
    private Color3f color = new Color3f(0.5f, 0.5f, 0.5f);

    /**
     * <code>SelectionColorScheme</code> constructor.
     *
     * @param contextData Description of parameter.
     */
    public SelectionColorScheme(ContextData contextData) {
        super(contextData);
    }

    /**
     * <code>SelectionColorScheme</code> constructor.
     *
     * @param color Description of parameter.
     * @param contextData Description of parameter.
     * @param isVolatile Description of parameter.
     */
    public SelectionColorScheme(ContextData contextData, Color3f color,
        boolean isVolatile) {
        this(contextData);
        this.color = color;
        this.isVolatile = isVolatile;
    }

    /**
     * Gets the Volatile attribute of the SelectionColorScheme object
     *
     * @return The Volatile value
     */
    public boolean isVolatile() {
        return isVolatile;
    }

    /**
     * Description of the method.
     *
     * @param object Description of parameter.
     * @param appearance Description of parameter.
     */
    public boolean modify(AbstractObject object, Appearance appearance) {
        Color3f color = new Color3f();
        AppearanceHelper.getColor(appearance, color);
        color.add(this.color);
        AppearanceHelper.modifyAppearance(appearance, color);
        AppearanceHelper.modifyLineWidth(appearance, 3, 0);
        AppearanceHelper.modifyPointSize(appearance, 3, 0);
        return true;
    }

    /**
     * Method description.
     *
     * @param color Parameter description.
     */
    public void setColor(Color3f color) {
        this.color = color;
    }
}
