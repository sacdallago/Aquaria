/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.geometry.primitive;

import java.util.Hashtable;
import java.util.Map;

import javax.media.j3d.QuadArray;
import javax.media.j3d.Shape3D;
import javax.media.j3d.Transform3D;
import javax.media.j3d.TransformGroup;
import javax.vecmath.Matrix3f;
import javax.vecmath.Point3f;
import javax.vecmath.Vector3f;

import org.srs3d.viewer.j3d.geometry.GeometryHelper;
import org.srs3d.viewer.vecmath.Contour;
import org.srs3d.viewer.vecmath.SweepingSurface;

/**
 * The <code>Cylinder</code> class provides the ability to construct cylindrical
 * geometric primitives as <code>Shape3D</code> objects. Note that a former version used
 * the <code>Cylinder</code> class from the sun utility package. But sun suggested the
 * user to attach the cylider shape to a transformation node. Since this remarkely
 * slowed down the rendering, we generated the geometry with suns <code>Cylinder</code>
 * class, and transformed the geometry statically. This worked fine till sun changed the
 * internal representation of the cylinder. Till the version 1.2.1 beta1 everything was
 * just fine and the implementation worked on all tested systems. With beta2 the
 * orientations of suns cylinders changed swapping the x, y axes. The current
 * implementation doesn't use the util package at all. Instead it employs the sweeping
 * surface algorithm of the org.srs3d.viewer package. The new implementation can now
 * handle different radii on the ends of the cylinder.
 *
 * @author Karsten Klein
 *
 * @created October 26, 2000
 *
 * @see org.srs3d.viewer.vecmath.SweepingSurface
 */
public class Cylinder extends Line {
    private static final Matrix3f identity =
        new Matrix3f(1, 0, 0, 0, 1, 0, 0, 0, 1);
    private static Contour defaultContour =
        Contour.getCircleContour(6, (float) Math.PI / 2);

    /** Radii of the cylinder */
    private float[] radius = null;

    /** Number of divisions along the x axis (direction of the cylinder) */
    private int divisionX = 1;

    /** Number of divisions along the circular cross-scetion */
    private int divisionY = 6;

    /** Default contour for generating a default cylinder */
    private Contour contour = defaultContour;
    private Map cylinderMap = new Hashtable();

    /**
     * Contructs a new <code>Cylinder</code> with default values. Radii are both
     * <code>1.0f</code> , coordinates are all zero.
     */
    public Cylinder() {
        super();
        radius = new float[2];
        radius[0] = 1.0f;
        radius[1] = 1.0f;
    }

    /**
     * Sets the <code>uniformRadius</code> attribute of the <code>Cylinder</code> object.
     *
     * @param radius The new <code>uniformRadius</code> value.
     */
    public void setUniformRadius(float radius) {
        this.radius[0] = radius;
        this.radius[1] = radius;
    }

    /**
     * Sets the <code>radiusAt</code> attribute of the <code>Cylinder</code> object.
     *
     * @param index The new <code>radiusAt</code> value.
     * @param radius The new <code>radiusAt</code> value.
     */
    public void setRadiusAt(int index, float radius) {
        this.radius[index] = radius;
    }

    /**
     * Sets the <code>divisionX</code> attribute of the <code>Cylinder</code> object.
     *
     * @param divisionX The new <code>divisionX</code> value.
     */
    public void setDivisionX(int divisionX) {
        this.divisionX = divisionX;
    }

    /**
     * Sets the <code>divisionY</code> attribute of the <code>Cylinder</code> object.
     *
     * @param divisionY The new <code>divisionY</code> value.
     */
    public void setDivisionY(int divisionY) {
        this.divisionY = divisionY;
        if (divisionY == 6) {
            contour = defaultContour;
        } else {
            contour = Contour.getCircleContour(divisionY, (float) Math.PI / 2);
        }
    }

    /**
     * Sets the <code>contour</code> attribute of the <code>Cylinder</code> object.
     *
     * @param contour The new <code>contour</code> value.
     */
    public void setContour(Contour contour) {
        this.contour = contour;
    }

    /**
     * Gets the <code>radiusAt</code> attribute of the <code>Cylinder</code> object.
     *
     * @param index Description of parameter.
     *
     * @return The <code>radiusAt</code> value.
     */
    public float getRadiusAt(int index) {
        return radius[index];
    }

    /**
     * Gets the <code>divisionX</code> attribute of the <code>Cylinder</code> object.
     *
     * @return The <code>divisionX</code> value.
     */
    public int getDivisionX() {
        return divisionX;
    }

    /**
     * Gets the <code>divisionY</code> attribute of the <code>Cylinder</code> object.
     *
     * @return The <code>divisionY</code> value.
     */
    public int getDivisionY() {
        return divisionY;
    }

    /**
     * Gets the <code>shapeOld</code> attribute of the <code>Cylinder</code> object.
     *
     * @return The <code>shapeOld</code> value.
     */
    public final Shape3D getShapeOld() {
        float length = this.computeLength();
        if (length > 0) {
            SweepingSurface sweepingSurface = new SweepingSurface(contour);
            Matrix3f rotation = new Matrix3f();
            Point3f translation = new Point3f();
            Vector3f direction = this.computeAxis();
            Vector3f scale = new Vector3f(1, 1, 1);
            float t = 0;
            float dT = 1.0f / divisionX;
            float dScale = radius[1] - radius[0];
            computeRotation(rotation);
            for (int i = 0; i <= divisionX; i++) {
                t = dT * i;
                translation.set(direction);
                translation.scale(t);
                translation.add(this.getCoordinates().getAt(0));
                scale.x = t * dScale + radius[0];
                scale.y = scale.x;
                sweepingSurface.addFrame(rotation, translation, scale,
                    i == 0 || i == divisionX);
            }
            Shape3D shape = sweepingSurface.getFullGeometry(0, divisionX);
            return shape;
        } else {
            return null;
        }
    }

    /**
     * Gets the <code>unitCylinder</code> attribute of the <code>Cylinder</code> object.
     *
     * @return The <code>unitCylinder</code> value.
     */
    public final Shape3D getUnitCylinder() {
        SweepingSurface sweepingSurface = new SweepingSurface(contour);
        Matrix3f rotation = new Matrix3f(1, 0, 0, 0, 1, 0, 0, 0, 1);
        Point3f translation = new Point3f();
        Vector3f direction = new Vector3f(0, 0, 1);
        Vector3f scale = new Vector3f(1, 1, 1);
        float t = 0;
        float dT = 1.0f / divisionX;
        for (int i = 0; i <= divisionX; i++) {
            t = dT * i;
            translation.set(direction);
            translation.scale(t);
            sweepingSurface.addFrame(rotation, translation, scale,
                i == 0 || i == divisionX);
        }
        Shape3D shape = sweepingSurface.getFullGeometry(0, divisionX);
        return shape;
    }

    /**
     * Gets the <code>transformGroup</code> attribute of the <code>Cylinder</code>
     * object.
     *
     * @return The <code>transformGroup</code> value.
     */
    public TransformGroup getTransformGroup() {
        TransformGroup transformGroup = new TransformGroup();
        Transform3D transform = new Transform3D();
        Matrix3f matrix = new Matrix3f();
        computeRotation(matrix);
        Matrix3f scale =
            new Matrix3f(radius[0], 0f, 0f, 0f, radius[0], 0f, 0f, 0f,
                (float) computeLength());
        matrix.mul(scale);
        transform.setRotation(matrix);
        transform.setTranslation(new Vector3f(getCoordinates().getAt(0)));
        transformGroup.setTransform(transform);
        return transformGroup;
    }

    /**
     * This methods inserts the plane information from this cylinder instance at the
     * given index into a quad array.
     *
     * @param index index of the cylinder in the line array.
     * @param quadArray the according quad array.
     */
    public void insertInto(int index, QuadArray quadArray) {
        Point3f[] points;
        Vector3f axis = computeAxis();
        Vector3f orthogonal = new Vector3f();

        // :FIXME: assuming shape is in the xy plane (2d)
        orthogonal.x = axis.y;
        orthogonal.y = -axis.x;
        Quad quad = new Quad();
        quad.getColors().setAt(0, getColors().getAt(0));
        quad.getColors().setAt(1, getColors().getAt(0));
        quad.getColors().setAt(2, getColors().getAt(1));
        quad.getColors().setAt(3, getColors().getAt(1));
        points = quad.getCoordinates().getBuffer();
        orthogonal.normalize();
        orthogonal.scale(getRadiusAt(0));
        points[0].set(getCoordinates().getAt(0));
        points[1].set(points[0]);
        orthogonal.normalize();
        orthogonal.scale(getRadiusAt(1));
        points[2].set(getCoordinates().getAt(1));
        points[3].set(points[2]);

        // modify points
        points[0].add(orthogonal);
        points[1].sub(orthogonal);
        points[2].add(orthogonal);
        points[3].sub(orthogonal);
        quad.getNormals().setUniform(quad.computeNormal());
        quad.insertInto(index, quadArray);
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public Shape3D getShape() {
        String id = Integer.toString(divisionX) + "x" + divisionY;
        Shape3D shape = (Shape3D) cylinderMap.get(id);
        Shape3D copy = new Shape3D();
        if (shape == null) {
            shape = getUnitCylinder();
            cylinderMap.put(id, shape);
        }
        GeometryHelper.copyGeometry(shape, copy);
        return copy;
    }
}
