/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.loaders.pdb;

import java.util.HashMap;
import java.util.Map;

import org.srs3d.viewer.util.ExceptionHandler;
import org.srs3d.viewer.util.Log;

/**
 * This class is part of the pdb file parsing architecture. It is used by the high level
 * parsers to instantiate the appropriate parser based on the current read string.
 *
 * @author Karsten Klein
 *
 * @created January 28, 2001
 */
public final class AbstractParserFactory {
    private static final Log log = new Log(AbstractParserFactory.class);
    private Map parserMap = new HashMap();

    /**
     * Constructor description.
     */
    public AbstractParserFactory() {

        // register all parsers with their appropriate tag
        parserMap.put(PdbAtomParser.TAG, new PdbAtomParser());
        parserMap.put(PdbHetAtmParser.TAG, new PdbHetAtmParser());
        parserMap.put(PdbHelixParser.TAG, new PdbHelixParser());
        parserMap.put(PdbSheetParser.TAG, new PdbSheetParser());
        parserMap.put(PdbTurnParser.TAG, new PdbTurnParser());
        parserMap.put(PdbModResParser.TAG, new PdbModResParser());
        parserMap.put(PdbHetParser.TAG, new PdbHetParser());
        parserMap.put(PdbDbRefParser.TAG, new PdbDbRefParser());
        parserMap.put(PdbTerParser.TAG, new PdbTerParser());
        parserMap.put(PdbModelParser.TAG, new PdbModelParser());
        parserMap.put(PdbSiteParser.TAG, new PdbSiteParser());
        parserMap.put(PdbEndMdlParser.TAG, new PdbEndMdlParser());
        parserMap.put(PdbHeaderParser.TAG, new PdbHeaderParser());
        parserMap.put(PdbEndParser.TAG, new PdbEndParser());
        parserMap.put(PdbCompndParser.TAG, new PdbCompndParser());
    }

    /**
     * Creates an instance of an AbstractPdbParser subclass, to parse the specified
     * string.
     *
     * @param string Description of parameter.
     *
     * @return The appropriate <code>AbstractPdbParser</code> or <code>null</code> if no
     *         parser was found.
     */
    public final AbstractPdbParser getInstance(String string) {
        if (string.length() < 6) {
            if (PdbParser.isVerbose()) {
                log.info("not a valid pdb tag:");
                AbstractPdbParser.displayError(string, 0);
            }
        } else {
            AbstractPdbParser parser =
                (AbstractPdbParser) parserMap.get(string.substring(0, 6));
            if (parser == null) {
                if (PdbParser.isVerbose()) {
                    log.info("no parser for " + string);
                }
            } else {

                // for retained parsers we create a new instance
                if (parser.isRetained()) {
                    try {
                        parser =
                            (AbstractPdbParser) parser.getClass().newInstance();
                    } catch (Exception e) {
                        ExceptionHandler.handleException(e,
                            ExceptionHandler.SILENT_IN_DEBUG, this);
                        if (PdbParser.isVerbose()) {
                            log.error("unable to instantiate parser of class " +
                                parser.getClass());
                        }
                    }
                }
            }
            return parser;
        }
        return null;
    }
}
