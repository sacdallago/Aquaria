/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d;

import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;

import org.srs3d.viewer.objects.AbstractManager;

/**
 * Description of the class.
 *
 * @author Karsten Klein
 *
 * @created September 6, 2001
 */
public class JunctionManager extends AbstractManager {
    private Map junctionMap = new Hashtable();

    /**
     * <code>JunctionManager</code> constructor.
     *
     * @param contextData Description of parameter.
     */
    public JunctionManager(ContextData contextData) {
        super(contextData);
    }

    /**
     * Sets the <code>switch</code> attribute of the <code>JunctionManager</code> object.
     *
     * @param switchIndex The new <code>switch</code> value.
     */
    public void setMode(int mode) {
        Iterator iterator = junctionMap.values().iterator();
        Junction junction;
        while (iterator.hasNext()) {
            junction = (Junction) iterator.next();
            junction.setMode(mode);
        }
    }

    /**
     * Gets the <code>junction</code> attribute of the <code>JunctionManager</code>
     * object.
     *
     * @param object Description of parameter.
     *
     * @return The <code>junction</code> value.
     */
    public Junction getJunction(Object object) {
        return (Junction) junctionMap.get(object);
    }

    /**
     * Description of the method.
     *
     * @param object Description of parameter.
     * @param junction Description of parameter.
     */
    public void register(Object object, Junction junction) {
        junctionMap.put(object, junction);
    }

    /**
     * Description of the method.
     */
    public void clear() {
        junctionMap.clear();
    }

    /**
     * Description of the method.
     *
     * @param object Description of parameter.
     */
    public void remove(Object object) {
        junctionMap.remove(object);
    }
}
