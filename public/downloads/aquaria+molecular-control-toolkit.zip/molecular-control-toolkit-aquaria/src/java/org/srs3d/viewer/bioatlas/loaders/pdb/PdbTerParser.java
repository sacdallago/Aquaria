/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.loaders.pdb;

import org.srs3d.viewer.bioatlas.objects.Chain;

/**
 * This class parses strings for pdb TER tags and tranfers/builts the appropriate
 * datastructure in a <code>ObjectContainer</code> .
 *
 * @author Karsten Klein
 *
 * @created January 20, 2001
 */
public class PdbTerParser extends PdbResidueParser {

    /** Description of the field */
    public static final String TAG = new String("TER   ");

    /**
     * Parses the formated pdb string for TER data.
     *
     * @param string Description of parameter.
     */
    public void create(String string) {
        clear();

        // :NOTE: the residue serial is not read!
        residueName = extractString(string, 17, 22);
        chainId = extractChar(string, 21);
        residueId = extractInt(string, 22, 26);
        residueICode = extractChar(string, 26);
    }

    /**
     * Visits a chain for applying the termination of the chain.
     *
     * @param chain the chain to apply the atom data to
     */
    public void visit(Chain chain) {
        chain.setId(chainId);
        chain.setTerminated(true);
        setSuccess(true);
    }
}
