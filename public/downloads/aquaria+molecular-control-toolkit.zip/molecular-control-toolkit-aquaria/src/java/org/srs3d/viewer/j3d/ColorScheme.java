/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d;

import java.util.Collection;
import java.util.Map;

import javax.media.j3d.Appearance;

import org.srs3d.viewer.objects.AbstractObject;

/**
 * This interface provides the methods used by a ColorScheme to modify objects
 * appearances.
 *
 * @author Karsten Klein
 *
 * @created July 23, 2001
 */
public interface ColorScheme {

    /**
     * Processes a single object modifying the specified <code>Appearance</code>
     *
     * @param object the object to apply the process.
     * @param appearance Description of parameter.
     *
     * @return <code>true</code> when the appearance was modified.
     */
    public boolean modify(AbstractObject object, Appearance appearance);

    /**
     * Applies the color scheme to all <code>AbstractObject</code>s in the specified
     * collection. This method uses the <code>AppearanceManager</code> to access the
     * associated appearances.
     *
     * @param collection <code>Collection</code> of <code>AbstractObject</code> s to
     *        modify.
     * @param contextData The <code>ContextData</code> identifies the context the changes
     *        will apply to. Note that the color scheme context could be different form
     *        this reference.
     */
    public void modify(ContextData contextData, Collection collection);

    /**
     * Gets the <code>volatile</code> attribute of the <code>ColorScheme</code> object.
     * If a color scheme is volatile it doesn't reregister it's modifications.
     *
     * @return The <code>volatile</code> value.
     */
    public boolean isVolatile();

    /**
     * Checks if the color scheme is a complete color scheme. This means that every
     * object can be colored by the color scheme. Or, in other words, no object is left
     * unchanged. Or, if there is a dependency to a previous color scheme.
     *
     * @return The <code>complete</code> value.
     */
    public boolean isComplete();

    /**
     * Determines whether the color scheme operates on per vertex level.
     *
     * @return If <code>true</code> some geometry have to bew recolored.
     */
    public boolean isVertexBased();

    /**
     * Returns a map with coloring information. The string GRADIENT is reserved for a
     * color curve; string GRADIENT_START is reserved for the token the gradient starts
     * with; string GRADIENT_END is reserved for the token the gradient ends with; The
     * string ORDER is reserved for a vector that defines the order of the tokens;
     *
     * @param map The map used for modifications.
     *
     * @return The information map.
     */
    public Map getInformation(Map map);

    /**
     * Method to determine if information is available.
     *
     * @return If false the colorscheme doesn't (want to ) provide further information.
     */
    public boolean hasInformation();
}
