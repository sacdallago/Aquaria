/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.factories;

import java.util.Hashtable;

import org.srs3d.viewer.bioatlas.objects.templates.ResidueTemplate;

/**
 * The class <code>ResidueTemplateFactory</code> produces and manages all
 * <code>ResidueTemplates</code> that are needed or are already available. Note that
 * this class implement the singleton(127) design pattern.
 *
 * @author Karsten Klein, 01/2001
 *
 * @since 1.0
 */
public final class ResidueTemplateFactory {

    /**
     * The static intstance is the only instance that is available of the
     * <code>ResidueTemplateFactory</code> class. Note that the class implements the
     * singleton(127) design pattern. The interface aims for transparancy concering the
     * static instance, that means there is no method getInstance() available and that
     * all public operations are redirected automatically
     */
    private static ResidueTemplateFactory residueTemplateFactory =
        new ResidueTemplateFactory();

    /**
     * The <code>ResidueTemplate</code> instances are kept in a HashMap to ensure fast
     * access
     */
    private Hashtable residueTemplates = null;

    /**
     * Constructor description.
     */
    private ResidueTemplateFactory() {
        residueTemplates = new Hashtable();
    }

    /**
     * This method inquires an <code>ResidueTemplate</code> by the specifeid identifying
     * string. If such a template doesn't exist yet, it will be allocated and stored
     * with the other templates for further accessing.
     *
     * @param string specifies the template to retrieve
     *
     * @return The appropriate <code>ResidueTemplate</code>
     */
    public static final ResidueTemplate getTemplate(String string) {
        return residueTemplateFactory.getResidueTemplate(string);
    }

    /**
     * Private redirected version of getTemplate()
     */
    private final ResidueTemplate getResidueTemplate(String string) {
        if (string != null) {
            Integer templateKey = new Integer(string.hashCode());
            if (residueTemplates.containsKey(templateKey)) {
                return (ResidueTemplate) residueTemplates.get(templateKey);
            } else {

                // construct a new residue template
                ResidueTemplate residueTemplate = new ResidueTemplate(string);
                residueTemplates.put(templateKey, residueTemplate);
                return residueTemplate;
            }
        }
        return null;
    }
}
