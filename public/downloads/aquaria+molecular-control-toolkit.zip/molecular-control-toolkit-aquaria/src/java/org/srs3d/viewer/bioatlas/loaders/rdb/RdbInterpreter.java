/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.loaders.rdb;

import java.util.Map;

import org.srs3d.viewer.objects.ObjectContainer;

/**
 * RdbInterpreters are used to interprete the date contained in an RDB file. It is used
 * in conjunction with the RdbFieldParser that creates a map of the data fields in an
 * RDB line. The interpreter than interpretes the data and stores the generated objects
 * in the specifided objectContainer.
 *
 * @author Karsten Klein
 *
 * @created December 10, 2001
 */
public interface RdbInterpreter {

    /**
     * Interpretes then data in the fieldMap and creates a representation that is stored
     * in the specified object container.
     *
     * @param fieldMap Maps field identifiers to field content.
     * @param objectContainer Destination of the interpreted data.
     */
    public void interprete(Map fieldMap, ObjectContainer objectContainer);

    /**
     * Finalizes the interpretation. The finalization is applied on all data item in the
     * specified container.
     *
     * @param objectContainer Container to finalze interpretation for.
     */
    public void finalizeInterpretation(ObjectContainer objectContainer);
}
