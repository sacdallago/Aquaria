/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.modules;

import java.awt.event.ActionEvent;
import java.net.URL;

import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.util.Log;

/**
 * @author Karsten Klein
 *
 * @created February 06, 2002
 */
public class AboutModule extends AbstractModule {
    private static final Log log = new Log(AboutModule.class);

    // temporary solution for sampling structures
    private boolean isSampling = false;

    /**
     * <code>ResetModule</code> constructor.
     *
     * @param name Description of parameter.
     * @param context Description of parameter.
     */
    public AboutModule(String name, ContextData contextData) {
        super(name, contextData);
        setOperationSerializeable(false);
    }

    /**
     * Description of the method.
     *
     * @param e Description of parameter.
     */
    public void react(ActionEvent event) {
        ImageIcon icon = null;
        try {
            URL iconUrl =
                getClass().getResource("/org/srs3d/viewer/bioatlas/resource/SRS3D.jpg");
            icon = new ImageIcon(iconUrl);
        } catch (Exception e) {
            log.error("icon cannot be loaded.", e);
        }
        org.srs3d.viewer.swing.ComponentFactory.messageDialog(getContextData()
                                                                  .getContext(),
            org.srs3d.viewer.bioatlas.Parameter.applicationName + " - Build " +
            org.srs3d.viewer.bioatlas.Parameter.applicationVersion + "\n\n" +
            "Developed by\n" + "  Sean O'Donoghue, Karsten Klein,\n" +
            "  Andrea Schafferhans, Joachim Meyer,\n" +
            "  Christian Zofka\n\n\n" +
            "Copyright� 2007-2008 srs3d.org.\nAll rights reserved.   ",
            "About", JOptionPane.PLAIN_MESSAGE, icon);
        if (isSampling) {
            getContextData().getIntersectionManager().sample(50, 15, 120);
        }
    }
}
