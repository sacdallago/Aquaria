/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.objects;


/**
 * Description of the class.
 *
 * @author Karsten Klein
 *
 * @created December 14, 2001
 */
public class DbRef extends Subchain {

    /** Description of the field. */
    public static final char CODE = 'R';
    private String dbId = null;
    private String dbAccession = null;
    private String dbIdCode = null;

    /**
     * Sets the <code>dbId</code> attribute of the <code>DbRef</code> object.
     *
     * @param dbId The new <code>dbId</code> value.
     */
    public final void setDbId(String dbId) {
        this.dbId = dbId;
    }

    /**
     * Sets the <code>dbAccession</code> attribute of the <code>DbRef</code> object.
     *
     * @param dbAccession The new <code>dbAccession</code> value.
     */
    public final void setDbAccession(String dbAccession) {
        this.dbAccession = dbAccession;
    }

    /**
     * Sets the <code>dbIdCode</code> attribute of the <code>DbRef</code> object.
     *
     * @param dbIdCode The new <code>dbIdCode</code> value.
     */
    public final void setDbIdCode(String dbIdCode) {
        this.dbIdCode = dbIdCode;
    }

    /**
     * Sets the <code>id</code> attribute of the <code>DbRef</code> object.
     *
     * @param id The new <code>id</code> value.
     */
    public final void setId(String id) {
        this.dbId = id;
    }

    /**
     * Gets the <code>dbId</code> attribute of the <code>DbRef</code> object.
     *
     * @return The <code>dbId</code> value.
     */
    public final String getDbId() {
        return dbId;
    }

    /**
     * Gets the <code>dbAccession</code> attribute of the <code>DbRef</code> object.
     *
     * @return The <code>dbAccession</code> value.
     */
    public final String getDbAccession() {
        return dbAccession;
    }

    /**
     * Gets the <code>dbIdCode</code> attribute of the <code>DbRef</code> object.
     *
     * @return The <code>dbIdCode</code> value.
     */
    public final String getDbIdCode() {
        return dbIdCode;
    }

    /**
     * Gets the <code>code</code> attribute of the <code>DbRef</code> object.
     *
     * @return The <code>code</code> value.
     */
    public char getCode() {
        return CODE;
    }

    /**
     * Description of the method.
     *
     * @return Description of the returned value.
     */
    public String toString() {
        String string = new String("DbRef");
        string += "(" + getDbId() + ":";
        string += getDbAccession() + "(";
        string += getDbIdCode() + "))";
        return string;
    }
}
