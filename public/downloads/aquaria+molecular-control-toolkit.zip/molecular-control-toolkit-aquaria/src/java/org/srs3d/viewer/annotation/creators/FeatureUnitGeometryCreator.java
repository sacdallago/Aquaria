/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.annotation.creators;

import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Vector;

import javax.media.j3d.BranchGroup;
import javax.media.j3d.Shape3D;
import javax.vecmath.Point3f;
import javax.vecmath.Tuple3f;

import org.srs3d.viewer.annotation.attributes.LayoutPosition;
import org.srs3d.viewer.annotation.objects.Alignment;
import org.srs3d.viewer.annotation.objects.AnnotationUnit;
import org.srs3d.viewer.annotation.objects.ChainAnnotation;
import org.srs3d.viewer.annotation.objects.FeatureUnit;
import org.srs3d.viewer.bioatlas.Parameter;
import org.srs3d.viewer.bioatlas.objects.Residue;
import org.srs3d.viewer.j3d.ShapeManager;
import org.srs3d.viewer.j3d.creators.AbstractGeometryCreator;
import org.srs3d.viewer.j3d.geometry.GeometryHelper;
import org.srs3d.viewer.j3d.geometry.primitive.Line;
import org.srs3d.viewer.j3d.geometry.primitive.Quad;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.objects.ObjectManager;
import org.srs3d.viewer.objects.State;
import org.srs3d.viewer.util.Log;

/**
 * Description of the class.
 *
 * @author Karsten Klein
 *
 * @created October 11, 2001
 */
public class FeatureUnitGeometryCreator extends AbstractGeometryCreator {
    private static final Log log = new Log(FeatureUnitGeometryCreator.class);
    private Point3f position = new Point3f();

    /**
     * Description of the method.
     *
     * @param object Description of parameter.
     * @param branchGroup Description of parameter.
     */
    public void create(AbstractObject object, BranchGroup branchGroup) {
        create((FeatureUnit) object, branchGroup);
    }

    /**
     * Description of the method.
     *
     * @param branchGroup Description of parameter.
     * @param feature Description of parameter.
     */
    public void create(FeatureUnit featureUnit, BranchGroup branchGroup) {

        // do layout stuff
        State.Immutable state;
        LayoutPosition.Immutable layoutPosition;
        getContextData().getObjectManager().register(featureUnit.getFeature(),
            featureUnit);
        state =
            getContextData().getStateManager().getImmutableState(featureUnit);
        layoutPosition =
            (LayoutPosition.Immutable) state.getAttribute(LayoutPosition.class);
        if (layoutPosition != null) {
            position.add(layoutPosition.getPosition());
        }
        position.z += 1.5f;
        Alignment alignment = null;
        AnnotationUnit annotationUnit = null;
        ChainAnnotation chainAnnotation = null;
        Collection alignments = new Vector();
        getContextData().getObjectManager().getUpAssociations(featureUnit,
            alignments);
        Collection annotationUnits = new Vector();
        ObjectManager.extract(alignments, annotationUnits, AnnotationUnit.class);
        ObjectManager.extract(alignments, Alignment.class);
        if (!alignments.isEmpty()) {
            alignment = (Alignment) alignments.iterator().next();
            if (!annotationUnits.isEmpty()) {
                annotationUnit =
                    (AnnotationUnit) annotationUnits.iterator().next();
                chainAnnotation = alignment.findChainAnnotation(annotationUnit);
                if (chainAnnotation != null) {
                    Shape3D shape =
                        createQuadGeometry(featureUnit,
                            chainAnnotation.getGapSequence());
                    getContextData().getShapeManager().register(featureUnit.getFeature(),
                        shape);
                    ShapeManager.setCapabilities(shape, featureUnit);
                    branchGroup.addChild(shape);
                    shape =
                        createLineGeometry(featureUnit,
                            chainAnnotation.getGapSequence());
                    getContextData().getShapeManager().register(featureUnit.getFeature(),
                        shape);
                    ShapeManager.setCapabilities(shape, featureUnit);
                    shape.setPickable(false);
                    branchGroup.addChild(shape);
                } else {
                    log.error("no ChainAnnotation found for " + featureUnit);
                }
            }
        }
        if (chainAnnotation == null) {
            log.error("no ChainAnnotation found for " + featureUnit);
        }
    }

    /**
     * Description of the method.
     *
     * @param start Description of parameter.
     * @param width Description of parameter.
     *
     * @return Description of the returned value.
     */
    private Shape3D createQuad(float start, float end, float height,
        Tuple3f position) {
        Shape3D shape = null;
        float width = end - start;
        Tuple3f offset = new Point3f(start + width / 2.0f, 0.0f, 0.0f);
        Quad quad = new Quad();
        quad.getCoordinates().scale(new Point3f(width, height, 1.0f));
        quad.getCoordinates().add(offset);
        quad.getCoordinates().add(position);
        shape = quad.getShape();
        return shape;
    }

    private Shape3D createLine(float start, float end, float height,
        Tuple3f position) {
        Shape3D shape = null;
        float width = end - start;
        height -= 0.2;
        Tuple3f offset = new Point3f(start + 0.5f, -height / 2, 0.0f);
        offset.add(position);
        Line line = new Line();
        line.getCoordinates().setAt(0, offset);
        offset.y += height;
        line.getCoordinates().setAt(1, offset);
        shape = line.getShape();
        return shape;
    }

    private Shape3D createQuadGeometry(FeatureUnit featureUnit,
        Vector gapSequence) {
        Shape3D composedShape = new Shape3D();
        Shape3D shape;
        HashSet residues = new HashSet();
        residues.addAll(featureUnit.getFeature().getObjects());
        ObjectManager.extract(residues, Residue.class);
        Iterator iterator = gapSequence.iterator();
        Residue residue;
        int index = -1;
        int i;
        for (i = 0; i < gapSequence.size(); i++) {
            residue = (Residue) gapSequence.elementAt(i);
            if (residue != null && residues.contains(residue)) {
                if (index == -1) {
                    index = i;
                }
            } else {
                if (index != -1) {
                    shape =
                        createQuad(index, i, Parameter.featureHeight, position);
                    GeometryHelper.copyGeometry(shape, composedShape);
                }
                index = -1;
            }
        }
        if (index != -1) {
            shape = createQuad(index, i, Parameter.featureHeight, position);
            GeometryHelper.copyGeometry(shape, composedShape);
        }
        return composedShape;
    }

    private Shape3D createLineGeometry(FeatureUnit featureUnit,
        Vector gapSequence) {
        Shape3D composedShape = new Shape3D();
        Shape3D shape;
        HashSet residues = new HashSet();
        residues.addAll(featureUnit.getFeature().getObjects());
        ObjectManager.extract(residues, Residue.class);
        Iterator iterator = gapSequence.iterator();
        Residue residue;
        int index = -1;
        int i;
        for (i = 0; i < gapSequence.size(); i++) {
            residue = (Residue) gapSequence.elementAt(i);
            if (residue != null && residues.contains(residue)) {
                if (index == -1) {
                    index = i;
                }
            } else {
                if (index != -1) {
                    shape =
                        createLine(index, i, Parameter.featureHeight, position);
                    GeometryHelper.copyGeometry(shape, composedShape);
                }
                index = -1;
            }
        }
        if (index != -1) {
            shape = createLine(index, i, Parameter.featureHeight, position);
            GeometryHelper.copyGeometry(shape, composedShape);
        }
        return composedShape;
    }
}
