/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.styles;

import org.srs3d.viewer.annotation.colorschemes.DisplacementColorScheme;
import org.srs3d.viewer.bioatlas.colorschemes.TransparentColorScheme;
import org.srs3d.viewer.bioatlas.objects.Layer;
import org.srs3d.viewer.j3d.ColorScheme;
import org.srs3d.viewer.j3d.ColorSchemeBucket;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.commands.ColorCommand;

/**
 * @author Karsten Klein
 *
 * @created July 11, 2001
 */
public class DisplacementStyle extends HomologyStyle {

    /**
     * Constructor description.
     *
     * @param contextData Parameter description.
     */
    public DisplacementStyle(ContextData contextData) {
        super(contextData);
    }

    /**
     * Description of the method.
     *
     * @param layer Description of parameter.
     */
    public void applyColorScheme(Layer layer) {
        ColorSchemeBucket colorSchemeBucket = new ColorSchemeBucket();
        ColorScheme colorScheme = getColorScheme(DisplacementColorScheme.class);
        colorSchemeBucket.extend(colorScheme);
        getContextData().setColorScheme(colorScheme);
        if (layer.isMaster() && layer.isImposed()) {
            colorSchemeBucket.add(getColorScheme(TransparentColorScheme.class));
        }
        ColorCommand colorCommand =
            new ColorCommand(getContextData(), colorSchemeBucket);
        colorCommand.setForceRecoloring(true);
        colorCommand.propagate(layer);
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public String getName() {
        return "Displacement";
    }
}
