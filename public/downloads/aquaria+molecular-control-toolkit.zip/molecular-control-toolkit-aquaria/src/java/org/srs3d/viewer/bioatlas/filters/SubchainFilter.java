/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.filters;

import org.srs3d.viewer.bioatlas.objects.Residue;
import org.srs3d.viewer.bioatlas.objects.Subchain;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.objects.filters.ObjectClassFilter;

/**
 * <code>ObjectFilter</code> implementation filtering <code>Residue</code> with
 * <code>ResidueTemplate</code> specific serial, and insertion code.
 *
 * @author Karsten Klein
 *
 * @created May 14, 2001
 */
public class SubchainFilter extends ObjectClassFilter {

    /**
     * Constructor description.
     */
    public SubchainFilter() {

        // uses the residue as breaking the preFilter process
        super(Residue.class);
    }

    /**
     * Description of the method.
     *
     * @param object Description of parameter.
     *
     * @return Description of the returned value.
     */
    public boolean filter(AbstractObject object) {
        return (Subchain.class.isAssignableFrom(object.getClass()));
    }
}
