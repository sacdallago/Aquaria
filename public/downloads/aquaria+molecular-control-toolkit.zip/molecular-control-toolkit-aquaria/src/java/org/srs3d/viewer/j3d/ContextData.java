/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d;

import java.applet.AppletStub;
import java.awt.Component;
import java.util.Collection;
import java.util.HashSet;

import org.srs3d.viewer.integration.datamodel.GenericDataTransferObject;
import org.srs3d.viewer.integration.datamodel.contract.GenericContract;
import org.srs3d.viewer.j3d.behaviors.dispatcher.Dispatcher;
import org.srs3d.viewer.j3d.factories.GeometryCreatorFactory;
import org.srs3d.viewer.j3d.factories.SpawnerFactory;
import org.srs3d.viewer.objects.ObjectContainer;
import org.srs3d.viewer.objects.ObjectManager;
import org.srs3d.viewer.objects.StateManager;
import org.srs3d.viewer.objects.StatePrototypeManager;
import org.srs3d.viewer.objects.StrategyManager;
import org.srs3d.viewer.util.ExceptionHandler;

/**
 * Description of the class
 *
 * @author Karsten Klein
 *
 * @created March 20, 2001
 */
public class ContextData {
    private Context context;

    /** the component the context is embedded in */
    private Component component;
    private boolean isExpertContext = false;
    private boolean isValid = true;

    // move to color scheme manager
    private ColorSchemeBucket colorSchemeBucket = null;
    private Dispatcher dispatcher = null;
    private ShapeManager shapeManager;
    private SpawnerManager spawnerManager;
    private TransformManager transformManager;
    private JunctionManager junctionManager;
    private AppearanceManager appearanceManager;
    private ColorSchemeManager colorSchemeManager;
    private IntersectionManager intersectionManager;
    private SpawnerFactory spawnerFactory;
    private GeometryCreatorFactory geometryCreatorFactory;
    private ObjectManager objectManager = new ObjectManager();
    private StateManager stateManager;
    private StatePrototypeManager statePrototypeManager;
    private StrategyManager strategyManager = null;
    private SelectionManager selectionManager = null;
    private SensorManager sensorManager = null;
    private LabelManager labelManager = new LabelManager();
    private OverlayManager overlayManager;
    private ObjectContainer objectContainer = new ObjectContainer();
    private AppletStub appletStub = null;
    private GenericDataTransferObject propertyMap =
        new GenericDataTransferObject();

    /**
     * <code>ContextData</code> constructor.
     *
     * @param context Description of parameter.
     */
    public ContextData(Context context) {
        propertyMap.setContract(new GenericContract());
        this.context = context;
        intersectionManager = new IntersectionManager(this);
        sensorManager = new SensorManager(this);
        selectionManager = new SelectionManager(this);
        strategyManager = new StrategyManager(this);
        appearanceManager = new AppearanceManager(this);
        colorSchemeManager = new ColorSchemeManager(this);
        geometryCreatorFactory = new GeometryCreatorFactory(this);
        spawnerManager = new SpawnerManager(this);
        spawnerFactory = new SpawnerFactory(this);
        statePrototypeManager = new StatePrototypeManager(this);
        shapeManager = new ShapeManager(this);
        junctionManager = new JunctionManager(this);
        transformManager = new TransformManager(this);
        stateManager = new StateManager(this);
        overlayManager = new OverlayManager(this);
        colorSchemeBucket = new ColorSchemeBucket();
        setVerbose(false);
    }

    /**
     * Sets the <code>ColorScheme</code> attribute of the <code>ContextData </code>object
     *
     * @param colorScheme The new <code>ColorScheme</code> value
     */
    public void setColorScheme(ColorScheme colorScheme) {
        colorSchemeBucket.extend(colorScheme);
    }

    /**
     * Method description.
     *
     * @param colorSchemeBucket Parameter description.
     */
    public void setColorSchemeBucket(ColorSchemeBucket colorSchemeBucket) {
        this.colorSchemeBucket.extend(colorSchemeBucket);
    }

    /**
     * Sets the <code>Dispatcher</code> attribute of the <code>ContextData </code>object
     *
     * @param dispatcher The new <code>Dispatcher</code> value
     */
    public void setDispatcher(Dispatcher dispatcher) {
        this.dispatcher = dispatcher;
    }

    /**
     * Sets the <code>labelManager</code> attribute of the <code>ContextData</code>
     * object.
     *
     * @param manager The new <code>labelManager</code> value.
     */
    public void setLabelManager(LabelManager manager) {
        labelManager = manager;
    }

    /**
     * Sets the <code>appletStub</code> attribute of the <code>ContextData</code> object.
     *
     * @param appletStub The new <code>appletStub</code> value.
     */
    public void setAppletStub(AppletStub appletStub) {
        this.appletStub = appletStub;
    }

    /**
     * Sets the <code>component</code> attribute of the <code>ContextData</code> object.
     *
     * @param component The new <code>component</code> value.
     */
    public void setComponent(Component component) {
        this.component = component;
    }

    /**
     * Sets the <code>expertContext</code> attribute of the <code>ContextData</code>
     * object.
     *
     * @param isExpertContext The new <code>expertContext</code> value.
     */
    public void setExpertContext(boolean isExpertContext) {
        this.isExpertContext = isExpertContext;
    }

    /**
     * Gets the <code>colorSchemeManager</code> attribute of the <code>ContextData</code>
     * object.
     *
     * @return The <code>colorSchemeManager</code> value.
     */
    public ColorSchemeManager getColorSchemeManager() {
        return colorSchemeManager;
    }

    /**
     * Gets the <code>SpawnerManager</code> attribute of the <code>ContextData
     * </code>object
     *
     * @return The <code>SpawnerManager</code> value
     */
    public SpawnerManager getSpawnerManager() {
        return spawnerManager;
    }

    /**
     * Gets the <code>ObjectManager</code> attribute of the <code>ContextData
     * </code>object
     *
     * @return The <code>ObjectManager</code> value
     */
    public ObjectManager getObjectManager() {
        return objectManager;
    }

    /**
     * Gets the <code>ShapeManager</code> attribute of the <code>ContextData
     * </code>object
     *
     * @return The <code>ShapeManager</code> value
     */
    public ShapeManager getShapeManager() {
        return shapeManager;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public SensorManager getSensorManager() {
        return sensorManager;
    }

    /**
     * Gets the <code>stateManager</code> attribute of the <code>ContextData </code>
     * object.
     *
     * @return The <code>stateManager</code> value.
     */
    public StateManager getStateManager() {
        return stateManager;
    }

    /**
     * Gets the <code>statePrototypeManager</code> attribute of the
     * <code>ContextData</code> object.
     *
     * @return The <code>statePrototypeManager</code> value.
     */
    public StatePrototypeManager getStatePrototypeManager() {
        return statePrototypeManager;
    }

    /**
     * Gets the <code>strategyManager</code> attribute of the <code>ContextData </code>
     * object.
     *
     * @return The <code>strategyManager</code> value.
     */
    public StrategyManager getStrategyManager() {
        return strategyManager;
    }

    /**
     * Gets the <code>transformManager</code> attribute of the <code>ContextData </code>
     * object.
     *
     * @return The <code>transformManager</code> value.
     */
    public TransformManager getTransformManager() {
        return transformManager;
    }

    /**
     * Gets the <code>junctionManager</code> attribute of the <code>ContextData </code>
     * object.
     *
     * @return The <code>junctionManager</code> value.
     */
    public JunctionManager getJunctionManager() {
        return junctionManager;
    }

    /**
     * Gets the <code>labelManager</code> attribute of the <code>ContextData</code>
     * object.
     *
     * @return The <code>labelManager</code> value.
     */
    public LabelManager getLabelManager() {
        return labelManager;
    }

    /**
     * Gets the <code>overlayManager</code> attribute of the <code>ContextData</code>
     * object.
     *
     * @return The <code>overlayManager</code> value.
     */
    public OverlayManager getOverlayManager() {
        return overlayManager;
    }

    /**
     * Gets the <code>geometryCreatorFactory</code> attribute of the
     * <code>ContextData</code> object.
     *
     * @return The <code>geometryCreatorFactory</code> value.
     */
    public GeometryCreatorFactory getGeometryCreatorFactory() {
        return geometryCreatorFactory;
    }

    /**
     * Gets the <code>spawnerFactory</code> attribute of the <code>ContextData </code>
     * object.
     *
     * @return The <code>spawnerFactory</code> value.
     */
    public SpawnerFactory getSpawnerFactory() {
        return spawnerFactory;
    }

    /**
     * Gets the <code>appearanceManager</code> attribute of the <code>ContextData </code>
     * object.
     *
     * @return The <code>appearanceManager</code> value.
     */
    public AppearanceManager getAppearanceManager() {
        return appearanceManager;
    }

    /**
     * Gets the <code>intersectionManager</code> attribute of the
     * <code>ContextData</code> object.
     *
     * @return The <code>intersectionManager</code> value.
     */
    public IntersectionManager getIntersectionManager() {
        return intersectionManager;
    }

    /**
     * Gets the <code>selectionManager</code> attribute of the <code>ContextData</code>
     * object.
     *
     * @return The <code>selectionManager</code> value.
     */
    public SelectionManager getSelectionManager() {
        return selectionManager;
    }

    /**
     * Gets the <code>ColorScheme</code> attribute of the <code>ContextData </code>object
     *
     * @return The <code>ColorScheme</code> value
     */
    public ColorSchemeBucket getColorSchemeBucket() {
        return colorSchemeBucket;
    }

    /**
     * Gets the <code>Dispatcher</code> attribute of the <code>ContextData </code>object
     *
     * @return The <code>Dispatcher</code> value
     */
    public Dispatcher getDispatcher() {
        return dispatcher;
    }

    /**
     * Gets the <code>context</code> attribute of the <code>ContextData</code> object.
     *
     * @return The <code>context</code> value.
     */
    public final Context getContext() {
        return context;
    }

    /**
     * Gets the <code>objectContainer</code> attribute of the <code>ContextData</code>
     * object.
     *
     * @return The <code>objectContainer</code> value.
     */
    public ObjectContainer getObjectContainer() {
        return objectContainer;
    }

    /**
     * Gets the <code>appletStub</code> attribute of the <code>ContextData</code> object.
     *
     * @return The <code>appletStub</code> value.
     */
    public AppletStub getAppletStub() {
        return appletStub;
    }

    /**
     * Gets the <code>component</code> attribute of the <code>ContextData</code> object.
     *
     * @return The <code>component</code> value.
     */
    public Component getComponent() {
        return component;
    }

    /**
     * Gets the <code>expertContext</code> attribute of the <code>ContextData</code>
     * object.
     *
     * @return The <code>expertContext</code> value.
     */
    public boolean isExpertContext() {
        return isExpertContext;
    }

    /**
     * Description of the method
     */
    public void cleanup() {
        try {
            strategyManager.cancel();
            strategyManager.clear();
            propertyMap.clear();
            propertyMap.setContract(null);
            propertyMap = null;
            colorSchemeBucket.clear();
            colorSchemeBucket = null;
            if (dispatcher != null) {
                dispatcher.cleanup();
                dispatcher = null;
            }
        } catch (Exception e) {
            ExceptionHandler.handleException(e, this);
        }
        try {
            Selection selection = null;
            appearanceManager.clear();
            colorSchemeManager.clear();
            junctionManager.clear();
            geometryCreatorFactory.clearRegistry();
            selectionManager.clear();
            shapeManager.clear();
            spawnerFactory.clearRegistry();
            spawnerManager.clear();
            stateManager.clear();
            statePrototypeManager.clearRegistry();
            transformManager.clear();
            objectManager.clear();
            labelManager.clear();
            overlayManager.clear();
            sensorManager.clear();
            appearanceManager.cleanup();
            intersectionManager.cleanup();
        } catch (Exception e) {
            ExceptionHandler.handleException(e, this);
        }
        try {
            appearanceManager = null;
            colorSchemeManager = null;
            junctionManager = null;
            geometryCreatorFactory = null;
            selectionManager = null;
            shapeManager = null;
            spawnerFactory = null;
            spawnerManager = null;
            stateManager = null;
            statePrototypeManager = null;
            strategyManager = null;
            transformManager = null;
            objectManager = null;
            labelManager = null;
            overlayManager = null;
            sensorManager = null;
            ObjectContainer.clearDeep(objectContainer);
            objectContainer = null;
            appletStub = null;
            context = null;
            component = null;
        } catch (Exception e) {
            ExceptionHandler.handleException(e, this);
        }
    }

    /**
     * Method description.
     *
     * @param isVerbose Parameter description.
     */
    public void setVerbose(boolean isVerbose) {
        appearanceManager.setVerbose(isVerbose);
        colorSchemeManager.setVerbose(isVerbose);
        junctionManager.setVerbose(isVerbose);
        selectionManager.setVerbose(isVerbose);
        spawnerManager.setVerbose(isVerbose);
        stateManager.setVerbose(isVerbose);
        shapeManager.setVerbose(isVerbose);
        statePrototypeManager.setVerbose(isVerbose);
        strategyManager.setVerbose(isVerbose);
        transformManager.setVerbose(isVerbose);
        overlayManager.setVerbose(isVerbose);
        sensorManager.setVerbose(isVerbose);
        AppearanceHelper.setVerbose(isVerbose);
    }

    /**
     * Method description.
     *
     * @param key Parameter description.
     *
     * @return Return description.
     */
    public Object getProperty(Object key) {
        if (propertyMap != null) {
            return propertyMap.get(key);
        }
        return null;
    }

    /**
     * Method description.
     *
     * @param key Parameter description.
     * @param property Parameter description.
     */
    public void setProperty(Object key, Object property) {
        if (propertyMap != null) {
            propertyMap.set(key, property);
        }
    }

    /**
     * Method description.
     *
     * @param key Parameter description.
     * @param property Parameter description.
     */
    public void addProperty(Object key, Object property) {
        if (propertyMap != null) {
            Collection collection = (Collection) getProperty(key);
            if (collection == null) {
                collection = new HashSet();
                setProperty(key, collection);
            }
            collection.add(property);
        }
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public final boolean isValid() {
        return isValid;
    }

    /**
     * Method description.
     */
    public final void invalidate() {
        isValid = false;
    }
}
