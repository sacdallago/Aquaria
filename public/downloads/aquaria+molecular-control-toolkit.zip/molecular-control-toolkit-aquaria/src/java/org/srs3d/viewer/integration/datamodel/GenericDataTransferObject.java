/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.integration.datamodel;

import org.srs3d.viewer.integration.datamodel.contract.DefaultObjectAttribute;
import org.srs3d.viewer.integration.interfaces.Contract;
import org.srs3d.viewer.integration.interfaces.ContractQualifier;

/**
 * Genric implementation of the AbstractDataTransferObject interface
 *
 * @author Karsten Klein
 *
 * @created September 12, 2002
 */
public class GenericDataTransferObject extends AbstractDataTransferObject {
    private Contract contract = null;

    /**
     * Sets the contract of the GenericDataTransferObject.
     *
     * @param contract New contract.
     */
    public void setContract(Contract contract) {
        this.contract = contract;
    }

    /**
     * Restrieves the contract for this object.
     *
     * @return Contract of the object.
     */
    public Contract getContract() {
        return contract;
    }

    /**
     * Gets the <code>object</code> attribute of the
     * <code>GenericDataTransferObject</code> object.
     *
     * @return The <code>object</code> value.
     */
    public Object getDataObject() {
        return this;
    }

    /**
     * Retrieve the object associated with the provided key.
     *
     * @param key Key for identifying the object.
     *
     * @return Associated object. This object might be the default object. Can be null.
     */
    public Object get(Object key) {
        Object object = super.get(key);
        if (object == null) {
            Contract contract = getContract();
            if (contract != null) {
                ContractQualifier qualifier =
                    contract.getContractQualifier(key);
                if (qualifier != null) {
                    DefaultObjectAttribute attribute =
                        (DefaultObjectAttribute) qualifier.getAttribute(DefaultObjectAttribute.class);
                    if (attribute != null) {
                        object = attribute.getDefaultObject();
                    }
                }
            }
        }
        return object;
    }
}
