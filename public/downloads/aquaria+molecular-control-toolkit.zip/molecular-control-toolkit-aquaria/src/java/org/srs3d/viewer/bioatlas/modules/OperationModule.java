/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.modules;

import java.awt.event.ActionEvent;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Vector;

import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.Selection;
import org.srs3d.viewer.objects.ObjectManager;
import org.srs3d.viewer.objects.Operation;
import org.srs3d.viewer.objects.StrategyManager;

/**
 * Menu module for executing <code>Command</code> s on the current selection.
 *
 * @author Karsten Klein
 *
 * @created May 14, 2001
 */
public class OperationModule extends ProcessModule {
    private Collection operations;

    /**
     * <code>CommandModule</code> constructor.
     *
     * @param name Description of parameter.
     * @param commands Description of parameter.
     * @param context Description of parameter.
     * @param objectClass Description of parameter.
     */
    public OperationModule(String name, ContextData contextData,
        Collection operations) {
        super(name, contextData);
        this.operations = operations;
        setOperationSerializeable(false);
    }

    /**
     * Constructor description.
     *
     * @param name Parameter description.
     * @param contextData Parameter description.
     * @param operation Parameter description.
     */
    public OperationModule(String name, ContextData contextData,
        Operation operation) {
        super(name, contextData);
        this.operations = new Vector();
        operations.add(operation);
        setOperationSerializeable(false);
    }

    /**
     * Description of the method.
     *
     * @param e Description of parameter.
     */
    public void process(ActionEvent e) {
        ContextData contextData = getContextData();
        ObjectManager objectManager = contextData.getObjectManager();
        StrategyManager strategyManager = contextData.getStrategyManager();
        Selection selection = contextData.getSelectionManager().getSelection();
        final Collection objects = new HashSet(selection);
        Iterator iterator = operations.iterator();
        while (iterator.hasNext()) {
            contextData.getDispatcher().runDispatch((Operation) iterator.next());
        }
    }

    /**
     * Description of the method.
     */
    public void cleanup() {
        super.cleanup();
        if (operations != null) {
            operations.clear();
            operations = null;
        }
    }
}
