/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.objects.strategies;

import java.awt.image.BufferedImage;
import java.util.Collection;
import java.util.HashSet;

import javax.media.j3d.Appearance;
import javax.media.j3d.Texture;
import javax.vecmath.Color3f;
import javax.vecmath.Color4f;

import org.srs3d.viewer.bioatlas.attributes.ResidueRepresentation;
import org.srs3d.viewer.bioatlas.attributes.SubchainRepresentation;
import org.srs3d.viewer.bioatlas.objects.Residue;
import org.srs3d.viewer.bioatlas.objects.Subchain;
import org.srs3d.viewer.j3d.AppearanceHelper;
import org.srs3d.viewer.j3d.AppearanceManager;
import org.srs3d.viewer.j3d.AppearanceManager.TextureColors;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.Reaction;
import org.srs3d.viewer.j3d.attributes.Expanded;
import org.srs3d.viewer.j3d.commands.ColorCommand;
import org.srs3d.viewer.j3d.commands.ExpandCommand;
import org.srs3d.viewer.j3d.commands.IdentificationCommand;
import org.srs3d.viewer.j3d.commands.IntersectCommand;
import org.srs3d.viewer.j3d.commands.PreSelectCommand;
import org.srs3d.viewer.j3d.commands.RepresentationCommand;
import org.srs3d.viewer.j3d.commands.SpawnCommand;
import org.srs3d.viewer.j3d.objects.strategies.AbstractStrategy;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.objects.Attribute;
import org.srs3d.viewer.objects.Command;
import org.srs3d.viewer.objects.State;
import org.srs3d.viewer.objects.StrategyManager;

/**
 * Specialized Strategy implementation for subchains.
 *
 * @author Karsten Klein
 *
 * @created April 03, 2001
 */
public class SubchainStrategy extends AbstractStrategy {

    /**
     * Constructor description.
     */
    public SubchainStrategy() {
        register(ExpandCommand.class, new ExpandReaction());
        register(PreSelectCommand.class, new PreSelectReaction());
        register(ColorCommand.class, new ColorReaction());
        register(IdentificationCommand.class, new IdentificationReaction());
        register(IntersectCommand.class, new ResidueStrategy.IntersectReaction());
    }

    /**
     * Class description.
     *
     * @author Karsten Klein, LION bioscience AG
     */
    public class PreSelectReaction implements Reaction {

        /**
         * Method description.
         *
         * @param command Parameter description.
         */
        public void execute(Command command) {
            PreSelectCommand preSelect = (PreSelectCommand) command;
            ContextData contextData = preSelect.getContextData();
            StrategyManager strategyManager = contextData.getStrategyManager();
            State.Immutable state =
                contextData.getStateManager().getImmutableState(preSelect.getObject());
            if (!state.hasAttribute(Expanded.class)) {

                // expand the subchain
                ExpandCommand expand = new ExpandCommand(contextData);
                expand.setObject(preSelect.getObject());
                SubchainStrategy.this.execute(expand);

                // respawn new geometry
                Collection spawners = new HashSet();
                spawners.add(preSelect.getObject());
                SpawnCommand.searchSpawners(contextData, spawners);
                SpawnCommand spawn = new SpawnCommand(contextData);
                contextData.getStrategyManager().execute(spawners, spawn);
                preSelect.setExpansion(true);
            }

            // finally execute the preSelect command
            preSelect.execute();
        }
    }

    /**
     * Class description.
     *
     * @author Karsten Klein, LION bioscience AG
     */
    public class ExpandReaction implements Reaction {

        /**
         * Method description.
         *
         * @param command Parameter description.
         */
        public void execute(Command command) {
            ExpandCommand expandCommand = (ExpandCommand) command;
            ContextData contextData = expandCommand.getContextData();
            StrategyManager strategyManager = contextData.getStrategyManager();
            State.Immutable state =
                contextData.getStateManager().getImmutableState(expandCommand.getObject());
            if (!state.hasAttribute(Expanded.class)) {
                expandCommand.execute();
                SubchainRepresentation.Immutable subchainRepresentation =
                    (SubchainRepresentation.Immutable) state.getAttribute(SubchainRepresentation.class);
                if (subchainRepresentation != null) {
                    ResidueRepresentation residueRepresentation =
                        (ResidueRepresentation) Attribute.getInstance(ResidueRepresentation.class);
                    residueRepresentation.setMode(subchainRepresentation.getMode());
                    RepresentationCommand residueRepresentationCommand =
                        new RepresentationCommand(contextData);
                    residueRepresentationCommand.setRepresentation(residueRepresentation);
                    strategyManager.propagate(expandCommand.getObject(),
                        residueRepresentationCommand, Residue.class);
                }
            }
        }
    }

    /**
     * Class description.
     *
     * @author Karsten Klein, LION bioscience AG
     */
    public static class ColorReaction implements Reaction {

        /**
         * Method description.
         *
         * @param command Parameter description.
         */
        public void execute(Command command) {

            // to keep track of the buckets for the subchain (to be rethought;
            //   yes: wireframe coloring on subchain level)
            command.execute();
            ColorCommand colorCommand = (ColorCommand) command;
            ContextData contextData =
                (ContextData) colorCommand.getContextData();
            Subchain subchain = (Subchain) command.getObject();
            boolean isForceRecoloring = colorCommand.isForceRecoloring();
            colorCommand.setForceRecoloring(true);
            AppearanceManager appearanceManager =
                contextData.getAppearanceManager();
            Appearance appearance = appearanceManager.getAppearance(subchain);
            Appearance textureAppearance;
            TextureColors textureColors =
                appearanceManager.getTextureColors(subchain);
            if (textureColors == null) {
                textureColors = initializeTexture(contextData, subchain);
                appearanceManager.registerTextureColors(subchain, textureColors);
            }
            activateResidueTexture(contextData, subchain, false);
            modifyColors(subchain, colorCommand, textureColors);

            // color residues (including texture color update)
            if (!textureColors.isMonochromatic()) {

                // the subchain appearance is overwritten
                // (always the same appearance for the subchain, but the bucket may change,
                // since the bucket may be propagated to the children)
                textureAppearance =
                    AppearanceHelper.createAppearance(new Color3f(1, 1, 1));
                Texture texture = textureColors.createTexture(contextData);
                textureAppearance.setTexture(texture);
                AppearanceHelper.setTextureDefaults(textureAppearance, texture);
                if (textureColors.isTransparent()) {
                    AppearanceHelper.enableTransparency(textureAppearance, 0,
                        true);
                }
            } else {
                textureAppearance =
                    AppearanceHelper.createAppearance(getResidueColor(
                            contextData, subchain.getInitialResidue()));
            }

            //      AppearanceHelper.enableVertexColors( textureAppearance,
            //        AppearanceHelper.areVertexColorsEnabled( appearance ) );
            //      AppearanceHelper.enableMesh( textureAppearance,
            //          AppearanceHelper.isMesh( appearance ) );
            // copy rendering (vertex colors) and polygon (mesh) attributes
            textureAppearance.setRenderingAttributes(appearance.getRenderingAttributes());
            textureAppearance.setPolygonAttributes(appearance.getPolygonAttributes());

            // copy the point and line attributes
            textureAppearance.setPointAttributes(appearance.getPointAttributes());
            textureAppearance.setLineAttributes(appearance.getLineAttributes());
            ColorCommand.apply(contextData, subchain, textureAppearance);
            colorCommand.setForceRecoloring(isForceRecoloring);

            // :FIXME: once the residues got a little smarter, we can remove (move) this line
            activateResidueTexture(contextData, subchain, true);
        }

        /**
         * Method description.
         *
         * @param contextData Parameter description.
         * @param residue Parameter description.
         *
         * @return Return description.
         */
        public Color4f getResidueColor(ContextData contextData, Residue residue) {
            Color4f color = new Color4f();
            Appearance appearance =
                contextData.getAppearanceManager().getAppearance(residue);
            AppearanceHelper.getColor(appearance, color);
            return color;
        }

        /**
         * Method description.
         *
         * @param contextData Parameter description.
         * @param subchain Parameter description.
         *
         * @return Return description.
         */
        public TextureColors initializeTexture(ContextData contextData,
            Subchain subchain) {
            TextureColors textureColors = new TextureColors();
            int width = subchain.getLength();
            textureColors.setWidth(width);
            width =
                org.srs3d.viewer.vecmath.Constants.computeNextHigherPowerOf2(width);
            BufferedImage bufferedImage =
                new BufferedImage(width, 1, BufferedImage.TYPE_INT_ARGB);
            textureColors.setImage(bufferedImage);
            textureColors.setReferenceObject(subchain);

            // create offset residue TextureColors instance
            AppearanceManager appearanceManager =
                contextData.getAppearanceManager();
            Residue residue = subchain.getInitialResidue();
            Residue limit = subchain.getEndResidue().getProceeding();
            TextureColors residueTextureColors;
            int index = 0;
            while (residue != limit) {
                residueTextureColors =
                    appearanceManager.getTextureColors(residue);
                if (residueTextureColors == null) {
                    residueTextureColors = textureColors.createOffset(index++);
                    appearanceManager.registerTextureColors(residue,
                        residueTextureColors);
                }
                residue = residue.getProceeding();
            }
            return textureColors;
        }

        /**
         * Method description.
         *
         * @param contextData Parameter description.
         * @param subchain Parameter description.
         * @param isActivate Parameter description.
         */
        public void activateResidueTexture(ContextData contextData,
            Subchain subchain, boolean isActivate) {

            // create offset residue TextureColors instance
            AppearanceManager appearanceManager =
                contextData.getAppearanceManager();
            Residue residue = subchain.getInitialResidue();
            Residue limit = subchain.getEndResidue().getProceeding();
            TextureColors residueTextureColors;
            int index = 0;
            while (residue != limit) {
                residueTextureColors =
                    appearanceManager.getTextureColors(residue);
                if (residueTextureColors != null) {
                    residueTextureColors.setActive(isActivate);
                }
                residue = residue.getProceeding();
            }
        }

        /**
         * Method description.
         *
         * @param subchain Parameter description.
         * @param colorCommand Parameter description.
         * @param textureColors Parameter description.
         */
        public void modifyColors(Subchain subchain, ColorCommand colorCommand,
            TextureColors textureColors) {
            Residue residue = subchain.getInitialResidue();
            Residue limit = subchain.getEndResidue().getProceeding();
            StrategyManager strategyManager =
                colorCommand.getContextData().getStrategyManager();
            AppearanceManager appearanceManager =
                colorCommand.getContextData().getAppearanceManager();
            Appearance appearance;
            Color4f color = new Color4f();
            TextureColors residueTextureColors;
            int index = 0;
            AbstractObject object = colorCommand.getObject();
            while (residue != limit) {
                strategyManager.execute(residue, colorCommand);
                appearance = appearanceManager.getAppearance(residue);
                AppearanceHelper.getColor(appearance, color);
                textureColors.setColor(index++, color);
                residue = residue.getProceeding();
            }
            colorCommand.setObject(object);
        }
    }

    /**
     * Reaction for retrieving the object identification.
     *
     * @author Karsten Klein
     *
     * @created March 26, 2002
     */
    public static class IdentificationReaction implements Reaction {

        /**
         * Execute implementation of the reaction interface.
         *
         * @param command Command to react to.
         */
        public void execute(Command command) {
            IdentificationCommand idCommand = (IdentificationCommand) command;
            idCommand.setObjectId("S:" + command.getObject());
            idCommand.execute();
        }
    }
}
