/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.commands;

import java.util.HashSet;

import javax.vecmath.Matrix4f;
import javax.vecmath.Point3f;
import javax.vecmath.Tuple3f;
import javax.vecmath.Vector3f;

import org.srs3d.viewer.bioatlas.objects.Layer;
import org.srs3d.viewer.bioatlas.visitors.AtomCollector;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.Transform;
import org.srs3d.viewer.j3d.TransformManager;
import org.srs3d.viewer.objects.ObjectManager;

/**
 * Compute center command. Do NOT propagate the command. Only execute
 *
 * @author Karsten Klein
 *
 * @created April 03, 2001
 */
public class ComputeCenterCommand extends ObjectCommand {
    private Point3f center = new Point3f();
    private int counter = -1;
    private Vector3f extend =
        new Vector3f(Float.MAX_VALUE, Float.MAX_VALUE, Float.MAX_VALUE);
    private transient Vector3f min =
        new Vector3f(Float.MAX_VALUE, Float.MAX_VALUE, Float.MAX_VALUE);
    private transient Vector3f max =
        new Vector3f(-Float.MAX_VALUE, -Float.MAX_VALUE, -Float.MAX_VALUE);

    /**
     * Constructor description.
     *
     * @param contextData Parameter description.
     */
    public ComputeCenterCommand(ContextData contextData) {
        super(contextData);
    }

    /**
     * Method description.
     */
    public void execute() {
        AtomCollector atomCollector = new AtomCollector();
        atomCollector.visit(getObject());
        if (!atomCollector.getObjects().isEmpty()) {
            Point3f center = atomCollector.getCenter();
            Vector3f extend = atomCollector.getExtend();
            HashSet set = new HashSet();
            getContextData().getObjectManager().getAssociations(getObject(), set);
            ObjectManager.extract(set, Layer.class);
            if (!set.isEmpty()) {
                TransformManager transformManager =
                    getContextData().getTransformManager();
                Layer layer = (Layer) set.iterator().next();
                Transform transform = transformManager.getTransform(layer);
                if (transform != null) {
                    Matrix4f matrix = new Matrix4f();
                    transform.getTransform().get(matrix);
                    matrix.transform(center);
                }
            }
            modifyCenter(center, extend);
        }
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public Point3f getCenter() {
        if (counter != -1) {
            center.scale(1.0f / counter);
        } else {
            center.set(Float.POSITIVE_INFINITY, Float.POSITIVE_INFINITY,
                -Float.POSITIVE_INFINITY);
        }
        return center;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public Vector3f getExtend() {
        return extend;
    }

    /**
     * Method description.
     *
     * @param center Parameter description.
     * @param extend Parameter description.
     */
    public void modifyCenter(Tuple3f center, Tuple3f extend) {
        if (counter == -1) {
            this.center.set(center);
            this.extend.set(extend);
            this.extend.scale(0.5f);
            min.set(this.center);
            min.sub(this.extend);
            max.set(this.center);
            max.add(this.extend);
            this.extend.scale(2);
            counter = 1;
        } else {

            // accumulate centers
            this.center.add(center);

            // merge extends
            extend.scale(0.5f);
            center.sub(extend);
            if (center.x < min.x) {
                min.x = center.x;
            }
            if (center.y < min.y) {
                min.y = center.y;
            }
            if (center.z < min.z) {
                min.z = center.z;
            }
            center.add(extend);
            center.add(extend);
            if (center.x > max.x) {
                max.x = center.x;
            }
            if (center.y > max.y) {
                max.y = center.y;
            }
            if (center.z > max.z) {
                max.z = center.z;
            }
            this.extend.set(max);
            this.extend.sub(min);
            counter++;
        }
    }
}
