/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.annotation.modules;

import java.awt.event.ActionEvent;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.StringTokenizer;

import javax.media.j3d.BoundingSphere;
import javax.media.j3d.BranchGroup;
import javax.vecmath.Point3d;

import org.srs3d.viewer.annotation.behaviors.ZoomBoxBehavior;
import org.srs3d.viewer.annotation.colorschemes.HomologyColorScheme;
import org.srs3d.viewer.annotation.constraints.PlaneAnnotationConstraint;
import org.srs3d.viewer.annotation.contexts.AbstractAnnotationContext;
import org.srs3d.viewer.annotation.contexts.AnnotationContext;
import org.srs3d.viewer.annotation.contexts.AnnotationContextData;
import org.srs3d.viewer.annotation.dispatcher.AnnotationUpDispatcher;
import org.srs3d.viewer.annotation.objects.Alignment;
import org.srs3d.viewer.annotation.objects.AnnotationContainer;
import org.srs3d.viewer.annotation.visitors.GapAnnotationCreator;
import org.srs3d.viewer.bioatlas.dispatcher.NavigateUpDispatcher;
import org.srs3d.viewer.bioatlas.factories.ResidueTemplateFactory;
import org.srs3d.viewer.bioatlas.filters.ChainIdFilter;
import org.srs3d.viewer.bioatlas.filters.ResidueFilter;
import org.srs3d.viewer.bioatlas.modules.ProcessModule;
import org.srs3d.viewer.bioatlas.objects.Chain;
import org.srs3d.viewer.bioatlas.objects.Coil;
import org.srs3d.viewer.bioatlas.objects.Compound;
import org.srs3d.viewer.bioatlas.objects.Layer;
import org.srs3d.viewer.bioatlas.objects.Residue;
import org.srs3d.viewer.bioatlas.objects.Section;
import org.srs3d.viewer.bioatlas.objects.Subchain;
import org.srs3d.viewer.bioatlas.objects.templates.ResidueTemplate;
import org.srs3d.viewer.j3d.BranchGroupHelper;
import org.srs3d.viewer.j3d.Context;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.Selection;
import org.srs3d.viewer.j3d.behaviors.PanXYBehavior;
import org.srs3d.viewer.j3d.commands.RegisterCommand;
import org.srs3d.viewer.j3d.commands.SpawnCommand;
import org.srs3d.viewer.j3d.commands.VisibleCommand;
import org.srs3d.viewer.j3d.objects.Rectangle;
import org.srs3d.viewer.j3d.operations.ParameterStringOperation;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.objects.ObjectContainer;
import org.srs3d.viewer.objects.ObjectManager;
import org.srs3d.viewer.objects.Operation;
import org.srs3d.viewer.objects.visitors.ObjectCollector;
import org.srs3d.viewer.objects.visitors.ObjectLocalizer;
import org.srs3d.viewer.sequence.contexts.SequenceContext;
import org.srs3d.viewer.util.Log;

/**
 * Description of the class.
 *
 * @author Karsten Klein
 *
 * @created May 14, 2001
 */
public class AnnotationModule extends ProcessModule {
    private static final Log log = new Log(AnnotationModule.class);
    private AnnotationContext annotationContext = null;
    private SequenceContext sequenceContext = null;
    private Context context = null;

    /**
     * <code>AnnotationModule</code> constructor.
     *
     * @param name Description of parameter.
     * @param context Description of parameter.
     * @param annotationContext Description of parameter.
     * @param sequenceContext Description of parameter.
     */
    public AnnotationModule(String name, Context context,
        AnnotationContext annotationContext, SequenceContext sequenceContext) {
        super(name, context.getContextData());
        this.context = context;
        this.annotationContext = annotationContext;
        this.sequenceContext = sequenceContext;
    }

    /**
     * Description of the method.
     *
     * @param e Description of parameter.
     */
    public void process(ActionEvent e) {
        ContextData contextData = context.getContextData();
        Selection selection = contextData.getSelectionManager().getSelection();
        Collection layers = new HashSet();
        contextData.getObjectManager().getUpAssociations(selection, layers);
        layers.addAll(selection);
        ObjectManager.extract(layers, Layer.class);
        ObjectContainer localContainer = new ObjectContainer();
        localContainer.addAll(layers);

        // remove all from current annotation container
        ObjectContainer.clearDeep(annotationContext.getContextData()
                                                   .getObjectContainer());
        annotationContext.clearContent();
        visualizeSegmentInformation(localContainer, context, annotationContext,
            sequenceContext, new HashMap());
        if (sequenceContext != null) {
            ObjectContainer.clearDeep(sequenceContext.getContextData()
                                                     .getObjectContainer());
            sequenceContext.clearContent();
            org.srs3d.viewer.sequence.modules.SequenceModule.visualizeResidueInformation(localContainer,
                annotationContext, sequenceContext, context);
        }

        // transmit selection (used in the cell view)
        //    Operation operation = new Operation( context, "TRANSFER_SELECTION", null );
        //    operation.setObjects( context.getContextData().getSelectionManager().getSelection() );
        //    DispatchManager.runDispatch( context, operation );
        //    super.actionPerformed( e );
    }

    /**
     * Description of the method.
     */
    public void cleanup() {
        super.cleanup();
        context = null;
        annotationContext = null;
    }

    /**
     * Description of the method.
     *
     * @param objectContainer Description of parameter.
     * @param context Description of parameter.
     * @param annotationContext Description of parameter.
     * @param sequenceContext Description of parameter.
     * @param layerAlignmentMap Description of parameter.
     */
    public static void visualizeSegmentInformation(
        ObjectContainer objectContainer, Context context,
        final AnnotationContext annotationContext,
        SequenceContext sequenceContext, Map layerAlignmentMap) {
        final ContextData annotationContextData =
            annotationContext.getContextData();
        ObjectContainer annotationObjectContainer =
            annotationContextData.getObjectContainer();

        //    AnnotationContainer annotationContainer = null;
        //
        //    if ( annotationContainer == null ) {
        //
        //      GapAnnotationCreator annotationCreator = new GapAnnotationCreator();
        //      annotationCreator.setLayerAlignmentMap( layerAlignmentMap );
        //      annotationCreator.visit( objectContainer );
        //
        //      annotationContainer = annotationCreator.getAnnotationContainer();
        //
        //    }
        GapAnnotationCreator annotationCreator = new GapAnnotationCreator();
        annotationCreator.setLayerAlignmentMap(layerAlignmentMap);
        annotationCreator.visit(objectContainer);
        final AnnotationContainer annotationContainer =
            annotationCreator.getAnnotationContainer();
        if (annotationContainer != null) {
            annotationObjectContainer.addObject(annotationContainer);
            setBehaviors(annotationContext, annotationContainer);
            if (annotationContainer.getAlignmentCount() != 0) {
                annotationContainer.update();
                if (sequenceContext != null) {
                    AnnotationContextData sequenceContextData =
                        (AnnotationContextData) sequenceContext.getContextData();
                    if (sequenceContextData.getZoomBox() != null) {

                        // get all zoomBox related things from the allready existing
                        // sequenceContextData
                        initializeZoomBox(annotationContext, sequenceContextData);
                    }
                }
                ((AnnotationUpDispatcher) annotationContextData.getDispatcher()).setAnnotationContainer(annotationContainer);
                context.addUpdateCallback(new org.srs3d.viewer.j3d.behaviors.UpdateBehavior.Callback() {
                        public void execute() {
                            SpawnCommand spawn =
                                new SpawnCommand(annotationContextData);
                            spawn.setBranchGroup(annotationContext.getSceneLevel());
                            annotationContextData.getStrategyManager().execute(annotationContainer,
                                spawn);
                            ((AnnotationUpDispatcher) annotationContextData.getDispatcher()).setAnnotationContainer(annotationContainer);
                            AnnotationUpDispatcher.processSelectionZoom(annotationContext,
                                annotationContainer, null, 0);
                        }
                    });
            }
            if (annotationContainer.getAlignmentMap() != null) {
                HomologyColorScheme.register(context.getContextData(),
                    annotationContainer);
            }
        } else {
            log.error("no annotations created.");
        }
    }

    /**
     * make the initializing of the zoomBox for the annotationContext; Important:
     * sequenceContext has to initialize the zoomBox first
     *
     * @param annotationContext Description of parameter.
     * @param sequenceContextData Description of parameter.
     */
    public static void initializeZoomBox(AnnotationContext annotationContext,
        AnnotationContextData sequenceContextData) {
        AnnotationContextData annotationContextData =
            (AnnotationContextData) annotationContext.getContextData();
        Rectangle zoomBox = sequenceContextData.getZoomBox();
        Alignment alignment = sequenceContextData.getActiveBoxAlignment();

        // register/saves zoomBox, current alignment, zoomBoxThread
        annotationContextData.setZoomBox(zoomBox);
        annotationContextData.setActiveBoxAlignment(alignment);
        SpawnCommand spawn = new SpawnCommand(annotationContextData);
        spawn.setBranchGroup(annotationContext.getSceneLevel());
        annotationContextData.getStrategyManager().execute(zoomBox, spawn);
        ZoomBoxBehavior zoomBoxBehavior =
            new ZoomBoxBehavior(annotationContextData);
        zoomBoxBehavior.setSchedulingBounds(new BoundingSphere(new Point3d(),
                Float.MAX_VALUE));
        zoomBoxBehavior.setSpeedy(0.0f);
        BranchGroup behaviorGroup = new BranchGroup();
        BranchGroupHelper.setDefaultCapabilities(behaviorGroup);
        behaviorGroup.addChild(zoomBoxBehavior);
        annotationContext.getBehaviorLevel().addChild(behaviorGroup);
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     * @param attributes Description of parameter.
     * @param sequenceMap Description of parameter.
     * @param descriptionMap Description of parameter.
     * @param chainMap Description of parameter.
     * @param layerMap Description of parameter.
     * @param alignmentMap Description of parameter.
     * @param flagMap Description of parameter.
     */
    public static void createMatches(ContextData contextData,
        String attributes, Map sequenceMap, Map descriptionMap, Map chainMap,
        Map layerMap, Map layerAlignmentMaps, Map flagMap) {
        ObjectCollector residueCollector;
        attributes =
            org.srs3d.viewer.bioatlas.modules.AnnotationModule.insertToken(attributes,
                ";", " ");
        StringTokenizer matchTokenizer = new StringTokenizer(attributes, ";");
        StringTokenizer tokenizer;
        StringTokenizer subTokenizer;
        Layer tempLayer = null;
        String match;
        String pdbRange;
        String seqRange;
        String sequenceId = null;
        char chainId = Chain.INVALID_ID;
        int residueSerial;
        char residueICode;
        int seqMatchStart = 0;
        int seqMatchEnd = 0;
        Residue pdbStartResidue = null;
        Residue pdbEndResidue = null;
        Residue seqStartResidue = null;
        Residue seqEndResidue = null;
        boolean foundAllResidues;
        Chain chain;
        String sequence = null;
        String layerId;

        // collects the chain ids that got an instance of a sequence
        // the ids are mapped to a collection of sequences that have already been
        // mapped onto the structure
        Map alignedChainIdMap = new HashMap();
        while (matchTokenizer.hasMoreTokens()) {
            match = matchTokenizer.nextToken().trim();
            if (match.length() > 0) {
                match =
                    org.srs3d.viewer.bioatlas.modules.AnnotationModule.insertToken(match,
                        ",", " ");
                tokenizer = new StringTokenizer(match, ",");
                foundAllResidues = false;
                if (tokenizer.countTokens() == 2) {
                    pdbRange = tokenizer.nextToken();
                    seqRange = tokenizer.nextToken();
                    pdbRange =
                        org.srs3d.viewer.bioatlas.modules.AnnotationModule.insertToken(pdbRange,
                            ":", " ");
                    tokenizer = new StringTokenizer(pdbRange, ":");

                    // parse pdb range
                    if (tokenizer.countTokens() == 6) {

                        // first token identifies the layer
                        layerId = tokenizer.nextToken().toLowerCase().trim();
                        tempLayer = (Layer) layerMap.get(layerId);
                        if (tempLayer != null) {

                            // search pdb seq start residue
                            chainId = tokenizer.nextToken().charAt(0);
                            residueSerial =
                                Integer.parseInt(tokenizer.nextToken());
                            residueICode = tokenizer.nextToken().charAt(0);
                            ObjectCollector chainCollector =
                                new ObjectCollector(new ChainIdFilter(chainId));
                            chainCollector.visit((AbstractObject) tempLayer);
                            Iterator chainIterator =
                                chainCollector.getObjects().iterator();
                            while (chainIterator.hasNext()) {
                                chain = (Chain) chainIterator.next();
                                if (chain.containsLigandResidues()) {
                                    chainIterator.remove();
                                }
                            }
                            residueCollector =
                                new ObjectCollector(new ResidueFilter(null,
                                        residueSerial, residueICode));
                            residueCollector.setMode(ObjectCollector.COLLECT_ONE);
                            residueCollector.visit(chainCollector.getObjects());
                            if (residueCollector.getObjects().size() != 0) {
                                pdbStartResidue =
                                    (Residue) residueCollector.getObjects()
                                                              .iterator().next();
                            } else {
                                pdbStartResidue = null;
                            }

                            // find pdb end residue
                            residueSerial =
                                Integer.parseInt(tokenizer.nextToken());
                            residueICode = tokenizer.nextToken().charAt(0);
                            residueCollector =
                                new ObjectCollector(new ResidueFilter(null,
                                        residueSerial, residueICode));
                            residueCollector.visit(chainCollector.getObjects());
                            if (residueCollector.getObjects().size() != 0) {
                                pdbEndResidue =
                                    (Residue) residueCollector.getObjects()
                                                              .iterator().next();
                            } else {
                                pdbEndResidue = null;
                            }

                            // :NOTE: we allow one pdb residue to null (not found)
                            if (pdbStartResidue != null ||
                                  pdbEndResidue != null) {

                                // parse seq range
                                seqRange =
                                    org.srs3d.viewer.bioatlas.modules.AnnotationModule.insertToken(seqRange,
                                        ":", " ");
                                tokenizer = new StringTokenizer(seqRange, ":");
                                if (tokenizer.countTokens() == 3) {
                                    sequenceId = tokenizer.nextToken().trim();
                                    sequence =
                                        (String) sequenceMap.get(sequenceId);
                                    if (sequence != null) {
                                        seqMatchStart =
                                            Integer.parseInt(tokenizer.nextToken());
                                        if (seqMatchStart <= sequence.length()) {
                                            seqMatchEnd =
                                                Integer.parseInt(tokenizer.nextToken());
                                            if (seqMatchEnd <= sequence.length()) {
                                                foundAllResidues = true;
                                            } else {
                                                log.error(
                                                    "sequence end residue not found.");
                                            }
                                        } else {
                                            log.error(
                                                "sequence end residue not found.");
                                        }
                                    } else {
                                        log.error("sequence not found.");
                                    }
                                } else {
                                    log.error("error in seq range '" +
                                        seqRange + "'.");
                                }
                            } else {
                                log.error(
                                    "both structure range residues not found.");
                            }
                        } else {
                            log.error("layer with id '" + layerId +
                                "' not found!");
                        }
                    } else {
                        log.error("error in pdb residue range '" + pdbRange +
                            "'.");
                    }
                    if (foundAllResidues) {
                        pdbStartResidue =
                            resolveStartResidue(pdbStartResidue, pdbEndResidue,
                                seqMatchStart, seqMatchEnd);
                        pdbEndResidue =
                            resolveEndResidue(pdbStartResidue, pdbEndResidue,
                                seqMatchStart, seqMatchEnd);
                        if (pdbStartResidue == null || pdbEndResidue == null) {
                            foundAllResidues = false;
                        }
                    }
                    if (foundAllResidues) {
                        foundAllResidues = false;
                        Collection alignedSequences =
                            (Collection) alignedChainIdMap.get(String.valueOf(
                                    chainId));
                        Chain sequenceChain = (Chain) chainMap.get(sequenceId);
                        if (alignedSequences == null) {
                            alignedSequences = new HashSet();
                            alignedChainIdMap.put(String.valueOf(chainId),
                                alignedSequences);
                        }
                        String flag = (String) flagMap.get(sequenceId);
                        if (!alignedSequences.contains(sequenceChain)) {
                            chain =
                                createSequence(sequence,
                                    (String) descriptionMap.get(sequenceId));
                            chainMap.put(sequenceId + String.valueOf(chainId),
                                chain);
                            if (flag != null) {
                                flagMap.put(sequenceId +
                                    String.valueOf(chainId), flag);
                            }
                        } else {
                            chain =
                                (Chain) chainMap.get(sequenceId +
                                    String.valueOf(chainId));
                        }

                        // redo residue search for sequence
                        residueCollector =
                            new ObjectCollector(new ResidueFilter(null,
                                    seqMatchStart, ' '));
                        residueCollector.visit(chain);
                        if (residueCollector.getObjects().size() != 0) {
                            seqStartResidue =
                                (Residue) residueCollector.getObjects()
                                                          .iterator().next();

                            // find end residue
                            residueCollector =
                                new ObjectCollector(new ResidueFilter(null,
                                        seqMatchEnd, ' '));
                            residueCollector.visit(chain);
                            if (residueCollector.getObjects().size() != 0) {
                                seqEndResidue =
                                    (Residue) residueCollector.getObjects()
                                                              .iterator().next();

                                // we found all four residues
                                foundAllResidues = true;
                            }
                            if (foundAllResidues) {
                                alignedSequences.add(sequenceChain);
                            }
                            Residue limit = pdbEndResidue.getProceeding();
                            Residue residue = pdbStartResidue;
                            Residue seqResidue = seqStartResidue;
                            Residue seqLimit = seqEndResidue.getProceeding();
                            Residue sectionStartResidue = null;
                            Residue sectionEndResidue = null;
                            boolean matchContainedUnalignedResidue = true;
                            boolean notFullyAligned = false;
                            Map localMap = new HashMap();
                            if (flag != null &&
                                  flag.indexOf("REFERENCE") != -1) {

                                // the sequence is reference
                                while (residue != null && seqResidue != null &&
                                      residue != limit &&
                                      seqResidue != seqLimit) {

                                    // create map to reference (sequence)
                                    localMap.put(residue, seqResidue);
                                    residue = residue.getProceeding();
                                    seqResidue = seqResidue.getProceeding();
                                }
                                mergeMaps(tempLayer, layerAlignmentMaps,
                                    localMap);
                            } else {
                                matchContainedUnalignedResidue = false;

                                // the structure is the reference
                                while (residue != null && seqResidue != null &&
                                      residue != limit &&
                                      seqResidue != seqLimit) {
                                    if (!isResidueAlreadyAligned(residue,
                                              layerAlignmentMaps)) {

                                        // create map to reference
                                        localMap.put(seqResidue, residue);
                                        if (sectionStartResidue == null) {
                                            sectionStartResidue = seqResidue;
                                        }
                                        sectionEndResidue = seqResidue;
                                        matchContainedUnalignedResidue = true;
                                    } else {
                                        notFullyAligned = true;
                                    }
                                    residue = residue.getProceeding();
                                    seqResidue = seqResidue.getProceeding();
                                }
                                mergeMaps(chain, layerAlignmentMaps, localMap);
                            }

                            // in case we didn't go through the whole sequence
                            if (seqResidue != null && seqResidue != seqLimit) {
                                if (seqResidue.getPreceeding() != null) {
                                    seqEndResidue = seqResidue.getPreceeding();
                                }
                            }
                            if (matchContainedUnalignedResidue) {
                                if (sectionStartResidue == null) {
                                    sectionStartResidue = seqStartResidue;
                                    sectionEndResidue = seqEndResidue;
                                }
                                insertSection(chain, sectionStartResidue,
                                    sectionEndResidue);
                            } else {
                                if (((Map) layerAlignmentMaps.get(chain)).isEmpty()) {
                                    chainMap.remove(sequenceId +
                                        String.valueOf(chainId));
                                    layerAlignmentMaps.remove(chain);
                                }
                            }
                            if (seqResidue != null && seqResidue != seqLimit) {
                                log.error("remaining residues in sequence '" +
                                    seqResidue + "'.");
                            }
                            if (residue != null && residue != limit) {
                                log.error(
                                    "remaining residues in structure sequence '" +
                                    residue + "'.");
                            }
                            if (notFullyAligned) {
                                log.error("conflicts aligning match '" + match +
                                    "'.");
                            }
                        }
                    } else {
                        log.error("error in match '" + match + "'.");
                    }
                } else {
                    log.error("error in match attributes '" + match + "'.");
                }
            } else {

                // empty match string
            }
        }
    }

    /**
     * Description of the method.
     *
     * @param attributes Description of parameter.
     * @param sequenceMap Description of parameter.
     * @param descriptionMap Description of parameter.
     * @param flagMap Description of parameter.
     */
    public static void createSequence(String attributes, Map sequenceMap,
        Map descriptionMap, Map flagMap) {
        attributes =
            org.srs3d.viewer.bioatlas.modules.AnnotationModule.insertToken(attributes,
                ";", " ");
        StringTokenizer sequenceTokenizer =
            new StringTokenizer(attributes, ";");
        StringTokenizer tokenizer;
        StringTokenizer subTokenizer;
        String sequenceId;
        String description;
        String flag;
        String sequence;
        Layer tempLayer;
        boolean success = true;
        while (sequenceTokenizer.hasMoreTokens()) {
            String sequenceToken = sequenceTokenizer.nextToken();
            sequenceToken =
                org.srs3d.viewer.bioatlas.modules.AnnotationModule.insertToken(sequenceToken,
                    ",", " ");
            tokenizer = new StringTokenizer(sequenceToken, ",");

            // parse sequence-id and sequence
            if (tokenizer.countTokens() == 4) {
                sequenceId = tokenizer.nextToken().trim();
                description = tokenizer.nextToken().trim();
                flag = tokenizer.nextToken().trim();
                sequence = tokenizer.nextToken().trim();
                sequence = clearifySequence(sequence);
                sequenceMap.put(sequenceId, sequence);
                descriptionMap.put(sequenceId, description);
                flagMap.put(sequenceId, flag);
            } else {
                if (sequenceToken.trim().length() > 0) {
                    log.error("error in sequence attributes '" + sequenceToken +
                        "'.");
                }
            }
        }
    }

    /**
     * Description of the method.
     *
     * @param sequence Description of parameter.
     *
     * @return Description of the returned value.
     */
    public static String clearifySequence(String sequence) {

        // remove all kinds of chars from the sequence (space, return, aso)
        StringTokenizer tokenizer = new StringTokenizer(sequence);
        sequence = "";
        while (tokenizer.hasMoreTokens()) {
            sequence += tokenizer.nextToken();
        }
        return sequence;
    }

    /**
     * Description of the method.
     *
     * @param sequence Description of parameter.
     * @param description Description of parameter.
     *
     * @return Description of the returned value.
     */
    public static Chain createSequence(String sequence, String description) {

        // create chain
        Chain chain = new Chain();
        chain.setId(Chain.INVALID_ID);
        Compound compound = new Compound();
        compound.setMolecule(description);
        compound.setComplete(true);
        chain.setCompound(compound);
        Coil coil = new Coil();

        // create residue chain for the sequence with correct numbering
        Residue residue;
        ResidueTemplate template = null;
        for (int i = 0; i < sequence.length(); i++) {
            residue = new Residue();
            residue.setId(i + 1);
            residue.setICode(' ');
            template =
                ResidueTemplateFactory.getTemplate(ResidueTemplate.getName(
                        sequence.charAt(i)));
            residue.setTemplate(template);
            chain.addResidue(residue);
        }
        coil.setInitialResidue(chain.getInitialResidue());
        coil.setEndResidue(chain.getEndResidue());
        chain.addSubchain(coil);
        return chain;
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     * @param layerMap Description of parameter.
     */
    public static void createLayerMap(ContextData contextData, Map layerMap) {

        // prepare layer map (pdb id to layer)
        HashSet layers = new HashSet();
        ObjectManager.extract(contextData.getObjectContainer().getObjects(),
            layers, Layer.class);
        Iterator iterator = layers.iterator();
        Layer tempLayer;
        while (iterator.hasNext()) {
            tempLayer = (Layer) iterator.next();
            layerMap.put(tempLayer.getId().toLowerCase(), tempLayer);
        }
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     * @param alignmentString Description of parameter.
     * @param layer Description of parameter.
     * @param alignmentMap Description of parameter.
     * @param idMap Description of parameter.
     *
     * @return Description of the returned value.
     */
    public static boolean createSequenceAlignment(ContextData contextData,
        String alignmentString, Layer layer, Map layerAlignmentMap, Map idMap) {
        Map layerMap = new HashMap();
        Map chainMap = new HashMap();
        Map sequenceMap = new HashMap();
        Map descriptionMap = new HashMap();
        Map flagMap = new HashMap();
        String dummy;
        String attributes;
        String content;
        boolean isStopped = false;
        String string = alignmentString;
        createLayerMap(contextData, layerMap);
        while (string.trim().length() > 0 && !isStopped) {
            attributes =
                org.srs3d.viewer.bioatlas.modules.AnnotationModule.getAttributeString(string);
            content =
                org.srs3d.viewer.bioatlas.modules.AnnotationModule.getNextBlock(string);
            string = string.substring(attributes.length() + content.length());
            attributes =
                org.srs3d.viewer.bioatlas.modules.AnnotationModule.decode(attributes.trim());
            content = content.substring(1, content.length() - 1);
            if (attributes.equalsIgnoreCase("sequences")) {
                createSequence(content, sequenceMap, descriptionMap, flagMap);
            } else if (attributes.equalsIgnoreCase("matches")) {
                createMatches(contextData, content, sequenceMap,
                    descriptionMap, chainMap, layerMap, layerAlignmentMap,
                    flagMap);
            } else {
                log.error("error in '" + attributes + "'.");
            }
        }
        idMap.putAll(chainMap);
        Iterator iterator = chainMap.values().iterator();
        String flag;
        layer.setTemplate(true);
        layer.setSequenceLayer(true);
        layer.setMergeable(true);
        Chain chain;
        while (iterator.hasNext()) {
            chain = (Chain) iterator.next();
            trim(chain);
            org.srs3d.viewer.bioatlas.visitors.SubchainAnalyser subchainAnalyser =
                new org.srs3d.viewer.bioatlas.visitors.SubchainAnalyser();
            chain.update();
            subchainAnalyser.visit(chain.getChainFragments());

            // the layer map still contains the mapping from chain to alignment map
            // rather than layer to alignment map (since the layer was just recently created)
            // --> the mergeMaps inserted chains and is starting point for modifications.
            Map map = (Map) layerAlignmentMap.get(chain);
            if (map != null) {
                mergeMaps(layer, layerAlignmentMap,
                    (Map) layerAlignmentMap.get(chain));
                layerAlignmentMap.remove(chain);
            }
            layer.addObject(chain);
        }
        iterator = chainMap.keySet().iterator();
        String id;
        boolean hasOneReference = false;
        while (!hasOneReference && iterator.hasNext()) {
            id = (String) iterator.next();
            flag = (String) flagMap.get(id);
            if (flag != null && flag.indexOf("REFERENCE") != -1) {
                layer.setTemplate(false);
                hasOneReference = true;
            }
        }
        return true;
    }

    /**
     * Creates a section for the residue range specified. This method relies on the fact
     * that the underlying chain consists of a single subchain element from residueA to
     * the end of the chain. ASSUMES no overlapping alignments.
     *
     * @param chain Chain for section insertion.
     * @param residueA Residue range start residue.
     * @param residueB Residue range end residue.
     */
    public static void insertSection(Chain chain, Residue residueA,
        Residue residueB) {
        Collection residues = new HashSet();
        Residue residue = residueA;
        Residue limit = residueB.getProceeding();
        while (residue != limit) {
            residues.add(residue);
            residue = residue.getProceeding();
        }
        ObjectLocalizer objectLocalizer = new ObjectLocalizer();
        Collection chains = new HashSet();
        chains.add(chain);
        objectLocalizer.localize(residues, chains);
        Collection subchains = objectLocalizer.getObjects();
        ObjectManager.extract(subchains, Subchain.class);
        Subchain subchain;
        if (subchains.size() == 1) {
            subchain = (Subchain) subchains.iterator().next();
            insertSection(chain, subchain, residueA, residueB);
        } else {
            log.info("found " + subchains.size() + " subchains");
            log.info(subchains);
        }
    }

    /**
     * Description of the method.
     *
     * @param chain Description of parameter.
     * @param subchain Description of parameter.
     * @param residueA Description of parameter.
     * @param residueB Description of parameter.
     */
    public static void insertSection(Chain chain, Subchain subchain,
        Residue residueA, Residue residueB) {

        // initialize section with the appropriate residues A to B
        Section section = new Section();
        section.setInitialResidue(residueA);
        section.setEndResidue(residueB);
        if (section.getLength() > 0) {

            // insert section into chain
            chain.addSubchain(section);

            // create proceeding coil
            if (residueB.getProceeding() != null) {

                // initialize coil for as ending subchain
                Coil coil = new Coil();
                coil.setInitialResidue(residueB.getProceeding());
                coil.setEndResidue(subchain.getEndResidue());
                if (coil.getLength() > 0) {
                    chain.addSubchain(coil);
                }
            }

            // if there is a previous residue, terminate previous subchain
            if (residueA.getPreceeding() != null) {
                subchain.setEndResidue(residueA.getPreceeding());
                if (subchain.getLength() == 0) {
                    chain.removeSubchain(subchain);
                }
            } else {
                chain.removeSubchain(subchain);
            }
        }
    }

    /**
     * Sets the <code>behaviors</code> attribute of the <code>AnnotationModule</code>
     * class.
     *
     * @param annotationContext The new <code>behaviors</code> value.
     * @param annotationContainer The new <code>behaviors</code> value.
     */
    private static void setBehaviors(
        AbstractAnnotationContext annotationContext,
        AnnotationContainer annotationContainer) {

        // create a bounding sphere for the whole bunch of behaviors
        BoundingSphere bounds =
            new BoundingSphere(new Point3d(0.0, 0.0, 0.0), Double.MAX_VALUE);
        PanXYBehavior panner =
            new PanXYBehavior(annotationContext.getContextData());
        panner.setSchedulingBounds(bounds);
        panner.setSpeedy(0.0f);
        float lengthHalf = annotationContainer.getLength() / 2.0f;
        PlaneAnnotationConstraint constraint =
            new PlaneAnnotationConstraint(annotationContext);
        panner.addConstraint(constraint);
        BranchGroup branchGroup = new BranchGroup();
        BranchGroupHelper.setDefaultCapabilities(branchGroup);
        branchGroup.addChild(panner);
        annotationContext.getBehaviorLevel().addChild(branchGroup);
    }

    private static void mergeMaps(Object object, Map layerMaps, Map localMap) {
        Map map = (Map) layerMaps.get(object);
        if (map != null) {
            map.putAll(localMap);
        } else {
            layerMaps.put(object, localMap);
        }
    }

    private static final Residue resolveStartResidue(Residue pdbStartResidue,
        Residue pdbEndResidue, int seqMatchStart, int seqMatchEnd) {

        // one of the structure residues might by null
        if (pdbStartResidue == null) {
            int length = seqMatchEnd - seqMatchStart;
            Residue residue;
            residue = pdbStartResidue = pdbEndResidue;
            while (length > 0) {
                residue = residue.getPreceeding();
                length--;
                if (residue != null) {
                    if (org.srs3d.viewer.bioatlas.visitors.ChainAnalyser.isConnected(
                              residue, pdbStartResidue)) {
                        pdbStartResidue = residue;
                    } else {
                        length = 0;
                    }
                } else {
                    length = 0;
                }
            }
        }
        return pdbStartResidue;
    }

    private static final Residue resolveEndResidue(Residue pdbStartResidue,
        Residue pdbEndResidue, int seqMatchStart, int seqMatchEnd) {
        if (pdbEndResidue == null) {
            int length = seqMatchEnd - seqMatchStart;
            Residue residue;
            residue = pdbEndResidue = pdbStartResidue;
            while (length > 0) {
                residue = residue.getProceeding();
                length--;
                if (residue != null) {
                    if (org.srs3d.viewer.bioatlas.visitors.ChainAnalyser.isConnected(
                              pdbEndResidue, residue)) {
                        pdbEndResidue = residue;
                    } else {
                        length = 0;
                    }
                } else {
                    length = 0;
                }
            }
        }
        return pdbEndResidue;
    }

    /**
     * Method description.
     *
     * @param sequenceString Parameter description.
     */
    public void loadSequence(String sequenceString) {
        if (sequenceString != null && sequenceString.length() > 0) {
            NavigateUpDispatcher.updateDescription(getContextData(),
                "Loading sequence...");
            getContextData().getContext().addUpdateCallback(null);

            //      Thread.currentThread().yield();
            // create a template layer
            Layer layer = new Layer();
            layer.setTemplate(true);
            layer.setSequenceLayer(true);
            layer.setDescription("Sequence");
            layer.setId("Sequence");
            Map layerAlignmentMap =
                (Map) getContextData().getProperty("LAYER_ALIGNMENTMAP");
            Map idMap = (Map) getContextData().getProperty("LAYER_IDMAP");
            if (createSequenceAlignment(context.getContextData(),
                      sequenceString, layer, layerAlignmentMap, idMap)) {
                context.getContextData().setProperty("Homology", layer);

                // hide sequence layer
                context.getContextData().getObjectContainer().addObject(layer);

                //        ExpandCommand expandCommand = new ExpandCommand( context.getContextData() );
                //        expandCommand.setColorChildren( false );
                //        context.getContextData().getStrategyManager().propagate( layer, expandCommand, Subchain.class );
                VisibleCommand visibleCommand =
                    new VisibleCommand(context.getContextData(), false);

                //        context.getContextData().getStrategyManager().propagate( layer, visibleCommand );
                context.getContextData().getStrategyManager().execute(layer,
                    visibleCommand);
                RegisterCommand registerCommand =
                    new RegisterCommand(context.getContextData());
                context.getContextData().getStrategyManager().propagate(layer,
                    registerCommand, Subchain.class);
            }
        }
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     * @param sequenceString Parameter description.
     *
     * @return Return description.
     */
    public static Operation createLoadOperation(ContextData contextData,
        String sequenceString) {
        ParameterStringOperation operation =
            new ParameterStringOperation(contextData.getContext(),
                "LOAD_SEQUENCE", sequenceString, null);
        return operation;
    }

    /**
     * Method description.
     *
     * @param chain Parameter description.
     */
    public static void trim(Chain chain) {
        int LIMIT = 500;
        Collection subchains = chain.getSubchains();
        Iterator iterator = subchains.iterator();
        Subchain subchain;
        int index = 0;
        while (iterator.hasNext()) {
            subchain = (Subchain) iterator.next();
            index++;
            if (index == 1 || index == subchains.size()) {
                if (index == 1) {
                    if (subchain.getCode() == Coil.CODE) {
                        if (subchain.getLength() > LIMIT) {

                            // trim left coil
                            Residue residue = subchain.getEndResidue();
                            int counter = LIMIT;
                            while (residue != null && counter > 0) {
                                residue = residue.getPreceeding();
                                counter--;
                            }
                            if (residue != null) {
                                residue.setPreceeding(null);
                                subchain.setInitialResidue(residue);
                                chain.setInitialResidue(residue);
                            }
                        }
                    }
                } else {

                    // trim right
                    if (subchain.getCode() == Coil.CODE) {
                        if (subchain.getLength() > LIMIT) {

                            // trim left coil
                            Residue residue = subchain.getInitialResidue();
                            int counter = LIMIT;
                            while (residue != null && counter > 0) {
                                residue = residue.getProceeding();
                                counter--;
                            }
                            if (residue != null) {
                                residue.setProceeding(null);
                                subchain.setEndResidue(residue);
                                chain.setEndResidue(residue);
                            }
                        }
                    }
                }
                subchain.update();
            }
        }
    }

    /**
     * Method description.
     *
     * @param residue Parameter description.
     * @param layerAlignmentMaps Parameter description.
     *
     * @return Return description.
     */
    public static boolean isResidueAlreadyAligned(Residue residue,
        Map layerAlignmentMaps) {
        if (layerAlignmentMaps.isEmpty()) {
            return false;
        }
        Iterator iterator = layerAlignmentMaps.values().iterator();
        Map map;
        while (iterator.hasNext()) {
            map = (Map) iterator.next();
            if (map.containsValue(residue)) {
                return true;
            }
        }
        return false;
    }
}
