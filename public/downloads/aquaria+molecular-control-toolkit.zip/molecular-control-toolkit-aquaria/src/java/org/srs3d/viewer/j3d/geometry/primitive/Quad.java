/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.geometry.primitive;

import javax.media.j3d.GeometryArray;
import javax.media.j3d.QuadArray;
import javax.media.j3d.Shape3D;
import javax.vecmath.TexCoord2f;
import javax.vecmath.Vector3f;

import org.srs3d.viewer.j3d.geometry.GeometryHelper;
import org.srs3d.viewer.vecmath.ColorArray4f;
import org.srs3d.viewer.vecmath.PointArray3f;
import org.srs3d.viewer.vecmath.VectorArray3f;

/**
 * This class is intended to arbitrary place quads into the scene.
 *
 * @author Karsten Klein, 11/2000
 *
 * @created March 20, 2001
 * @since 1.0
 */
public class Quad implements AbstractPrimitive {

    /** Coordinates of the rectangle */
    private PointArray3f coordinates = null;

    /** Per vertex colors of the rectangle */
    private ColorArray4f colors = null;

    /** Normal of the plane defined by the rectangle */
    private VectorArray3f normals = null;

    /**
     * Constructs a <code>Quad</code> with the default settings. The rectangle is
     * centered at (0, 0, 0) with width and height 1.
     */
    public Quad() {
        coordinates = new PointArray3f(4);
        coordinates.setAt(0, -0.5f, -0.5f, 0);
        coordinates.setAt(1, 0.5f, -0.5f, 0);
        coordinates.setAt(2, 0.5f, 0.5f, 0);
        coordinates.setAt(3, -0.5f, 0.5f, 0);
        normals = new VectorArray3f(4);
        colors = new ColorArray4f(4);
        normals.setUniform(computeNormal());
    }

    /**
     * Gets the <code>Coordinates</code> attribute of the <code>Quad</code> object
     *
     * @return The <code>Coordinates</code> value
     */
    public PointArray3f getCoordinates() {
        return coordinates;
    }

    /**
     * Gets the <code>Normals</code> attribute of the <code>Quad</code> object
     *
     * @return The <code>Normals</code> value
     */
    public VectorArray3f getNormals() {
        return normals;
    }

    /**
     * Gets the <code>Colors</code> attribute of the <code>Quad</code> object
     *
     * @return The <code>Colors</code> value
     */
    public ColorArray4f getColors() {
        return colors;
    }

    /**
     * <code>AbstractPrimitive</code> implementation of the <code>getShape(...)
     * </code>method. The <code>Rectangle</code> will create a new <code>Shape3D
     * </code>instance containing the rectangle.
     *
     * @return The <code>Shape</code> value
     *
     * @see AbstractPrimitive
     */
    public Shape3D getShape() {
        int i;
        Vector3f[] normals = new Vector3f[4];

        // create new geometry array with appropriate settings
        QuadArray quad =
            GeometryHelper.getDefaultQuadArray(1,
                GeometryArray.COLOR_4 | GeometryArray.TEXTURE_COORDINATE_2);
        insertInto(0, quad);
        Shape3D shape = new Shape3D(quad);
        return shape;
    }

    /**
     * This methods inserts the information from this quad instance at the given index
     * into the quad array.
     *
     * @param index index of the quad in the quad array. Note that this is the index of
     *        the quad and not of the point.
     * @param quadArray the according quad array.
     */
    public void insertInto(int index, QuadArray quadArray) {
        int format = quadArray.getVertexFormat();
        if ((format & QuadArray.COORDINATES) != 0) {
            quadArray.setCoordinates(index * 4, coordinates.getBuffer());
        }
        if ((format & QuadArray.NORMALS) != 0) {
            quadArray.setNormals(index * 4, normals.getBuffer());
        }
        if ((format & QuadArray.COLOR_4) != 0) {
            quadArray.setColors(index * 4, colors.getBuffer());
        }
        if ((format & QuadArray.TEXTURE_COORDINATE_2) != 0) {

            // create a default texure coordinate setting
            TexCoord2f textureCoordinate = new TexCoord2f(0, 0);
            quadArray.setTextureCoordinate(0, 0, textureCoordinate);
            textureCoordinate.x = 1;
            quadArray.setTextureCoordinate(0, 1, textureCoordinate);
            textureCoordinate.y = 1;
            quadArray.setTextureCoordinate(0, 2, textureCoordinate);
            textureCoordinate.x = 0;
            quadArray.setTextureCoordinate(0, 3, textureCoordinate);
        }
    }

    /**
     * Computes the normal of the rectangle according to the coordinates.
     *
     * @return Description of the returned value
     */
    public Vector3f computeNormal() {
        Vector3f normal = new Vector3f();
        normal.cross(new Vector3f(coordinates.getAt(0)),
            new Vector3f(coordinates.getAt(1)));
        return normal;
    }
}
