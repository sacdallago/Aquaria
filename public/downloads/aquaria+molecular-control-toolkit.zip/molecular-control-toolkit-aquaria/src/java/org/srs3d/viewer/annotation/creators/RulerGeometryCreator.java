/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.annotation.creators;

import java.awt.Color;
import java.util.Collection;
import java.util.Iterator;

import javax.media.j3d.Appearance;
import javax.media.j3d.BranchGroup;
import javax.media.j3d.Geometry;
import javax.media.j3d.ImageComponent2D;
import javax.media.j3d.LineArray;
import javax.media.j3d.RenderingAttributes;
import javax.media.j3d.Shape3D;
import javax.media.j3d.TransparencyAttributes;
import javax.vecmath.Color4f;
import javax.vecmath.Point3f;

import org.srs3d.viewer.annotation.attributes.LayoutPosition;
import org.srs3d.viewer.annotation.objects.Ruler;
import org.srs3d.viewer.j3d.AppearanceHelper;
import org.srs3d.viewer.j3d.ShapeManager;
import org.srs3d.viewer.j3d.creators.AbstractGeometryCreator;
import org.srs3d.viewer.j3d.geometry.GeometryHelper;
import org.srs3d.viewer.j3d.geometry.primitive.Line;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.objects.State;

/**
 * Create the geometry of a <code>Ruler</code> instance.
 *
 * @author Christian Zofka
 *
 * @created October 17, 2001
 * @rewritten Karsten Fries, LION bioscience AG
 * @rewritten January 09, 2001
 */
public class RulerGeometryCreator extends AbstractGeometryCreator {
    private static final Color4f RULER_COLOR = new Color4f(0.3f, 0.3f, 0.3f, 1);
    private static final Color LABEL_COLOR = new Color(1, 1, 1);
    private static transient Appearance appearance = null;
    private Point3f position = new Point3f();

    /**
     * Creates geometry for an <code>AbstractObject</code>.
     *
     * @param object The current implementation only allows <code>Ruler</code> instances.
     * @param branchGroup BranchGroup to attach ruler geometry to.
     */
    public void create(AbstractObject object, BranchGroup branchGroup) {
        create((Ruler) object, branchGroup);
    }

    /**
     * Creates geometry for an <code>AbstractObject</code>.
     *
     * @param ruler The ruler to create geometry for.
     * @param branchGroup BranchGroup to attach ruler geometry to.
     */
    public void create(Ruler ruler, BranchGroup branchGroup) {
        State.Immutable state;
        LayoutPosition.Immutable layoutPosition;
        state = getContextData().getStateManager().getImmutableState(ruler);
        layoutPosition =
            (LayoutPosition.Immutable) state.getAttribute(LayoutPosition.class);
        if (layoutPosition != null) {
            position.set(layoutPosition.getPosition());
        } else {

            // :FIXME: Christian
            // don't draw the ruler if not layouted
            return;
        }
        if (ruler.getVerticalDirection() == Ruler.VERTICALS_UP) {
            position.y -= ruler.getHeight();
        }
        Shape3D shape;

        // create horizontals and vertical geometries
        shape = createGeometry(ruler, position);
        if (shape != null) {
            ShapeManager.setCapabilities(shape, null);
            branchGroup.addChild(shape);
        }
        if (ruler.isLabeled()) {

            // create label geometry
            shape = createLabelGeometry(ruler, position);
            if (shape != null) {
                ShapeManager.setCapabilities(shape, null);
                if (appearance == null) {
                    appearance = new Appearance();
                    AppearanceHelper.setDefaults(appearance);
                    RenderingAttributes renderingAttributes =
                        new RenderingAttributes();
                    renderingAttributes.setDepthBufferEnable(false);
                    appearance.setRenderingAttributes(renderingAttributes);
                    TransparencyAttributes transparencyAttributes =
                        new TransparencyAttributes(TransparencyAttributes.BLENDED,
                            0.0f);
                    appearance.setTransparencyAttributes(transparencyAttributes);
                }
                shape.setAppearance(appearance);
                shape.setPickable(false);
                branchGroup.addChild(shape);
            }
        }
    }

    /**
     * Creates a shape with label geometries.
     *
     * @param ruler Ruler to create labels for.
     * @param position Ruler position.
     *
     * @return Shape objects containing all the labels created.
     */
    private Shape3D createLabelGeometry(Ruler ruler, Point3f position) {
        Shape3D shape = null;
        Collection verticals = ruler.getVerticals();
        if (!verticals.isEmpty()) {
            shape = new Shape3D();
            Iterator iterator = verticals.iterator();
            Ruler.Vertical vertical;
            while (iterator.hasNext()) {
                vertical = (Ruler.Vertical) iterator.next();
                if (vertical.isLabeled()) {
                    shape.addGeometry(createLabel(vertical.getLabel(),
                            vertical.getPosition() + 0.1f, ruler));
                }
            }
        }
        return shape;
    }

    /**
     * Creates ruler geometry.
     *
     * @param ruler Ruler used for geometry creation.
     * @param position Position of the ruler.
     *
     * @return Shape containing ruler geometries.
     */
    private Shape3D createGeometry(Ruler ruler, Point3f position) {
        Collection verticals = ruler.getVerticals();
        Collection horizontals = ruler.getHorizontals();
        Shape3D shape = null;
        int lineCount = verticals.size() + horizontals.size();
        if (lineCount > 0) {
            LineArray lineArray =
                GeometryHelper.getDefaultLineArray(lineCount, LineArray.COLOR_4);
            Line line = new Line();
            line.getColors().setUniform(RULER_COLOR);
            Point3f point0 = new Point3f();
            Point3f point1 = new Point3f();
            float offsetY = position.y;
            float yUp;
            float yDown;
            int lineIndex = 0;
            if (!verticals.isEmpty()) {
                Iterator iterator = verticals.iterator();
                Ruler.Vertical vertical;

                // create verticals
                while (iterator.hasNext()) {
                    vertical = (Ruler.Vertical) iterator.next();
                    yUp = offsetY;
                    yDown = offsetY;
                    if ((ruler.getVerticalDirection() & Ruler.VERTICALS_DOWN) != 0) {
                        yDown -= vertical.getLength();
                    }
                    if ((ruler.getVerticalDirection() & Ruler.VERTICALS_UP) != 0) {
                        yUp += vertical.getLength();
                    }
                    point0.x = position.x + vertical.getPosition();
                    point1.x = point0.x;
                    point0.y = yUp;
                    point1.y = yDown;
                    line.getCoordinates().set(point0, point1);
                    line.insertInto(lineIndex++, lineArray);
                }
            }

            // create horizontals
            if (!horizontals.isEmpty()) {
                Iterator iterator = horizontals.iterator();
                Ruler.Horizontal horizontal;
                while (iterator.hasNext()) {
                    horizontal = (Ruler.Horizontal) iterator.next();
                    point0.x = position.x + horizontal.getStart();
                    point0.y = offsetY;
                    point1.x = position.x + horizontal.getStop();
                    point1.y = offsetY;

                    // :FIXME: this has to be removed (at least here)
                    // continous line needed
                    point0.x -= 125.5f;
                    point1.x += 125.5f;
                    line.getCoordinates().set(point0, point1);
                    line.insertInto(lineIndex++, lineArray);
                }
            }
            shape = new Shape3D(lineArray);
        }
        return shape;
    }

    /**
     * Creates a label for a ruler.
     *
     * @param string Label string.
     * @param ruler Ruler to create label geometry for.
     * @param offset Offset of the label (i.e. vertical position).
     *
     * @return Geometry of the label.
     */
    private Geometry createLabel(String string, float offset, Ruler ruler) {
        ImageComponent2D image =
            getContextData().getLabelManager().getLabel(string, LABEL_COLOR,
                true, null);
        javax.media.j3d.Raster raster = new javax.media.j3d.Raster();
        raster.setImage(image);
        raster.setSize(image.getWidth(), image.getHeight());

        // :FIXME: this values are not general (zooming, font dependend)
        float yOffset = -0.3f;
        if (ruler.getVerticalDirection() == Ruler.VERTICALS_UP) {
            yOffset = ruler.getHeight() + 1.3f;
        }
        Point3f textPosition = new Point3f(offset, yOffset, 0.0f);
        textPosition.add(position);
        raster.setPosition(textPosition);
        return raster;
    }
}
