/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.operations;

import javax.swing.KeyStroke;

import org.srs3d.viewer.j3d.Context;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.util.XmlTag;

/**
 * @author Karsten Klein
 *
 * @created June 28, 2001
 */
public class KeyStrokeOperation extends InputOperation {
    private KeyStroke keyStroke = null;

    /**
     * <code>Operation</code> constructor.
     *
     * @param context Description of parameter.
     * @param id Description of parameter.
     * @param object Description of parameter.
     */
    public KeyStrokeOperation(Context context, String id, AbstractObject object) {
        super(context, id, object);
        setSerializable(false);
    }

    /**
     * Method description.
     *
     * @param keyStroke Parameter description.
     */
    public void setKeyStroke(KeyStroke keyStroke) {
        this.keyStroke = keyStroke;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public KeyStroke getKeyStroke() {
        return keyStroke;
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     * @param xmlTag Parameter description.
     *
     * @return Return description.
     */
    public boolean deserializeAttributes(ContextData contextData, XmlTag xmlTag) {
        if (super.deserializeAttributes(contextData, xmlTag)) {
            String value = xmlTag.getAttribute("keystroke");
            if (value != null) {
                keyStroke = KeyStroke.getKeyStroke(value);
            }
            return keyStroke != null;
        }
        return false;
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     * @param xmlTag Parameter description.
     *
     * @return Return description.
     */
    public boolean serializeAttributes(ContextData contextData, XmlTag xmlTag) {
        if (super.serializeAttributes(contextData, xmlTag)) {
            if (keyStroke != null) {
                xmlTag.setAttribute("keystroke", keyStroke.toString());
            }
            return keyStroke != null;
        }
        return false;
    }
}
