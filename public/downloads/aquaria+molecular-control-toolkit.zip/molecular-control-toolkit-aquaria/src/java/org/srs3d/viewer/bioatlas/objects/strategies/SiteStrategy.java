/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.objects.strategies;

import java.util.ArrayList;

import org.srs3d.viewer.bioatlas.objects.Layer;
import org.srs3d.viewer.bioatlas.objects.Site;
import org.srs3d.viewer.j3d.Reaction;
import org.srs3d.viewer.j3d.commands.ColorCommand;
import org.srs3d.viewer.j3d.commands.ExpandCommand;
import org.srs3d.viewer.j3d.commands.IdentificationCommand;
import org.srs3d.viewer.j3d.commands.PreSelectCommand;
import org.srs3d.viewer.j3d.commands.RegisterCommand;
import org.srs3d.viewer.j3d.commands.RepresentationCommand;
import org.srs3d.viewer.j3d.commands.VisibleCommand;
import org.srs3d.viewer.j3d.objects.strategies.AbstractStrategy;
import org.srs3d.viewer.j3d.objects.strategies.reactions.EmptyReaction;
import org.srs3d.viewer.objects.Command;
import org.srs3d.viewer.objects.ObjectContainer;
import org.srs3d.viewer.objects.ObjectManager;

/**
 * @author Karsten Klein
 *
 * @created April 03, 2001
 */
public class SiteStrategy extends AbstractStrategy {

    /**
     * Constructor description.
     */
    public SiteStrategy() {
        register(RepresentationCommand.class, EmptyReaction.getSharedInstance());
        register(PreSelectCommand.class, EmptyReaction.getSharedInstance());
        register(ColorCommand.class, EmptyReaction.getSharedInstance());
        register(IdentificationCommand.class, new IdentificationReaction());
        register(ExpandCommand.class, EmptyReaction.getSharedInstance());
        register(RegisterCommand.class, EmptyReaction.getSharedInstance());
        register(VisibleCommand.class, EmptyReaction.getSharedInstance());
    }

    /**
     * Reaction for retrieving the object identification.
     *
     * @author Karsten Klein
     *
     * @created March 26, 2002
     */
    public static class IdentificationReaction implements Reaction {

        /**
         * Execute implementation of the reaction interface.
         *
         * @param command Command to react to.
         */
        public void execute(Command command) {
            IdentificationCommand idCommand = (IdentificationCommand) command;
            ArrayList parents = new ArrayList();
            ObjectManager.extract(idCommand.getObjects(), parents, Layer.class);
            if (!parents.isEmpty()) {
                ObjectContainer parent = (ObjectContainer) parents.get(0);
                ArrayList sites = new ArrayList();
                ObjectManager.extract(parent.getObjects(), sites, Site.class);
                idCommand.setObjectId("SITE:#" +
                    sites.indexOf(command.getObject()));
            }
            idCommand.execute();
        }
    }
}
