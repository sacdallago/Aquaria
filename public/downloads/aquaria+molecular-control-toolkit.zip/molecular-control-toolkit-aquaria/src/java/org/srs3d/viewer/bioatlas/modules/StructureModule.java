/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.modules;

import java.awt.event.ActionEvent;
import java.net.URL;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.StringTokenizer;

import javax.swing.JOptionPane;
import javax.vecmath.Matrix4f;
import javax.vecmath.Point3f;

import org.srs3d.viewer.bioatlas.dispatcher.NavigateUpDispatcher;
import org.srs3d.viewer.bioatlas.loaders.GenericLoader;
import org.srs3d.viewer.bioatlas.objects.Layer;
import org.srs3d.viewer.bioatlas.visitors.AtomCollector;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.operations.ParameterStringOperation;
import org.srs3d.viewer.objects.ObjectContainer;
import org.srs3d.viewer.objects.ObjectManager;
import org.srs3d.viewer.objects.Operation;
import org.srs3d.viewer.util.Chronometer;
import org.srs3d.viewer.util.ExceptionHandler;
import org.srs3d.viewer.util.Log;

/**
 * Module for loading structures with aligned sequences and according annotations.
 *
 * @author Karsten Klein
 *
 * @created May 14, 2001
 */
public class StructureModule extends ProcessModule {
    private static final Log log = new Log(StructureModule.class);
    private String structureString = null;

    /**
     * <code>StructureModule</code> constructor.
     *
     * @param name Description of parameter.
     */
    public StructureModule(String name, ContextData contextData) {
        super(name, contextData);
    }

    /**
     * Description of the method
     *
     * @param url Description of parameter
     * @param matrix Description of parameter
     *
     * @return Description of the returned value.
     */
    public static Layer loadStructure(URL url, Matrix4f matrix,
        String flagString) throws java.io.IOException {
        Chronometer c = Chronometer.getChronometer("Loading structure");
        c.start();
        GenericLoader loader = new GenericLoader();
        loader.setParameterObject(flagString);
        ObjectContainer tempContainer = loader.load(url);
        c.stop("loading" + url);
        if (tempContainer != null) {
            c.start();

            // :FIXME: this should be done in the loader
            Layer layer = new Layer();
            layer.merge(tempContainer);
            layer.addId("PDB", tempContainer.getName());
            layer.setId(tempContainer.getName());
            layer.setDescription(tempContainer.getName());
            if (matrix != null) {
                layer.setSuperpositionOperator(matrix);
                layer.superimpose();
            }
            layer.update();
            c.stop("update " + layer.getId());
            return layer;
        } else {
            log.error("no data found in container.");
        }
        return null;
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     * @param structureString Description of parameter.
     * @param idMap Description of parameter.
     */
    public static void loadStructureBlock(ContextData contextData,
        String structureString, Map idMap) {
        String attributes =
            org.srs3d.viewer.bioatlas.modules.AnnotationModule.insertToken(structureString,
                ";", " ");
        StringTokenizer structureTokenizer =
            new StringTokenizer(attributes, ";");
        StringTokenizer tokenizer;
        StringTokenizer subTokenizer;
        String structureId;
        String urlString = null;
        String matrixString;
        String flagString;
        URL url;
        Matrix4f matrix;
        Layer layer;
        while (structureTokenizer.hasMoreTokens()) {
            String structureToken = structureTokenizer.nextToken();
            try {
                structureToken =
                    org.srs3d.viewer.bioatlas.modules.AnnotationModule.insertToken(structureToken,
                        ",", " ");
                tokenizer = new StringTokenizer(structureToken, ",");

                // parse sequence-id and sequence
                if (tokenizer.countTokens() == 4) {
                    structureId = tokenizer.nextToken().trim();
                    urlString = tokenizer.nextToken().trim();
                    flagString = tokenizer.nextToken().trim();
                    if (urlString.length() > 0) {
                        url = org.srs3d.viewer.bioatlas.Parameter.supplementUrl(contextData.getAppletStub()
                                                                                           .getCodeBase(),
                                urlString);
                    } else {

                        // this is needed for smiles strings to be loaded
                        url = null;
                    }
                    matrixString = tokenizer.nextToken().trim();
                    if (matrixString.length() > 0) {
                        matrix = readMatrix(matrixString);
                    } else {
                        matrix = null;
                    }
                    layer = loadStructure(url, matrix, flagString);
                    if (layer != null) {
                        layer.setTemplate(false);
                        layer.setTemplate(flagString.indexOf("REFERENCE") == -1);
                        layer.setMergeable(flagString.indexOf("MERGEABLE") != -1);
                        layer.setImposed(flagString.indexOf("IMPOSED") != -1);
                        layer.setMaster(flagString.indexOf("MASTER") != -1);
                        contextData.getObjectContainer().addObject(layer);
                        if (structureId.trim().length() == 0) {
                            structureId = layer.getId("PDB");
                            if (structureId == null) {
                                structureId = "id";
                            }
                        }
                        idMap.put(structureId, layer);
                        layer.setId(structureId);
                        layer.setDescription(structureId);
                    }
                } else {
                    if (structureToken.trim().length() > 0) {
                        log.error("error in structure attributes '" +
                            structureToken + "'.");
                    }
                }
            } catch (Exception e) {
                ExceptionHandler.handleException(e,
                    ExceptionHandler.SILENT_IN_RELEASE);

                // :FIXME: this indicated that there was a cleanup, that is responsible for
                // the exeception
                if (contextData.getContext() != null) {
                    org.srs3d.viewer.swing.ComponentFactory.messageDialog(contextData.getContext(),
                        "The structure " + urlString + " cannot be loaded.",
                        "Error loading structure", JOptionPane.WARNING_MESSAGE,
                        null);
                }
            }
        }
    }

    /**
     * Description of the method.
     *
     * @param contextData Description of parameter.
     * @param structuresString Description of parameter.
     * @param idMap Description of parameter.
     */
    public static void loadStructures(ContextData contextData,
        String structuresString, Map idMap) {
        String string = structuresString;
        String attributes;
        String content;
        boolean isStopped = false;
        while (string.trim().length() > 0 && !isStopped) {
            attributes =
                org.srs3d.viewer.bioatlas.modules.AnnotationModule.getAttributeString(string);
            content =
                org.srs3d.viewer.bioatlas.modules.AnnotationModule.getNextBlock(string);
            string = string.substring(attributes.length() + content.length());
            attributes =
                org.srs3d.viewer.bioatlas.modules.AnnotationModule.decode(attributes.trim());
            content = content.substring(1, content.length() - 1);
            if (attributes.equalsIgnoreCase("structures")) {
                loadStructureBlock(contextData, content, idMap);
            } else {
                log.error("error in '" + attributes + "'.");
            }
        }
    }

    /**
     * Description of the method.
     *
     * @param matrixString Description of parameter.
     *
     * @return Description of the returned value.
     */
    public static Matrix4f readMatrix(String matrixString) {
        Matrix4f matrix = new Matrix4f();
        matrix.setIdentity();
        try {
            StringTokenizer stringTokenizer =
                new StringTokenizer(matrixString, ":");

            // :FIXME: backward compatibility allow white spaces as separators
            if (stringTokenizer.countTokens() != 12) {
                stringTokenizer = new StringTokenizer(matrixString);
            }
            matrix.m00 = Float.parseFloat(stringTokenizer.nextToken().trim());
            matrix.m01 = Float.parseFloat(stringTokenizer.nextToken().trim());
            matrix.m02 = Float.parseFloat(stringTokenizer.nextToken().trim());
            matrix.m03 = Float.parseFloat(stringTokenizer.nextToken().trim());
            matrix.m10 = Float.parseFloat(stringTokenizer.nextToken().trim());
            matrix.m11 = Float.parseFloat(stringTokenizer.nextToken().trim());
            matrix.m12 = Float.parseFloat(stringTokenizer.nextToken().trim());
            matrix.m13 = Float.parseFloat(stringTokenizer.nextToken().trim());
            matrix.m20 = Float.parseFloat(stringTokenizer.nextToken().trim());
            matrix.m21 = Float.parseFloat(stringTokenizer.nextToken().trim());
            matrix.m22 = Float.parseFloat(stringTokenizer.nextToken().trim());
            matrix.m23 = Float.parseFloat(stringTokenizer.nextToken().trim());
        } catch (Exception e) {
            log.error("matrix input is not appropriate.", e);
        }
        return matrix;
    }

    /**
     * Description of the method.
     *
     * @param e Parameter description.
     */
    public void process(ActionEvent e) {
        loadStructure(structureString);
    }

    /**
     * Method description.
     *
     * @param structureString Parameter description.
     */
    public void loadStructure(String structureString) {
        if (structureString != null) {
            NavigateUpDispatcher.updateDescription(getContextData(),
                "Loading structure...");
            getContextData().getContext().addUpdateCallback(null);
            Map idMap = (Map) getContextData().getProperty("LAYER_IDMAP");
            Collection features =
                (Collection) getContextData().getProperty("FEATURES");
            Collection activeFeatures =
                (Collection) getContextData().getProperty("ACTIVE_FEATURES");
            StructureModule.loadStructures(getContextData(), structureString,
                idMap);
            Collection annotations =
                (Collection) getContextData().getProperty("ANNOTATIONS");
            Iterator iterator = idMap.values().iterator();
            Layer layer;
            while (iterator.hasNext()) {
                layer = (Layer) iterator.next();
                AnnotationModule.convertSitesToAnnotations(layer, annotations);
            }
            if (idMap.size() > 1) {
                getContextData().setProperty("Superposition", "ON");
                getContextData().setProperty("Displacement", "ON");
                getContextData().setProperty("Homology", "ON");
            } else {
                if (idMap.size() == 1) {
                    ((Layer) idMap.values().iterator().next()).setMaster(true);
                }
            }

            // preprocess
            preprocessObjectContainer();
            NavigateUpDispatcher.processZoomOut(getContextData(),
                new Operation(getContextData().getContext(), "ZOOM_OUT", null),
                0);
        }
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     * @param structureString Parameter description.
     *
     * @return Return description.
     */
    public static Operation createLoadOperation(ContextData contextData,
        String structureString) {
        ParameterStringOperation operation =
            new ParameterStringOperation(contextData.getContext(),
                "LOAD_STRUCTURE", structureString, null);
        return operation;
    }

    /**
     * Method description.
     *
     * @param contextData Parameter description.
     * @param structureString Parameter description.
     *
     * @return Return description.
     */
    public static Operation createVisualizeOperation(ContextData contextData,
        String structureString) {
        ParameterStringOperation operation =
            new ParameterStringOperation(contextData.getContext(),
                "VISUALIZE_STRUCTURE", structureString, null);
        return operation;
    }

    /**
     * Method description.
     *
     * @param structureString Parameter description.
     */
    public void setStructureString(String structureString) {
        this.structureString = structureString;
    }

    /**
     * Method description.
     */
    public void preprocessObjectContainer() {
        Collection layers = new HashSet();
        ObjectManager.extract(getContextData().getObjectContainer().getObjects(),
            layers, Layer.class);
        StructureModule.filterSequenceLayers(layers);

        // center the all layers in the container
        AtomCollector atomCollector = new AtomCollector();
        atomCollector.visit(layers);
        Point3f translation = atomCollector.getCenter();
        translation.negate();
        atomCollector.translateAtoms(translation);
        Point3f temp;
        Iterator iterator = layers.iterator();
        Layer layer;
        while (iterator.hasNext()) {
            layer = ((Layer) iterator.next());
            temp = layer.getCenter();
            temp.add(translation);
            layer.setCenter(temp);
        }
    }

    /**
     * Method description.
     *
     * @param layers Parameter description.
     */
    public static void filterSequenceLayers(Collection layers) {
        Iterator iterator = layers.iterator();
        Layer layer;
        while (iterator.hasNext()) {
            layer = (Layer) iterator.next();
            if (layer.isSequenceLayer()) {
                iterator.remove();
            }
        }
    }
}
