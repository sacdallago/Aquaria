/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.annotation.contexts;

import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;

import org.srs3d.viewer.annotation.dispatcher.ZoomBoxThread;
import org.srs3d.viewer.annotation.objects.Alignment;
import org.srs3d.viewer.annotation.objects.AnnotationContainer;
import org.srs3d.viewer.j3d.Context;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.objects.Rectangle;
import org.srs3d.viewer.objects.ObjectManager;

/**
 * AnnotationContextData; used in <code>AbstractAnnotationContext</code>
 *
 * @author Christian Zofka
 *
 * @created August 17, 2001
 * @reviewed Karsten Fries, LION bioscience AG
 * @reviewed September 21, 2001
 */
public class AnnotationContextData extends ContextData {

    // elements used for the interaction between annotation & seuqence contexts;
    // notice that sequence needs them even without an annotationcontext
    private Rectangle zoomBox = null;
    private Alignment activeBoxAlignment = null;
    private ContextData referenceContextData = null;

    /**
     * <code>AnnotationContextData</code> constructor.
     *
     * @param context Description of parameter.
     */
    public AnnotationContextData(Context context) {
        super(context);
        referenceContextData = this;
    }

    /**
     * Sets the reference context data object. The reference context data is used to
     * access objects and registration from another context.
     *
     * @param referenceContextData The new <code>referenceContextData</code> value.
     */
    public void setReferenceContextData(ContextData referenceContextData) {
        this.referenceContextData = referenceContextData;
    }

    /**
     * Sets the <code>zoomBox</code> attribute of the <code>AnnotationContextData</code>
     * object.
     *
     * @param rectangle The new <code>zoomBox</code> value.
     */
    public void setZoomBox(Rectangle rectangle) {
        zoomBox = rectangle;
    }

    /**
     * Sets the <code>zoomBoxThread</code> attribute of the
     * <code>AnnotationContextData</code> object.
     *
     * @param thread The new <code>zoomBoxThread</code> value.
     */
    public void setZoomBoxThread(ZoomBoxThread thread) {
        referenceContextData.setProperty("FOCUS_THREAD", thread);
    }

    /**
     * Sets the <code>activeBoxAlignment</code> attribute of the
     * <code>AnnotationContextData</code> object.
     *
     * @param alignment The new <code>activeBoxAlignment</code> value.
     */
    public void setActiveBoxAlignment(Alignment alignment) {
        activeBoxAlignment = alignment;
    }

    /**
     * Gets the reference context data object. The reference context data is used to
     * access objects and registration from another context.
     *
     * @return The <code>referenceContextData</code> value.
     */
    public ContextData getReferenceContextData() {
        return referenceContextData;
    }

    /**
     * Gets the <code>zoomBoxThread</code> attribute of the
     * <code>AnnotationContextData</code> object.
     *
     * @return The <code>zoomBoxThread</code> value.
     */
    public ZoomBoxThread getZoomBoxThread() {
        if (referenceContextData != null) {
            return (ZoomBoxThread) referenceContextData.getProperty(
                "FOCUS_THREAD");
        }
        return null;
    }

    /**
     * Gets the <code>zoomBox</code> attribute of the <code>AnnotationContextData</code>
     * object.
     *
     * @return The <code>zoomBox</code> value.
     */
    public Rectangle getZoomBox() {
        return zoomBox;
    }

    /**
     * Gets the <code>activeBoxAlignment</code> attribute of the
     * <code>AnnotationContextData</code> object.
     *
     * @return The <code>activeBoxAlignment</code> value.
     */
    public Alignment getActiveBoxAlignment() {
        return activeBoxAlignment;
    }

    /**
     * Gets the <code>annotation</code> attribute of the
     * <code>AnnotationContextData</code> object.
     *
     * @return The <code>annotation</code> value.
     */
    public AnnotationContainer getAnnotationContainer() {
        Collection annotations = new HashSet();
        ObjectManager.extract(getObjectContainer().getObjects(), annotations,
            AnnotationContainer.class);
        Iterator iterator = annotations.iterator();
        if (iterator.hasNext()) {
            return ((AnnotationContainer) iterator.next());
        } else {
            return null;
        }
    }

    /**
     * Description of the method.
     */
    public void clearContent() {
        ZoomBoxThread zoomBoxThread = getZoomBoxThread();
        if (zoomBoxThread != null) {
            zoomBoxThread.terminate();
            zoomBoxThread = null;
        }
        if (getZoomBox() != null) {
            getSpawnerManager().remove(zoomBox);
            getShapeManager().remove(zoomBox);
            getStateManager().remove(zoomBox);
            setZoomBox(null);
        }
        setActiveBoxAlignment(null);
    }

    /**
     * Description of the method.
     */
    public void cleanup() {
        clearContent();
        super.cleanup();
    }
}
