/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.objects;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

import javax.vecmath.Point3f;

import org.srs3d.viewer.bioatlas.objects.templates.AtomTemplate;
import org.srs3d.viewer.bioatlas.objects.templates.ResidueTemplate;
import org.srs3d.viewer.bioatlas.visitors.AtomCollector;
import org.srs3d.viewer.bioatlas.visitors.BondCreator;
import org.srs3d.viewer.objects.AbstractObject;

/**
 * Residue class. The residue is a container for atoms and bonds. Note that each residue
 * is sharing a <code>ResidueTemplate</code> with residues of the same kind. The
 * template contains residue type specific information.
 *
 * @author Karsten Klein
 *
 * @created March 20, 2001
 */
public final class Residue extends AbstractObject {

    /** Description of the field */
    public static final int INVALID_ID = -1;

    /** Description of the field */
    public static final char INVALID_ICODE = 0;

    /** Description of the field */
    public Atom refCA = null;

    /** Description of the field */
    public Atom refC = null;

    /** Description of the field */
    public Atom refN = null;

    /** Description of the field */
    public Atom refP = null;

    /** Description of the field */
    public Atom refO3 = null;

    /** Residue template link */
    private ResidueTemplate template;

    /** Collection of atoms in the residue */
    private Collection atoms = new ArrayList();

    /** Collection of bonds in the residue */
    private Collection bonds = new ArrayList();
    private int id = INVALID_ID;
    private char iCode = INVALID_ICODE;
    private Residue proceeding = null;
    private Residue preceeding = null;

    /**
     * Sets the <code>id</code> attribute of the <code>Residue</code> object.
     *
     * @param id The new <code>id</code> value.
     */
    public final void setId(int id) {
        this.id = id;
    }

    /**
     * Sets the <code>iCode</code> attribute of the <code>Residue</code> object.
     *
     * @param iCode The new <code>iCode</code> value.
     */
    public final void setICode(char iCode) {
        this.iCode = iCode;
    }

    /**
     * Sets the <code>Template</code> attribute of the <code>Residue</code> object.
     *
     * @param template The new <code>Template</code> value.
     */
    public final void setTemplate(ResidueTemplate template) {
        this.template = template;
    }

    /**
     * Sets the <code>Preceeding</code> attribute of the <code>Residue</code> object.
     *
     * @param residue The new <code>Preceeding</code> value.
     */
    public void setPreceeding(Residue residue) {
        preceeding = residue;
    }

    /**
     * Sets the <code>Proceeding</code> attribute of the <code>Residue</code> object.
     *
     * @param residue The new <code>Proceeding</code> value.
     */
    public void setProceeding(Residue residue) {
        proceeding = residue;
    }

    /**
     * Gets the <code>id</code> attribute of the <code>Residue</code> object.
     *
     * @return The <code>id</code> value.
     */
    public final int getId() {
        return id;
    }

    /**
     * Gets the <code>iCode</code> attribute of the <code>Residue</code> object.
     *
     * @return The <code>iCode</code> value.
     */
    public final char getICode() {
        return iCode;
    }

    /**
     * Gets the <code>template</code> attribute of the <code>Residue</code> object.
     *
     * @return The <code>template</code> value.
     */
    public final ResidueTemplate getTemplate() {
        return template;
    }

    /**
     * Gets the <code>Preceeding</code> attribute of the <code>Residue</code> object.
     *
     * @return The <code>Preceeding</code> value.
     */
    public final Residue getPreceeding() {
        return preceeding;
    }

    /**
     * Gets the <code>Proceeding</code> attribute of the <code>Residue</code> object.
     *
     * @return The <code>Proceeding</code> value.
     */
    public final Residue getProceeding() {
        return proceeding;
    }

    /**
     * Gets the <code>atoms</code> attribute of the <code>Residue</code> object.
     *
     * @return The <code>atoms</code> value.
     */
    public final Collection getAtoms() {
        return atoms;
    }

    /**
     * Gets the <code>Bonds</code> attribute of the <code>Residue</code> object.
     *
     * @return The <code>Bonds</code> value.
     */
    public final Collection getBonds() {
        return bonds;
    }

    /**
     * Gets the <code>AllObjects</code> attribute of the <code>Residue</code> object.
     *
     * @param collection Description of parameter.
     */
    public void getAllObjects(Collection collection) {
        if (atoms != null) {
            collection.addAll(atoms);
        }
        if (bonds != null) {
            collection.addAll(bonds);
        }
    }

    /**
     * Gets the <code>Coordinate</code> attribute of the <code>Residue</code> object.
     *
     * @return The <code>Coordinate</code> value.
     */
    public final Point3f getCoordinate() {
        if (refCA != null) {
            return new Point3f(refCA.getCoordinate());
        } else if (refP != null) {
            return new Point3f(refP.getCoordinate());
        } else {
            AtomCollector atomCollector = new AtomCollector();
            atomCollector.visit(this);
            Point3f point = atomCollector.getCenter();
            atomCollector = null;
            return point;
        }
    }

    /**
     * Adds a feature to the <code>Bond</code> attribute of the <code>Residue
     * </code>object.
     *
     * @param bond The feature to be added to the <code>Bond</code> attribute.
     */
    public void addBond(Bond bond) {
        bonds.add(bond);
    }

    /**
     * Adds a <code>Atom</code> to the <code>Residue</code> s list of atoms.
     *
     * @param atom The feature to be added to the <code>Atom</code> attribute.
     */
    public void addAtom(Atom atom) {

        //    atoms.addElement( atom );
        atoms.add(atom);
        AtomTemplate atomTemplate = atom.getTemplate();
        if (atomTemplate.is(" CA ")) {
            refCA = atom;
        } else if (atomTemplate.is(" C  ")) {
            refC = atom;
        } else if (atomTemplate.is(" N  ")) {
            refN = atom;
        } else if (atomTemplate.is(" P  ")) {
            refP = atom;
        } else if (atomTemplate.is(" O3*")) {
            refO3 = atom;
        }
    }

    /**
     * Description of the method.
     *
     * @return Description of the returned value.
     */
    public String toString() {
        String string = new String();
        if (getTemplate() != null && getTemplate().getName() != null) {
            string += getTemplate().getName();
            string = string.substring(0, 1) +
                string.substring(1).toLowerCase();
        }
        if (id != INVALID_ID) {
            string += id;
        }
        if (iCode != INVALID_ICODE && iCode != ' ') {
            string += iCode;
        }

        // Appends information about previous and next residue
        //    string += "{";
        //    if ( getPreceeding() != null ) {
        //
        //       string += getPreceeding().getId();
        //
        //    }
        //    else {
        //
        //       string += "-";
        //
        //    }
        //    string += "-";
        //    if ( getProceeding() != null ) {
        //
        //       string += getProceeding().getId();
        //
        //    }
        //    else {
        //
        //       string += "-";
        //
        //    }
        //    string += "}";
        //    string = string + refN + refCA + refC;
        return string;
    }

    /**
     * Cleans up the residues data.
     */
    public void cleanup() {
        super.cleanup();
        template = null;
        proceeding = null;
        preceeding = null;
        refCA = null;
        refC = null;
        refN = null;
        refP = null;
        refO3 = null;
        cleanup(atoms);
        atoms = null;
        cleanup(bonds);
        bonds = null;
    }

    /**
     * Description of the method.
     *
     * @return Description of the returned value.
     */
    public Collection computeBonds() {
        BondCreator bondCreator = new BondCreator();
        bondCreator.mode = BondCreator.ALL;
        bondCreator.visit(this);
        return bondCreator.bonds;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public boolean isLigand() {
        if (refCA != null && refP != null) {
            return false;
        } else {
            return getTemplate().isLigand();
        }
    }

    /**
     * Method description.
     *
     * @param bonds Parameter description.
     */
    public void addBonds(Collection bonds) {

        // pick only the bonds for the atoms contained in this residue
        Iterator iterator = bonds.iterator();
        Bond bond;
        while (iterator.hasNext()) {
            bond = (Bond) iterator.next();
            if (atoms.contains(bond.getAtom0())) {
                this.bonds.add(bond);
                iterator.remove();
            }
        }
    }
}
