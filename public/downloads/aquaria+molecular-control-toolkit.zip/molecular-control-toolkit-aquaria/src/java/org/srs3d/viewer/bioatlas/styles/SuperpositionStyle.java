/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.styles;

import java.util.Vector;

import org.srs3d.viewer.bioatlas.attributes.AtomRepresentation;
import org.srs3d.viewer.bioatlas.attributes.Representation;
import org.srs3d.viewer.bioatlas.attributes.ResidueRepresentation;
import org.srs3d.viewer.bioatlas.attributes.SubchainRepresentation;
import org.srs3d.viewer.bioatlas.colorschemes.StructureColorScheme;
import org.srs3d.viewer.bioatlas.filters.LigandFilter;
import org.srs3d.viewer.bioatlas.modules.BallAndStickCheck;
import org.srs3d.viewer.bioatlas.objects.Atom;
import org.srs3d.viewer.bioatlas.objects.Coil;
import org.srs3d.viewer.bioatlas.objects.Helix;
import org.srs3d.viewer.bioatlas.objects.Layer;
import org.srs3d.viewer.bioatlas.objects.NucleicChain;
import org.srs3d.viewer.bioatlas.objects.Residue;
import org.srs3d.viewer.bioatlas.objects.Strand;
import org.srs3d.viewer.bioatlas.objects.Turn;
import org.srs3d.viewer.j3d.ColorScheme;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.attributes.Visible;
import org.srs3d.viewer.j3d.commands.ColorCommand;
import org.srs3d.viewer.j3d.commands.ExpandCommand;
import org.srs3d.viewer.j3d.commands.RemoveStateCommand;
import org.srs3d.viewer.j3d.commands.VisibleCommand;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.objects.Attribute;
import org.srs3d.viewer.objects.State;
import org.srs3d.viewer.objects.StrategyManager;
import org.srs3d.viewer.objects.visitors.ObjectCollector;

/**
 * @author Karsten Klein
 *
 * @created September 4, 2001
 */
public class SuperpositionStyle extends FirstImpressionStyle {

    /**
     * <code>DisplacementStyle</code> constructor.
     *
     * @param contextData Description of parameter.
     */
    public SuperpositionStyle(ContextData contextData) {
        super(contextData);
        ColorScheme colorScheme = new StructureColorScheme(contextData);
        contextData.setProperty(StructureColorScheme.class, colorScheme);
    }

    /**
     * Gets the <code>name</code> attribute of the <code>SuperpositionStyle</code>
     * object.
     *
     * @return The <code>name</code> value.
     */
    public String getName() {
        return "Superposition";
    }

    /**
     * Description of the method.
     *
     * @param layer Description of parameter.
     */
    public void applyColorScheme(Layer layer) {
        ColorScheme colorScheme =
            (ColorScheme) getColorScheme(StructureColorScheme.class);
        StrategyManager strategyManager = getContextData().getStrategyManager();
        getContextData().setColorScheme(colorScheme);
        ColorCommand colorCommand =
            new ColorCommand(getContextData(), colorScheme);
        colorCommand.setForceRecoloring(true);
        colorCommand.propagate(layer);
    }

    /**
     * Description of the method.
     *
     * @param layer Description of parameter.
     */
    public void processLigands(Layer layer) {
        processWaters(layer);
        ContextData contextData = getContextData();
        StrategyManager strategyManager = contextData.getStrategyManager();

        // collect all ligands
        ObjectCollector objectCollector =
            new ObjectCollector(new LigandFilter(true));
        objectCollector.visit((AbstractObject) layer);
        strategyManager.propagate(objectCollector.getObjects(),
            new RemoveStateCommand(contextData), null);

        // ball and stick
        Vector commands = new Vector();
        BallAndStickCheck.sharedInstance.getAllOnCommands(contextData, commands);
        commands.add(new VisibleCommand(contextData, true));
        strategyManager.propagate(objectCollector.getObjects(),
            new ExpandCommand(contextData, true, false), Residue.class);
        strategyManager.execute(objectCollector.getObjects(), commands);
    }

    /**
     * Set the subchain mode.
     */

    //  public void processSubchains( Layer layer ) {
    //
    //    ContextData contextData = getContextData();
    //
    //    ObjectCollector objectCollector = new ObjectCollector( new SubchainFilter() );
    //    objectCollector.visit( ( AbstractObject ) layer );
    //
    //    Collection commands = new Vector();
    //    commands.add( new PropagateClassCommand( contextData,
    //      new ExpandCommand( contextData, false ), null ) );
    //    CATraceCheck.sharedInstance.getAllOnCommands( contextData, commands );
    //    commands.add( new VisibleCommand( contextData, true ) );
    //
    //    StrategyManager strategyManager = contextData.getStrategyManager();
    //    strategyManager.execute( objectCollector.getObjects(), commands );
    //
    //  }
    //  /**
    //   *  Sets the residue mode.
    //   *
    //   * @param  layer  Description of parameter.
    //   */
    //  public void processResidues( Layer layer ) {
    //
    //  }
    protected void adaptStatePrototypes() {
        ContextData contextData = getContextData();
        State state;

        // subchain state prototype changed
        state = new State();
        state.setAttribute(Attribute.getInstance(Visible.class));
        SubchainRepresentation subchainRepresentation =
            (SubchainRepresentation) Attribute.getInstance(SubchainRepresentation.class);
        subchainRepresentation.setMode(Representation.REPRESENTATION_CATRACE);
        state.setAttribute(subchainRepresentation);
        contextData.getStatePrototypeManager().register(Helix.class, state);
        contextData.getStatePrototypeManager().register(Strand.class, state);
        contextData.getStatePrototypeManager().register(Turn.class, state);
        contextData.getStatePrototypeManager().register(Coil.class, state);
        contextData.getStatePrototypeManager().register(NucleicChain.class,
            state);

        // residue state prototype changed
        state = new State();
        state.setAttribute(Attribute.getInstance(Visible.class));
        ResidueRepresentation residueRepresentation =
            (ResidueRepresentation) Attribute.getInstance(ResidueRepresentation.class);
        residueRepresentation.setMode(Representation.REPRESENTATION_CATRACE);
        state.setAttribute(residueRepresentation);
        contextData.getStatePrototypeManager().register(Residue.class, state);

        // atom state prototype changed
        state = new State();
        state.setAttribute(Attribute.getInstance(Visible.class));
        AtomRepresentation atomRepresentation =
            (AtomRepresentation) Attribute.getInstance(AtomRepresentation.class);
        atomRepresentation.setMode(Representation.REPRESENTATION_WIREFRAME);
        state.setAttribute(atomRepresentation);
        contextData.getStatePrototypeManager().register(Atom.class, state);
    }
}
