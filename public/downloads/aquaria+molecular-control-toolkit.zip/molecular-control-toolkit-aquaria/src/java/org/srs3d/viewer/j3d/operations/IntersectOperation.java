/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.operations;

import java.awt.Point;
import java.awt.event.InputEvent;

import org.srs3d.viewer.j3d.Context;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.objects.Operation;

import com.sun.j3d.utils.picking.PickResult;

/**
 * @author Karsten Klein
 *
 * @created June 28, 2001
 */
public class IntersectOperation extends Operation {
    private InputEvent triggerEvent;
    private PickResult pickResult;
    private Point coordinate = new Point();
    private String triggerId = null;

    /**
     * <code>Operation</code> constructor.
     *
     * @param context Description of parameter.
     * @param id Description of parameter.
     * @param object Description of parameter.
     */
    public IntersectOperation(Context context, String id, AbstractObject object) {
        super(context, id, object);
        setSerializable(false);
    }

    /**
     * Method description.
     *
     * @param pickResult Parameter description.
     */
    public void setPickResult(PickResult pickResult) {
        this.pickResult = pickResult;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public PickResult getPickResult() {
        return pickResult;
    }

    /**
     * Method description.
     *
     * @param coordinate Parameter description.
     */
    public void setCoordinate(Point coordinate) {
        this.coordinate.setLocation(coordinate);
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public Point getCoordinate() {
        return coordinate;
    }

    /**
     * Method description.
     *
     * @param triggerId Parameter description.
     */
    public void setTriggerId(String triggerId) {
        this.triggerId = triggerId;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public String getTriggerId() {
        return triggerId;
    }

    /**
     * Method description.
     *
     * @param triggerEvent Parameter description.
     */
    public void setTriggerEvent(InputEvent triggerEvent) {
        this.triggerEvent = triggerEvent;
    }

    /**
     * Method description.
     *
     * @return Return description.
     */
    public InputEvent getTriggerEvent() {
        return triggerEvent;
    }
}
