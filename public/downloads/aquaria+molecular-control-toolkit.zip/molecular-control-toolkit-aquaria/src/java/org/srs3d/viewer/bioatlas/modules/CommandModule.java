/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.modules;

import java.awt.event.ActionEvent;
import java.util.Collection;
import java.util.HashSet;

import javax.swing.JMenuItem;

import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.Selection;
import org.srs3d.viewer.j3d.behaviors.UpdateBehavior;
import org.srs3d.viewer.j3d.commands.SpawnCommand;
import org.srs3d.viewer.objects.ObjectManager;
import org.srs3d.viewer.objects.StrategyManager;

/**
 * Menu module for executing <code>Command</code> s on the current selection.
 *
 * @author Karsten Klein
 *
 * @created May 14, 2001
 */
public class CommandModule extends ProcessModule {
    private Collection commands;
    private Class objectClass = null;

    /**
     * <code>CommandModule</code> constructor.
     *
     * @param name Description of parameter.
     * @param commands Description of parameter.
     * @param context Description of parameter.
     * @param objectClass Description of parameter.
     */
    public CommandModule(String name, ContextData contextData,
        Collection commands, Class objectClass) {
        super(name, contextData);
        this.commands = commands;
        this.objectClass = objectClass;
    }

    /**
     * Description of the method.
     *
     * @param e Description of parameter.
     */
    public void process(ActionEvent e) {
        ContextData contextData = getContextData();
        ObjectManager objectManager = contextData.getObjectManager();
        StrategyManager strategyManager = contextData.getStrategyManager();
        Selection selection = contextData.getSelectionManager().getSelection();
        final Collection objects = new HashSet();
        if (!selection.isEmpty()) {
            objects.addAll(selection);
        } else {
            contextData.getObjectContainer().getAllObjects(objects);
        }
        final Collection spawners = new HashSet();
        spawners.addAll(objects);
        SpawnCommand.searchSpawners(getContextData(), spawners);
        contextData.getContext().addUpdateCallback(new UpdateBehavior.Callback() {
                public void execute() {
                    executeCommands(commands, objects);
                    getContextData().getStrategyManager().execute(spawners,
                        new SpawnCommand(getContextData()));
                }
            });
    }

    /**
     * Description of the method.
     */
    public void cleanup() {
        super.cleanup();
        if (commands != null) {
            commands.clear();
            commands = null;
        }
    }

    /**
     * Description of the method.
     */
    public void updateIntern() {
        JMenuItem menuItem = (JMenuItem) getComponent();
        if (objectClass == null) {
            menuItem.setEnabled(true);
        } else {
            ContextData contextData = getContextData();
            Selection selection =
                contextData.getSelectionManager().getSelection();
            if (selection != null) {
                Collection set = new HashSet();
                contextData.getObjectManager().getDownAssociations(selection,
                    set);
                set.addAll(selection);
                ObjectManager.extract(set, objectClass);
                menuItem.setEnabled(!set.isEmpty());
            } else {
                menuItem.setEnabled(false);
            }
        }
    }

    /**
     * Description of the method.
     *
     * @param commands Description of parameter.
     * @param objects Description of parameter.
     */
    private void executeCommands(Collection commands, Collection objects) {
        if (commands != null && !commands.isEmpty()) {
            ContextData contextData = getContextData();
            StrategyManager strategyManager = contextData.getStrategyManager();
            strategyManager.execute(objects, commands);
        }
    }
}
