/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.loaders.rdb;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.Vector;

import org.srs3d.viewer.bioatlas.loaders.AbstractParser;
import org.srs3d.viewer.objects.ObjectContainer;
import org.srs3d.viewer.util.Log;

/**
 * <code>AbstractParser</code> implementation for reading RDB files. Note that this
 * parser implements only rudamentry RDB parsing.
 * <pre>
 *   Files have to be tab separated with some header information for specific
 *   interpretation
 *   # X Y Z
 *   # INTERPRETATION:POINT
 *   10 10 10
 *   10 20 30
 * </pre>
 *
 * @author Karsten Klein
 *
 * @created May 18, 2001
 */
public class RdbParser extends BufferedReader implements AbstractParser {
    private static final Log log = new Log(RdbParser.class);
    private static final String INTERPRETER_PREFIX = "INTERPRETATION:";
    private Map interpreterMap = new HashMap();

    /**
     * <code>RdbParser</code> constructor.
     *
     * @param filename Description of parameter.
     *
     * @exception FileNotFoundException Description of exception.
     */
    public RdbParser(String filename) throws FileNotFoundException {
        super(new FileReader(filename));
        initializeInterpreterMap();
    }

    /**
     * <code>RdbParser</code> constructor.
     *
     * @param inputStream Description of parameter.
     */
    public RdbParser(InputStream inputStream) {
        super(new InputStreamReader(inputStream));
        initializeInterpreterMap();
    }

    private final void initializeInterpreterMap() {
        interpreterMap.put(RdbLayerInterpreter.getInterpreterId(),
            new RdbLayerInterpreter());
        interpreterMap.put(RdbPointInterpreter.getInterpreterId(),
            new RdbPointInterpreter());
    }

    /**
     * Parses the rdb file to retrieve protein information.
     *
     * @return <code>ObjectContainer</code> - the database accumulated the protein data.
     */
    public ObjectContainer parse() {

        // :NOTE: finalization is applied to whole container always. this can
        // be very usefull, since an interpreter might only implement the
        // finalizeInterpretation() method to modify the read data (from other
        // interpreters.
        ObjectContainer localDatabase = new ObjectContainer();
        localDatabase.setName("3D point set");
        RdbFieldParser rdbParser = new RdbFieldParser();
        RdbInterpreter rdbInterpreter = null;
        Vector fieldOrder = null;
        String token = null;
        String line = null;
        int headerLinesRead = 0;

        // parser needs to successully apply at least one interpreter    
        boolean isSuccess = false;
        try {
            do {
                line = null;
                line = readLine();
                if (line != null) {
                    if (!line.startsWith("#")) {
                        if (headerLinesRead == 2) {
                            rdbParser.setFieldOrder(fieldOrder);
                            rdbInterpreter.interprete(rdbParser.create(line),
                                localDatabase);
                        } else {
                            headerLinesRead++;

                            // read order vector
                            if (headerLinesRead == 1) {
                                fieldOrder = createOrderVector(line);
                            }
                        }
                    } else {
                        int index = line.indexOf(INTERPRETER_PREFIX);
                        if (index != -1) {
                            String interpreterString =
                                line.substring(index +
                                    INTERPRETER_PREFIX.length()).trim();
                            if (rdbInterpreter != null) {
                                rdbInterpreter.finalizeInterpretation(localDatabase);
                                rdbInterpreter = null;
                                isSuccess = true;
                            }
                            rdbInterpreter =
                                (RdbInterpreter) getInstance(interpreterString);
                            log.debug("interpreter: " + rdbInterpreter);
                            log.debug("interpreterId: " + interpreterString);
                            log.debug("interpreterMap: " + interpreterMap);
                        }
                    }
                }
            } while (line != null);
        } catch (IOException e) {
            log.error(e, e);
            isSuccess = false;
        }
        if (rdbInterpreter != null) {
            rdbInterpreter.finalizeInterpretation(localDatabase);
            rdbInterpreter = null;
            isSuccess = true;
        }
        rdbParser = null;
        token = null;
        line = null;
        if (isSuccess) {
            return localDatabase;
        }

        // rdb parser actively fails 
        return null;
    }

    private RdbInterpreter getInstance(String interpreterString) {
        log.debug("interpreter: " + interpreterString);
        return (RdbInterpreter) interpreterMap.get(interpreterString.toUpperCase());
    }

    private Vector createOrderVector(String string) {
        Vector fieldOrder = new Vector();
        StringTokenizer tokenizer = new StringTokenizer(string, "\t");
        String token;
        while (tokenizer.hasMoreTokens()) {
            token = tokenizer.nextToken().trim().toUpperCase();
            fieldOrder.add(token);
        }
        log.debug("fields order: " + fieldOrder);
        return fieldOrder;
    }
}
