/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.modules;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.TreePath;
import javax.swing.tree.TreeSelectionModel;

import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.Contextual;
import org.srs3d.viewer.j3d.attributes.Expanded;
import org.srs3d.viewer.j3d.attributes.Visible;
import org.srs3d.viewer.objects.Attribute;
import org.srs3d.viewer.objects.ObjectContainer;
import org.srs3d.viewer.objects.ObjectManager;
import org.srs3d.viewer.objects.Operation;
import org.srs3d.viewer.objects.State;
import org.srs3d.viewer.swing.AbstractObjectTreeModel;
import org.srs3d.viewer.util.ExceptionHandler;

/**
 * <code>Module</code> implementation displaying the hierarchy of the visible objects.
 *
 * @author Karsten Klein
 *
 * @created May 14, 2001
 */
public class HierarchyViewModule extends AbstractModule implements Contextual {
    private String name;
    private JFrame frame = null;

    /**
     * <code>ResetModule</code> constructor.
     *
     * @param name Description of parameter.
     * @param contextData Description of parameter.
     */
    public HierarchyViewModule(String name, ContextData contextData) {
        super(name, contextData);
        setOperationSerializeable(false);
    }

    /**
     * Description of the method.
     *
     * @param e Description of parameter.
     */
    public void react(ActionEvent e) {
        showHierarchyFrame();
    }

    /**
     * Description of the method.
     */
    public void showHierarchyFrame() {
        if (frame == null) {
            frame =
                new JFrame(org.srs3d.viewer.bioatlas.Parameter.applicationName +
                    " - Hierarchy Browser");
            ContextData contextData = getContextData();
            ObjectContainer objectContainer = contextData.getObjectContainer();
            State expandedState = new State();
            expandedState.setAttribute(Attribute.getInstance(Visible.class));
            expandedState.setAttribute(Attribute.getInstance(Expanded.class));
            contextData.getStateManager().register(objectContainer,
                expandedState);
            frame.getContentPane().add(createPanel(contextData));
            frame.setSize(200, 500);
            frame.setVisible(true);
        } else {
            frame.setVisible(true);
        }
    }

    /**
     * Description of the method.
     */
    public static JPanel createPanel(final ContextData contextData) {
        ObjectContainer objectContainer = contextData.getObjectContainer();
        State expandedState = new State();
        expandedState.setAttribute(Attribute.getInstance(Visible.class));
        expandedState.setAttribute(Attribute.getInstance(Expanded.class));
        contextData.getStateManager().register(objectContainer, expandedState);
        final AbstractObjectTreeModel treeModel =
            new AbstractObjectTreeModel(contextData, objectContainer);
        final JTree tree = new JTree(treeModel);
        JScrollPane vScrollPane = new JScrollPane(tree);
        JPanel panel = new JPanel(new BorderLayout());
        panel.add(vScrollPane, BorderLayout.CENTER);
        tree.getSelectionModel().setSelectionMode(TreeSelectionModel.CONTIGUOUS_TREE_SELECTION);
        tree.setShowsRootHandles(true);

        //Listen for when the selection changes.
        tree.addTreeSelectionListener(new TreeSelectionListener() {

                /**
                 * Description of the method.
                 *
                 * @param e Description of parameter.
                 */
                public void valueChanged(TreeSelectionEvent e) {
                    try {
                        ObjectManager objectManager =
                            contextData.getObjectManager();
                        TreePath[] paths = tree.getSelectionPaths();
                        if (paths != null) {
                            ArrayList set = new ArrayList();
                            for (int i = 0; i < paths.length; i++) {
                                set.add(paths[i].getLastPathComponent());
                            }
                            Operation operation =
                                new Operation(contextData.getContext(),
                                    "REQUEST_SELECTION", null);
                            operation.setSerializable(true);
                            operation.setObjects(set);
                            contextData.getDispatcher().runDispatch(operation);
                        }
                    } catch (Exception ex) {

                        // silent
                        ExceptionHandler.handleException(ex,
                            ExceptionHandler.SILENT_IN_DEBUG);
                    }
                }
            });
        return panel;
    }

    /**
     * Description of the method.
     */
    public void cleanup() {
        if (frame != null) {
            frame.setVisible(false);
            frame.dispose();
            frame = null;
        }
    }
}
