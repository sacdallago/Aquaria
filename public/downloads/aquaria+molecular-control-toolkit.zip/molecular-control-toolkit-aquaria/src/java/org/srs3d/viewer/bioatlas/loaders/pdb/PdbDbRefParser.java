/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.loaders.pdb;

import java.util.Iterator;

import org.srs3d.viewer.bioatlas.objects.Chain;
import org.srs3d.viewer.bioatlas.objects.DbRef;
import org.srs3d.viewer.bioatlas.objects.Residue;
import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.objects.ObjectContainer;

/**
 * This class parses strings for pdb DBREF tags and stores the SWISSPROT identifiers in
 * the appropriate postions.
 *
 * @author Karsten Klein, 01/2001
 *
 * @created June 19, 2001
 */
public class PdbDbRefParser extends PdbSubchainParser {
    public static final String TAG = new String("DBREF ");
    private String dbId;
    private String dbAccession;
    private String dbIdCode;
    private int initialResidueSeqId = Residue.INVALID_ID;
    private char initialResidueSeqICode = Residue.INVALID_ICODE;
    private int endResidueSeqId = Residue.INVALID_ID;
    private char endResidueSeqICode = Residue.INVALID_ICODE;

    /**
     * Method description.
     *
     * @return Return description.
     */
    public boolean isRetained() {
        return true;
    }

    /**
     * Parses the formated pdb string for DBREF data. The data is stored locally and no
     * object is created.
     *
     * @param string Description of parameter.
     */
    public void create(String string) {
        clear();

        // :NOTE: the standard residue name is not read!
        // chain data
        chainId = extractChar(string, 12);

        // initial- and end-residue data
        initialResidueId = extractInt(string, 14, 18);
        initialResidueICode = extractChar(string, 18);
        endResidueId = extractInt(string, 20, 24);
        endResidueICode = extractChar(string, 14);

        // database data
        dbId = extractString(string, 26, 32, true);
        dbAccession = extractString(string, 33, 41, true);
        dbIdCode = extractString(string, 42, 54, true);

        // reading sequence mapping of residues
        initialResidueSeqId = extractInt(string, 55, 60);
        initialResidueSeqICode = extractChar(string, 60);
        endResidueSeqId = extractInt(string, 62, 67);
        endResidueSeqICode = extractChar(string, 67);
    }

    /**
     * Specialized implementation visiting all objects contained in the specified
     * <code>ObjectContainer</code> instance. Only the chains are the interesting
     * objects. Note that the parser is retained and all chains already exit. Therefore
     * no chains will be instantiated.
     *
     * @param ObjectContainer the <code>ObjectContainer</code> instance to visit
     */
    public void visit(ObjectContainer ObjectContainer) {
        Iterator iterator = ObjectContainer.getIterator();
        AbstractObject object = null;
        while (iterator.hasNext()) {
            object = (AbstractObject) iterator.next();
            if (object instanceof Chain) {
                Chain chain = (Chain) object;
                if (chain.getId() == chainId) {
                    visit(chain);
                }
            }
        }
    }

    /**
     * Visits a chain for transfering the DBREF data. Note that the DbRef parser is
     * retained. We therefore can assume the residue as already generated.
     *
     * @param chain the chain to apply the atom data to
     */
    public void visit(Chain chain) {
        chain.setId(chainId);
        DbRef dbRef = new DbRef();
        visit(dbRef, chain);
    }

    /**
     * Method description.
     *
     * @param dbRef Parameter description.
     * @param chain Parameter description.
     */
    public void visit(DbRef dbRef, Chain chain) {
        Residue residue =
            chain.getResidue(null, initialResidueId, initialResidueICode);
        if (residue != null) {
            dbRef.setInitialResidue(residue);
        } else {
            dbRef.setInitialResidue(chain.getInitialResidue());
        }
        residue = chain.getResidue(null, endResidueId, endResidueICode);
        if (residue != null) {
            dbRef.setEndResidue(residue);
        } else {
            dbRef.setEndResidue(chain.getEndResidue());
        }
        chain.addDbRef(dbRef);
        setSuccess(true);
        dbRef.setDbId(dbId);
        dbRef.setDbAccession(dbAccession);
        dbRef.setDbIdCode(dbIdCode);
    }

    /**
     * Description of the method.
     */
    public void clear() {
        super.clear();
        dbId = null;
        dbAccession = null;
        dbIdCode = null;
        initialResidueSeqId = Residue.INVALID_ID;
        initialResidueSeqICode = Residue.INVALID_ICODE;
        endResidueSeqId = Residue.INVALID_ID;
        endResidueSeqICode = Residue.INVALID_ICODE;
    }
}
