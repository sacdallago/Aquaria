/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.contexts;

import java.awt.GraphicsConfiguration;
import java.net.URL;

import javax.media.j3d.Appearance;
import javax.media.j3d.BranchGroup;
import javax.media.j3d.QuadArray;
import javax.media.j3d.Shape3D;
import javax.media.j3d.Texture;
import javax.vecmath.Point3d;
import javax.vecmath.Tuple3f;

import org.srs3d.viewer.j3d.AppearanceHelper;
import org.srs3d.viewer.j3d.BranchGroupHelper;
import org.srs3d.viewer.j3d.Context;
import org.srs3d.viewer.j3d.ShapeManager;
import org.srs3d.viewer.j3d.geometry.GeometryHelper;
import org.srs3d.viewer.j3d.geometry.primitive.Quad;

import com.sun.j3d.utils.image.TextureLoader;

/**
 * This class specializes the <code>Context</code> for the cell view application. Main
 * novelity to its base class is the <code>setup</code> method
 *
 * @author Karsten Klein
 *
 * @created November 20, 2000
 */
public class OverviewContext extends Context {

    /**
     * Constructs a context with the appropriate <code>GraphicsContext</code>
     *
     * @param graphicsConfiguration Description of Parameter
     */
    public OverviewContext(GraphicsConfiguration graphicsConfiguration) {
        super(graphicsConfiguration);
    }

    /**
     * Constructor for the OverviewContext object
     */
    public OverviewContext() {
        super();
    }

    /**
     * Constructs a context with the appropriate <code>GraphicsContext</code> and offset
     * screen flag.
     *
     * @param graphicsConfiguration Description of Parameter.
     * @param offScreen Description of Parameter.
     */
    public OverviewContext(GraphicsConfiguration graphicsConfiguration,
        boolean offScreen) {
        super(graphicsConfiguration, offScreen);
    }

    /**
     * Sets the context setting.
     */
    public void setup() {
        super.setup();
        setupLights(true);
    }

    /**
     * Description of the Method
     *
     * @param jpgFilename Description of Parameter
     */
    public void setup(URL jpgUrl, Tuple3f scale) {
        if (jpgUrl != null) {
            QuadArray quadArray =
                GeometryHelper.getDefaultQuadArray(1,
                    QuadArray.TEXTURE_COORDINATE_2);
            Quad quad = new Quad();
            quad.getCoordinates().scale(scale);
            TextureLoader loader = new TextureLoader(jpgUrl, "RGBA", null);
            Texture texture = loader.getTexture();
            quad.insertInto(0, quadArray);
            Appearance appearance = new Appearance();
            AppearanceHelper.setTextureDefaults(appearance, texture, 0.5f);
            BranchGroup branch = new BranchGroup();
            BranchGroupHelper.setDefaultCapabilities(branch);
            Shape3D shape = new Shape3D(quadArray, appearance);
            ShapeManager.setCapabilities(shape, null);
            branch.addChild(shape);
            getSceneLevel().addChild(branch);
        }
        setViewingPlatformPosition(new Point3d(0, 0, scale.x));
    }

    protected void initializeContextData() {

        // :FIXME: the annotation context data has more than we need for the overview
        //   we should really use the property map for additional data items.
        setContextData(new org.srs3d.viewer.annotation.contexts.AnnotationContextData(
                this));
    }
}
