/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d;

import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;

import javax.media.j3d.BranchGroup;
import javax.media.j3d.Locale;
import javax.media.j3d.Node;
import javax.media.j3d.PickCone;
import javax.media.j3d.PickShape;
import javax.media.j3d.Shape3D;
import javax.media.j3d.Transform3D;
import javax.vecmath.Point3d;
import javax.vecmath.Vector3d;

import org.srs3d.viewer.objects.AbstractObject;
import org.srs3d.viewer.util.ExceptionHandler;
import org.srs3d.viewer.util.Log;

import com.sun.j3d.utils.picking.PickCanvas;
import com.sun.j3d.utils.picking.PickIntersection;
import com.sun.j3d.utils.picking.PickResult;
import com.sun.j3d.utils.picking.PickTool;

/**
 * The intersection manager handles intersections calculations with the scene.
 *
 * @author Karsten Klein
 *
 * @created June 27, 2001
 */
public final class IntersectionManager {
    private static final Log log = new Log(IntersectionManager.class);
    private PickCanvas pickCanvas;
    private ContextData contextData;
    private float pickTolerance = 2;
    private int pickMode = PickTool.GEOMETRY;

    /**
     * <code>IntersectionManager</code> constructor.
     *
     * @param context <code>Context of the IntersectionManager</code>
     */
    public IntersectionManager(ContextData contextData) {
        this.contextData = contextData;
    }

    /**
     * Gets the <code>context</code> attribute of the <code>IntersectionManager </code>
     * object.
     *
     * @return The <code>context</code> value.
     */
    public final ContextData getContextData() {
        return contextData;
    }

    /**
     * Creates a PickCanvas for the specified Context and BranchGroup. The BranchGroup
     * limit the objects that are intersected
     *
     * @param context Context to create PickCanvas for.
     * @param branchGroup The BranchGroup limit the picking range.
     *
     * @return Created PickCanvas.
     */
    public final PickCanvas createPickCanvas(BranchGroup branchGroup) {
        PickCanvas pickCanvas =
            new PickCanvas(getContextData().getContext(), branchGroup);
        pickCanvas.setTolerance(pickTolerance);
        pickCanvas.setMode(pickMode);
        return pickCanvas;
    }

    /**
     * <code>IntersectionManager</code> constructor.
     *
     * @param context Description of parameter.
     * @param locale Description of parameter.
     *
     * @return Description of the returned value.
     */
    public final PickCanvas createPickCanvas(Locale locale) {
        PickCanvas pickCanvas =
            new PickCanvas(getContextData().getContext(), locale);
        pickCanvas.setTolerance(pickTolerance);
        pickCanvas.setMode(pickMode);
        return pickCanvas;
    }

    /**
     * Initializes the PickCanvas member
     */
    public void createPickCanvas() {
        if (pickCanvas == null) {
            pickCanvas =
                createPickCanvas(getContextData().getContext().getSceneLevel());

            // :NOTE: we encoured problems with the first pick. So, we do the first
            //   pick right after the creation of the PickCanvas to achieve proper
            //   initialization
            pickClosest(0, 0);
        }
    }

    /**
     * Clear all references of this IntersectionManager.
     */
    public void cleanup() {
        if (pickCanvas != null) {

            //      pickCanvas.setBranchGroup(null);
            pickCanvas = null;
        }
        contextData = null;
    }

    /**
     * Searchs for the closest object at the specified position
     *
     * @param x Image plate x ordinate.
     * @param y Image plate y ordinate.
     *
     * @return Closest picked object. Might be <code>null</code>.
     */
    public AbstractObject pickClosestObject(int x, int y) {
        PickResult pickResult = pickClosest(x, y);
        if (pickResult != null) {
            Node node = pickResult.getObject();
            if (node != null) {
                return (AbstractObject) node.getUserData();
            }
        }
        return null;
    }

    /**
     * Computes the closest intersection to the viewer.
     *
     * @param x X-oordinate intersected by the ray passing the screen.
     * @param y Y-oordinate intersected by the ray passing the screen.
     *
     * @return The <code>pickResult</code> of the closest element or <code>null </code>
     */
    public PickResult pickClosest(int x, int y) {
        createPickCanvas();
        Point3d eyePoint =
            new Point3d(getContextData().getContext()
                            .getViewingPlatformPosition());
        pickCanvas.setShapeLocation(x, y);
        PickResult[] pickResults = null;

        // :NOTE: unfortunately the pickClosest() method simply won't not give
        //   me the closest node. the following is a work around for the line
        // PickResult pickResult = pickCanvas.pickClosest();
        try {
            pickResults = pickCanvas.pickAll();
        } catch (Exception e) {

            // :NOTE: we catch all kinds of exception to prevent application stalls
            // on the linux side (LINUX SPECIFIC)
            ExceptionHandler.handleException(e,
                ExceptionHandler.SILENT_IN_RELEASE, this);
        }

        // sort the pick results by distance
        if ((pickResults != null) && (pickResults.length > 0)) {
            double frontClippingPlaneDistance =
                getContextData().getContext().getView().getFrontClipDistance();

            // :FIXME: this value is assumed to give correct results. we have to filter
            //  distances of geometry that was already clipped.
            frontClippingPlaneDistance += 7.0f;
            double distance = Float.MAX_VALUE;
            int index = 0;
            double d = 0;
            PickIntersection pickIntersection;
            Node node;
            for (int i = 0; i < pickResults.length; i++) {
                node = pickResults[i].getObject();

                // :NOTE: only shapes with not-null user data are picked; others are
                //   ignored by the picking
                if ((node != null) && (node.getUserData() != null)) {
                    pickIntersection =
                        pickResults[i].getClosestIntersection(eyePoint);
                    if (pickIntersection != null) {
                        d = pickIntersection.getDistance();
                        if (d > frontClippingPlaneDistance) {
                            if (d < distance) {
                                distance = d;
                                index = i;
                            }
                        }
                    }
                }
            }
            return pickResults[index];
        } else {

            // :FIXME: this could be LINUX SPECIFIC code.
            //      return pickCanvas.pickAny();
            return null;
        }
    }

    /**
     * Collect all shapes of the specified objects and uses pickClosestShape() to
     * determine the closest object
     *
     * @param objects Intersection candidates.
     * @param pickResult PickResult from prior pick operation.
     *
     * @return One of objects or <code>null</code>.
     */
    public AbstractObject pickClosestObject(Collection objects,
        PickResult pickResult) {
        Iterator iterator = objects.iterator();
        AbstractObject object;
        HashSet shapes = new HashSet();
        Collection objectShapes;
        ShapeManager shapeManager = getContextData().getShapeManager();
        while (iterator.hasNext()) {
            object = (AbstractObject) iterator.next();
            objectShapes = shapeManager.getShapes(object);
            if (objectShapes != null) {
                shapes.addAll(objectShapes);
            }
        }
        Shape3D shape = pickClosestShape(shapes, pickResult);
        if (shape != null) {
            return (AbstractObject) shape.getUserData();
        }
        return null;
    }

    /**
     * Determines the "closest" shape out of the provided set.
     *
     * @param shapes Set of shapes to intersect.
     * @param pickResult PickResult from prior pick operation.
     *
     * @return Closest shape (out of shapes) user data object.
     */
    public Shape3D pickClosestShape(Collection shapes, PickResult pickResult) {
        Iterator iterator = shapes.iterator();
        Shape3D shape;
        Point3d point =
            pickResult.getClosestIntersection(pickCanvas.getStartPosition())
                      .getClosestVertexCoordinates();

        // :NOTE: this determines by comparing the point to the shape bounds
        while (iterator.hasNext()) {
            shape = (Shape3D) iterator.next();
            if (shape.getBounds().intersect(point)) {
                return shape;
            }
        }
        return null;
    }

    /**
     * This method computes an intersectionwith the XY-plane.
     *
     * @return Intersection with XY-plane
     */
    public Vector3d computeXYPlaneIntersection(int x, int y) {
        createPickCanvas();
        Vector3d intersection = null;
        Point3d eyePoint = pickCanvas.getStartPosition();
        if (eyePoint != null) {
            Context context = getContextData().getContext();
            pickCanvas.setShapeRay(context.getViewingPlatformPosition(),
                new Vector3d(0, 0, 1));
            pickCanvas.setShapeLocation(x, y);
            Vector3d direction = new Vector3d();

            // :NOTE: this may throw an exception in a later implementation
            //   and may need a special fix: we just need to inquire the
            //   direction of the incorporated pick shape
            PickShape pickShape = pickCanvas.getPickShape();
            PickCone pickCone = (PickCone) pickShape;
            pickCone.getDirection(direction);
            if (direction.z != 0) {
                double parameter = -eyePoint.z / direction.z;
                direction.scale(parameter);
                intersection = new Vector3d(eyePoint);
                intersection.add(direction);

                // look through on xy plane
                intersection.z = 0;
            }

            // :NOTE: this is needed to synchronize the distorted geometry of the
            // in certain contexts (Annotation- and Sequuence-Context).
            // adapt to transformation; this should work for all cases!
            Vector3d scale = new Vector3d(1, 1, 1);
            Transform3D transform = new Transform3D();
            getContextData().getContext().getSceneTransform().getTransform(transform);
            transform.transform(scale);
            intersection.x /= scale.x;
            intersection.y /= scale.y;
        }
        return intersection;
    }

    /**
     * Method description.
     */
    public void invalidate() {
        pickCanvas = null;
    }

    /**
     * Description of the method.
     *
     * @param rayCount Parameter description.
     * @param delta Parameter description.
     */
    public void sample(int subdivisions, int samplesPerCube, double delta) {
        FileOutputStream out = null;
        try {
            out = new FileOutputStream("d:\\temp\\samples.cvs");
            out.write("# X\tY\tZ\n".getBytes());
            out.write("# INTERPRETATION:POINT\n".getBytes());
            Context context = getContextData().getContext();
            PickTool pickTool = new PickTool(context.getLocalLevel());
            subdivisions++;
            double deltaCube = delta / subdivisions;
            Point3d offset = new Point3d();
            double bias = delta / 2;
            log.info("starting sampling.");
            for (int i = 0; i < subdivisions; i++) {
                log.info("sampling row " + i + "/" + subdivisions + ".");
                offset.x = i * deltaCube - bias;
                for (int j = 0; j < subdivisions; j++) {
                    offset.y = j * deltaCube - bias;
                    for (int k = 0; k < subdivisions; k++) {
                        offset.z = k * deltaCube - bias;
                        sample(offset, samplesPerCube, deltaCube, pickTool, out);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (out != null) {
                try {
                    out.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private void sample(Point3d offset, int rayCount, double delta,
        PickTool pickTool, OutputStream out) throws Exception {
        Point3d origin = new Point3d();
        Vector3d orientation = new Vector3d();
        Point3d point;
        PickResult[] pickResults;
        PickIntersection pickIntersection;
        for (int i = 0; i < rayCount; i++) {

            // create random sample ray
            origin.x = (Math.random() - 0.5) * delta;
            origin.y = (Math.random() - 0.5) * delta;
            origin.z = (Math.random() - 0.5) * delta;
            origin.x += offset.x;
            origin.y += offset.y;
            origin.z += offset.z;
            orientation.x = (Math.random() - 0.5) * delta;
            orientation.y = (Math.random() - 0.5) * delta;
            orientation.z = (Math.random() - 0.5) * delta;
            orientation.normalize();
            pickTool.setShapeRay(origin, orientation);
            pickResults = pickTool.pickAll();
            if (pickResults != null) {
                for (int j = 0; j < pickResults.length; j++) {
                    for (int k = 0; k < pickResults[j].numIntersections();
                          k++) {
                        pickIntersection = pickResults[j].getIntersection(k);
                        point = pickIntersection.getPointCoordinatesVW();
                        out.write(("" + (float) point.x + "\t" +
                            (float) point.y + "\t" + (float) point.z + "\n").getBytes());
                    }
                }
            }
        }
    }
}
