/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.modules;

import org.srs3d.viewer.objects.Computation;

/**
 * @author Karsten Klein
 *
 * @created August 30, 2001
 */
public class ProcessModuleComputation implements Computation {

    // sub computation
    private Computation computation = null;
    private String description = "";
    private boolean isCanceled = false;
    private boolean isRefreshedDescription = false;
    private int taskNumber = 0;
    private int progress = 0;

    /**
     * Sets the <code>progress</code> attribute of the
     * <code>ProcessModuleComputation</code> object.
     *
     * @param progress The new <code>progress</code> value.
     */
    public void setProgress(int progress) {
        this.progress = progress;
    }

    /**
     * Sets the <code>computation</code> attribute of the
     * <code>ProcessModuleComputation</code> object.
     *
     * @param computation The new <code>computation</code> value.
     */
    public void setComputation(Computation computation) {
        this.computation = computation;
    }

    /**
     * Sets the <code>description</code> attribute of the
     * <code>ProcessModuleComputation</code> object.
     *
     * @param description The new <code>description</code> value.
     */
    public void setDescription(String description) {
        this.description = description;
        isRefreshedDescription = true;
    }

    /**
     * Sets the <code>finished</code> attribute of the
     * <code>ProcessModuleComputation</code> object.
     *
     * @param hasFinished The new <code>finished</code> value.
     */
    public void setFinished(boolean hasFinished) {
        if (hasFinished) {
            taskNumber--;
            if (taskNumber < 0) {
                taskNumber = 0;
            }
        } else {
            isCanceled = false;
            taskNumber++;
        }
    }

    /**
     * Gets the <code>progress</code> attribute of the <code>SurfaceComputation</code>
     * object.
     *
     * @return The <code>progress</code> value.
     */
    public int getProgress() {
        if (computation != null) {
            return computation.getProgress();
        }
        return progress;
    }

    /**
     * Gets the <code>description</code> attribute of the <code>SurfaceComputation</code>
     * object.
     *
     * @return The <code>description</code> value.
     */
    public String getDescription() {
        if (isRefreshedDescription) {
            isRefreshedDescription = false;
            return description;
        }
        if (computation != null) {
            return computation.getDescription();
        }
        return description;
    }

    /**
     * Gets the <code>canceled</code> attribute of the
     * <code>ProcessModuleComputation</code> object.
     *
     * @return The <code>canceled</code> value.
     */
    public boolean isCanceled() {
        return isCanceled;
    }

    /**
     * Description of the method.
     *
     * @return Description of the returned value.
     */
    public boolean hasFinished() {
        return taskNumber == 0;
    }

    /**
     * Description of the method.
     */
    public void cancel() {
        if (!hasFinished()) {
            if (computation != null) {
                computation.cancel();
                computation = null;
            }
            isCanceled = true;
        }
    }

    /**
     * Description of the method.
     *
     * @return Description of the returned value.
     */
    public boolean canCancel() {
        if (computation != null) {
            return computation.canCancel();
        }
        return false;
    }
}
