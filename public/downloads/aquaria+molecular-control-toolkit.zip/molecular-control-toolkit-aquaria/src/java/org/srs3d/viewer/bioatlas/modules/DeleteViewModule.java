/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.bioatlas.modules;

import java.awt.event.ActionEvent;

import org.srs3d.viewer.bioatlas.PopupContext;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.operations.ParameterStringOperation;
import org.srs3d.viewer.objects.Operation;

/**
 * Extension of the SaveModule providing a name of the object that should be saved in
 * addition.
 *
 * @author Karsten Klein
 *
 * @created August 19, 2003
 */
public class DeleteViewModule extends SaveModule {
    private PopupContext popupContext;

    /**
     * Constructor description.
     *
     * @param name Parameter description.
     * @param contextData Parameter description.
     * @param popupContext PopupContext used for updating the menus.
     */
    public DeleteViewModule(String name, ContextData contextData,
        PopupContext popupContext) {
        super(name, contextData);
        setOperationSerializeable(false);
        this.popupContext = popupContext;
    }

    /**
     * Description of the method.
     *
     * @param e Description of parameter.
     */
    public void process(ActionEvent e) {
        String name = (String) getContextData().getProperty("VIEW");
        if (name != null) {
            Operation operation =
                new ParameterStringOperation(getContextData().getContext(),
                    RestoreModule.DELETE_VIEW_OPERATION, name);
            operation.setSerializable(false);
            getContextData().getDispatcher().runDispatch(operation);
        }
        if (popupContext != null) {
            popupContext.initializePopupMenu();
        }
    }

    /**
     * Method description.
     */
    public void cleanup() {
        super.cleanup();
        popupContext = null;
    }
}
