/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

package org.srs3d.viewer.j3d.behaviors;

import java.awt.event.MouseEvent;

import javax.media.j3d.Transform3D;
import javax.vecmath.Matrix3f;
import javax.vecmath.Point3d;
import javax.vecmath.Tuple3f;
import javax.vecmath.Vector3f;

import org.srs3d.viewer.annotation.contexts.AnnotationContextData;
import org.srs3d.viewer.j3d.ContextData;
import org.srs3d.viewer.j3d.objects.Rectangle;
import org.srs3d.viewer.j3d.operations.ZoomBoxOperation;
import org.srs3d.viewer.objects.Operation;
import org.srs3d.viewer.sequence.contexts.SequenceContext;

/**
 * SequencePanXYBehaviour has to trigger the ZoomBoxMovement
 *
 * @author Christian Zofka
 *
 * @created August 01, 2001
 */
public class SequencePanXYBehavior extends PanXYBehavior {

    /**
     * <code>PanXYBehavior</code> constructor.
     *
     * @param context Description of parameter.
     */
    public SequencePanXYBehavior(ContextData contextData) {
        super(contextData);
    }

    /**
     * When processStilmulus is called by the framework the behavior will adjust scaling
     * and translation values of the viewplatform tranformation
     *
     * @param mouseEvent Description of parameter
     */
    public void processStimulus(MouseEvent mouseEvent) {
        lastX = x;
        lastY = y;
        x = mouseEvent.getX();
        y = mouseEvent.getY();
        if (checkCriteria(mouseEvent)) {
            SequenceContext context =
                (SequenceContext) getContextData().getContext();
            KeyHandler.setCursor(getContextData(), "PanXY", true);
            AnnotationContextData contextData =
                (AnnotationContextData) context.getContextData();
            Transform3D transform = context.getViewingPlatformTransform();
            Matrix3f matrix = new Matrix3f();
            transform.get(matrix);
            Vector3f directionX = new Vector3f();
            Vector3f directionY = new Vector3f();
            matrix.getColumn(0, directionX);
            matrix.getColumn(1, directionY);

            // get current translation of the ViewingPlatform
            Vector3f translation = new Vector3f();
            transform.get(translation);
            float panSpeed = (10.0f + translation.length()) / 1000;
            directionX.scale(-panSpeed * getSpeedX() * (x - lastX));
            translation.add(directionX);
            directionY.scale(panSpeed * getSpeedY() * (y - lastY));
            translation.add(directionY);

            // translation.x = org.srs3d.viewer.sequence.dispatcher.SequenceUpDispatcher.limitXRange( context, translation.x );
            Point3d checkedPoint = new Point3d(translation);
            processConstraints(checkedPoint);
            context.setViewingPlatformPosition(checkedPoint);
            triggerZoomBox();
        }
    }

    /**
     * modifies the zoomBox position and sends a MOVE_ZOOMBOX command to the
     * zoomBoxThread (instead of dispatch manager)
     */
    private void triggerZoomBox() {
        SequenceContext context =
            (SequenceContext) getContextData().getContext();
        AnnotationContextData contextData =
            (AnnotationContextData) context.getContextData();
        Rectangle zoomBox = contextData.getZoomBox();
        Tuple3f point = zoomBox.getCoordinate();
        point.x = (float) context.getViewingPlatformPosition().x;
        zoomBox.setCoordinate(point);
        Operation operation =
            new ZoomBoxOperation(context, "MOVE_ZOOMBOX", zoomBox);
        contextData.getZoomBoxThread().schedule(context, operation);

        //      DispatchManager.dispatch( context, operation );
    }
}
