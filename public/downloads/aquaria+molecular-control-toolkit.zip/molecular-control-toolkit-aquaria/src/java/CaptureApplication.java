/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.net.URL;

import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JFrame;

import org.srs3d.viewer.applet.AppletStub;
import org.srs3d.viewer.bioatlas.Application;
import org.srs3d.viewer.util.Chronometer;
import org.srs3d.viewer.util.ExceptionHandler;
/**
 * Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org) Copyright (C)
 * 2007-2008 This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later version.
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
 * PARTICULAR PURPOSE.  See the GNU General Public License for more details. You should
 * have received a copy of the GNU General Public License along with this program.  If
 * not, see http://www.gnu.org/licenses/.
 */

/**
 * Capture Application. Starts a org.srs3d.viewer.bioatlas.Capture instance as
 * application.
 *
 * @author Karsten Klein
 *
 * @created July 18, 2001
 */
public class CaptureApplication {
    public static final int MIN_WIDTH = 400;
    public static final int MIN_HEIGHT = 450;
    public static final int INITIAL_WIDTH = 500;
    public static final int INITIAL_HEIGHT = 550;

    /** Description of the field. */
    public static Application application = null;

    /**
     * The main program for the <code>CaptureApplication</code> class.
     *
     * @param args The command line arguments.
     */
    public static void main(final String[] args) {
        org.srs3d.viewer.swing.SwingSettings.setLookAndFeel(
            "com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
        org.srs3d.viewer.swing.SwingSettings.update();
        AppletStub appletStub = new AppletStub();
        appletStub.createParameterMap(args);

        // for simulating the browser embedded applet environment
        //    Thread.currentThread().getThreadGroup().setMaxPriority( 4 );
        //    Thread.currentThread().setPriority( 4 );
        final JFrame jFrame =
            new JFrame(org.srs3d.viewer.bioatlas.Parameter.applicationName);
        int width = INITIAL_WIDTH;
        int height = INITIAL_HEIGHT;
        if (appletStub.getParameter("width") != null) {
            width = Integer.parseInt(appletStub.getParameter("width"));
            width = Math.max(MIN_WIDTH, width);
        }
        if (appletStub.getParameter("height") != null) {
            height = Integer.parseInt(appletStub.getParameter("height"));
            height = Math.max(MIN_HEIGHT, height);
        }
        jFrame.setSize(width, height);
        Capture.initialOutput();
        if (true || Capture.checkIP(appletStub)) {
            String mode = appletStub.getParameter("mode");
            if (mode != null && mode.equalsIgnoreCase("multi")) {
                application = new org.srs3d.viewer.bioatlas.BioAtlasPlugin();
            } else {
                application = new org.srs3d.viewer.bioatlas.Capture();
            }

            //      application.setAppletStub( appletStub );
            application.getApplicationContext().set("AppletStub", appletStub);
            if (appletStub.getParameter("fullscreen") != null) {
                jFrame.setSize(Toolkit.getDefaultToolkit().getScreenSize());
            }

            // :FIXME: wrapped for the obfuscator, exception after file was not found
            try {
                URL iconUrl =
                    appletStub.getClass().getResource("/org/srs3d/viewer/bioatlas/resource/icon.gif");
                jFrame.setIconImage(new ImageIcon(iconUrl).getImage());
            } catch (Exception e) {
                ExceptionHandler.handleException(e,
                    ExceptionHandler.VISIBLE_IN_RELEASE,
                    CaptureApplication.class);
            }

            //      application.setParent( jFrame );
            application.getApplicationContext().set("ParentContainer", jFrame);
            jFrame.setContentPane((JComponent) application.getComponent());
            application.init();
            jFrame.setVisible(true);
            application.start();
        } else {
            Capture.initializeDummyApplet(jFrame, appletStub);
            jFrame.setVisible(true);
        }

        // adding some listeners
        jFrame.addWindowListener(new WindowAdapter() {
                public void windowClosing(WindowEvent e) {
                    Chronometer.displayAll();
                    if (application != null) {
                        application.stop();
                        application.destroy();
                        jFrame.remove(application.getComponent());
                    }
                    jFrame.dispose();
                    System.exit(0);
                }
            });
        jFrame.addComponentListener(new ComponentAdapter() {
                public void componentResized(ComponentEvent e) {
                    int width = Math.max(MIN_WIDTH, jFrame.getWidth());
                    int height = Math.max(MIN_HEIGHT, jFrame.getHeight());
                    jFrame.setSize(new Dimension(width, height));
                    if (application != null) {
                        application.update();
                    }
                }
            });
        if (application != null) {
            application.startVisualization();
            application.update();
        }
    }
}
