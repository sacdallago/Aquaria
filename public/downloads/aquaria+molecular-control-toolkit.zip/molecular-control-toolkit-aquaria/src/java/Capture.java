/** 
 *    Part of SRS 3D, a system for viewing macromolecules (http://srs3d.org)
 *    
 *    Copyright (C) 2007-2008
 *
 *    This program is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program.  If not, see http://www.gnu.org/licenses/.
 */

import java.applet.AppletContext;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;

import javax.swing.JApplet;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.RootPaneContainer;

import org.srs3d.viewer.applet.AppletStub;
import org.srs3d.viewer.bioatlas.Application;
import org.srs3d.viewer.bioatlas.Parameter;
import org.srs3d.viewer.j3d.GCThread;
import org.srs3d.viewer.util.ExceptionHandler;
import org.srs3d.viewer.util.Log;

/**
 * Applet implementation for BioAtlas applications. Checks for availability of the Java3D
 * API and guides the user to an appropriate installation procedure if no Java3D is
 * installed.
 *
 * @author Karsten Klein
 *
 * @created July 18, 2001
 */
public class Capture extends JApplet implements java.applet.AppletStub {
    private static final Log log = new Log(Capture.class);
    private Application application = null;
    private AppletStub appletStub = null;

    /**
     * <code>Capture</code> constructor.
     */
    public Capture() {
    }

    /**
     * Returns the instantiated application.
     *
     * @return The application.
     */
    public Application getApplication() {
        return application;
    }

    /**
     * Gets the <code>parentContainer</code> attribute of the <code>Capture</code>
     * object.
     *
     * @return The <code>parentContainer</code> value.
     */
    public Container getParentContainer() {
        Container parent = getParent();
        if (parent == null) {
            parent = this;
        }
        return parent;
    }

    /**
     * Description of the method
     */
    public void init() {
        initialOutput();
        super.init();

        // create applet stub
        appletStub = new AppletStub(this);

        // read parameter files if available
        appletStub.loadParameters();
        org.srs3d.viewer.swing.SwingSettings.setLookAndFeel(
            "com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
        org.srs3d.viewer.swing.SwingSettings.update();
        startComponent();
    }

    /**
     * Description of the method.
     *
     * @param message Description of parameter.
     */
    public void showStatus(String message) {
        AppletContext appletContext = getAppletContext();
        if (appletContext != null) {
            super.showStatus(message);
        }
    }

    /**
     * Description of the method
     */
    public void start() {
        super.start();
        if (application != null) {
            application.start();
            application.startVisualization();
        }
    }

    private void startComponent() {

        //    if (!hasExpired()) {
        //
        //      hasAgreedDisclaimer = checkIP(appletStub);
        //      
        //      // :TODO: remove the following line for appropriate license checking
        //      hasAgreedDisclaimer = true;
        //
        //        if (isShowingDisclaimer) {
        //                showDisclaimer();
        //              }
        //      else {
        //
        //        hasAgreedDisclaimer = true;
        //
        //      }
        //
        //      if (hasAgreedDisclaimer) {
        finalizeAppletInitialization();

        //      }
        //      else {
        //
        //        initializeDummyApplet(Capture.this, appletStub);
        //
        //      }
        //
        //    }
    }

    /**
     * Description of the method
     */
    public void stop() {
        if (application != null) {
            application.stop();
        }
        super.stop();
    }

    /**
     * Description of the method
     */
    public void destroy() {
        if (application != null) {
            application.destroy();
        }
        application = null;
        super.destroy();

        // show memory footprint
        GCThread.runFinalization();
        GCThread.gc();
    }

    /**
     * Description of the method.
     */
    public void finalizeAppletInitialization() {

        //    SwingUtilities.invokeLater(new Runnable() {
        //
        //      public void run() {
        org.srs3d.viewer.swing.SwingSettings.update();
        getContentPane().setLayout(new BorderLayout());
        try {
            String mode = getParameter("mode");
            if (mode != null && mode.equalsIgnoreCase("multi")) {
                application = new org.srs3d.viewer.bioatlas.BioAtlasPlugin();
            } else {
                application = new org.srs3d.viewer.bioatlas.Capture();
            }
            application.getApplicationContext().set("AppletStub", appletStub);
            application.getApplicationContext().set("ParentContainer",
                Capture.this);
            application.init();
            getContentPane().add(application.getComponent());
        } catch (NoClassDefFoundError e) {
            ExceptionHandler.handleException(e, Capture.class);
            initializeFailedApplet();
        } catch (UnsatisfiedLinkError e) {
            ExceptionHandler.handleException(e, Capture.class);
            initializeFailedApplet();
        } catch (ExceptionInInitializerError e) {
            ExceptionHandler.handleException(e, Capture.class);
            initializeFailedApplet();
        }

        //      }
        //
        //    } );
    }

    /**
     * Description of the method.
     *
     * @param w Description of parameter.
     * @param h Description of parameter.
     */
    public void appletResize(int w, int h) {
        log.debug("appletResize() not implemented!");
    }

    /**
     * Description of the method.
     *
     * @param e Description of parameter.
     */
    public void processEvent(java.awt.AWTEvent e) {
        if (e instanceof java.awt.event.ComponentEvent) {
            update();
        }
        super.processEvent(e);
    }

    /**
     * Description of the method.
     */
    public void update() {
        if (application != null) {
            ((org.srs3d.viewer.bioatlas.Capture) application).validate();
        }
    }

    /**
     * Description of the method.
     *
     * @param graphics Description of parameter.
     */
    public void update(Graphics graphics) {
        update();
        super.update(graphics);
    }

    /**
     * Method description.
     *
     * @param appletStub Parameter description.
     *
     * @return Return description.
     */
    public static boolean checkIP(AppletStub appletStub) {
        org.srs3d.viewer.accesscontrol.AccessControl accessControl = null;
        try {
            String licenseKeyFile = appletStub.getParameter("licenseKey");
            if (licenseKeyFile == null) {
                licenseKeyFile = "license.key";
            }
            URL url =
                Parameter.supplementUrl(appletStub.getCodeBase(), licenseKeyFile);
            log.info("Checking " + appletStub.getCodeBase().getHost());
            accessControl =
                org.srs3d.viewer.accesscontrol.AccessControl.load(url);
            if (!hasExpired()) {
                if (accessControl.check(appletStub)) {
                    log.info("Access check successful.");
                    return true;
                } else {
                    log.info("Access check failed.");
                }
            }
        } catch (Exception e) {
            log.error("Error during license check!");
            ExceptionHandler.handleException(e,
                ExceptionHandler.SILENT_IN_RELEASE, Capture.class);
        }
        return false;
    }

    /**
     * Description of the method.
     */
    private void initializeFailedApplet() {
        final JButton button =
            new JButton("Click here for the " +
                org.srs3d.viewer.bioatlas.Parameter.applicationName +
                " Client Installation Guide");
        final JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());
        panel.setPreferredSize(new Dimension(400, 300));
        panel.add(new JLabel("Java 3D is not installed on your client!",
                JLabel.CENTER), BorderLayout.CENTER);
        panel.add(button, BorderLayout.SOUTH);
        button.addActionListener(new ActionListener() {

                /**
                 * User clicked the installation guide button
                 *
                 * @param e Description of parameter.
                 */
                public void actionPerformed(ActionEvent e) {

                    //          String urlString = "install_Java3D";
                    // :FIXME: the url is located in the same location as the license key
                    String urlString = getParameter("licenseKey");
                    int index = urlString.lastIndexOf("/");
                    if (index != -1) {
                        if (index != urlString.length() - 1) {
                            index++;
                        }

                        // replace license name by SRS3D_client_install
                        urlString = urlString.substring(0, index);
                    } else {
                        urlString = "";
                    }
                    urlString += "SRS3D_client_install";
                    URL url =
                        org.srs3d.viewer.bioatlas.Parameter.supplementUrl(getCodeBase(),
                            urlString);
                    if (url != null) {
                        AppletContext appletContext = getAppletContext();
                        if (appletContext != null) {
                            appletContext.showDocument(url);
                        }
                    }
                    button.setEnabled(false);
                }
            });

        //    SwingUtilities.invokeLater(new Runnable() {
        //
        //      public void run() {
        org.srs3d.viewer.swing.SwingSettings.update();
        getContentPane().setLayout(new FlowLayout());
        getContentPane().add(panel);
        getContentPane().setBackground(panel.getBackground());

        //      }
        //
        //    } );
    }

    /**
     * Shows a uninitialized applet when user didn't agree to the disclaimer or the
     * license condition is not met.
     */
    public static void initializeDummyApplet(RootPaneContainer container,
        AppletStub appletStub) {
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(25, 1));
        panel.setBackground(Color.white);
        JLabel label;
        label =
            new JLabel("Your machine is not licensed to use the " +
                org.srs3d.viewer.bioatlas.Parameter.applicationName + ".",
                JLabel.CENTER);
        label.setForeground(Color.black);
        panel.add(label);
        label =
            new JLabel("To obtain a license contact your system administrator!",
                JLabel.CENTER);
        label.setForeground(Color.black);
        panel.add(label);
        try {
            label =
                new JLabel("Client Name: " +
                    java.net.InetAddress.getLocalHost().getHostName(),
                    JLabel.CENTER);
            label.setForeground(Color.black);
            panel.add(label);
            label =
                new JLabel("Client IP: " +
                    java.net.InetAddress.getLocalHost().getHostAddress(),
                    JLabel.CENTER);
            label.setForeground(Color.black);
            panel.add(label);
            label =
                new JLabel("Server Name: " +
                    java.net.InetAddress.getByName(appletStub.getCodeBase()
                                                             .getHost())
                                        .getHostName(), JLabel.CENTER);
            label.setForeground(Color.black);
            panel.add(label);
            label =
                new JLabel("Server IP: " +
                    java.net.InetAddress.getByName(appletStub.getCodeBase()
                                                             .getHost())
                                        .getHostAddress(), JLabel.CENTER);
            label.setForeground(Color.black);
            panel.add(label);
            if (org.srs3d.viewer.bioatlas.Parameter.expirationDate != null) {
                label =
                    new JLabel("Application Expiration Date: " +
                        org.srs3d.viewer.bioatlas.Parameter.expirationDate,
                        JLabel.CENTER);
                label.setForeground(Color.black);
                panel.add(label);
            }
        } catch (Exception e) {
            log.error("Caught during Name/IP listing!");
            ExceptionHandler.handleException(e,
                ExceptionHandler.SILENT_IN_DEBUG, Capture.class);
        }
        container.getContentPane().add(panel, "Center");
    }

    /**
     * Method description.
     */
    public static void initialOutput() {
        log.info(org.srs3d.viewer.bioatlas.Parameter.applicationName +
            " - Build " +
            org.srs3d.viewer.bioatlas.Parameter.applicationVersion);
        if (org.srs3d.viewer.bioatlas.Parameter.expirationDate != null) {
            java.util.Calendar calendar = java.util.Calendar.getInstance();
            calendar.clear();
            calendar.set(2002, 11, 1, 12, 0, 0);
            org.srs3d.viewer.bioatlas.Parameter.expirationDate =
                calendar.getTime();
            log.info("Expires " +
                org.srs3d.viewer.bioatlas.Parameter.expirationDate);
        }
    }

    /**
     * This method checks the jar files expiration status. The expiration limit is given
     * by a Parameter attribute. If the setting is null the jar file doesn't expire at
     * all.
     *
     * @return Return Returns <code>true</code> if the expiration date is exceeded.
     */
    public static boolean hasExpired() {
        if (org.srs3d.viewer.bioatlas.Parameter.expirationDate != null) {
            return System.currentTimeMillis() > org.srs3d.viewer.bioatlas.Parameter.expirationDate.getTime();
        }
        return false;
    }

    /**
     * Component method overwrite. This method is called when the applet gets printed.
     * The Java3D context are not rendered in the graphics object by default, so the
     * application has to provide additional printing facilities.
     *
     * @param g Parameter Graphics object to render to.
     */
    public void printAll(Graphics g) {
        super.printAll(g);
        if (application != null) {
            application.printContexts(this, g);
        }
    }
}
