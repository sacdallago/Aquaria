Molecular-Control-Toolkit demo using Aquaria.
---------------------------------------------
Creation Date: 9 May 2013
Update: 13 June 2013
Version 0.13


The Molecular Control Toolkit supports Windows for the Leap Motion & Kinect, and Mac for the Leap Motion. 


Prerequisites
-----------
To run, you will need to install the prerequisites for the gesture device you wish to support. 

Kinect: the Kinect SDK and Developer Toolkit 
(http://www.microsoft.com/en-us/kinectforwindows/develop/developer-downloads.aspx)

Leap Motion: the Leap Motion SDK 
(http://www.leapmotion.com)

When installing the Leap Motion SDK we recommend installing it into ~/Leap so it will look like ~/Leap/LeapSDK

Run
-----

Choose the script file to run and edit the file to set JAVA_HOME & LEAP_SDK variables if required
NOTE: If you are using the Leap and you installed the SDK to a different location than what was recommended above, you WILL need to set the variable to point to the LEAP_SDK.


Windows 32 bit
Kinect 			- run_kinect32.bat  
Leap Motion 	- run_leap32.bat
Mouse/Keyboard	- run_mouse.bat (works for 64 bit too)

Windows 64 bit
#Kinect 	- run_kinect64.bat  (coming soon)
Leap Motion 	- run_leap64.bat
Mouse/Keyboard	- run_mouse.bat (works for 32 bit too)

Mac OS *
Leap Motion 	- run_leap_mac.sh
Mouse/Keyboard	- run_mouse_mac.sh


* See running on Mac below

Versions
--------
The Molecular-control-toolkit is using JOGL 2.0rc11 & Java3D 1.6pre7 which is distributed with the bundle.



Running Aquaria on Mac
----------------------

Browser: use Firefox
Currently, you will need to run Aquaria in Firefox. When the Java3D component tries to open, it is initially blocked and you will see a warning like ��This plugin has security vulnerabilities. Click here to activate plugin�. You can choose to �Always activate plugins from this site� to prevent this warning from occurring again.

The Java does not work in Chrome, because Chrome does not currently support 64 bit Java on Mac. Safari used to work, but recent updates means that Java doesn't work unless it is the latest one from Oracle. The main Oracle Java version now says it is up to u17, but these have mainly been rushed security fixes, and they do not have the position bug fix yet. 
Install Java & Java3D
If you already have a Java installed, you will need to first delete the Applet plugin - on MacOS that is located at /Library/Internet Plug-Ins/JavaAppletPlugin.plugin

Next, install the OpenJDK version 7u40 from http://jdk7.java.net/download.html

Now delete the old Java3D jars that Mac java installs in your system. They exist in: /System/Library/Java/Extensions. You need to delete all the j3d* libJ3D* vecmath.jar files, or move them to a separate temp directory (renaming them isn't good enough).
sudo rm j3d* libJ3D* vecmath.jar

