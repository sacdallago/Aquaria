#!/bin/bash
#; 64 bit leap
export LEAP_SDK=~/Leap/LeapSDK
java -Xmx1024m -Djava.library.path="$LEAP_SDK/lib" -classpath "bin:$LEAP_SDK/lib/LeapJava.jar:aquaria_lib:aquaria_lib/jogl-all-natives-macosx-universal.jar:aquaria_lib/commons-logging.jar:aquaria_lib/gluegen-rt.jar:aquaria_lib/djava.jar:aquaria_lib/gluegen-rt-natives-macosx-universal.jar:aquaria_lib/j3dutils.jar:aquaria_lib/log4j.jar:aquaria_lib/cdk.jar:aquaria_lib/jai_core.jar:aquaria_lib/vecmath.jar:aquaria_lib/j3dcore.jar:aquaria_lib/jai_codec.jar:aquaria_lib/junit.jar:aquaria_lib/jogl-all.jar:aquaria_lib/molecularcontroltoolkit.jar" CaptureApplication structures="structures{2mpr,file:data/2mpr.pdb.gz,,;}" annotationView="off" sequenceView="off" expertMode="on" instanceId="2mpr_default_p" interactive="leap"
